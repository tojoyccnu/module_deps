#!/bin/bash
# Cursor afterFileEdit：仅对「与 premerge_check.sh 中 autopep8 相同范围」的 .py 执行格式化。
# stdin JSON: { "file_path": "<path>", ... }
#
# premerge 对应（仓库根 premerge_check.sh）：
#   "$UGBASE/script/python3" -m autopep8 ... --recursive lib plugin *.py
# 即：递归 lib/、plugin/；以及 ugbase 根目录下一层 *.py。不包含 tests/ 等。
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"

JSON_INPUT=$(cat)
FILE_PATH=$(echo "$JSON_INPUT" | jq -r '.file_path // empty')
[[ -z "$FILE_PATH" ]] && exit 0
[[ -f "$FILE_PATH" ]] || exit 0
[[ "${FILE_PATH##*.}" == "py" ]] || exit 0

UGBASE=""
if [[ -x "$WORKSPACE_ROOT/script/python3" ]] && { [[ -f "$WORKSPACE_ROOT/premerge_check.sh" ]] || [[ -f "$WORKSPACE_ROOT/_main.py" ]]; }; then
  UGBASE="$WORKSPACE_ROOT"
elif [[ -x "$WORKSPACE_ROOT/ugbase/script/python3" ]]; then
  UGBASE="$WORKSPACE_ROOT/ugbase"
fi
[[ -n "$UGBASE" ]] || exit 0

FILE_ABS=$(realpath "$FILE_PATH" 2>/dev/null) || exit 0
UGBASE_ABS=$(realpath "$UGBASE" 2>/dev/null) || exit 0

case "$FILE_ABS" in
  "$UGBASE_ABS"/*) ;;
  *) exit 0 ;;
esac

REL="${FILE_ABS#"$UGBASE_ABS"/}"
case "$REL" in
  lib/*|plugin/*) ;;
  *.py)
    [[ "$REL" != */* ]] || exit 0
    ;;
  *)
    exit 0
    ;;
esac

"$UGBASE_ABS/script/python3" -m autopep8 --in-place "$FILE_ABS" 2>/dev/null || true

exit 0
