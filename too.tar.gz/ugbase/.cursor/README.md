# ugbase `.cursor`（Python 栈）

本目录位于 **`ugbase/.cursor`**，为 **Python（ugbase）** 提供规则、示例库、子代理（agents）与 Hooks/MCP。**无需**再单独软链 `cursor/python`。

若你希望在工作区根目录复用同一套规则，可在 **ugreen 仓库根**执行（路径改为本机实际路径）：

```bash
ln -snf "${UGBASE_DOT_CURSOR:-/path/to/ugbase/.cursor}" .cursor
```

## 本目录包含哪些文件（互不重复）

| 路径 | 单一职责 |
|------|-----------|
| `rules/llm-coding-behavior.mdc` | **四条协作准则**（`alwaysApply: true`） |
| `rules/agents.mdc` | **子代理索引**（`python-*` 角色） |
| `rules/effective-generation.mdc` | **有效生成**（**仅 `*.py`**）：会话内验证闭环 |
| `skills/llm-coding-examples.md` | **正反例长文**（示例库） |
| `skills/upstream-sync-notes.md` | **与外部示例仓库对齐**的维护说明 |
| `agents/python-*.md` | **ugbase 专用**子代理说明（`python-planner`、`python-architect` 等） |
| `agents/ugbase-ut-agent.mdc` | 编写 `tests/` 时的专用指引（按需） |
| `hooks.json`、`hooks/format.sh` | 保存后 **autopep8**（需 Cursor Hooks + `jq`） |
| `mcp.json` | MCP 服务器声明（可按需改） |

准则正文以 **`rules/llm-coding-behavior.mdc`** 为准；`agents/python-*.md` 提供**按角色**的入口。

## Cursor 使用要点

- **规则**：见 `rules/*.mdc`。
- **子代理**：在 Agent 面板选择 `python-planner`、`python-code-reviewer` 等（定义见 `agents/python-*.md`）。
- **Hooks**：启用 Hooks；保存 `.py` 时触发 `hooks/format.sh`。
- **自定义命令**：可在 `.cursor/commands/` 下自行维护 slash 命令。
