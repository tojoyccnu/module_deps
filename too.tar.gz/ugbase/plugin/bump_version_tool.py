from ug_utils import GS
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "bump-version", "make build number +1", [
    ])

  def main(self):
    proj = UgProject.load(self.env, [])
    proj.inc_build_number()
    proj.save()
    return 0
