from collections import OrderedDict
from ug_common import info
import ug_cmd_base
import http.client
import ssl


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "http", "test http", [
        ('H', 'host', 'host', None),
        ('p', 'path', "path", "/"),
        ('P', 'port', "port", "80"),
        ('s', 'ssl', 'enable ssl', False),
        ('V', 'verbose', 'show verbose information', False),
    ])

  def main(self):
    port = int(self.get_opt('port'))
    host = self.get_opt('host')
    if self.get_opt('ssl'):
      context = ssl.create_default_context()
      context.check_hostname = False
      context.verify_mode = ssl.CERT_NONE
      conn = http.client.HTTPSConnection(host, port=port, context=context)
    else:
      conn = http.client.HTTPConnection(host, port=port)
    info("connecting ...")
    conn.connect()
    info("sleeping ...")
    # time.sleep(10)
    info("wake up")
    n = 1
    while True:
      cmd = "GET"
      path = self.get_opt('path')
      info("%d sock %s" % (n, conn.sock))
      n += 1
      info("send request %s %s ..." % (cmd, path))
      headers = OrderedDict()
      headers["connection"] = "keep-alive"
      headers["host"] = host + ":" + str(port)

      for k in headers.keys():
        v = headers[k]
        info(" - %20s : %s" % (k, v))
      conn.request(cmd, path, headers=headers)
      resp = conn.getresponse()
      ss = resp.read().decode()
      status_code = resp.status
      if self.get_opt('verbose'):
        info("resp %s: %s" % (status_code, ss))
        headers = resp.getheaders()
      else:
        info("resp: %s %s" % (status_code, len(ss)))
      for header in headers:
        info(" - %20s : %s" % (header[0], header[1]))
    return 0
