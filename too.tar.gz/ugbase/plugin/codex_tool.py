import os
import re
import sys
import ug_cmd_base
import textwrap
from ug_common import info, fatal, make_dir, read_file, write_file_if_changed, dump_json, set_verbose


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "codex", "install codex AI tool config", [
        ('V', 'verbose', 'show verbose information', False),
        ('r', 'refersh-apikey', 'run enter api key', False),
    ])

  def main(self):
    env = self.env
    set_verbose(self.get_opt('verbose'))
    codex_dir = os.path.expanduser("~/.codex")
    make_dir(codex_dir)
    os.chmod(codex_dir, 0o700)

    auth_file = os.path.join(codex_dir, "auth.json")
    config_file = os.path.join(codex_dir, "config.toml")
    refresh = self.get_opt('refersh-apikey')

    base_url = None
    if os.path.exists(config_file) and not refresh:
      old_content = read_file(config_file)
      m = re.search(r'^\s*base_url\s*=\s*"([^"]+)"', old_content, re.MULTILINE)
      if m:
        base_url = m.group(1)

    if not base_url:
      default_url = "https://fireware.ai.ugreencloud.com/v1"
      prompt = "请输入 API 地址[默认%s](注意：默认用的是固件组的AI服务，其他组的API key在固件组服务器不能生效):" % default_url
      base_url = input(prompt).strip()
      if not base_url:
        base_url = default_url

    if not os.path.exists(auth_file) or refresh:
      api_key = input("请输入 API Key：")
      if not api_key:
        fatal("API Key 不能为空")
      obj = {}
      obj["auth_mode"] = "apikey"
      obj["OPENAI_API_KEY"] = api_key
      write_file_if_changed(auth_file, dump_json(obj))
      os.chmod(auth_file, 0o600)

    content = read_file(os.path.join(env.root, "res", "codex_config.toml"))
    content = content.replace("{base_url}", base_url)
    write_file_if_changed(config_file, content)
    os.chmod(config_file, 0o600)
    return 0
