import fcntl
import os
import ug_cmd_base
from ug_common import cd, env_is_true, get_ugdata, info, make_dir, read_file, run, warning
from urllib.parse import urlparse

from ug_utils import get_clean_git_url


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "lock_git_run", "clone or attach to a locked exclusive cache folder then run a command", [
        ('u', "git", "git url", None),
        ('c', "change-to-git-dir", "change currrent dir to git dir", False),
        ('o', "output", "output to", "stdout"),
    ])

  def __clone(self, git, folder):
    cmd = "git clone %s %s" % (git, folder)
    run(cmd, show_start_log=True)

  def __try_to_clean(self, git, folder):
    cmds = []
    if env_is_true("UG_LOCK_GIT_NO_CLEAN"):
      info("skip git clean/update by UG_LOCK_GIT_NO_CLEAN")
      return True
    prefix = "cd %s && " % folder
    cmds.append(prefix + "git checkout .")
    cmds.append(prefix + "git clean -dfx")
    # 专用缓存可显式跳过远端更新，避免高并发场景反复访问 GitLab。
    if env_is_true("UG_LOCK_GIT_NO_UPDATE"):
      info("skip git pull by UG_LOCK_GIT_NO_UPDATE")
    else:
      cmds.append(prefix + "git fetch --tags --force --prune")
      cmds.append(prefix + "git pull -r")
    for cmd in cmds:
      if run(cmd, assert_ok=False) != 0:
        # 任一清理或更新命令失败，都让外层重建缓存仓库。
        warning("git cache update failed, command: " + cmd)
        return False
    return True

  def main(self):
    env = self.env
    tmp_root = os.path.join(get_ugdata(), "cache", "for_lock_git")
    # 默认使用当前 UGDATA；调用方可通过环境变量切换到专用缓存。
    tmp_root_env = os.environ.get("UG_LOCK_GIT_CACHE_ROOT", "")
    if tmp_root_env:
      tmp_root = os.path.expanduser(tmp_root_env)
    info("lock git cache root: " + tmp_root)
    url_text = self.get_opt('git')
    url_text = url_text.replace("git@", "")

    url = urlparse(url_text)
    url_path = url.path
    if url.path[0] == '/':
      url_path = url.path[1:]
    host = url.netloc
    git_folder = os.path.join(tmp_root, host, url_path)

    make_dir(git_folder)
    data_folder = os.path.join(git_folder, "data")
    lock_file = os.path.join(git_folder, "data.lock")
    if not os.path.exists(lock_file):
      run("touch " + lock_file)

    fp = open(lock_file, "rb")
    info("try to get lock %s ..." % lock_file)
    fcntl.flock(fp, fcntl.LOCK_EX)
    info("get lock %s OK" % lock_file)

    git = "ssh://git@%s/%s" % (host, url_path)
    git = get_clean_git_url(git)

    if not os.path.exists(data_folder):
      self.__clone(git, data_folder)
    else:
      info("found - " + data_folder)
      if not self.__try_to_clean(git, data_folder):
        # 缓存仓库可能损坏或无法 pull，删除后重新 clone 保证后续命令有完整提交。
        warning("git cache update failed, remove and clone again: " + data_folder)
        run("rm -rf " + data_folder)
        self.__clone(git, data_folder)

    os.environ["LOCK_GIT_DIR"] = data_folder
    info("export LOCK_GIT_DIR=%s" % data_folder)

    cmd = ""
    for target in self.get_targets():
      if cmd:
        cmd += " "
      cmd += target
    if self.get_opt('change-to-git-dir'):
      cd(data_folder)
    output_file = self.get_opt("output")
    if output_file != "stdout":
      cmd += " > " + output_file + " 2>&1"
    ret = run(cmd, show_start_log=True, assert_ok=False)
    if ret != 0:
      if output_file != "stdout":
        if os.path.exists(output_file):
          error_content = read_file(output_file)
          warning("exec [%s] ret %d > %s" % (cmd, ret, error_content))
        else:
          warning("exec [%s] ret %d, output file %s not found" % (cmd, ret, output_file))
      return ret
    return 0
