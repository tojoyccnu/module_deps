import shlex
import sys
import time

import ug_cmd_base

SSH_HOST = "192.168.75.171"
SSH_PORT = 22
SSH_USER = "repos"
SSH_PASSWORD = "@WSX3edc"
REMOTE_WORKDIR = "$HOME/ugreen"
REMOTE_UGBASE_DIR = "$HOME/ugreen/ugbase"
DOCKER_UTIL_SCRIPT = "./script/docker_util.sh"
DOCKER_ARCH = "amd64"
RELEASE_FIRMWARE_REPO = "git@gitlab.ugnas.com:ugos-pro/package/release-firmware.git"
RELEASE_FLOW_SCRIPT = "$HOME/ugreen/ugbase/pipelines/release_flow.py"
GIT_SSH_COMMAND = "ssh -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR"
START_SSHD_CMD = "/usr/local/ugreen/ugbase/ugbt start_sshd"
CONTAINER_NAME_FMT = "%s_%s"
CONTAINER_BUSY_MSG = "当前正在有任务运行中，执行容器为%s，请稍后再试！！！"
CONTAINER_FORCE_RM_MSG = "检测到容器%s已存在，force=true 已开启，强行删除后继续启动…"

DEFAULT_REPOS_ACTION = "1"
VALID_REPOS_ACTIONS = ("0", "1", "2", "3")

DEFAULT_FORCE = False
FORCE_TRUE_VALUES = ("1", "true", "yes", "y", "on")
FORCE_FALSE_VALUES = ("0", "false", "no", "n", "off", "")

BRANCH_FORBIDDEN_CHARS = set(" \t\r\n;|&$`\\\"'<>*?()[]{}")


def parse_query_vars(var_list):
  """将 -v key=value 列表解析为字典，后者覆盖前者。"""
  params = {}
  for item in var_list:
    item = item.strip()
    if not item:
      continue
    if "=" not in item:
      continue
    key, val = item.split("=", 1)
    params[key.strip()] = val.strip()
  return params


def validate_branch(branch):
  """校验分支名：非空且不含空白与常见 shell 元字符，避免远程命令注入。"""
  if not branch:
    return "missing required parameter 'branch'. Usage: ugbt db -v branch=release_YYYYMMDD_xxx"
  for ch in branch:
    if ch in BRANCH_FORBIDDEN_CHARS:
      return "invalid branch name: %r contains forbidden char %r" % (branch, ch)
  return None


def parse_repos_action(cli):
  """解析 git.sh repo 菜单选项，默认 1（clone：删除源目录并重新克隆）。

  与 repos_query_tools.py 的 parse_repos_action 同款：
    0 exit / 1 clone / 2 checkout / 3 pull
  """
  action = cli.get("repos_action", DEFAULT_REPOS_ACTION).strip()
  if action == "":
    action = DEFAULT_REPOS_ACTION
  if action not in VALID_REPOS_ACTIONS:
    return None, "Invalid repos_action '%s', must be one of %s" % (
        action,
        "/".join(VALID_REPOS_ACTIONS),
    )
  return action, None


def parse_force_flag(cli):
  """解析 force 开关，默认 False。

  接受不区分大小写的常见布尔字面量：
    truthy → 1 / true / yes / y / on
    falsy  → 0 / false / no / n / off / ""（缺省视同 false）
  非法字面量返回 (None, error_message)。
  """
  raw = cli.get("force", "").strip().lower()
  if raw in FORCE_FALSE_VALUES:
    return False, None
  if raw in FORCE_TRUE_VALUES:
    return True, None
  return None, "Invalid force '%s', must be one of %s/%s" % (
      raw,
      "/".join(v for v in FORCE_TRUE_VALUES),
      "/".join(v for v in FORCE_FALSE_VALUES if v != ""),
  )


def build_container_name(branch):
  """容器名规则与 docker_util.sh `--name `whoami`_${DOCKER_NAME}` 保持一致。

  这里 whoami=SSH_USER（远程登录用户），DOCKER_NAME=branch。
  """
  return CONTAINER_NAME_FMT % (SSH_USER, branch)


def build_check_container_cmd(container_name):
  """构造容器存在性探测命令：使用 podman ps -a + 精确名字过滤。

  --filter "name=^<name>$" 走正则锚定，避免误命中 <name>_suffix。
  """
  return (
      "podman ps -a --filter %s --format '{{.Names}}' 2>/dev/null"
      % shlex.quote("name=^%s$" % container_name)
  )


def build_stop_container_cmd(container_name):
  """构造容器停止命令；失败降级为 true，避免清理阶段把整体退出码污染掉。"""
  return "podman stop %s 2>&1 || true" % shlex.quote(container_name)


def build_force_rm_container_cmd(container_name):
  """构造容器强删命令；与 stop 不同，rm -f 即使容器正在跑也会先 kill 再 rm。

  用于 force=true 时绕过互斥检查直接清掉残留/正在跑的容器。失败仍 || true 兜底，
  让后续 docker_util.sh 自己再去暴露真正的错误（如残留 mount 或 image 缺失）。
  """
  return "podman rm -f %s 2>&1 || true" % shlex.quote(container_name)


def build_inner_repo_update_cmd(branch, repos_action=DEFAULT_REPOS_ACTION):
  """容器内执行的 git.sh repo update 命令（不含 cd），用 printf 把菜单选项喂入 stdin。"""
  repo_arg = "%s@%s" % (RELEASE_FIRMWARE_REPO, branch)
  action_q = shlex.quote(repos_action)
  repo_q = shlex.quote(repo_arg)
  return "printf '%%s\\n' %s | bash ./git.sh repo %s" % (action_q, repo_q)


def build_inner_release_flow_cmd(branch):
  """容器内执行的 release_flow.py 命令（绝对路径，不含 cd）。"""
  return "python3 %s --branch %s" % (RELEASE_FLOW_SCRIPT, shlex.quote(branch))


def build_dockerized_pipeline_cmd(branch, repos_action=DEFAULT_REPOS_ACTION):
  """SSH 后实际下发的命令：

    cd $HOME/ugreen/ugbase && git pull -r &&
    export DOCKER_ARCH_TYPE=amd64 DOCKER_NAME=<branch> &&
    ./script/docker_util.sh bash -lc '<inside docker>'

  - 不再通过 start_docker.sh 末尾的交互 bash + heredoc 喂命令；那种方式在
    podman -it 下容易停在容器 prompt，后续命令没有稳定执行。
  - 直接让容器前台进程执行 bash -lc <pipeline>，stdout/stderr 顺着 podman、
    SSH PTY 和本地 _stream_ssh_pty 实时回到当前 ugbt 终端。
  - 外层显式 export DOCKER_NAME=<branch>，docker_util.sh 仍生成
    `whoami`_<branch>（即 repos_<branch>），与 build_container_name 对齐。
  - 在容器内 export GIT_SSH_COMMAND（podman 不透传外层 env）。
  - 容器内合并 stderr、打开 bash trace、设置 Python 非缓冲输出，让命令与日志实时回显。
  - 任一条失败 || exit $?，保证退出码忠实传播到 paramiko。
  """
  inner_repo = build_inner_repo_update_cmd(branch, repos_action)
  inner_flow = build_inner_release_flow_cmd(branch)
  git_ssh_q = shlex.quote(GIT_SSH_COMMAND)
  branch_q = shlex.quote(branch)
  inner_script = (
      "exec 2>&1\n"
      "source ~/.bashrc\n"
      "unset PS1 PS2 PROMPT_COMMAND\n"
      "export PYTHONUNBUFFERED=1\n"
      "export GIT_SSH_COMMAND=%s\n"
      "export PS4='+ [container] '\n"
      "set -e\n"
      "set -o pipefail\n"
      "set -x\n"
      "sudo usermod -s /bin/bash $(whoami)\n"
      "%s\n"
      "cd %s || exit $?\n"
      "echo '===== [container] update release-firmware ====='\n"
      "%s || exit $?\n"
      "cd %s || exit $?\n"
      "echo '===== [container] run release_flow.py ====='\n"
      "%s || exit $?\n"
      "exit 0\n"
  ) % (
      git_ssh_q,
      START_SSHD_CMD,
      REMOTE_WORKDIR,
      inner_repo,
      REMOTE_WORKDIR,
      inner_flow,
  )
  return (
      "cd %s && git pull -r && export DOCKER_ARCH_TYPE=%s DOCKER_NAME=%s && "
      "%s bash -lc %s"
      % (
          REMOTE_UGBASE_DIR,
          shlex.quote(DOCKER_ARCH),
          branch_q,
          DOCKER_UTIL_SCRIPT,
          shlex.quote(inner_script),
      )
  )


def _connect_ssh():
  """以硬编码凭据连接固定主机；失败返回 (None, err_message)。"""
  try:
    import paramiko
  except ImportError:
    return None, "paramiko is not installed, run: pip install paramiko"
  client = paramiko.SSHClient()
  client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  try:
    client.connect(
        SSH_HOST,
        port=SSH_PORT,
        username=SSH_USER,
        password=SSH_PASSWORD,
        timeout=30,
        allow_agent=False,
        look_for_keys=False,
    )
  except Exception as e:
    return None, "Cannot connect to %s - %s" % (SSH_HOST, str(e))
  return client, None


def _write_console(stream, data):
  if not data:
    return
  buffer = getattr(stream, "buffer", None)
  if buffer is not None:
    buffer.write(data)
    buffer.flush()
    return
  if isinstance(data, bytes):
    data = data.decode("utf-8", errors="replace")
  stream.write(data)
  stream.flush()


def _drain_ssh_channel(channel):
  drained = False
  while channel.recv_ready():
    data = channel.recv(4096)
    if data:
      _write_console(sys.stdout, data)
      drained = True
  if hasattr(channel, "recv_stderr_ready"):
    while channel.recv_stderr_ready():
      data = channel.recv_stderr(4096)
      if data:
        _write_console(sys.stderr, data)
        drained = True
  return drained


def _stream_ssh_pty(channel):
  """将远程 stdout/stderr 实时写到当前终端，并返回 channel 的 exit_status。"""
  while True:
    drained = _drain_ssh_channel(channel)
    if channel.exit_status_ready():
      while _drain_ssh_channel(channel):
        pass
      break
    if not drained:
      time.sleep(0.05)
  return channel.recv_exit_status()


def _run_remote_step(client, label, cmd):
  """实时回显远程命令的 PTY 输出，返回退出码。"""
  print("\n===== [%s] =====" % label, flush=True)
  _, stdout, _ = client.exec_command(cmd, get_pty=True, timeout=86400)
  channel = stdout.channel
  exit_status = _stream_ssh_pty(channel)
  if exit_status != 0:
    print(
        "\n===== [%s] FAILED with exit code %d =====" % (label, exit_status),
        flush=True,
    )
  return exit_status


def _container_exists(client, container_name):
  """探测远程是否已有同名容器；任何异常一律保守视为不存在。"""
  cmd = build_check_container_cmd(container_name)
  try:
    _, stdout, _ = client.exec_command(cmd, timeout=60)
  except Exception:
    return False
  exit_status = stdout.channel.recv_exit_status()
  if exit_status != 0:
    return False
  out = stdout.read()
  if isinstance(out, bytes):
    out = out.decode("utf-8", errors="replace")
  for line in out.splitlines():
    if line.strip() == container_name:
      return True
  return False


def _stop_container(client, container_name):
  """尽力停止容器并实时回显输出；失败不抛异常（已 || true）。"""
  cmd = build_stop_container_cmd(container_name)
  try:
    _, stdout, _ = client.exec_command(cmd, get_pty=True, timeout=120)
  except Exception as e:
    print("WARNING: failed to issue stop for %s - %s" % (container_name, str(e)))
    return
  _stream_ssh_pty(stdout.channel)


def _force_rm_container(client, container_name):
  """强删容器并实时回显输出；失败不抛异常（已 || true 兜底）。"""
  cmd = build_force_rm_container_cmd(container_name)
  try:
    _, stdout, _ = client.exec_command(cmd, get_pty=True, timeout=120)
  except Exception as e:
    print(
        "WARNING: failed to issue force rm for %s - %s" % (container_name, str(e))
    )
    return
  _stream_ssh_pty(stdout.channel)


def run_db_pipeline(branch, repos_action=DEFAULT_REPOS_ACTION, force=DEFAULT_FORCE):
  """执行 ugbt db 主流程：

  1) SSH 登录 192.168.75.171
  2) 探测容器 repos_<branch> 是否已存在：
     - 存在 && force=False（默认）→ 报「正在有任务运行中」并 return 1（不动容器）
     - 存在 && force=True → 打印提示后 podman rm -f 残留容器再继续
     - 不存在 → 直接进入下一阶段
  3) 下发 dockerized pipeline：cd ugbase + docker_util.sh bash -lc <pipeline>
     依次跑 git.sh repo + release_flow.py
  4) 无论 pipeline 成败，最后调 podman stop repos_<branch> 显式清理
  """
  client, err = _connect_ssh()
  if err:
    print("ERROR: %s" % err)
    return 1

  container = build_container_name(branch)
  try:
    if _container_exists(client, container):
      if not force:
        print(CONTAINER_BUSY_MSG % container)
        return 1
      print(CONTAINER_FORCE_RM_MSG % container, flush=True)
      _force_rm_container(client, container)

    cmd = build_dockerized_pipeline_cmd(branch, repos_action)
    label = (
        "dockerized pipeline (container=%s, branch=%s, menu choice=%s, force=%s)"
        % (container, branch, repos_action, "true" if force else "false")
    )
    try:
      return _run_remote_step(client, label, cmd)
    finally:
      print(
          "\n===== [cleanup] stopping container %s =====" % container,
          flush=True,
      )
      _stop_container(client, container)
  finally:
    client.close()


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "db",
                                     "在 %s 上通过 docker_util.sh 进入容器后"
                                     "更新 release-firmware 并运行 release_flow.py" % SSH_HOST,
                                     [
                                         ("v", "query-var",
                                          "opts: branch=<release_branch> "
                                          "[repos_action=0/1/2/3, default 1=clone] "
                                          "[force=true/false, default false]", ""),
                                     ])

  def main(self):
    cli = parse_query_vars(self.get_opts("query-var"))
    branch = cli.get("branch", "").strip()
    err = validate_branch(branch)
    if err:
      print("ERROR: %s" % err)
      return 1
    repos_action, action_err = parse_repos_action(cli)
    if action_err:
      print("ERROR: %s" % action_err)
      return 1
    force, force_err = parse_force_flag(cli)
    if force_err:
      print("ERROR: %s" % force_err)
      return 1
    return run_db_pipeline(branch, repos_action, force)
