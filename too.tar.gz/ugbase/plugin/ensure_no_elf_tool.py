import os
import ug_cmd_base
from ug_common import fatal, runex, info


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "ensure_no_elf", "ensure no elf files in foler", [
        ('V', "verbose", "show verbose information", False),
    ])

  def look_up_elf_files(self, folder):
    if not os.path.exists(folder):
      fatal(folder + " not found")
    lst = []
    for root, folders, files in os.walk(folder):
      for file in files:
        file_path = os.path.join(root, file)
        if runex("file -b \"%s\"" % file_path).startswith("ELF "):
          lst.append(file_path)
    return lst

  def main(self):
    folders = self.get_targets()
    if len(folders) == 0:
      fatal("input empty")
    folder_set = set()
    elf_files = []
    for folder in folders:
      if not folder in folder_set:
        lst = self.look_up_elf_files(folder)
        elf_files.append((folder, lst))
        folder_set.add(folder)
    count = 0
    for folder, lst in elf_files:
      print(folder + ":")
      for f in lst:
        print(" - " + f)
      count += len(lst)
    if count > 0:
      fatal("%d elf files found" % count)
    else:
      info("ensure no elf files in " + str(folders))
