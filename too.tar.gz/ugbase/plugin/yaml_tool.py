

import ug_cmd_base
from ug_common import dump_yaml, info, load_yaml, read_file, run, uuid_gen, write_file


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "yaml", "format yaml tool", [
        ('p', "parse", "parse only", False),
    ])

  def main(self):
    input_files = self.get_targets()
    if len(input_files) == 0:
      info("no yaml file to format")
      return 1

    parse_only = self.get_opt("parse")
    count_write = 0
    for input_file in input_files:
      content = read_file(input_file)
      obj = load_yaml(content)
      if parse_only:
        continue

      content_new = dump_yaml(obj)
      if content == content_new:
        info("update to date - " + input_file)
      else:
        write_file(input_file, content_new)
        count_write += 1

    if count_write == 0:
      return 0
    else:
      return 1
