from ug_common import info, tool_set_verbose, tool_set_job_count
from ug_build_platform import BuildPlatform
from ug_utils import GS
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "pack", "build a project and pack output", [
        ('v', 'build-var', 'build vars', ""),
        ('V', 'verbose', 'show verbose information', False),
        ('p', 'platform', 'use platform string instead of --build-var -v', ""),
        ('d', 'dry-run', 'run dry-run mode', False),
        ('a', 'all', 'try to pack all avilable platforms, if this option is set, the --build-var input is skipped', False),
        ('j', 'job', 'task count of running jobs, default `nproc`, if > 16 then 16', ""),
    ])

  def main(self):
    tool_set_verbose(self)
    tool_set_job_count(self)
    env = self.env
    dry_run = self.get_opt('dry-run')

    if self.get_opt('all'):
      dumpy_proj = UgProject.load(self.env, [])
      platforms = dumpy_proj.get_all_platforms()
      for platform in platforms:
        info("start pack " + platform.get_sorted_str() + " ...")
        proj = UgProject.load(env, {}, platform=platform)
        proj.gen_makefiles()
        proj.make(GS.PACK, dry_run=dry_run)
        info("pack " + platform.get_sorted_str() + " OK")
    else:
      pstr = self.get_opt('platform')
      if pstr:
        platform = BuildPlatform.parse(env, pstr)
        proj = UgProject.load(env, {}, platform=platform)
      else:
        vars = self.get_opts('build-var')
        proj = UgProject.load(env, vars)

      proj.gen_makefiles()
      proj.make(GS.PACK, dry_run=dry_run)
    return 0
