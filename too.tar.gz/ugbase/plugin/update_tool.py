from ug_common import set_verbose, run
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "update", "update the 'deps' of ugreen_project.yaml to the latest versions", [
        ('l', 'local', 'find in local repo or not (in remote repo)', False),
        ('i', 'increase-build-number', 'set build number + 1', False),
        ('s', 'skip-lock', 'update all modules including those marked as locked', False),
        ('V', 'verbose', 'show verbose information', False),
    ])

  def main(self):
    env = self.env
    run("cd /usr/local/ugreen/ugbase && git pull -r", show_start_log=True, assert_ok=False)
    set_verbose(self.get_opt("verbose"))
    proj = UgProject.load(env, [])
    proj.update(self.get_opt('local'), self.get_opt('increase-build-number'), self.get_opt('skip-lock'))

    return 0
