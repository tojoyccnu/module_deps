import ast
import glob
import os
import shlex
from ug_common import fatal, tool_set_verbose, run, runex, info, tool_set_job_count, env_is_true, load_yaml_f
from ug_build_platform import BuildPlatform
from ug_utils import GS
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "test", "test project(use ctest)", [
        ('v', 'build-var', 'build vars', ""),
        ('V', 'verbose', 'show verbose information', False),
        ('p', 'platform', 'use platform string instead of --build-var -v', ""),
        ('d', 'dry-run', 'run dry-run mode', False),
        ('c', 'with-coverage', 'run test with coverage', False),
        ('j', 'job', 'task count of running jobs, default `nproc`, if > 16 then 16', ""),
    ])

  def __get_coredump_files(self):
    """获取/coredump/目录下所有core文件的路径集合"""
    coredump_dir = "/coredump/"
    if not os.path.exists(coredump_dir):
      return set()

    files = set()
    for file_path in glob.glob(os.path.join(coredump_dir, "core-*")):
      if os.path.isfile(file_path):
        files.add(file_path)
    return files

  def __check_coredump(self, pre_files, test_name="test"):
    """检查测试后是否有新的coredump文件"""
    post_files = self.__get_coredump_files()
    new_files = post_files - pre_files

    if new_files:
      msg = f"{test_name} FAILED: Found {len(new_files)} core dump file(s)!\n"
      for f in sorted(new_files):
        msg += f"  - {f}\n"
      msg += "NOTE: Core dumps indicate crashes even if tests show 'passed'."
      fatal(msg)

    info(f"{test_name} completed, no new core files")

  def __get_coverage_skip_patterns(self, prj_dir):
    value = os.environ.get("UG_COVERAGE_SKIP", "").strip()
    if not value:
      return []

    if value.startswith("["):
      try:
        patterns = ast.literal_eval(value)
      except (SyntaxError, ValueError):
        fatal("UG_COVERAGE_SKIP must be a string or list")
    else:
      try:
        patterns = shlex.split(value.replace(",", " "))
      except ValueError as e:
        fatal("parse UG_COVERAGE_SKIP fail: %s" % e)

    if isinstance(patterns, str):
      patterns = [patterns]
    if not isinstance(patterns, list):
      fatal("UG_COVERAGE_SKIP must be a string or list")

    ret = []
    for pattern in patterns:
      if not isinstance(pattern, str):
        fatal("UG_COVERAGE_SKIP item must be string")
      if os.path.isabs(pattern):
        ret.append(pattern)
      else:
        ret.append(os.path.join(prj_dir, pattern))
    return ret

  def __run_test_with_coverage(self):
    env = self.env
    vars = self.get_opts('build-var')
    for var in vars:
      if "build_type" in var:
        fatal("build_type is not valid in coverage mode")
    if self.get_opt('dry-run'):
      fatal('dry-run is not valid in coverate mode')
    os.environ["UG_COVERAGE_TEST"] = "1"
    vars.append("build_type=release")

    proj = UgProject.load(self.env, vars)
    proj.gen_makefiles()
    opts = ""
    if self.get_opt("verbose"):
      opts += "--output-on-failure"

    os.environ["UG_TEST_OPTS"] = opts
    # run("touch %s/CMakeLists.txt" % proj.get_root())

    pre_core_files = self.__get_coredump_files()
    proj.make(GS.BUILD)

    cmds = [
        "lcov --zerocounters --directory .",
        "lcov --capture --initial --directory . --output-file coverage-base.info",
    ]
    prefix = "cd " + env.build_dir + " && "
    for cmd in cmds:
      run(prefix + cmd)

    proj.make(GS.TEST)
    self.__check_coredump(pre_core_files, "Coverage test")

    prj_dir = proj.get_root()
    prj_dir = os.path.abspath(prj_dir)

    remove_patterns = ["%s/test/*" % prj_dir]
    remove_patterns.extend(self.__get_coverage_skip_patterns(prj_dir))
    remove_args = " ".join(shlex.quote(pattern) for pattern in remove_patterns)
    cmds = [
        "lcov --capture --directory . --output-file coverage-run.info",
        "lcov --add-tracefile coverage-base.info --add-tracefile coverage-run.info --output-file coverage-1.info",
        "lcov --extract coverage-1.info '%s/*' -o coverage-2.info" % prj_dir,
        "lcov --remove coverage-2.info '%s/ugreen_build/*' -o coverage-3.info" % prj_dir,
        "lcov --remove coverage-3.info %s -o coverage.info" % remove_args,
        "lcov --list coverage.info > coverage.info.list",
        "genhtml coverage.info --output-directory html-report-coverage",
        "cat coverage.info.list"
    ]

    for cmd in cmds:
      run(prefix + cmd)
    ss = runex(prefix + " cat coverage.info.list | grep Total | awk -F \\| '{print $2}'")
    percent = float(ss.split('%')[0])
    info("get detail info in %s/html-report-coverage/index.html" % env.build_dir)
    if percent < 80.0:
      fatal("coverage rate must >= 80%%, current rate %.2f%%" % percent)
    info("coverage test OK, rate %.2f%%" % percent)

  def main(self):
    tool_set_verbose(self)
    tool_set_job_count(self)
    env = self.env

    pre_core_files = self.__get_coredump_files()
    targets = self.get_targets()

    pstr = self.get_opt('platform')
    if pstr:
      platform = BuildPlatform.parse(env, pstr)
      proj = UgProject.load(env, {}, platform=platform)
    else:
      vars = self.get_opts('build-var')
      proj = UgProject.load(env, vars)

    # 加载项目yaml文件中的env变量
    project_yaml = load_yaml_f(os.path.join(proj.get_root(), "ugreen_project.yaml"))
    if "env" in project_yaml:
      for key, value in project_yaml["env"].items():
        os.environ[key] = str(value)

    if self.get_opt("with-coverage"):
      # 如果UG_SKIP_COVERAGE_TEST为true，则跳过覆盖率测试
      if env_is_true("UG_SKIP_COVERAGE_TEST"):
        info("skip coverage test because UG_SKIP_COVERAGE_TEST is true")
        return 0
      else:
        return self.__run_test_with_coverage()

    proj.gen_makefiles()
    opts = ""
    if self.get_opt("verbose"):
      opts += "--output-on-failure"
    if len(targets) > 0:
      for target in targets:
        if opts:
          opts += " "
        opts += "-R \"" + target + "\""
    os.environ["UG_TEST_OPTS_EXTRA"] = opts

    proj.make(GS.TEST, dry_run=self.get_opt('dry-run'))
    self.__check_coredump(pre_core_files, "ugbt test")
    return 0
