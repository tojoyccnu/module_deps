import os
import ug_cmd_base
from ug_common import info, dump_yaml, fatal, load_yaml_f, read_file, set_verbose, write_file
from ug_utils import ManifestLoader, diff_go_mods


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "diff-go-mod", "diff two go.mod", [
        ('v', 'verbose', "show verbose log", False),
        ('o', 'output', "output file", "diff.yaml"),
    ])

  def main(self):
    env = self.env
    if self.get_opt('verbose'):
      set_verbose(True)
      info("verbose is enabled")

    if len(self.get_targets()) != 2:
      fatal("run ugbt 'diff-go-mod file1 file2'")

    file_new = os.path.expandvars(self.get_targets()[0])
    file_old = os.path.expandvars(self.get_targets()[1])
    diff = diff_go_mods(env, file_new, file_old)
    write_file(self.get_opt('output'), dump_yaml(diff))
    return 0
