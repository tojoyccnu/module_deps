import os
from ug_common import Git, fatal, info, run
import ug_cmd_base


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "clang-format", "use clang-format to check source code files in a dirctory", [
    ])

  def main(self):
    env = self.env
    targets = self.get_targets()

    if len(targets) == 0:
      fatal("input command: 'ugbt clang-format <dir1> [<dir2> ...]'")

    dirs = []
    for target in targets:
      path = os.path.expandvars(target)
      dirs.append(path)
      if not os.path.exists(path):
        fatal(path + " not found")
      if not os.path.isdir(path):
        fatal(path + " is not a folder")

    exts = [
        "h", "hh", "hpp", "c", "cc", "CC", "c++", "cpp", "CPP", "CXX", "cxx"
    ]
    exts_str = ""
    for ext in exts:
      if exts_str:
        exts_str += " -or "
      exts_str += "-name \"*.%s\"" % ext
    exts_str = "\( " + exts_str + " \)"
    for path in dirs:
      info("clang-format %s ..." % path)
      find_cmd = 'find . -type f -and ' + exts_str + ' ! -path "./.git*" ! -path "./ugreen_build/*"'
      cmd = "cd %s && %s | xargs dos2unix >> ugreen_build/dox2unix.log 2>&1" % (path, find_cmd)
      run(cmd, show_start_log=True)
      cmd = "cd %s && %s | xargs clang-format -i" % (path, find_cmd)
      run(cmd, show_start_log=True)
      if os.path.exists(os.path.join(path, "Doxyfile")):
        cmd = "cd %s && doxygen Doxyfile > ugreen_build/doxygen_build.log" % (path)  # 生成文档检查
        run(cmd, show_start_log=True)
      git = Git(False, path)
      if git.is_dirty():
        run("cd %s && git status" % path)
        run("cd %s && git diff" % path)
        fatal("git dir %s is dirty" % path)
    return 0
