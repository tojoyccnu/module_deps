"""ugbt beta_run_once 命令入口。

beta_run_once 是内部 worker：一次只处理一个 SMB platform_dir。它根据 --type
分发到固件或套件处理逻辑，完成下载、转换/签名、校验、上传，并写出 MD5 报告。
"""

import os
import posixpath
import shlex
import shutil
import tempfile

import ug_cmd_base
from ug_build_platform import BuildPlatform
from ug_common import (
    SambaConnection,
    add_tail_lf,
    dump_json,
    dump_yaml,
    fatal,
    info,
    load_json_f,
    load_yaml,
    make_dir,
    md5,
    parse_smb_url,
    read_file,
    run,
    runex,
    write_file,
)
from ug_utils import beta_default_tools_dir, beta_release_branch_index


class _BetaOnceContext(object):
  """保存 beta_run_once 单个 platform_dir worker 需要的命令参数。"""

  def __init__(self, tool):
    self.env = tool.env
    self.smb_url = tool.get_opt("smb-url")
    self.package_type = (tool.get_opt("type") or "").strip().lower()
    self.mode = (tool.get_opt("mode") or "").strip().lower()
    self.platform_dir = tool.get_opt("platform-dir")
    self.tasks_root = os.path.abspath("tasks")
    self.report_root = os.path.abspath("reports")
    self.remote_tmp_root = tool.get_opt("remote-tmp-root")
    self.tools_dir = beta_default_tools_dir(tool.env.home)


class _TaskDirWorkerBase(object):
  """单 platform_dir worker 基类，负责公共目录、上传、报告和执行编排。"""

  SIGN_RETRY_INTERVAL = 10
  SIGN_MAX_ATTEMPTS = 5

  def __init__(self, ctx):
    self.ctx = ctx
    self.smb_url = ctx.smb_url
    self.platform_dir = ctx.platform_dir
    self.mode = ctx.mode
    if self.mode not in ("ga", "beta"):
      fatal("mode must be ga or beta: %s" % ctx.mode)
    self.tasks_root = ctx.tasks_root
    self.report_root = ctx.report_root
    self.staging_remote_root = ctx.remote_tmp_root
    self.tools_dir = ctx.tools_dir
    self.sign_retry_interval = self.SIGN_RETRY_INTERVAL
    self.sign_max_attempts = self.SIGN_MAX_ATTEMPTS
    self.location = parse_smb_url((ctx.smb_url or "").strip())
    self.task_root = os.path.join(ctx.tasks_root, ctx.platform_dir)
    self.work_dir = os.path.join(self.task_root, "work")
    self.tmp_dir = os.path.join(self.task_root, "tmp")

  def _pack_stem(self):  # 根据 SMB 发布路径和 platform_dir 生成发布包 stem
    parts = [part for part in self.location.remote_path.split("/") if part]
    repo_index = parts.index("repo")
    release_index = beta_release_branch_index(parts)
    if release_index < 0:
      fatal("smb path must contain release_ branch before version and build: %s" %
            self.location.remote_path)
    version_parts = parts[release_index + 1:]
    if len(version_parts) != 2:
      fatal("release_ branch must be followed by version and build: %s" %
            self.location.remote_path)
    project_name = "_".join(parts[repo_index + 1:release_index])
    platform = BuildPlatform.parse(self.ctx.env, self.platform_dir)
    return "%s-%s-%s.%s-%s" % (
        parts[release_index],
        project_name,
        version_parts[0],
        version_parts[1],
        platform.get_sorted_short_str(),
    )

  def _parse_nonnegative_int(self, value, label):  # 解析签名重试配置里的非负整数
    text = str(value).strip()
    if not text.isdigit():
      fatal("%s must be integer: %s" % (label, value))
    result = int(text)
    if result < 0:
      fatal("%s must be >= 0" % label)
    return result

  def _run_sign_command(self, cmd):  # 执行签名命令，日志和重试交给 ug_common.run
    retry_interval = self._parse_nonnegative_int(self.sign_retry_interval, "sign retry interval")
    retry_times = self._parse_nonnegative_int(self.sign_max_attempts, "sign max attempts")
    if retry_times < 1:
      retry_times = 1
    command = cmd if isinstance(cmd, str) else shlex.join(cmd)
    returncode = run(command,
                     assert_ok=False,
                     show_log=True,
                     retry_interval=retry_interval,
                     retry_times=retry_times)
    if returncode != 0:
      return "command failed(%d)" % returncode
    return None

  def _resolve_sign_config(self, sign_api_env, sign_key_env):  # 校验 Jenkins 注入的签名配置
    if not os.environ.get(sign_api_env) or not os.environ.get(sign_key_env):
      fatal("%s and %s must be set" % (sign_api_env, sign_key_env))
    return sign_api_env, sign_key_env

  def _upload(self):  # 上传最终 work_dir 到远端临时发布目录
    conn = SambaConnection(self.location.host)
    conn.connect()
    staging_platform_dir = posixpath.join(self.staging_remote_root, self.platform_dir)
    conn.mkdir(self.location.share, staging_platform_dir)
    conn.upload_dir_recursive(self.work_dir, self.location.share, staging_platform_dir)
    return staging_platform_dir

  def run(self):  # 编排单个 platform_dir 的下载、处理、校验、上传和报告
    make_dir(self.tmp_dir)
    # One beta_run_once worker owns exactly one platform_dir from download through report.
    self._download()
    report = self._process()
    verify = self._verify()
    remote_dir = self._upload()
    if not isinstance(report, dict):
      report = {}
    report["platform_dir"] = self.platform_dir
    report["mode"] = self.mode
    report["remote_dir"] = remote_dir
    report["verify"] = verify
    make_dir(self.report_root)
    report_path = os.path.join(self.report_root, self.platform_dir + ".json")
    report_content = add_tail_lf(dump_json(report))
    write_file(report_path, report_content, show_log=False)


class _FirmwareWorker(_TaskDirWorkerBase):
  """固件 platform_dir worker，负责 img 解包、beta 标记修改、v2 签名和固件校验。"""

  SIGN_API_ENV = "UGBT_FIRMWARE_SIGN_API"
  SIGN_KEY_ENV = "UGBT_FIRMWARE_SIGN_KEY"
  MAX_SIZE_DIFF_BYTES = 10000

  def _package_files(self):  # 根据发布命名规则生成固件 img/product/manifest 路径
    package_dir = self.work_dir
    stem = self._pack_stem()
    files = {
        "img": os.path.join(package_dir, stem + ".img"),
        "manifest": os.path.join(package_dir, stem + ".manifest.yaml"),
        "product": os.path.join(package_dir, stem + ".product.json"),
        "stem": stem,
    }
    for key in ("img", "manifest", "product"):
      if not os.path.isfile(files[key]):
        fatal("%s not found: %s" % (key, files[key]))
    return files

  def _check_size_diff(self, label, old_size, new_size):  # 防止 beta 标记外的大幅内容变化
    diff = new_size - old_size
    info("--> %s size old=%d new=%d diff=%d" % (label, old_size, new_size, diff))
    if abs(diff) > self.MAX_SIZE_DIFF_BYTES:  # beta 标记修改不应导致大体积变化
      fatal("%s size diff %d exceeds %d bytes" % (label, diff, self.MAX_SIZE_DIFF_BYTES))

  def _squashfs_build_options(self, path):  # 重建 oem.squashfs 时沿用原压缩格式，避免只改 beta 却改变包结构
    values = {}
    for line in runex(shlex.join(["unsquashfs", "-s", path]), err_output=True).splitlines():
      stripped = line.strip()
      for prefix in ("Compression ", "Block size ", "Dictionary size ", "Filters selected:"):
        if stripped.startswith(prefix):
          values[prefix] = stripped[len(prefix):].strip()
          break
    compression = values.get("Compression ")
    block_size = values.get("Block size ")
    if not compression or not block_size:  # 缺少这些参数就不能保证重建后的 squashfs 仍接近原包
      fatal("cannot read squashfs options: %s" % path)
    opts = ["-comp", compression, "-b", block_size]
    if compression == "xz":
      dict_size = values.get("Dictionary size ")
      xz_filters = values.get("Filters selected:")
      if dict_size:  # xz 字典大小影响压缩结果，能保留就保留
        opts.extend(["-Xdict-size", dict_size])
      if xz_filters:  # xz bcj filter 和架构相关，避免重打后设备侧行为变化
        opts.extend(["-Xbcj", xz_filters.replace(" ", "")])
    return opts

  def _permission_mode(self, perms):
    """把 crw------- 里的权限位转成 mksquashfs -pf 需要的 600。"""
    return "".join(str(
        (4 if perms[index] == "r" else 0) +
        (2 if perms[index + 1] == "w" else 0) +
        (1 if perms[index + 2] in ("x", "s", "t") else 0)
    ) for index in range(0, 9, 3))

  def _squashfs_device_pseudo_definitions(self, path):
    """记录 dev/console 这类设备节点，非 root 解压跳过后再用 mksquashfs -pf 写回。"""
    definitions = []
    for line in runex(shlex.join(["unsquashfs", "-lln", path]), err_output=True).splitlines():
      fields = line.split()
      if not fields or fields[0][0] not in ("b", "c"):
        continue
      file_type = fields[0][0]
      uid, gid = fields[1].split("/", 1)
      remote_path = fields[6]
      prefix = "squashfs-root/"
      if remote_path.startswith(prefix):
        remote_path = remote_path[len(prefix):]
      definitions.append("%s %s %s %s %s %s %s" % (
          remote_path,
          file_type,
          self._permission_mode(fields[0][1:10]),
          uid,
          gid,
          fields[2].rstrip(","),
          fields[3],
      ))
    return definitions

  def _update_os_release(self, unpack_dir):  # 修改 img 顶层 os-release beta 标记
    info("==》 更新 os-release 文件")
    path = os.path.join(unpack_dir, "os-release")
    if not os.path.isfile(path):
      fatal("os-release not found: %s" % path)
    run(shlex.join(["sed", "-i", "s/OS_IS_BETA=True/OS_IS_BETA=False/", path]))
    info("os-release --> OS_IS_BETA=True replace to OS_IS_BETA=False")

  def _update_oem_squashfs(self, unpack_dir):  # oem.squashfs 是压缩文件系统，只改内部 os-release 并尽量保持原格式
    info("==》 更新 oem.squashfs 文件")
    path = os.path.join(unpack_dir, "oem.squashfs")
    if not os.path.isfile(path):
      fatal("oem.squashfs not found: %s" % path)
    work_dir = tempfile.mkdtemp(prefix="oem_squashfs_", dir=unpack_dir)
    squashfs_root = os.path.join(work_dir, "root")
    tmp_path = os.path.join(work_dir, "oem.squashfs")
    device_pseudo_path = os.path.join(work_dir, "devices.pseudo")
    try:
      build_opts = self._squashfs_build_options(path)  # 重打时保留原 compression/block/filter 参数
      device_pseudo_defs = self._squashfs_device_pseudo_definitions(path)
      extract_cmd = ["unsquashfs", "-q", "-no-progress"]
      if device_pseudo_defs:
        # 非 root 解压不能创建 dev/console 这类设备节点；跳过解压错误，但重打包时用 -pf 写回原设备节点。
        write_file(device_pseudo_path, "\n".join(device_pseudo_defs) + "\n", show_log=False)
        extract_cmd.extend(["-ignore-errors", "-no-exit-code"])
      extract_cmd.extend(["-d", squashfs_root, path])
      run(shlex.join(extract_cmd))
      os_release = os.path.join(squashfs_root, "usr/lib/os-release")
      if not os.path.isfile(os_release):
        fatal("oem squashfs os-release not found: %s" % os_release)
      text = read_file(os_release)
      if "OS_IS_BETA=True" not in text:
        fatal("cannot find OS_IS_BETA=True in %s" % os_release)
      write_file(os_release, text.replace("OS_IS_BETA=True", "OS_IS_BETA=False", 1), show_log=False)
      info("os-release --> OS_IS_BETA=True replace to OS_IS_BETA=False")
      cmd = ["mksquashfs", squashfs_root, tmp_path, "-noappend", "-all-root"]
      cmd.extend(build_opts)
      if device_pseudo_defs:
        cmd.extend(["-pf", device_pseudo_path])
      cmd.extend(["-quiet", "-no-progress"])
      run(shlex.join(cmd))
      os.replace(tmp_path, path)
    finally:
      shutil.rmtree(work_dir, ignore_errors=True)

  def _rewrite_checksum_file(self, path, base_dir):  # 按实际文件重算 md5 清单
    lines = read_file(path).splitlines(True)
    new_lines = []
    for line in lines:
      stripped = line.strip()
      if not stripped:
        new_lines.append(line)
        continue
      parts = stripped.split()
      if len(parts) != 2:
        fatal("invalid checksum line in %s: %s" % (path, line.rstrip("\n")))
      old_file_md5, filename = parts
      file_path = os.path.join(base_dir, filename)
      if not os.path.isfile(file_path):
        fatal("checksum target missing: %s" % file_path)
      file_md5 = md5(file_path)
      new_lines.append("%s  %s\n" % (file_md5, filename))
      if file_md5 != old_file_md5:
        info("[replace] %s --> %s -> %s  %s" % (os.path.basename(path), old_file_md5, file_md5, filename))
    write_file(path, "".join(new_lines), show_log=False)

  def _update_md5sum(self, unpack_dir):  # 刷新 img 内 md5sum.txt
    path = os.path.join(unpack_dir, "md5sum.txt")
    if not os.path.isfile(path):
      fatal("md5sum.txt not found: %s" % path)
    self._rewrite_checksum_file(path, unpack_dir)

  def _update_product_json(self, source_product, target_product, img_md5, img_size, is_beta=False):  # 刷新固件 product.json
    info("==》 更新 product.json 文件")
    product = load_json_f(source_product)
    if "固件" not in product or "是否beta" not in product["固件"]:  # 中文字段用于旧页面展示
      fatal("product json missing beta key: 固件.是否beta")
    if "firmware" not in product or "isBeta" not in product["firmware"]:  # 英文字段用于程序消费
      fatal("product json missing beta key: firmware.isBeta")
    chinese_beta = product["固件"]["是否beta"]
    english_beta = product["firmware"]["isBeta"]
    product["固件"]["是否beta"] = is_beta
    product["firmware"]["isBeta"] = is_beta
    info("[replace] product.json --> 固件.是否beta: %s -> 固件.是否beta: %s" % (chinese_beta, is_beta))
    info("[replace] product.json --> firmware.isBeta: %s -> firmware.isBeta: %s" % (english_beta, is_beta))
    for key in ("固件MD5值", "升级包大小"):
      if key not in product["固件"]:
        fatal("product json missing metadata key: 固件.%s" % key)
    for key in ("md5", "size"):
      if key not in product["firmware"]:
        fatal("product json missing metadata key: firmware.%s" % key)
    product["固件"]["固件MD5值"] = img_md5
    product["固件"]["升级包大小"] = "%.2f" % (img_size / 1000.0)
    product["firmware"]["md5"] = img_md5
    product["firmware"]["size"] = img_size
    write_file(target_product, add_tail_lf(dump_json(product)), show_log=False)

  def _update_manifest_yaml(self, source_manifest, target_manifest, img_name, img_md5, product_name, product_md5, is_beta=False):  # 刷新固件 manifest.yaml
    info("==》 更新 manifest.yaml 文件")
    manifest = load_yaml(read_file(source_manifest))
    if not isinstance(manifest, dict):  # manifest 根节点必须是 mapping 才能更新字段
      fatal("manifest yaml root must be a mapping: %s" % source_manifest)
    md5_map = manifest.get("md5")
    if not isinstance(md5_map, dict):  # md5 清单必须可按文件名更新
      fatal("manifest yaml missing md5 mapping: %s" % source_manifest)
    if "beta" not in manifest:
      fatal("manifest beta key not found: %s" % source_manifest)
    if img_name not in md5_map:
      fatal("manifest md5 missing image file: %s" % img_name)
    if product_name not in md5_map:
      fatal("manifest md5 missing product file: %s" % product_name)
    old_beta = manifest["beta"]
    manifest["beta"] = is_beta
    info("[replace] manifest.yaml --> beta: %s -> beta: %s" % (old_beta, is_beta))
    md5_map[img_name] = img_md5
    md5_map[product_name] = product_md5
    write_file(target_manifest, dump_yaml(manifest), show_log=False)

  def _process_package(self):  # 把当前 work 固件包 beta 转 GA
    files = self._package_files()
    info("process firmware package: %s" % self.work_dir)
    old_img_size = os.path.getsize(files["img"])
    make_dir(self.tmp_dir)
    unpack_dir = tempfile.mkdtemp(prefix=files["stem"] + "_", dir=self.tmp_dir)
    run(shlex.join(["tar", "-xf", files["img"], "-C", unpack_dir, "--no-same-owner"]))
    self._update_os_release(unpack_dir)
    self._update_oem_squashfs(unpack_dir)
    self._update_md5sum(unpack_dir)
    target_img = files["img"]
    run(shlex.join(["tar", "-cf", target_img, "-C", unpack_dir, "."]))
    self._check_size_diff(os.path.basename(files["img"]), old_img_size, os.path.getsize(target_img))
    shutil.rmtree(unpack_dir)
    img_md5 = md5(target_img)
    img_size = os.path.getsize(target_img)
    self._update_product_json(files["product"], files["product"], img_md5, img_size)
    product_md5 = md5(files["product"])
    self._update_manifest_yaml(
        files["manifest"],
        files["manifest"],
        os.path.basename(files["img"]),
        img_md5,
        os.path.basename(files["product"]),
        product_md5,
    )

  def _update_package_metadata(self):  # 签名后刷新固件外层元数据
    is_beta = self.mode == "beta"
    files = self._package_files()
    img_md5 = md5(files["img"])
    img_size = os.path.getsize(files["img"])
    self._update_product_json(files["product"], files["product"], img_md5, img_size, is_beta=is_beta)
    product_md5 = md5(files["product"])
    self._update_manifest_yaml(
        files["manifest"],
        files["manifest"],
        os.path.basename(files["img"]),
        img_md5,
        os.path.basename(files["product"]),
        product_md5,
        is_beta=is_beta,
    )

  def _verify_img_v2_signature(self, img):  # 校验固件 img v2 签名
    signer = os.path.join(self.tools_dir, "ugpkgsign")
    verify_pub = os.path.join(self.tools_dir, "ugreenRoot.pub")
    if not os.path.isfile(signer):
      fatal("ugpkgsign not found: %s" % signer)
    if not os.path.isfile(verify_pub):
      fatal("v2 verify public key not found: %s" % verify_pub)
    failure = self._run_sign_command([signer, "-file", img, "-isVerify", "-signVersion", "2", "-verifyPub", verify_pub])
    if failure:
      fatal(failure)

  def _sign_img_v2(self):  # 给固件 img 做 v2 签名
    files = self._package_files()
    signer = os.path.join(self.tools_dir, "ugpkgsign")
    verify_pub = os.path.join(self.tools_dir, "ugreenRoot.pub")
    if not os.path.isfile(signer):
      fatal("ugpkgsign not found: %s" % signer)
    if not os.path.isfile(verify_pub):
      fatal("v2 verify public key not found: %s" % verify_pub)
    sign_api_env, sign_key_env = self._resolve_sign_config(self.SIGN_API_ENV, self.SIGN_KEY_ENV)
    img = files["img"]
    make_dir(self.tmp_dir)
    sign_root = tempfile.mkdtemp(prefix="firmware_v2_sign_", dir=self.tmp_dir)
    try:
      config = {
          "node": os.environ[sign_api_env],
          "key": os.environ[sign_key_env],
      }
      write_file(os.path.join(sign_root, "config.json"), add_tail_lf(dump_json(config)), show_log=False)
      failure = self._run_sign_command([signer, "-file", img, "-signVersion", "2", "-root", sign_root])
      if failure:
        fatal(failure)
      failure = self._run_sign_command([signer, "-file", img, "-isVerify",
                                        "-signVersion", "2", "-verifyPub", verify_pub])
      if failure:
        fatal(failure)
    finally:
      shutil.rmtree(sign_root, ignore_errors=True)

  def _verify(self):  # 校验固件最终产物
    is_beta = self.mode == "beta"
    files = self._package_files()
    self._verify_img_v2_signature(files["img"])
    product = load_json_f(files["product"])
    manifest = load_yaml(read_file(files["manifest"]))
    img_md5 = md5(files["img"])
    product_md5 = md5(files["product"])
    if product.get("firmware", {}).get("isBeta") is not is_beta:  # product beta 必须等于目标模式
      fatal("product beta mismatch: %s" % files["product"])
    if product.get("firmware", {}).get("md5") != img_md5:  # product 里的 img md5 必须等于实际 img
      fatal("product image md5 mismatch: %s" % files["product"])
    if product.get("firmware", {}).get("size") != os.path.getsize(files["img"]):  # product size 必须等于实际 img
      fatal("product image size mismatch: %s" % files["product"])
    if manifest.get("beta") is not is_beta:  # manifest beta 必须等于目标模式
      fatal("manifest beta mismatch: %s" % files["manifest"])
    md5_map = manifest.get("md5")
    if not isinstance(md5_map, dict):
      fatal("manifest md5 missing: %s" % files["manifest"])
    if md5_map.get(os.path.basename(files["img"])) != img_md5:  # manifest 里的 img md5 必须刷新
      fatal("manifest image md5 mismatch: %s" % files["manifest"])
    if md5_map.get(os.path.basename(files["product"])) != product_md5:  # manifest 里的 product md5 必须刷新
      fatal("manifest product md5 mismatch: %s" % files["manifest"])
    return {
        "img": os.path.basename(files["img"]),
        "sign": "v2",
        "beta": product.get("firmware", {}).get("isBeta"),
    }

  def _download(self):  # 只下载固件 img/product/manifest 到本地 work_dir
    conn = SambaConnection(self.location.host)
    conn.connect()
    remote_platform_dir = posixpath.join(self.location.remote_path, self.platform_dir)
    tmp_work = self.work_dir + ".tmp"
    if os.path.exists(tmp_work):
      shutil.rmtree(tmp_work)
    make_dir(tmp_work)
    downloaded = False
    try:
      stem = self._pack_stem()
      for name in (stem + ".img", stem + ".product.json", stem + ".manifest.yaml"):
        conn.download(self.location.share, posixpath.join(remote_platform_dir, name), os.path.join(tmp_work, name))
      os.rename(tmp_work, self.work_dir)
      downloaded = True
    finally:
      if not downloaded and os.path.exists(tmp_work):
        shutil.rmtree(tmp_work)

  def _process(self):  # 固件处理主流程：必要时转 GA、签名、刷新元数据
    files = self._package_files()
    old_beta = load_json_f(files["product"]).get("firmware", {}).get("isBeta")
    old_md5 = md5(files["img"])
    if self.mode == "ga":
      self._process_package()
    self._sign_img_v2()
    self._update_package_metadata()
    target_files = self._package_files()
    return {
        "filename": os.path.basename(target_files["img"]),
        "old_beta": old_beta,
        "new_beta": self.mode == "beta",
        "old_md5": old_md5,
        "new_md5": md5(target_files["img"]),
    }


class _SuiteWorker(_TaskDirWorkerBase):
  """套件 platform_dir worker，负责 release tar 解包、upk setbeta 签名和套件校验。"""

  SIGN_API_ENV = "UGBT_SUITE_SIGN_API"
  SIGN_KEY_ENV = "UGBT_SUITE_SIGN_KEY"
  UPK_V2_HEADER = b"UGREEN-PKG-V2-FORMAT"

  def _find_single_file_by_suffix(self, paths, suffix, root):  # 在本地找唯一后缀文件
    matches = [path for path in paths if os.path.isfile(path) and path.endswith(suffix)]
    if len(matches) != 1:
      fatal("%s must contain exactly one %s" % (root, suffix))
    return matches[0]

  def _archive_files(self):  # 根据发布命名规则生成套件 tar/manifest 路径
    arch_dir = self.work_dir
    stem = self._pack_stem()
    files = {
        "tar": os.path.join(arch_dir, stem + ".tar.gz"),
        "manifest": os.path.join(arch_dir, stem + ".manifest.yaml"),
    }
    for key in ("tar", "manifest"):
      if not os.path.isfile(files[key]):
        fatal("%s not found: %s" % (key, files[key]))
    return files

  def _find_release_payload_files(self, release_dir):  # 定位 tar 内 upk/product
    if not os.path.isdir(release_dir):
      fatal("release dir not found: %s" % release_dir)
    children = [os.path.join(release_dir, name) for name in os.listdir(release_dir)]
    return {
        "upk": self._find_single_file_by_suffix(children, ".upk", release_dir),
        "product": self._find_single_file_by_suffix(children, ".product.json", release_dir),
    }

  def _extract_release_tar(self, tar_path, release_dir):  # 解套件 release tar
    if not os.path.isfile(tar_path):
      fatal("suite tar not found: %s" % tar_path)
    make_dir(release_dir)
    run(shlex.join(["tar", "-xzf", tar_path, "-C", release_dir, "--no-same-owner"]))

  def _update_manifest_yaml(self, manifest_path, upk_path, product_path, is_beta):  # 刷新套件 manifest.yaml
    manifest = load_yaml(read_file(manifest_path))
    if not isinstance(manifest, dict):
      fatal("manifest yaml root must be mapping: %s" % manifest_path)
    manifest["beta"] = is_beta
    manifest["md5"] = {
        os.path.basename(upk_path): md5(upk_path),
        os.path.basename(product_path): md5(product_path),
    }
    write_file(manifest_path, dump_yaml(manifest), show_log=False)

  def _verify(self):  # 校验套件最终发布文件
    is_beta = self.mode == "beta"
    manifest_path = os.path.join(self.work_dir, self._pack_stem() + ".manifest.yaml")
    if not os.path.isfile(manifest_path):
      fatal("manifest not found: %s" % manifest_path)
    payload = self._find_release_payload_files(self.work_dir)
    final_names = set(os.listdir(self.work_dir))
    expected_names = {
        os.path.basename(payload["upk"]),
        os.path.basename(payload["product"]),
        os.path.basename(manifest_path),
    }
    if final_names != expected_names:
      fatal("suite final files mismatch: %s" % self.work_dir)
    with open(payload["upk"], "rb") as fp:  # 只读 upk 二进制头判断 v2 签名
      upk_header = fp.read(len(self.UPK_V2_HEADER))
      if upk_header != self.UPK_V2_HEADER:  # 只接受 v2 签名后的 upk
        fatal("upk is not v2 signed: %s" % payload["upk"])
    upk_name = os.path.basename(payload["upk"])
    product_name = os.path.basename(payload["product"])
    product = load_json_f(payload["product"])
    if product.get("version", {}).get("beta") is not is_beta:  # product beta 必须等于目标模式
      fatal("product beta mismatch: %s" % payload["product"])
    if product.get("version", {}).get("size") != os.path.getsize(payload["upk"]):  # product size 必须等于实际 upk
      fatal("product size mismatch: %s" % payload["product"])
    if product.get("hash") != md5(payload["upk"]):  # product hash 必须等于实际 upk
      fatal("product hash mismatch: %s" % payload["product"])
    manifest = load_yaml(read_file(manifest_path))
    if manifest.get("beta") is not is_beta:  # manifest beta 必须等于目标模式
      fatal("manifest beta mismatch: %s" % manifest_path)
    md5_map = manifest.get("md5")
    if not isinstance(md5_map, dict):
      fatal("manifest md5 must be mapping: %s" % manifest_path)
    expected_md5 = {
        upk_name: md5(payload["upk"]),
        product_name: md5(payload["product"]),
    }
    if md5_map != expected_md5:
      fatal("manifest md5 mismatch: %s" % manifest_path)
    return {
        "upk": upk_name,
        "sign": "v2",
        "beta": product.get("version", {}).get("beta"),
    }

  def _sign_upk_with_setbeta(self, source_upk, target_upk, beta_value):  # 调用 ugtools setbeta 原地签名 upk
    ugtools = os.path.join(self.tools_dir, "ugtools")
    verify_pub = os.path.join(self.tools_dir, "ugreenRoot.pub")
    if not os.path.isfile(ugtools):
      fatal("ugtools not found: %s" % ugtools)
    if not os.path.isfile(verify_pub):
      fatal("verify public key not found: %s" % verify_pub)
    sign_api_env, sign_key_env = self._resolve_sign_config(self.SIGN_API_ENV, self.SIGN_KEY_ENV)
    beta_arg = "true" if beta_value else "false"
    cmd = [
        ugtools,
        "setbeta",
        "-f",
        source_upk,
        "-t",
        target_upk,
        "-beta",
        beta_arg,
        "-sign",
        "v2",
        "-verifyPub",
        verify_pub,
    ]

    command = "cd %s && %s -signAPI \"${%s}\" -signKey \"${%s}\"" % (
        shlex.quote(os.path.dirname(target_upk)),
        shlex.join(cmd),
        sign_api_env,
        sign_key_env,
    )
    failure = self._run_sign_command(command)
    if failure:
      fatal(failure)
    if not os.path.isfile(target_upk):
      fatal("setbeta did not create target upk: %s" % target_upk)

  def _download(self):  # 只下载套件 tar.gz 和 manifest 到本地 work_dir
    conn = SambaConnection(self.location.host)
    conn.connect()
    remote_platform_dir = posixpath.join(self.location.remote_path, self.platform_dir)
    tmp_work = self.work_dir + ".tmp"
    if os.path.exists(tmp_work):
      shutil.rmtree(tmp_work)
    make_dir(tmp_work)
    downloaded = False
    try:
      stem = self._pack_stem()
      for name in (stem + ".tar.gz", stem + ".manifest.yaml"):
        conn.download(self.location.share, posixpath.join(remote_platform_dir, name), os.path.join(tmp_work, name))
      os.rename(tmp_work, self.work_dir)
      downloaded = True
    finally:
      if not downloaded and os.path.exists(tmp_work):
        shutil.rmtree(tmp_work)

  def _process(self):  # 套件处理主流程：解 tar、setbeta 签名、输出 upk/product 并刷新 manifest
    files = self._archive_files()
    make_dir(self.tmp_dir)
    work_dir = tempfile.mkdtemp(prefix="suite_process_", dir=self.tmp_dir)
    try:
      release_dir = os.path.join(work_dir, "release")
      self._extract_release_tar(files["tar"], release_dir)
      payload = self._find_release_payload_files(release_dir)
      is_beta = self.mode == "beta"
      product = load_json_f(payload["product"])
      old_beta = product.get("version", {}).get("beta")
      old_md5 = md5(payload["upk"])
      upk_name = os.path.basename(payload["upk"])
      self._sign_upk_with_setbeta(payload["upk"], payload["upk"], is_beta)
      new_md5 = md5(payload["upk"])
      target_upk = os.path.join(self.work_dir, os.path.basename(payload["upk"]))
      target_product = os.path.join(self.work_dir, os.path.basename(payload["product"]))
      shutil.move(payload["upk"], target_upk)
      shutil.move(payload["product"], target_product)
      os.remove(files["tar"])
      self._update_manifest_yaml(files["manifest"], target_upk, target_product, is_beta)
    finally:
      shutil.rmtree(work_dir, ignore_errors=True)
    return {
        "filename": upk_name,
        "old_beta": old_beta,
        "new_beta": is_beta,
        "old_md5": old_md5,
        "new_md5": new_md5,
    }


class Tool(ug_cmd_base.CommandTool):
  """单 platform_dir 发布 worker。"""

  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "beta_run_once",
                                     "internal worker for one firmware or suite beta/GA platform_dir", [
                                         ("u", "smb-url", "source SMB root containing platform directories", None),
                                         ("T", "type", "package type: firmware or suite", None),
                                         ("m", "mode", "target mode: ga or beta", None),
                                         ("p", "platform-dir", "platform directory name under smb-url", ""),
                                         ("R", "remote-tmp-root", "remote temporary publish root", None),
                                     ])

  def main(self):  # 根据 type 创建对应 worker 并执行单 platform_dir 流程
    ctx = _BetaOnceContext(self)
    if not ctx.platform_dir:
      fatal("beta_run_once requires --platform-dir")
    if ctx.package_type == "firmware":
      worker = _FirmwareWorker(ctx)
    elif ctx.package_type == "suite":
      worker = _SuiteWorker(ctx)
    else:
      fatal("type must be firmware or suite: %s" % ctx.package_type)
    worker.run()
    return 0
