from collections import OrderedDict
import os
import yaml
import pandas as pd
from ug_common import dump_yaml, fatal, info, load_yaml_f, read_file, convert_string_numbers
import ug_cmd_base


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "did_init", "dingding userid sync tool", [
        ('v', 'verbose', "show verbose log", False),
        ('f', 'file', "did text file", "./dev/dingding.txt"),  # 修改默认文件为 .txt
    ])

  def __update_did_users(self):
    env = self.env
    txt_file = self.get_opt('file')  # 获取文本文件路径

    # 读取文本文件（制表符分隔，GBK编码）
    try:
      df = pd.read_csv(txt_file, sep='\t', encoding='gbk')  # 使用 pd.read_csv 读取文本文件
    except Exception as e:
      fatal(f"Failed to read text file {txt_file}: {str(e)}")

    # 创建从工号到 UserID 的映射
    eid_to_userid = {}
    for _, row in df.iterrows():
      eid = str(row['姓名']).strip().lower()  # 确保工号是字符串并去除空格
      userid = str(row['员工UserID']).strip()  # 注意列名改为 "员工UserID"
      eid_to_userid[eid] = convert_string_numbers(userid)
    # 加载 YAML 文件
    users_yaml_file = os.path.join(env.root, "dev", "users.yaml")
    try:
      # 读取 YAML 文件
      with open(users_yaml_file, 'r', encoding='utf-8') as file:
        users_data = yaml.safe_load(file)
      if users_data is None:
        fatal(f"YAML file is empty or invalid: {users_yaml_file}")
    except Exception as e:
      fatal(f"Failed to load YAML file {users_yaml_file}: {str(e)}")

    # 更新 did 字段（匹配工号）
    updated_count = 0
    for user_key in users_data:  # 直接遍历字典的键
      user_info = users_data[user_key]  # 获取对应的值
      if 'ename' in user_info:
        ename = str(user_info['ename']).strip().lower()
        if ename in eid_to_userid:
          user_info['did'] = eid_to_userid[ename]
          updated_count += 1

    # 写回 YAML 文件
    try:
      with open(users_yaml_file, 'w', encoding='utf-8') as f:
        yaml.dump(users_data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)  # 确保传递文件对象 f
      info(f"Successfully updated {updated_count} users in {users_yaml_file}")
    except Exception as e:
      fatal(f"Failed to write YAML file {users_yaml_file}: {str(e)}")

  def main(self):
    if len(self.get_targets()) == 0:
      fatal("Please specify command")

    cmd = self.get_targets()[0]
    if cmd == "update":
      self.__update_did_users()
    else:
      fatal(f"Unknown command: {cmd}")
    return 0
