import fcntl
import os
from ug_build_platform import BuildPlatform
from ug_common import fatal, dump_yaml, info, make_dir, run
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "upload", "upload the all packages of a version installed package to the samba server, upload will check all build platforms are ready", [
        ('v', 'build-var', 'build vars', ""),
        ('m', 'mock', "run mock upload, do not push to remote, just for test", False),
        ('c', 'check', "check remote package only, exit with error if remote package exists, ", False),
        ('C', 'clean', "clean remote temp dirs in this project folder", False),
        ('V', 'verbose', "show verbose log", False),
        ('p', 'platform', 'use platform string instead of --build-var -v', ""),
        ('s', 'staging-id', "shared name for split CI upload; SMB staging path is <vdir>-<name>.tmp (e.g. commit SHA)", ""),
        ('f', 'finalize', "mv staged dir to final vdir after all platforms uploaded with --staging-id and -p each", False),
        ('E', 'clear-staging-platform', "before install: clear this -p slice on SMB staging (final dir + pdir.tmp)", False),
    ])

  def __try_to_upload_doc(self):
    env = self.env
    fpath = os.path.join("Doxyfile")
    if not os.path.exists(fpath):
      info("doxyfile not found - " + fpath)
      info("skip doc building")
      return

    make_dir("ugreen_build")
    ret = run("doxygen Doxyfile > ugreen_build/doxygen.log", assert_ok=False, show_start_log=True)
    if ret != 0:
      return

    lock_dir = os.path.join(env.home, "ugreen.tmp")
    make_dir(lock_dir)
    lock_file = os.path.join(lock_dir, "upload_doxygen.lock")

    if not os.path.exists(lock_file):
      run("touch " + lock_file)
    fp = open(lock_file, "rb")
    info("try to get lock %s ..." % lock_file)
    fcntl.flock(fp, fcntl.LOCK_EX)
    info("get lock %s OK" % lock_file)
    # run("scp -r ugreen_build/doxygen/* ugreen@192.168.110.33:/home/ugreen/docs/doxygen/", assert_ok=False, show_start_log=True)

  def main(self):
    env = self.env
    build_vars = self.get_opts("build-var")
    dummy_proj = UgProject.load(env, build_vars)
    if self.get_opt("clean"):
      dummy_proj.clean_repo_tmp_dirs()
      return 0
    if self.get_opt("mock"):
      dummy_proj.upload(True)
      return 0
    dummy_proj.check_remote()
    if self.get_opt('check'):
      return 0
    else:
      if self.get_opt("clear-staging-platform") and self.get_opt("finalize"):
        fatal("--clear-staging-platform and --finalize cannot be used together")

      if self.get_opt("clear-staging-platform"):
        staging_id = self.get_opt("staging-id")
        if not staging_id:
          fatal("--clear-staging-platform requires --staging-id")
        platforms_pf = []
        for platform_str in self.get_opts("platform"):
          if platform_str:
            platforms_pf.append(BuildPlatform.parse(env, platform_str))
        if len(platforms_pf) != 1:
          fatal("--clear-staging-platform requires exactly one -p platform")
        UgProject.clear_upload_staging_platform(env, staging_id, platforms_pf[0])
        return 0

      platforms = []
      for platform_str in self.get_opts("platform"):
        if platform_str:
          platform = BuildPlatform.parse(env, platform_str)
          platforms.append(platform)

      staging_id = self.get_opt("staging-id")
      if len(platforms) == 0:
        platforms = dummy_proj.get_all_platforms()

      if self.get_opt("finalize"):
        if not staging_id:
          fatal("--finalize requires --staging-id")
        UgProject.upload_finalize(env, platforms, staging_id)
        self.__try_to_upload_doc()
        return 0

      if staging_id:
        if len(platforms) != 1:
          fatal("with --staging-id, specify exactly one -p platform (per-parallel-job upload)")
        UgProject.upload_stage_platform(env, platforms[0], staging_id)
        return 0

      UgProject.upload_all(env, platforms)

      self.__try_to_upload_doc()
    return 0
