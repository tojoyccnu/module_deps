"""ugbt beta_run_jenkins 命令入口。

Jenkins 对外入口只暴露 smb-url 和 mode。并发数、临时目录、签名工具目录
等内部参数由这里统一推导。
"""

import atexit
import html
import os
import posixpath
import shutil
from datetime import datetime

import ug_cmd_base
from ug_common import (
    SambaConnection,
    fatal,
    info,
    join_cmd,
    load_json_f,
    make_dir,
    parse_smb_url,
    read_file,
    run,
    send_notify_mail,
    uuid_gen,
)
from ug_utils import beta_normalize_mode, beta_release_branch_index, beta_resolve_package_type


_JENKINS_PACKAGE_ATTRS = {
    "firmware": {
        "mail_package_type": "固件",
    },
    "suite": {
        "mail_package_type": "套件",
    },
}


_SMB_PATH_INPUT_ERROR = (
    "smb 路径输入有误：请填写平台目录的上级目录，不要填写单个平台目录。"
    "示例：smb://.../repo/firmware/image/release_20260728/1.18.0/64"
)


def _beta_run_jenkins_team_addrs():
  team_addrs = []
  team_addrs.append("NAS-测试组 <nas-test@ugreen.com>")
  team_addrs.append("NAS-软件开发组 <nas-develop@ugreen.com>")
  team_addrs.append("NAS-PRO-产品小组 <nas-pro-product@ugreen.com>")
  team_addrs.append("NAS-UI设计组 <nas-ui@ugreen.com>")
  team_addrs.append("NAS-产品运营组 <nas-cpyy@ugreen.com>")
  team_addrs.append("NAS-音视频组 <nas-media@ugreen.com>")
  team_addrs.append("NAS-系统安全组 <nas-security@ugreen.com>")
  team_addrs.append("NAS-系统 <nas-os@ugreen.com>")
  team_addrs.append("NAS-云端组 <nas-cloud@ugreen.com>")
  team_addrs.append("NAS-软件项目组 <nas-project@ugreen.com>")
  team_addrs.append("NAS-AI <nas-ai@ugreen.com>")
  team_addrs.append("NAS-DQE组 <pz-nasdqe@ugreen.com>")
  team_addrs.append("NAS-硬件开发 <nas-hwyf@ugreen.com>")
  return team_addrs


def _resolve_package_path_parts(location, package_type):
  parts = [part for part in location.remote_path.split("/") if part]
  if "repo" not in parts:
    fatal("smb path must contain repo segment for release publish: %s" % location.remote_path)
  release_index = beta_release_branch_index(parts)
  if release_index < 0:
    fatal("smb path must contain release_ segment: %s" % location.remote_path)
  repo_index = parts.index("repo")
  source_parts = parts[repo_index + 1:release_index]
  if not source_parts or source_parts[0] != "firmware":
    fatal("smb path must contain firmware segment after repo: %s" % location.remote_path)
  if len(source_parts) < 2:
    fatal("smb path must include package path before release_: %s" % location.remote_path)
  package_path_parts = source_parts
  if package_type == "firmware":
    if "image" not in package_path_parts:
      fatal("firmware smb path must contain image segment: %s" % location.remote_path)
  return package_path_parts


def _release_remote_path(location, mode, release_category, package_path_parts):
  parts = [part for part in location.remote_path.split("/") if part]
  repo_index = parts.index("repo")
  release_index = beta_release_branch_index(parts)
  if release_index < 0:
    fatal("smb path must contain release_ segment: %s" % location.remote_path)
  label = "GA" if mode == "ga" else "beta"
  release_branch = parts[release_index]
  tail = list(package_path_parts) + parts[release_index + 1:]
  return "/".join(parts[:repo_index] + ["release", release_category, release_branch, label] + tail)


def _staging_remote_path(release_remote_path, run_name):
  parts = [part for part in release_remote_path.split("/") if part]
  release_index = next(
      (
          index for index, part in enumerate(parts[:-1])
          if part == "release" and parts[index + 1] in ("image", "service")
      ),
      -1,
  )
  if release_index < 0:
    fatal("release publish path must contain release segment: %s" % release_remote_path)
  parts[release_index] = "release.tmp"
  return "%s.%s.tmp" % ("/".join(parts), run_name)


def _windows_unc_path(location, remote_path):
  parts = [location.host, location.share]
  parts.extend(part for part in remote_path.split("/") if part)
  return "\\\\" + "\\".join(parts)


def _require_release_package_root(location):
  parts = [part for part in location.remote_path.split("/") if part]
  release_index = beta_release_branch_index(parts)
  if release_index < 0:
    fatal("smb path must contain release_ segment: %s" % location.remote_path)
  tail = parts[release_index + 1:]
  if len(tail) != 2 or not tail[1].isdigit():
    fatal(_SMB_PATH_INPUT_ERROR)


def _resolve_workspace_paths(start_dir):
  start_dir = os.path.abspath(start_dir)
  if os.path.isfile(os.path.join(start_dir, "ugbase", "ugbt")):
    workspace_root = start_dir
  elif os.path.basename(start_dir) == "ugbase" and os.path.isfile(os.path.join(start_dir, "ugbt")):
    workspace_root = os.path.dirname(start_dir)
  else:
    workspace_root = start_dir
  return workspace_root, os.path.join(workspace_root, "ugbase", "ugbt")


class _BetaJenkinsContext(object):
  """保存 beta_run_jenkins 单次发布需要共享的路径、参数和运行状态。"""

  def __init__(self, env, smb_url, mode, samba_connection_cls=SambaConnection, jobs="0"):
    self.env = env
    self.smb_url = smb_url
    self.mode = beta_normalize_mode(mode)
    self.package_type = beta_resolve_package_type(smb_url)
    self.package_attrs = _JENKINS_PACKAGE_ATTRS[self.package_type]
    self.location = parse_smb_url((smb_url or "").strip())
    _require_release_package_root(self.location)
    self.package_path_parts = _resolve_package_path_parts(self.location, self.package_type)
    self.release_category = "image" if self.package_type == "firmware" else "service"
    self.run_name = uuid_gen()
    self.workspace_root, self.ugbt_bin = _resolve_workspace_paths(os.getcwd())
    self.run_work_root = os.path.join(self.workspace_root, "ugbt", "beta_run_jenkins", self.run_name)
    self.tasks_root = os.path.join(self.run_work_root, "tasks")
    self.log_root = os.path.join(self.run_work_root, "logs")
    self.report_root = os.path.join(self.run_work_root, "reports")
    self.release_remote_paths = {
        mode: _release_remote_path(
            self.location, mode, self.release_category, self.package_path_parts)
        for mode in ("beta", "ga")
    }
    self.release_remote_path = self.release_remote_paths[self.mode]
    self.staging_remote_path = _staging_remote_path(self.release_remote_path, self.run_name)
    self.mail_to = _beta_run_jenkins_team_addrs()
    self.executor = ""
    self.samba_connection_cls = samba_connection_cls
    self.jobs = jobs
    self.conn = None
    self.staging_created = False
    self.published = False
    self.publish_url = ""
    self.success_mail_sent = False


class _BetaPublishMailer(object):
  """根据发布上下文渲染并发送成功通知邮件。"""

  def __init__(self, ctx):
    self.ctx = ctx

  def _resolve_executor(self):
    executor = (self.ctx.executor or "").strip()
    if executor:
      return executor
    build_user = os.environ.get("BUILD_USER", "").strip()
    if build_user:
      return build_user
    return os.environ.get("USER", "").strip() or "unknown"

  def _package_mode_title(self):
    if str(self.ctx.mode or "").strip().lower() == "ga":
      label = "正式包"
    else:
      label = "beta包"
    return "%s%s发布成功" % (self.ctx.package_attrs["mail_package_type"], label)

  def _resolve_jenkins_build(self):
    build_number = os.environ.get("BUILD_NUMBER", "").strip()
    if not build_number:
      return "-"
    job_name = os.environ.get("JOB_NAME", "").strip()
    label = "#%s" % build_number
    if job_name:
      label = "%s %s" % (html.escape(job_name), label)
    else:
      label = html.escape(label)
    build_url = os.environ.get("BUILD_URL", "").strip()
    if build_url:
      link = "<a href=\"%s\">#%s</a>" % (html.escape(build_url, quote=True), html.escape(build_number))
      if job_name:
        return "%s %s" % (html.escape(job_name), link)
      return link
    return label

  def _summarize_beta_change(self, reports):
    changes = []
    seen = set()
    for report in reports or []:
      old_beta = str(report.get("old_beta", "")).lower()
      new_beta = str(report.get("new_beta", "")).lower()
      change = "%s -> %s" % (old_beta, new_beta)
      if change not in seen:
        seen.add(change)
        changes.append(change)
    return ", ".join(changes)

  def _render_report_rows(self, reports):
    rows = []
    for report in reports:
      rows.append(
          "<tr>"
          "<td>%s</td>"
          "<td class=\"mono\">%s</td>"
          "<td class=\"mono\">%s</td>"
          "</tr>" % (
              html.escape(str(report.get("filename", ""))),
              html.escape(str(report.get("old_md5", ""))),
              html.escape(str(report.get("new_md5", ""))),
          )
      )
    return "\n".join(rows)

  def _render_success_html(self, reports, run_time=None, template_path=None):
    template = read_file(template_path or os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        "..",
        "tpl",
        "email",
        "package_publish_success.html",
    )))
    run_time = run_time or datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
    replacements = {
        "${TITLE}": html.escape(self._package_mode_title()),
        "${EXECUTOR}": html.escape(self._resolve_executor()),
        "${PACKAGE_TYPE}": html.escape(str(self.ctx.package_attrs["mail_package_type"])),
        "${BETA_CHANGE}": html.escape(self._summarize_beta_change(reports or [])),
        "${JENKINS_BUILD}": self._resolve_jenkins_build(),
        "${SOURCE_URL}": html.escape(self.ctx.source_url),
        "${PUBLISH_URL}": html.escape(self.ctx.publish_url),
        "${RESULT_COUNT}": html.escape("%d/%d %s OK" % (len(reports), len(reports), "platform_dir")),
        "${RUN_TIME}": html.escape(str(run_time)),
        "${REPORT_ROWS}": self._render_report_rows(reports or []),
    }
    for old, new in replacements.items():
      template = template.replace(old, new)
    return template

  def send_success(self, reports):
    send_notify_mail(
        tos=self.ctx.mail_to,
        subject="【%s】" % self._package_mode_title(),
        content=self._render_success_html(reports),
    )


class _BetaPublisher(object):
  """执行 Jenkins 发布主流程，负责 staging、foreach、发布和清理。"""

  def __init__(self, ctx):
    self.ctx = ctx
    self.mailer = _BetaPublishMailer(ctx)
    self.cleanup_done = False
    # 注册进程退出清理；正常命令执行结束后由 Python exit 自动触发。
    atexit.register(self._cleanup)

  def _check_publish_paths(self):
    ctx = self.ctx
    if os.path.exists(ctx.run_work_root):
      fatal("work dir already exists, refuse to reuse shared path: %s" % ctx.run_work_root)
    if not ctx.conn.isdir(ctx.location.share, ctx.location.remote_path):
      fatal("smb path is not a directory: %s" % ctx.smb_url)
    beta_path = ctx.release_remote_paths["beta"]
    if ctx.conn.exists(ctx.location.share, beta_path):
      fatal("该输入已经被转为 beta 包，不能再次用于正式包发布：smb://%s/%s/%s" %
            (ctx.location.host, ctx.location.share, beta_path))
    ga_path = ctx.release_remote_paths["ga"]
    if ctx.conn.exists(ctx.location.share, ga_path):
      fatal("该输入已经被转为正式包，不能再次用于beta发布：smb://%s/%s/%s" %
            (ctx.location.host, ctx.location.share, ga_path))
    if ctx.conn.exists(ctx.location.share, ctx.staging_remote_path):
      fatal("publish tmp already exists: smb://%s/%s/%s" %
            (ctx.location.host, ctx.location.share, ctx.staging_remote_path))

  def _run_foreach(self):
    ctx = self.ctx
    run_once_command = [
        ctx.ugbt_bin,
        "beta_run_once",
        "--smb-url",
        ctx.smb_url,
        "--type",
        ctx.package_type,
        "--mode",
        ctx.mode,
        "--remote-tmp-root",
        ctx.staging_remote_path,
        "--platform-dir",
        "{}",
    ]
    foreach_command = [
        self.ctx.ugbt_bin,
        "beta_run_foreach",
        "--smb-url",
        self.ctx.smb_url,
        "--",
    ] + run_once_command
    cmd = "cd %s && %s" % (
        join_cmd([self.ctx.run_work_root]),
        join_cmd(foreach_command),
    )
    run(cmd)

  def _load_reports(self):
    reports = []
    for name in sorted(os.listdir(self.ctx.report_root)):
      if name.endswith(".json"):
        reports.append(load_json_f(os.path.join(self.ctx.report_root, name)))
    return reports

  def _publish_staging_dir(self):
    ctx = self.ctx
    if ctx.conn.exists(ctx.location.share, ctx.release_remote_path):
      fatal("publish target already exists: smb://%s/%s/%s" %
            (ctx.location.host, ctx.location.share, ctx.release_remote_path))
    ctx.conn.mkdir(ctx.location.share, posixpath.dirname(ctx.release_remote_path))
    ctx.conn.mv(ctx.location.share, ctx.staging_remote_path, ctx.release_remote_path)
    ctx.published = True
    ctx.publish_url = "smb://%s/%s/%s" % (ctx.location.host, ctx.location.share, ctx.release_remote_path)
    ctx.source_url = "smb://%s/%s/%s" % (ctx.location.host, ctx.location.share, ctx.location.remote_path)

  def _cleanup(self):
    if self.cleanup_done:
      return
    self.cleanup_done = True
    ctx = self.ctx

    try:
      if ctx.conn:
        # atexit 会在进程退出时调用这里；邮件失败时回滚已发布目录。
        if ctx.published and not ctx.success_mail_sent:
          ctx.conn.delete_dir_recursive(ctx.location.share, ctx.release_remote_path)
        if ctx.staging_created and not ctx.published:
          ctx.conn.delete_dir_recursive(ctx.location.share, ctx.staging_remote_path)
    finally:
      # 远程和本地都要清理；finally 确保远程清理失败时仍会继续清理本地目录
      if os.path.exists(ctx.run_work_root):
        shutil.rmtree(ctx.run_work_root)
        info("clean work dir: %s" % ctx.run_work_root)

  def run(self):
    self.ctx.conn = self.ctx.samba_connection_cls(self.ctx.location.host)
    self.ctx.conn.connect()
    self._check_publish_paths()
    make_dir(self.ctx.tasks_root)
    make_dir(self.ctx.log_root)
    make_dir(self.ctx.report_root)
    self.ctx.conn.mkdir(self.ctx.location.share, self.ctx.staging_remote_path)
    self.ctx.staging_created = True
    self._run_foreach()
    reports = self._load_reports()
    self._publish_staging_dir()
    self.mailer.send_success(reports)
    # 发布目录已经对外可见，只有成功邮件发出后才算完整成功。
    self.ctx.success_mail_sent = True
    return self.ctx.publish_url


class Tool(ug_cmd_base.CommandTool):
  """Jenkins beta/GA 发布入口。"""

  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "beta_run_jenkins",
                                     "publish firmware or suite beta/GA package from Jenkins", [
                                         ("u", "smb-url", "smb input path", None),
                                         ("m", "mode", "required output mode: ga or beta", None),
                                     ])

  def main(self):
    smb_url = self.get_opt("smb-url")
    mode = self.get_opt("mode")
    info("输入目录：%s" % smb_url)
    self.ctx = _BetaJenkinsContext(self.env, smb_url, mode)
    info("包类型：%s" % self.ctx.package_attrs["mail_package_type"])
    info("最终目录：%s" % _windows_unc_path(
        self.ctx.location, self.ctx.release_remote_path))
    _BetaPublisher(self.ctx).run()
    return 0
