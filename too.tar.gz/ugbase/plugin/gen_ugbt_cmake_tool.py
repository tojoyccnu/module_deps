import ug_cmd_base
from ug_common import fatal
from ug_utils import UgProject
from ug_build_platform import BuildPlatform


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "gen-ugbt-cmake", "generate ugbt.cmake for ugreen project", [
        ('p', 'platform', 'platform str', ""),
    ])

  def main(self):
    env = self.env
    platform_str = self.get_opt("platform").strip()
    if not platform_str:
      fatal("platform is empty")
    platform = BuildPlatform.parse(env, platform_str)
    proj = UgProject.load(self.env, [], platform=platform)
    proj.generate_cmake()
    return 0
