import os
from typing import OrderedDict
import ug_cmd_base
from ug_common import fatal, info, runex, SambaConnection
from smb.SMBConnection import SMBConnection


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "smb", "test samba io tool", [
        ('c', 'credential', 'smb credential file', "${HOME}/.smb-credentials"),
        ('l', 'list', 'list samba dir', False),
        ('g', 'get', 'get samba file', False),
        ('p', 'put', 'put samba file', False),
        ('m', 'mkdir', 'mkdir samba dir', False),
        ('d', 'rm', 'rmdir dir', False),
        ('s', "share_name", "share name of the samba service", "backup"),
        ('H', "host", "samba server host", "172.16.16.6"),
    ])

  def connect(self):
    env = self.env
    conn = SMBConnection(
        username=env.smb_username,
        password=env.smb_password,
        my_name=env.local_ip,
        remote_name=env.host,
        use_ntlm_v2=True
    )

    info("connecting to %s 445 ..." % env.host)
    conn.connect(env.host, 445)
    info("connect OK")
    env.conn = conn

  def list(self):
    env = self.env
    if len(self.get_targets()) > 1:
      fatal("only support 1 or 0 target")
    if len(self.get_targets()) == 0:
      fpath = "/"
    else:
      fpath = self.get_targets()[0]

    self.connect()
    info("start listing ...")
    ff = env.conn.getAttributes(env.share_name, fpath)
    if not ff.isDirectory:
      fatal("%s %s %s is not a directory" % (env.host, env.share_name, fpath))
    files = env.conn.listPath(env.share_name, fpath)
    info("list OK")
    print("list %s %s" % (env.share_name, fpath))
    for file in files:
      print(" - " + file.filename)
    print("count: %s" % len(files))

  # add a file to ~/.smb-credentials
  # username = xxx
  # password = yyy
  def init_credential(self):
    cfile_path = self.get_opt('credential')
    cfile_path = os.path.expandvars(cfile_path)
    ct = OrderedDict()
    with open(cfile_path, 'r') as f:
      for line in f:
        line = line.strip()
        tokens = line.split('=')
        if len(tokens) <= 1:
          continue
        if len(tokens) != 2:
          fatal("invalid line: " + line + " in " + cfile_path)
        ct[tokens[0].strip()] = tokens[1].strip()
    env = self.env
    if not "username" in ct:
      fatal("username not found in " + cfile_path)
    if not "password" in ct:
      fatal("password not found in " + cfile_path)
    env.smb_username = ct["username"]
    env.smb_password = ct["password"]
    env.share_name = self.get_opt('share_name')
    env.host = self.get_opt('host')
    env.local_ip = runex("hostname -I | awk '{print $1}'")
    env.me = runex("whoami")
    env.share_name = self.get_opt('share_name')

  def get(self):
    if len(self.get_targets()) == 0:
      fatal("./ugbt smb -g <src> [dest]")
    fpath = self.get_targets()[0]
    if len(self.get_targets()) > 2:
      fatal("./ugbt smb -g <src> [dest]")
    if len(self.get_targets()) == 2:
      dest = self.get_targets()[1]
    else:
      dest = "smb_get.dat"

    self.connect()
    env = self.env
    ff = env.conn.getAttributes(env.share_name, fpath)
    if ff.isDirectory:
      fatal("%s %s %s is a directory" % (env.host, env.share_name, fpath))
    fp = open(dest, "wb")
    info("downloading ...")
    env.conn.retrieveFile(env.share_name, fpath, fp)
    fp.close()
    info("Copy %s %s %s to < %s > OK" % (env.host, env.share_name, fpath, dest))

  def put(self):
    env = self.env
    conn = SambaConnection.instance(env.host)
    src_file = self.get_targets()[0]
    fpath = self.get_targets()[1]
    conn.upload(src_file, env.share_name, fpath)

  def mkdir(self):
    if len(self.get_targets()) != 1:
      fatal("./ugbt smb -m <dir>")
    fpath = self.get_targets()[0]
    self.connect()
    env = self.env
    try:
      ff = env.conn.getAttributes(env.share_name, fpath)
      fatal("%s %s %s exists" % (env.host, env.share_name, fpath))
    except Exception as e:
      pass

    env.conn.createDirectory(env.share_name, fpath)
    info("mkdir %s %s %s OK" % (env.host, env.share_name, fpath))

  def delete_dir_recursive(self, share_name, dir_path):
    env = self.env
    conn = env.conn
    items = conn.listPath(env.share_name, dir_path)
    for item in items:
      if item.filename in ['.', '..']:
        continue
      full_path = f"{dir_path}/{item.filename}"
      if item.isDirectory:
        self.delete_dir_recursive(share_name, full_path)
      else:
        conn.deleteFiles(share_name, full_path)
    conn.deleteDirectory(share_name, dir_path)

  def rm(self):
    env = self.env
    self.connect()
    for target in self.get_targets():
      if len(target) < 20:
        fatal("target too short")
      ff = env.conn.getAttributes(env.share_name, target)
      if ff.isDirectory:
        self.delete_dir_recursive(env.share_name, target)
      else:
        info("skipped - " + target)

  def main(self):
    self.init_credential()
    if self.get_opt('list'):
      self.list()
      return 0
    elif self.get_opt('get'):
      self.get()
      return 0
    elif self.get_opt('put'):
      self.put()
      return 0
    elif self.get_opt('mkdir'):
      self.mkdir()
      return 0
    elif self.get_opt('rm'):
      self.rm()
      return 0
    else:
      fatal("add -l --list or -g --get or -p --put")
    return 0
