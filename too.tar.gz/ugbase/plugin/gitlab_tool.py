from collections import OrderedDict
import os
from ug_common import dump_json, dump_yaml, fatal, info, load_yaml_f, read_file
import ug_cmd_base
import gitlab

_DEVELOPER_ACCESS = 30
_MAINTAINER_ACCESS = 40


def get_gitlab_access_level(level):
  """根据权限等级数字返回权限名称"""
  access_levels = {
      0: "无访问权限",
      10: "访客（Guest）",
      20: "报告者（Reporter）",
      30: "开发者（Developer）",
      40: "维护者（Maintainer）",
      50: "所有者（Owner）"
  }
  return access_levels.get(level, "未知权限等级")


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "gitlab", "gitlab tool", [
        ('V', 'verbose', "show verbose log", False),
        ('p', 'project', "project parameter", "firmware/scm/ugbase"),
        ('b', 'branch', "test branch", "test_branch"),
    ])

  def __list_user(self, gl):
    env = self.env
    gitlab_users_lst_ori = gl.users.list(get_all=True)
    gitlab_users_lst = []
    for user in gitlab_users_lst_ori:
      if user.username.startswith("project_") or \
              user.username.startswith("group_") or \
              user.name == "Administrator":
        continue
      gitlab_users_lst.append(user)

    gitlab_users_dict = OrderedDict()
    print("gitlab users:")
    for user in gitlab_users_lst:
      print("- %4d %20s st %s %s" % (user.id, user.username, user.state, user.name))
      gitlab_users_dict[user.username] = user
    print(" - gitlab %d users" % len(gitlab_users_lst))
    print("---")
    users_conf = os.path.join(env.root, "dev", "users.yaml")
    conf_users = load_yaml_f(users_conf)
    gitlab_users_in_conf = {}
    for user_key in conf_users.keys():
      gitlab_user = conf_users[user_key]["gitlab"]
      gitlab_users_in_conf[gitlab_user] = user_key

    print("strangers:")
    count = 0
    found = 0
    found_set = set()
    for gitlab_user in gitlab_users_dict:
      if not gitlab_user in gitlab_users_in_conf:
        user = gitlab_users_dict[gitlab_user]
        print("- %4d %20s st %s %s" % (user.id, user.username, user.state, user.name))
        count += 1
      else:
        found += 1
        found_set.add(gitlab_users_in_conf[gitlab_user])
    print(" - %d strangers, %d acquaintances" % (count, found))
    print("---")
    print("no git account")
    for user_key in conf_users.keys():
      if not user_key in found_set:
        user = conf_users[user_key]
        print("%s %s" % (user["name"], user["ename"]))

  def __list_project(self, gl):
    projects = gl.projects.list(get_all=True)
    for project in projects:
      print(project.path_with_namespace)

  def __list_group(self, gl):
    groups = gl.groups.list(get_all=True)
    for group in groups:
      print("-----------")
      print("%s %s %s" % (group.id, group.name, group.full_path))
      try:
        members = group.members_all.list(all=True)
        for member in members:
          # print(" - %4d %20s [%s] %s" % (member.id, member.name, member.username, member.access_level))
          print(" - %4d %20s [%s] %s" % (member.id, member.name,
                member.username, get_gitlab_access_level(member.access_level)))
          # access_level, avatar_url, created_at, expires_at, id, membership_state, name, state, username, web_url
        print(" -----")
        projects = group.projects.list(all=True)
        for project in projects:
          print(" - " + project.path_with_namespace)
      except Exception as e:
        print(" - access denied")

  def __get_project(self, gl):
    project_name = self.get_opt('project')
    project = gl.projects.get(project_name)
    print("%d %s" % (project.id, project.path_with_namespace))
    direct_members = project.members.list()

    print("direct member %d" % len(direct_members))
    for member in direct_members:
      print(" - %4d %20s [%s] %s" % (member.id, member.name, member.username, member.access_level))

    all_members = project.members_all.list()
    print("all member %d" % len(all_members))
    for member in all_members:
      print(" - %4d %20s [%s] %s" % (member.id, member.name, member.username, member.access_level))

    groups = project.groups.list()
    print("groups %d" % len(groups))
    for group in groups:
      print(" - %s %s %s" % (group.id, group.name, group.full_path))
      try:
        group = gl.groups.get(group.id)
        members = group.members_all.list(all=True)
        for member in members:
          print("   - %4d %20s [%s] %s" % (member.id, member.name, member.username, member.access_level))
      except Exception as ex:
        print("   - access denied")

    groups = project.shared_with_groups
    print("share groups %d" % len(groups))
    for group in groups:
      print(" - %d %s %s %s" % (group["group_id"], group["group_full_path"],
            group["group_access_level"], group["group_name"]))
      try:
        group = gl.groups.get(group["group_id"])
        members = group.members_all.list(all=True)
        for member in members:
          print("   - %4d %20s [%s] %s" % (member.id, member.name, member.username, member.access_level))
      except Exception as ex:
        print("   - access denied")

  def __get_protected_branch(self, gl):
    project_name = self.get_opt('project')
    project = gl.projects.get(project_name)
    print("%d %s" % (project.id, project.path_with_namespace))
    protected_branches = project.protectedbranches.list(all=True)
    for b in protected_branches:
      print(" - %s" % b.name)
      print("   - allow_force_push %s" % b.allow_force_push)
      print("   - code_owner_approval_required %s" % b.code_owner_approval_required)
      print("   - merge access: " + dump_json(b.merge_access_levels))
      print("   - push access: " + dump_json(b.push_access_levels))
      print("   - unprotect_access_levels: " + dump_json(b.unprotect_access_levels))

  def __set_protected_branch(self, gl):
    project_name = self.get_opt('project')
    project = gl.projects.get(project_name)
    print("%d %s" % (project.id, project.path_with_namespace))

    branch = "origin/" + self.get_opt('branch')
    try:
      protected_branch = project.protectedbranches.get(branch)
    except Exception as ex:
      protected_branch = None

    if protected_branch:
      protected_branch.name = branch
      protected_branch.merge_access_level = _DEVELOPER_ACCESS
      protected_branch.allow_force_push = True
      protected_branch.save()
    else:
      project.protectedbranches.create({
          'name': branch,
          'merge_access_level': _DEVELOPER_ACCESS,
          'push_access_level': _MAINTAINER_ACCESS,
          'allow_force_push': False
      })

  def __rm_protected_branch(self, gl):
    project_name = self.get_opt('project')
    project = gl.projects.get(project_name)
    print("%d %s" % (project.id, project.path_with_namespace))

    branch = "origin/" + self.get_opt('branch')
    try:
      protected_branch = project.protectedbranches.get(branch)
    except Exception as ex:
      protected_branch = None
      fatal(branch + " not found")
    protected_branch.delete()

  def main(self):
    env = self.env
    hostname = "gitlab.ugnas.com"
    token_file = os.path.join(env.home, ".ugreen", "gitlab-token@" + hostname)
    if not os.path.exists(token_file):
      info("visit http://" + hostname + "/-/profile/personal_access_tokens")
      info("get the token and write to the file $HOME/.ugreen/gitlab-token@" + hostname)
      info("then run 'chmod 600 $HOME/.ugreen/gitlab-token@" + hostname + "'")
      fatal(token_file + " not found")
    token = read_file(token_file).strip()
    gl = gitlab.Gitlab(
        url="https://" + hostname,
        private_token=token
    )
    gl.auth()
    user = gl.user
    info(user.username)

    if len(self.get_targets()) == 0:
      fatal("input command")

    cmd = self.get_targets()[0]
    if cmd == "listuser":
      self.__list_user(gl)
    elif cmd == "listproject":
      self.__list_project(gl)
    elif cmd == "listgroup":
      self.__list_group(gl)
    elif cmd == "getproject":
      self.__get_project(gl)
    elif cmd == "getprotectedbranch":
      self.__get_protected_branch(gl)
    elif cmd == "setprotectedbranch":
      self.__set_protected_branch(gl)
    elif cmd == "rmprotectedbranch":
      self.__rm_protected_branch(gl)
    elif cmd == "rmprotectedbranch":
      self.__rm_protected_branch(gl)
    else:
      fatal("unknown command " + cmd)
    return 0
