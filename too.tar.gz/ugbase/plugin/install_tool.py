import os
from ug_build_platform import BuildPlatform
from ug_common import get_ugdata, info, run, md5, tool_set_job_count
from ug_utils import GS, UgProject
import ug_cmd_base


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "install", "install package to $LOCAL_REPO default use LOCAL_REPO of conf/build_env.yaml", [
        ('V', 'verbose', 'show verbose information', False),
        ('v', 'build-var', 'build vars', ""),
        ('p', 'platform', 'use platform string instead of --build-var -v', ""),
        ('d', 'dry-run', 'run dry-run mode', False),
        ('a', 'all', 'try to pack all avilable platforms, if this option is set, the --build-var input is skipped', False),
        ('l', 'list-only', 'list all platforms only', False),
        ('j', 'job', 'task count of running jobs, default `nproc`, if > 16 then 16', ""),
    ])

  def main(self):
    tool_set_job_count(self)
    env = self.env
    dry_run = self.get_opt('dry-run')
    if self.get_opt('list-only'):
      dumpy_proj = UgProject.load(self.env, [])
      platforms = dumpy_proj.get_all_platforms()
      for platform in platforms:
        print(" - " + platform.get_sorted_str())
    elif self.get_opt('all'):
      dumpy_proj = UgProject.load(self.env, [])
      platforms = dumpy_proj.get_all_platforms()
      install_dirs = []
      for platform in platforms:
        info("start pack " + platform.get_sorted_str() + " ...")
        proj = UgProject.load(env, {}, platform=platform)
        install_path = proj.get_install_path()
        proj.gen_makefiles()
        proj.make(GS.INSTALL, dry_run=dry_run)
        info("pack " + platform.get_sorted_str() + " OK")

        install_dir = os.path.join(get_ugdata(), GS.REPO, install_path)
        install_dirs.append(install_dir)
      for install_dir in install_dirs:
        info("install to < %s > OK" % install_dir)
    else:
      pstr = self.get_opt("platform")
      if pstr:
        platform = BuildPlatform.parse(env, pstr)
        proj = UgProject.load(env, {}, platform=platform)
      else:
        vars = self.get_opts('build-var')
        proj = UgProject.load(env, vars)
      install_path = proj.get_install_path()

      proj.gen_makefiles()
      proj.make(GS.INSTALL, dry_run=dry_run)
      install_dir = os.path.join(get_ugdata(), GS.REPO, install_path)
      info("install to < %s > OK" % install_dir)
    return 0
