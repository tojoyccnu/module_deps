from collections import OrderedDict
import os
import re

import ug_cmd_base
from ug_common import dump_yaml, fatal, read_file, write_file
from ug_utils import GS, Repo, UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "repo-gen-build-tree",
                                     "generate build tree yaml from repo workspace; "
                                     "only schema-version v1 ugreen_project.yaml is supported", [
                                         ('V', 'verbose', 'show verbose information', False),
                                         ('w', 'workspace', 'repo workspace root', '${HOME}/workspace'),
                                     ])

  def __get_ref(self, index):
    return "ref-%d" % index

  def __get_dep_ref(self, dep_obj, dep_refs):
    key = (dep_obj.name, dep_obj.branch, dep_obj.dep_ver)
    if key not in dep_refs:
      fatal("dep version not found in repo projects: %s@%s %s" % key)
    return dep_refs[key]

  def __build_version_yaml(self, projects, project_refs):
    ugbase_versions = OrderedDict()
    ugbase_modules = OrderedDict()
    modules = OrderedDict()
    ugbase_keys = set()
    for repo_path, proj, branch in projects:
      ugbase = proj.get_ugbase()
      ugbase_keys.add((ugbase.git, ugbase.branch, ugbase.revision))

    ugbase_version_refs = {}
    for i, key in enumerate(sorted(ugbase_keys, key=lambda item: "%s %s %s" % item), 1):
      version_ref = "v%d" % i
      ugbase_version_refs[key] = version_ref
      ugbase_versions[version_ref] = "%s %s %s" % key

    for repo_path, proj, branch in projects:
      ref = project_refs[repo_path]
      ugbase = proj.get_ugbase()
      key = (ugbase.git, ugbase.branch, ugbase.revision)
      ugbase_modules[ref] = ugbase_version_refs[key]
      modules[ref] = "%s %s" % (branch, proj.get_version_text())

    version_yaml = OrderedDict()
    version_yaml[GS.UGBASE] = OrderedDict()
    version_yaml[GS.UGBASE]["versions"] = ugbase_versions
    version_yaml[GS.UGBASE]["modules"] = ugbase_modules
    version_yaml["modules"] = modules
    return version_yaml

  def __load_external_project_patterns(self):
    conf_file = os.path.join(os.getcwd(), "extenal_project.conf")
    if not os.path.isfile(conf_file):
      return []
    return [line.strip() for line in read_file(conf_file).splitlines() if line.strip()]

  def __is_external_project(self, project, external_project_patterns):
    for pattern in external_project_patterns:
      if re.search(pattern, project):
        return True
    return False

  def __load_projects(self, workspace, external_project_patterns):
    repo = Repo(workspace)
    workspace = repo.get_workspace()
    projects = []
    for repo_path in repo.read_project_paths():
      if self.__is_external_project(repo_path, external_project_patterns):
        continue
      if not os.path.isdir(os.path.join(workspace, repo_path)):
        fatal("repo project not found: %s" % os.path.join(workspace, repo_path))
      proj = UgProject.load(self.env, [], root=os.path.join(workspace, repo_path))
      if proj.get_schema_version() != GS.V1:
        fatal("%s only supports %s %s ugreen_project.yaml: %s" % (
            self.cmd, GS.SCHEMA_VERSION, GS.V1, repo_path))
      projects.append((repo_path, proj, repo.get_project_branch(repo_path)))
    return projects

  def __check_dep_cycle(self, name, graph, state, visiting):
    status = state.get(name)
    if status == "done":
      return
    if status == "visiting":
      pos = visiting.index(name)
      fatal("cycle dependency: " + " -> ".join(visiting[pos:] + [name]))

    state[name] = "visiting"
    visiting.append(name)
    for dep_name in sorted(graph.get(name, [])):
      self.__check_dep_cycle(dep_name, graph, state, visiting)
    visiting.pop()
    state[name] = "done"

  def __check_deps(self, projects, external_project_patterns):
    names = set()
    graph = OrderedDict()
    for _, proj, _ in projects:
      name = proj.get_name()
      names.add(name)
      if name not in graph:
        graph[name] = set()

    for repo_path, proj, _ in projects:
      name = proj.get_name()
      for dep_obj in proj.get_deps():
        if dep_obj.name not in names:
          if self.__is_external_project(dep_obj.name, external_project_patterns):
            continue
          fatal("%s depends on missing project: %s" % (repo_path, dep_obj.name))
        graph[name].add(dep_obj.name)

    state = {}
    for name in sorted(graph.keys()):
      self.__check_dep_cycle(name, graph, state, [])

  def __get_project_version_counts(self, projects):
    versions = {}
    for _, proj, _ in projects:
      name = proj.get_name()
      if name not in versions:
        versions[name] = set()
      versions[name].add(proj.get_version_text())
    return {name: len(versions[name]) for name in versions}

  def __build_refs(self, projects):
    project_refs = OrderedDict()
    dep_refs = {}
    for i, (repo_path, proj, branch) in enumerate(projects, 1):
      ref = self.__get_ref(i)
      project_refs[repo_path] = ref
      key = (proj.get_name(), branch, proj.get_version_text())
      if key in dep_refs:
        fatal("duplicate project version: %s@%s %s" % key)
      dep_refs[key] = ref
    return project_refs, dep_refs

  def __build_project_yaml(self, repo_path, proj, project_refs, dep_refs,
                           project_version_counts, external_project_patterns):
    out = OrderedDict()
    out[GS.SCHEMA_VERSION] = GS.V2
    data = proj.get_data()
    for key, value in data.items():
      if key == GS.SCHEMA_VERSION:
        continue
      elif key == GS.VERSION:
        out["version-ref"] = project_refs[repo_path]
      elif key == GS.UGBASE:
        continue
      elif key == GS.DEPS:
        deps = []
        for dep_obj in proj.get_deps():
          if self.__is_external_project(dep_obj.name, external_project_patterns):
            deps.append(dep_obj.get_prefix())
          elif project_version_counts[dep_obj.name] > 1:
            ref = self.__get_dep_ref(dep_obj, dep_refs)
            deps.append("%s %s" % (dep_obj.get_prefix(), ref))
          else:
            deps.append(dep_obj.get_prefix())
        out[key] = deps
      else:
        out[key] = value
    return out

  def __generate_build_tree(self, workspace):
    external_project_patterns = self.__load_external_project_patterns()
    projects = self.__load_projects(workspace, external_project_patterns)
    self.__check_deps(projects, external_project_patterns)
    projects = sorted(projects, key=lambda item: item[0])

    project_version_counts = self.__get_project_version_counts(projects)
    project_refs, dep_refs = self.__build_refs(projects)

    building = OrderedDict()
    for repo_path, proj, _ in projects:
      building[repo_path] = self.__build_project_yaml(
          repo_path, proj, project_refs, dep_refs, project_version_counts, external_project_patterns)

    write_file("building.yaml", dump_yaml(building))
    write_file("building.version.yaml", dump_yaml(self.__build_version_yaml(projects, project_refs)))

  def main(self):
    self.__generate_build_tree(self.get_opt("workspace"))
    return 0
