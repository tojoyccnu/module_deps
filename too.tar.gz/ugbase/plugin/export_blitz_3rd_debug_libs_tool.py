# -*- coding: utf-8 -*-
"""
by liubin:
里面有些问题，包括并不限于：
1. 下载应该和公用资源库的下载缓存同步，以避免每次做重复下载
2. 默认的platform是全局定义的，不应该自己定义，默认值可能会调整
3. 选取哪个branch不应该find_compatiable，而应该根据manifest的指定明确获取，find_compatiable可能会调整
暂时先注释整个命令，以避免AI尝试修改本文件逻辑
-----
从 manifest.yaml 读取 deps，筛选 blitz/3rd/*，按 ugbase SMB 流程拉取 tar 包，
收集 lib/lib64 下 debug 产物到 <output-dir>/<stem>/lib/，并生成 <stem>-lib.tar.gz（解压顶层为 lib/）。

ugbt 调用示例：
  ugbt export-blitz-3rd-debug-libs \\
    -m /path/to/release_blitz_network-....manifest.yaml \\
    -o /data/jax/.ugreen.tmp/blitz_3rd_debug

  ugbt export-blitz-3rd-debug-libs -m 'kernel/debian12-utils/.../平台目录或xxx.manifest.yaml'

平台维度从 manifest 逻辑文件名自动解析；解析失败回退 release/amd64/intel/6.12.30+ 并 warning。


from __future__ import annotations

import os
import re
import shutil
import tarfile

import ug_cmd_base
from ug_build_platform import BuildPlatform
from ug_common import SambaConnection, dump_yaml, fatal, info, load_yaml_f, make_dir, uuid_gen, warning
from ug_utils import SmbDep, UgProject

DEPS_KEY = "deps"
BLITZ_3RD_PREFIX = "blitz/3rd/"

_DEFAULT_PLATFORM_KEYS = ["build_type", "cpu_arch", "arch_spu", "kernel"]
_DEFAULT_BUILD_PAIRS = ["build_type=release", "cpu_arch=amd64", "arch_spu=intel", "kernel=6.12.30+"]


class _UgbEnv:
  """与 _main.Config 一致的最小环境，供 UgProject.download_dep / BuildPlatform 使用。"""

  def __init__(self, ugbase_root: str):
    self.root = ugbase_root
    self.__build_env = None
    self.__build_vars = None
    self.__repo_root = None

  def get_build_env(self):
    if not self.__build_env:
      self.__build_env = load_yaml_f(os.path.join(self.root, "conf", "build_env.yaml"))
    return self.__build_env

  def get_build_vars(self):
    if not self.__build_vars:
      self.__build_vars = load_yaml_f(os.path.join(self.root, "conf", "build_vars.yaml"))
    return self.__build_vars

  def get_local_repo_root(self):
    if not self.__repo_root:
      if "LOCAL_REPO" in os.environ:
        local_repo = os.environ["LOCAL_REPO"]
        info("LOCAL_REPO=%s" % local_repo)
      else:
        local_repo = self.get_build_env()["LOCAL_REPO"]
      self.__repo_root = os.path.expandvars(local_repo)
    make_dir(self.__repo_root)
    return self.__repo_root


def _is_debug_artifact(rel_path: str) -> bool:
  lower = rel_path.lower()
  parts = lower.split("/")
  base = parts[-1] if parts else lower
  if base.endswith(".debug"):
    return True
  if base.endswith(".dwp"):
    return True
  if base.endswith(".dwo"):
    return True
  if "lib/debug/" in lower or "/lib/debug/" in lower:
    return True
  return False


def _collect_debug_files(lib_root: str) -> list[tuple[str, str]]:
  out: list[tuple[str, str]] = []
  if not os.path.isdir(lib_root):
    return out
  for dirpath, _dirnames, filenames in os.walk(lib_root):
    for fn in filenames:
      full = os.path.join(dirpath, fn)
      rel = os.path.relpath(full, lib_root)
      if _is_debug_artifact(rel.replace(os.sep, "/")):
        out.append((full, rel))
  return out


def _parse_smb_uri(manifest_arg: str) -> tuple[str, str, str] | None:
  raw = manifest_arg.strip()
  if not raw.lower().startswith("smb://"):
    return None
  rest = raw[6:]
  slash = rest.find("/")
  if slash < 0:
    fatal("无效的 smb:// URL（缺少路径）: " + manifest_arg)
  host = rest[:slash]
  path_part = rest[slash + 1:].strip("/")
  if not host or not path_part:
    fatal("无效的 smb:// URL: " + manifest_arg)
  seg = path_part.split("/", 1)
  share = seg[0]
  sub = seg[1] if len(seg) > 1 else ""
  return host, share, sub.replace("\\", "/")


def _parse_unc(manifest_arg: str) -> tuple[str, str, str] | None:
  raw = manifest_arg.strip().replace("\\", "/")
  if not raw.startswith("//"):
    return None
  parts = [p for p in raw[2:].split("/") if p]
  if len(parts) < 2:
    fatal("无效的 UNC 路径: " + manifest_arg)
  return parts[0], parts[1], "/".join(parts[2:])


def _manifest_local_cache_dir() -> str:
  d = os.path.join(os.path.expanduser("~"), ".ugreen.tmp", "export_blitz_3rd_manifest_cache")
  make_dir(d)
  return d


def _finalize_remote_manifest_file(conn: SambaConnection, host: str, share_name: str, remote_subpath: str) -> str:
  remote_subpath = remote_subpath.replace("\\", "/").strip("/")
  if not remote_subpath:
    fatal("SMB manifest 路径为空")
  base = os.path.basename(remote_subpath)
  if base.lower().endswith((".yaml", ".yml")):
    return remote_subpath
  if conn.isdir(share_name, remote_subpath):
    names = [n for n in conn.ls(share_name, remote_subpath) if n not in (".", "..")]
    cands = sorted([n for n in names if n.endswith(".manifest.yaml")])
    if len(cands) == 1:
      chosen = remote_subpath + "/" + cands[0]
      info("在 SMB 目录下选用 manifest 文件: %s" % chosen)
      return chosen
    if not cands:
      fatal(
          "SMB 目录下未找到 *.manifest.yaml: //%s/%s/%s\n列表示例: %s"
          % (host, share_name, remote_subpath, dump_yaml(names))
      )
    fatal(
        "SMB 目录下有多份 *.manifest.yaml，请指定完整文件名：\n%s\n路径: //%s/%s/%s"
        % (dump_yaml(cands), host, share_name, remote_subpath)
    )
  if conn.exists(share_name, remote_subpath):
    return remote_subpath
  fatal(
      "SMB 上不存在该路径（既不是带 .yaml 的文件名，也不是可列目录）: %s\n"
      "请确认路径相对 SMB_REPO 正确，或写成 smb:// 完整 URL。" % remote_subpath
  )


def _download_manifest_from_smb(host: str, share_name: str, remote_subpath: str) -> str:
  conn = SambaConnection.instance(host)
  remote_file = _finalize_remote_manifest_file(conn, host, share_name, remote_subpath)
  base = os.path.basename(remote_file) or "manifest.yaml"
  local_path = os.path.join(_manifest_local_cache_dir(), base + "." + uuid_gen() + ".tmp")
  info("从 SMB 下载 manifest: //%s/%s/%s -> %s" % (host, share_name, remote_file, local_path))
  conn.download(share_name, remote_file, local_path)
  if not os.path.isfile(local_path):
    fatal("下载后未找到本地文件: " + local_path)
  return os.path.abspath(local_path)


def _resolve_manifest_path(manifest_arg: str, env: _UgbEnv) -> str:
  raw = manifest_arg.strip().replace("\\", "/")
  expanded = os.path.expandvars(os.path.expanduser(raw))
  if os.path.isfile(expanded):
    return os.path.abspath(expanded)
  if os.path.isabs(expanded):
    if os.path.exists(expanded):
      fatal("manifest 必须是文件，而不是目录: " + expanded)
    fatal("本地 manifest 不存在: " + expanded)

  smb_triple = _parse_smb_uri(raw)
  if smb_triple:
    host, share, sub = smb_triple
    return _download_manifest_from_smb(host, share, sub)

  unc_triple = _parse_unc(raw)
  if unc_triple:
    host, share, sub = unc_triple
    return _download_manifest_from_smb(host, share, sub)

  be = env.get_build_env()
  host = be["SMB_HOST"]
  share_name = be["SMB_SHARE_NAME"]
  repo = be["SMB_REPO"].replace("\\", "/").strip("/")
  rel = expanded.replace("\\", "/").strip("/")
  remote_subpath = rel if not repo else (repo + "/" + rel)
  return _download_manifest_from_smb(host, share_name, remote_subpath)


def _manifest_logical_basename(manifest_path: str) -> str:
  base = os.path.basename(manifest_path)
  marker = ".manifest.yaml."
  if marker in base:
    return base.split(marker, 1)[0] + ".manifest.yaml"
  return base


def _manifest_output_stem(manifest_path: str) -> str:
  logical = _manifest_logical_basename(manifest_path)
  lower = logical.lower()
  for suf in (".manifest.yaml", ".manifest.yml"):
    if lower.endswith(suf):
      return logical[: len(logical) - len(suf)]
  for suf in (".yaml", ".yml"):
    if lower.endswith(suf):
      return logical[: len(logical) - len(suf)]
  return os.path.splitext(logical)[0]


def _infer_platform_from_manifest_path(manifest_path: str, env: _UgbEnv) -> tuple[list[str], list[str]]:
  logical = _manifest_logical_basename(manifest_path)
  m = re.search(r"-(\d+\.\d+\.\d+)\.(\d+)-(.+)\.manifest\.ya?ml$", logical, re.I)
  if not m:
    warning(
        "无法从 manifest 文件名解析平台（期望以 -<主版本>.<构建号>-<platform>.manifest.yaml 结尾）。\n"
        "  当前逻辑名: %s\n"
        "  已回退默认平台: %s" % (logical, ", ".join(_DEFAULT_BUILD_PAIRS))
    )
    return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)

  platform_short = m.group(3)
  parts = platform_short.split("_")
  bv = env.get_build_vars()
  keys_sorted = sorted(bv.keys())
  n = len(parts)
  if n < 1 or n > len(keys_sorted):
    warning(
        "manifest 文件名中平台段「%s」拆分为 %d 段，与 build_vars 维度数量不兼容，已回退默认平台。"
        % (platform_short, n)
    )
    return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)

  keys_used = keys_sorted[:n]
  build_pairs: list[str] = []
  for i, k in enumerate(keys_used):
    allowed = bv.get(k)
    if not isinstance(allowed, list):
      warning("build_vars 中缺少列表维度 %s，已回退默认平台。" % k)
      return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)
    vals = [str(x) for x in allowed]
    if parts[i] not in vals:
      warning(
          "manifest 平台段「%s」中第 %d 段「%s」不是合法的 %s（允许: %s），已回退默认平台。"
          % (platform_short, i + 1, parts[i], k, ", ".join(vals))
      )
      return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)
    build_pairs.append("%s=%s" % (k, parts[i]))

  try:
    bp = BuildPlatform(env, build_pairs, keys_used)
  except Exception as ex:
    warning("从文件名构建 BuildPlatform 失败: %s，已回退默认平台。" % ex)
    return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)

  if bp.get_sorted_short_str() != platform_short:
    warning(
        "从文件名还原的平台 short 串不一致（文件名中为「%s」，按规则重组为「%s」），已回退默认平台。"
        % (platform_short, bp.get_sorted_short_str())
    )
    return list(_DEFAULT_PLATFORM_KEYS), list(_DEFAULT_BUILD_PAIRS)

  info("已从 manifest 文件名解析构建平台: %s" % bp.get_sorted_str())
  return keys_used, build_pairs


def export_blitz_3rd_debug_libs_main(manifest_arg: str, output_dir: str, ugbase_root: str) -> int:
  """供 ugbt Tool 与单元测试调用；manifest_arg 同原 - -manifest 语义。"""
  env = _UgbEnv(os.path.abspath(ugbase_root))
  manifest_path = _resolve_manifest_path(manifest_arg, env)

  data = load_yaml_f(manifest_path)
  raw_deps = data.get(DEPS_KEY)
  if not raw_deps:
    fatal("manifest 中无 deps: " + manifest_path)

  branch_default = (data.get("branch") or "").strip()
  if not branch_default:
    fatal("manifest 缺少 branch 字段，无法解析依赖（请在 yaml 中填写 branch）: " + manifest_path)

  os.environ["BRANCH"] = branch_default

  third_deps = [d for d in raw_deps if isinstance(d, str) and d.strip().startswith(BLITZ_3RD_PREFIX)]
  if not third_deps:
    fatal("deps 中未找到前缀 %s 的项" % BLITZ_3RD_PREFIX)

  platform_keys, build_pairs = _infer_platform_from_manifest_path(manifest_path, env)

  platform = BuildPlatform(env, build_pairs, platform_keys)
  info("平台: %s" % platform.get_sorted_str())

  out_root = os.path.abspath(os.path.expandvars(output_dir))
  make_dir(out_root)

  stem = _manifest_output_stem(manifest_path)
  if not stem or stem in (".", ".."):
    fatal("无法从 manifest 得到有效输出目录名: %s" % manifest_path)
  out_dest = os.path.join(out_root, stem)
  if os.path.isdir(out_dest):
    shutil.rmtree(out_dest)
  make_dir(out_dest)
  out_lib = os.path.join(out_dest, "lib")
  make_dir(out_lib)

  seen_basename: dict[str, str] = {}

  for dep_line in third_deps:
    dep_line = dep_line.strip()
    dep = SmbDep.parse(dep_line, branch_default, [manifest_path])
    dep_path = os.path.join(dep.name, dep.branch, dep.version, str(dep.build_number))

    local_dir = platform.search_compatiable_pack_in_local(dep_path)
    if not local_dir:
      remote_dir = platform.search_compatiable_pack_in_remote(dep_path)
      if not remote_dir:
        fatal("无法定位依赖（本地与 SMB 均无匹配平台目录）: %s" % dep)
      UgProject.download_dep(env, dep, dep_path, remote_dir)
      local_dir = platform.search_compatiable_pack_in_local(dep_path)
      if not local_dir:
        fatal("下载后仍无法定位本地依赖: %s" % dep)

    pack_name = UgProject.get_dep_pack_name(env, dep, local_dir)
    pack_root = os.path.join(env.get_local_repo_root(), dep_path, local_dir, pack_name)
    matches: list[str] = []
    for lib_sub in ("lib", "lib64"):
      lib_root = os.path.join(pack_root, lib_sub)
      for full, _rel in _collect_debug_files(lib_root):
        matches.append(full)
    if not matches:
      info("跳过（lib/lib64 下无 debug 产物）: %s -> %s" % (dep, pack_root))
      continue

    for full in matches:
      name = os.path.basename(full)
      dst = os.path.join(out_lib, name)
      if name in seen_basename:
        warning(
            "重名跳过: 文件名「%s」已导出自「%s」，不再写入「%s」（请按需手工合并或改 manifest 集合）。"
            % (name, seen_basename[name], full)
        )
        continue
      shutil.copy2(full, dst)
      seen_basename[name] = full
      info("导出 %s -> %s" % (full, dst))

  if not any(os.scandir(out_lib)):
    warning("未导出任何 debug 文件，不生成 tar 包。输出目录: %s" % out_dest)
  else:
    tar_path = os.path.join(out_root, "%s-lib.tar.gz" % stem)
    if os.path.isfile(tar_path):
      os.remove(tar_path)
    with tarfile.open(tar_path, "w:gz", format=tarfile.GNU_FORMAT) as tf:
      for ent in os.scandir(out_lib):
        if ent.is_file(follow_symlinks=False):
          tf.add(ent.path, arcname=os.path.join("lib", ent.name))
    info("已生成 tar 包（解压后顶层为 lib/）: %s" % tar_path)

  info("完成，共处理 blitz/3rd 依赖 %d 条，输出目录: %s（内含 lib/）" % (len(third_deps), out_dest))
  return 0


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    # 须与「子命令名」写在同一行：ug_cmd_base.run_tool 用 grep .CommandTool.__init__|grep <cmd> 定位插件文件
    ug_cmd_base.CommandTool.__init__(self, env, "export-blitz-3rd-debug-libs", "export blitz/3rd debug libs from manifest (lib/ + tar.gz under output-dir)", [
        ("m", "manifest", "manifest: local path, smb://..., UNC //..., or path under SMB_REPO; directory may contain single *.manifest.yaml", None),
        ("o", "output-dir", "output root: <stem>/lib/ and <stem>-lib.tar.gz", "/data/jax/.ugreen.tmp/blitz_3rd_debug_export"),
        ("r", "ugbase-root", "ugbase root (conf/); default: ugbt repo root", env.root),
    ])

  def main(self):
    return export_blitz_3rd_debug_libs_main(
        self.get_opt("manifest"),
        self.get_opt("output-dir"),
        self.get_opt("ugbase-root"),
    )
"""
