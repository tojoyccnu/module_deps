import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "manifest", "generate manifest file of a project", [
        ('d', 'dir', 'install dir', None),
        ('p', 'pack', 'pack name', None),
    ])

  def main(self):
    pack_dir = self.get_opt('dir')
    pack_name = self.get_opt('pack')
    vars = []
    proj = UgProject.load(self.env, vars)
    proj.generate_manifest(pack_dir, pack_name)
    return 0
