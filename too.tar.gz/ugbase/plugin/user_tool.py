from collections import OrderedDict
import copy
import os
from ug_common import dump_yaml, error, fatal, info, load_yaml_f, read_file, warning, write_file
import ug_cmd_base

import unicodedata


def get_display_width(s):
  width = 0
  for char in s:
    if unicodedata.east_asian_width(char) in ('W', 'F'):  # 全角字符
      width += 2
    else:
      width += 1
  return width


def align_text(text, wid):
  text_wid = get_display_width(text)
  padding = max(0, wid - text_wid)
  ret = ' ' * padding + text
  return ret


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "user", "user tool", [
    ])

  def __list_user(self):
    env = self.env
    user_conf = os.path.join(env.root, "dev", "users.yaml")
    users = load_yaml_f(user_conf)

    eidset = set()
    valid_keys = ["name", "ename", "eid", "gitlab", "dingding", "samba", "did"]
    for email_prefix in users.keys():
      user = users[email_prefix]
      eid = user.get("eid", -1)
      if eid != -1:
        if eid in eidset:
          fatal("duplicate eid found: " + str(eid))
        eidset.add(eid)
      for user_key in user.keys():
        if not user_key in valid_keys:
          fatal("invalid user key %s in [%s]" % (user_key, dump_yaml(user)))

    print("%15s %15s %5s %20s %15s %15s %s" % ("ename", "email", "eid", "gitlab", "dingding", "samba", "name"))
    for email_prefix in users.keys():
      user = users[email_prefix]
      print("%15s %15s %5s %20s %s %s %s" % (user["ename"], email_prefix,
                                             user.get("eid", "??"),
                                             user.get("gitlab", "??"),
                                             align_text(user.get("dingding", "??"), 15),
                                             align_text(user.get("samba", "??"), 15),
                                             user["name"]))
    print("%d users" % len(users))

  def __show_group(self):
    env = self.env
    users_conf = os.path.join(env.root, "dev", "users.yaml")
    users = load_yaml_f(users_conf)
    users_x = copy.deepcopy(users)

    groups_conf = os.path.join(env.root, "dev", "groups.yaml")
    groups = load_yaml_f(groups_conf)
    for group in groups.keys():
      print(group)
      lst = groups[group]
      us = set()
      for user_key in lst:
        if user_key in users_x:
          del users_x[user_key]
        if not user_key in users:
          fatal(user_key + " not found in group [%s]" % group)
        if user_key in us:
          fatal(user_key + " duplicate in group [%s]" % group)
        us.add(user_key)
        user = users[user_key]
        print(" - %15s %15s %s" % (user_key, user["ename"], user["name"]))
      print("%d users in group %s" % (len(lst), group))
      print("-----")
    group = "no-group"
    print(group)
    for user_key in users_x.keys():
      user = users_x[user_key]
      print(" - %15s %15s %s" % (user_key, user["ename"], user["name"]))
    print("%d users in group %s" % (len(users_x), group))

    print("-> auto ugbt update register info:")
    obj = load_yaml_f(os.path.join(env.root, "dev", "auto_ugbt_update.yaml"))
    for git_url in obj.keys():
      reg_item = obj[git_url]
      branches = reg_item["branch"]
      print(git_url)
      for branch in branches:
        print(" - " + branch)
      print("owner:")
      owners = reg_item["owner"]
      for owner in owners:
        if not owner in users:
          fatal("owner [%s] in auto_ugbt_update.yaml is not a valid user in <ugbase>/dev/users.yaml" % owner)
        else:
          user = users[owner]
          if not "did" in user:
            fatal("did(dingding id) not found in users.yaml, ask for hr to get the private dingding id")
          if type(user["did"]).__name__ != "str":
            fatal("did type of [%s] is %s not str" % (user, type(user["did"]).__name__))
          print(" - " + owner + " " + user["did"])

  def __sync(self):
    env = self.env
    targets = self.get_targets()
    if len(targets) != 2:
      fatal("run 'ugbt user sync users.txt'")
    user_txt_file = targets[1]
    content = read_file(user_txt_file)
    lines = content.split('\n')
    user_file = os.path.join(env.root, "dev", "users.yaml")
    users = load_yaml_f(user_file)
    users_dict = OrderedDict()
    for email in users.keys():
      user = copy.deepcopy(users[email])
      user_key = user["name"]
      user_key += "-" + user["ename"]
      user["email"] = email
      users_dict[user_key] = user

    valid_users = set()
    for line in lines:
      line = line.strip()
      if line:
        tokens = line.split()
        if len(tokens) == 4:
          new_tokens = [tokens[0], tokens[1], tokens[2], tokens[2], tokens[3]]
          tokens = new_tokens

        if len(tokens) != 5:
          fatal("invalid line: " + line)
        did = tokens[1]
        ename = tokens[2]
        name = tokens[3]
        eid = int(tokens[4])
        user_key = name + "-" + ename
        if not user_key in users_dict:
          warning(user_key + " not found")
          continue
        email = users_dict[user_key]["email"]
        if not "eid" in users_dict[user_key]:
          users[email]["eid"] = eid
        elif users_dict[user_key]["eid"] != eid:
          error("eid not match %s != %s of %s" % (users_dict[user_key]["eid"], eid, user_key))

        email = users_dict[user_key]["email"]
        users[email]["did"] = str(did)
        users[email]["eid"] = eid
        valid_users.add(user_key)

    current_users = set(users_dict.keys())
    s1 = current_users - valid_users
    if len(s1) > 0:
      error("s1 " + str(len(s1)))
      for s in s1:
        error(" - " + s)
    s2 = valid_users - current_users
    if len(s2) > 0:
      error("s2 " + str(len(s2)))
      for s in s2:
        error(" - " + s)
    write_file(user_file, dump_yaml(users))

  def main(self):
    if len(self.get_targets()) == 0:
      fatal("input command")

    cmd = self.get_targets()[0]
    if cmd == "list":
      self.__list_user()
    elif cmd == "showgroup":
      self.__show_group()
    elif cmd == "sync":
      self.__sync()
    else:
      fatal("unknown command " + cmd)
    return 0
