import json
import os
import re
import subprocess
import sys

import ug_cmd_base
from ug_common import SambaConnection, fatal, info, run, warning
from ug_utils import GS, SmbDep, UgProject

_RELEASE_BRANCH_RE = re.compile(r"^release_(\d{8})$")


def _current_git_branch(project_root):
  return subprocess.check_output(
      ["git", "-C", project_root, "rev-parse", "--abbrev-ref", "HEAD"],
      text=True,
  ).strip()


def _assert_working_tree_clean(project_root, cmd_label):
  """要求 index 与工作区相对 HEAD 无任何变更（含未跟踪文件；与 git status --porcelain 一致）。"""
  try:
    out = subprocess.check_output(
        ["git", "-C", project_root, "status", "--porcelain"],
        text=True,
    )
  except subprocess.CalledProcessError as ex:
    fatal("%s: 无法执行 git status: %s" % (cmd_label, ex))
  porcelain = out.strip()
  if not porcelain:
    return
  preview = porcelain if len(porcelain) <= 4000 else porcelain[:4000] + "\n..."
  fatal(
      "%s: 要求当前 git 仓库工作区干净（无已暂存/未暂存修改、无未跟踪且未忽略的文件等）。"
      "请先 git stash / 提交 / 删除无关文件后再执行。\n当前 git status --porcelain:\n%s"
      % (cmd_label, preview)
  )


def _git_first_remote(project_root):
  try:
    out = subprocess.check_output(
        ["git", "-C", project_root, "remote"],
        text=True,
    ).strip()
  except subprocess.CalledProcessError:
    return ""
  lines = [ln.strip() for ln in out.split("\n") if ln.strip()]
  return lines[0] if lines else ""


def _release_new_branch_already_exists(project_root, branch):
  """本地已有 refs/heads/<branch>，或默认 remote 上已有同名分支（含已 fetch 的远程跟踪）。"""
  r = subprocess.run(
      ["git", "-C", project_root, "show-ref", "--verify", "--quiet", "refs/heads/%s" % branch],
  )
  if r.returncode == 0:
    return True, "本地"
  remote = _git_first_remote(project_root)
  if not remote:
    return False, ""
  rref = "refs/remotes/%s/%s" % (remote, branch)
  if subprocess.run(
      ["git", "-C", project_root, "show-ref", "--verify", "--quiet", rref],
  ).returncode == 0:
    return True, "远程跟踪 %s/%s" % (remote, branch)
  try:
    out = subprocess.check_output(
        [
            "git",
            "-C",
            project_root,
            "ls-remote",
            "--heads",
            remote,
            "refs/heads/%s" % branch,
        ],
        text=True,
        stderr=subprocess.DEVNULL,
        timeout=90,
    ).strip()
  except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as ex:
    fatal(
        "release new: 无法向远程 %s 确认分支 %s 是否已存在（%s），请检查网络后重试"
        % (remote, branch, ex)
    )
  if out:
    return True, "远程 %s" % remote
  return False, ""


def _git_checkout_existing_branch(project_root, branch):
  remote = _git_first_remote(project_root) or "origin"
  loc = subprocess.run(
      ["git", "-C", project_root, "show-ref", "--verify", "--quiet", "refs/heads/%s" % branch],
  )
  if loc.returncode == 0:
    subprocess.run(["git", "-C", project_root, "checkout", branch], check=True)
    return
  rref = "refs/remotes/%s/%s" % (remote, branch)
  if subprocess.run(
      ["git", "-C", project_root, "show-ref", "--verify", "--quiet", rref],
  ).returncode == 0:
    subprocess.run(
        ["git", "-C", project_root, "checkout", "-B", branch, rref],
        check=True,
    )
    return
  subprocess.run(
      ["git", "-C", project_root, "fetch", remote, "%s:%s" % (branch, branch)],
      check=True,
  )
  subprocess.run(["git", "-C", project_root, "checkout", branch], check=True)


def _handle_release_new_branch_exists(project_root, new_branch, where_label):
  print("", file=sys.stderr)
  print(
      "目标分支 %s 已存在（%s），已终止 release new（不会修改 version / deps / project.json）"
      % (new_branch, where_label),
      file=sys.stderr,
      flush=True,
  )
  if not sys.stdin.isatty():
    rm = _git_first_remote(project_root) or "origin"
    fatal(
        "release new: 目标分支已存在。如需切换: git -C <仓库> fetch %s %s && git checkout %s"
        % (rm, new_branch, new_branch)
    )
  while True:
    print("\n是否切换到该分支?", file=sys.stderr, flush=True)
    print("  [y] 是", file=sys.stderr, flush=True)
    print("  [n] 否，保持当前分支并退出", file=sys.stderr, flush=True)
    try:
      choice = input().strip().lower()
    except EOFError:
      choice = "n"
    if choice in ("y", "yes"):
      _git_checkout_existing_branch(project_root, new_branch)
      os.environ["BRANCH"] = new_branch
      info("release new: 已切换到分支 %s" % new_branch)
      return 0
    if choice in ("n", "no", "q", ""):
      info("release new: 未切换分支，当前分支未变")
      return 0
    print("无效输入，请输入 y 或 n", file=sys.stderr, flush=True)


def _git_show_diff(project_root, paths=None):
  """直接写到 stderr，配合 --color=always 在终端显示彩色 diff（不经 logger，避免 ANSI 被处理掉）。
  paths 非空时仅展示这些路径相对 HEAD 的差异（与仅提交这些文件一致）。"""
  tail = (["--"] + list(paths)) if paths else []
  stat = subprocess.check_output(
      ["git", "-C", project_root, "diff", "--color=always", "--stat"] + tail,
      text=True,
  )
  print("\n----- git diff --stat -----", file=sys.stderr, flush=True)
  print(stat.strip() if stat.strip() else "(无工作区差异)", file=sys.stderr, flush=True)
  full = subprocess.check_output(
      ["git", "-C", project_root, "diff", "--color=always"] + tail,
      text=True,
  )
  body = full.rstrip() if full else ""
  if len(body) > 24000:
    print(
        "\n----- git diff（内容过长已省略，请在仓库内执行 git diff --color=always）-----",
        file=sys.stderr,
        flush=True,
    )
  else:
    print("\n----- git diff -----", file=sys.stderr, flush=True)
    print(body if body else "(无)", file=sys.stderr, flush=True)


def _rollback_release_new(project_root, old_branch, new_branch):
  subprocess.run(
      ["git", "-C", project_root, "reset", "--hard", "HEAD"],
      check=True,
  )
  subprocess.run(
      ["git", "-C", project_root, "checkout", old_branch],
      check=True,
  )
  subprocess.run(
      ["git", "-C", project_root, "branch", "-D", new_branch],
      check=True,
  )
  os.environ["BRANCH"] = old_branch
  info("release new: 已回滚到分支 %s，并已删除分支 %s" % (old_branch, new_branch))


def _release_new_commit_paths(project_root):
  """release new 可能改动的已跟踪文件（避免 git commit -a 把无关修改一并提交）。"""
  out = [GS.FILENAME]
  if os.path.isfile(os.path.join(project_root, "project.json")):
    out.append("project.json")
  return out


def _commit_and_push_release_new(project_root, new_branch, version_text):
  msg = "release new: %s 版本 %s" % (new_branch, version_text)
  for p in _release_new_commit_paths(project_root):
    subprocess.run(["git", "-C", project_root, "add", "--", p], check=True)
  try:
    subprocess.run(
        ["git", "-C", project_root, "commit", "-m", msg],
        check=True,
    )
  except subprocess.CalledProcessError:
    fatal("release new: git commit 失败（若无变更可选手动处理）")
  subprocess.run(
      ["git", "-C", project_root, "push", "-u", "origin", new_branch],
      check=True,
  )
  info("release new: 已推送分支 %s" % new_branch)


def _git_restore_one(project_root, relpath):
  r = subprocess.run(
      ["git", "-C", project_root, "restore", "--", relpath],
  )
  if r.returncode != 0:
    subprocess.run(
        ["git", "-C", project_root, "checkout", "HEAD", "--", relpath],
        check=True,
    )


def _rollback_tracked_paths(project_root, rel_paths, cmd_label):
  for p in rel_paths:
    _git_restore_one(project_root, p)
  info("%s: 已还原工作区文件 %s" % (cmd_label, ", ".join(rel_paths)))


def _commit_and_push_current_branch(project_root, commit_msg, cmd_label, paths_to_commit):
  """仅提交 paths_to_commit 中的路径（与回滚列表一致），不把其它已修改跟踪文件带进同一 commit。"""
  branch = _current_git_branch(project_root)
  for p in paths_to_commit:
    subprocess.run(["git", "-C", project_root, "add", "--", p], check=True)
  try:
    subprocess.run(
        ["git", "-C", project_root, "commit", "-m", commit_msg],
        check=True,
    )
  except subprocess.CalledProcessError:
    fatal("%s: git commit 失败（若无变更可选手动处理）" % cmd_label)
  subprocess.run(
      ["git", "-C", project_root, "push", "origin", branch],
      check=True,
  )
  info("%s: 已推送到 origin/%s" % (cmd_label, branch))


def _prompt_after_simple_edit(project_root, cmd_label, commit_msg, restore_rel_paths):
  """stable / release / update 等仅改若干已跟踪文件后的 diff 与 c/n/r 交互。"""
  diff_args = ["git", "-C", project_root, "diff", "--quiet", "--"] + restore_rel_paths
  if subprocess.run(diff_args).returncode == 0:
    info("%s: 指定文件相对 HEAD 无未提交差异，跳过 diff 与提交确认" % cmd_label)
    return 0

  _git_show_diff(project_root, restore_rel_paths)
  if not sys.stdin.isatty():
    warning(
        "%s: 当前非交互终端，已保留本地修改；请自行提交推送。回滚可对下列已跟踪文件依次 "
        "git restore -- <path> : %s" % (cmd_label, ", ".join(restore_rel_paths))
    )
    return 0

  rdesc = ", ".join(restore_rel_paths)
  while True:
    print("\n请选择下一步:", file=sys.stderr, flush=True)
    print("  [c] 提交并推送", file=sys.stderr, flush=True)
    print("  [n] 取消退出（保留未提交修改）", file=sys.stderr, flush=True)
    print("  [r] 回滚（还原 %s）" % rdesc, file=sys.stderr, flush=True)
    try:
      choice = input().strip().lower()
    except EOFError:
      choice = "n"
    if choice in ("c", "commit", "y", "yes", "p", "push"):
      _commit_and_push_current_branch(
          project_root, commit_msg, cmd_label, restore_rel_paths,
      )
      return 0
    if choice in ("r", "rollback", "abort"):
      _rollback_tracked_paths(project_root, restore_rel_paths, cmd_label)
      return 0
    if choice in ("n", "cancel", "q", ""):
      info("%s: 已取消提交/推送，当前修改仍保留在工作区" % cmd_label)
      return 0
    print("无效输入，请输入 c / n / r", file=sys.stderr, flush=True)


def _prompt_after_release_update(project_root):
  return _prompt_after_simple_edit(
      project_root,
      "release update",
      "release update: 分支 %s 同步 deps" % _current_git_branch(project_root),
      [GS.FILENAME],
  )


def _prompt_after_release_new(project_root, old_branch, new_branch, version_text):
  paths = _release_new_commit_paths(project_root)
  if subprocess.run(
      ["git", "-C", project_root, "diff", "--quiet", "--"] + paths,
  ).returncode == 0:
    info("release new: 指定文件相对 HEAD 无未提交差异，跳过 diff 与提交确认")
    return 0
  _git_show_diff(project_root, paths)
  if not sys.stdin.isatty():
    warning(
        "release new: 当前非交互终端，已保留本地修改；请自行 git diff 后提交推送。"
        "若需回滚：在仓库根目录于当前分支执行 git reset --hard，再 git checkout %s，"
        "最后 git branch -D %s。"
        % (old_branch, new_branch)
    )
    return 0

  while True:
    print("\n请选择下一步:", file=sys.stderr, flush=True)
    print("  [c] 提交并推送", file=sys.stderr, flush=True)
    print("  [n] 取消退出（保留未提交修改）", file=sys.stderr, flush=True)
    print(
        "  [r] 回滚（切回 %s 并删除 %s）" % (old_branch, new_branch),
        file=sys.stderr,
        flush=True,
    )
    try:
      choice = input().strip().lower()
    except EOFError:
      choice = "n"
    if choice in ("c", "commit", "y", "yes", "p", "push"):
      _commit_and_push_release_new(
          project_root, new_branch, version_text,
      )
      return 0
    if choice in ("r", "rollback", "abort"):
      _rollback_release_new(project_root, old_branch, new_branch)
      return 0
    if choice in ("n", "cancel", "q", ""):
      info("release new: 已取消提交/推送，当前修改仍保留在工作区")
      return 0
    print("无效输入，请输入 c / n / r", file=sys.stderr, flush=True)


def _parse_release_branch_date(branch_name):
  m = _RELEASE_BRANCH_RE.match(branch_name.strip())
  if not m:
    return None
  return int(m.group(1))


def _assert_mainline_branch(project_root, cmd_label):
  branch = _current_git_branch(project_root)
  base_ymd = _parse_release_branch_date(branch)
  if base_ymd is None:
    fatal(
        "%s: 当前分支须为迭代主线分支，名称格式为 release_YYYYMMDD，当前为: %s"
        % (cmd_label, branch)
    )
  return base_ymd


def _normalize_iteration_arg(arg, base_ymd):
  s = arg.strip()
  if s.lower().startswith("release_"):
    s = s[8:]
  if len(s) == 4 and s.isdigit():
    mmdd = int(s)
    mm = mmdd // 100
    dd = mmdd % 100
    if mm < 1 or mm > 12 or dd < 1 or dd > 31:
      fatal("release new: 无效的月日: %s" % arg)
    y0 = base_ymd // 10000
    for y in range(y0, y0 + 5):
      cand = y * 10000 + mm * 100 + dd
      if cand > base_ymd:
        return cand, "release_%08d" % cand
    fatal("release new: 无法得到晚于基础分支 release_%08d 的迭代号（月日 %s）" % (base_ymd, arg))
  if len(s) == 8 and s.isdigit():
    ymd = int(s)
    if ymd <= base_ymd:
      fatal(
          "release new: 新迭代号 release_%08d 须晚于当前分支迭代 release_%08d"
          % (ymd, base_ymd)
      )
    return ymd, "release_%08d" % ymd
  fatal(
      "release new: 无效的迭代号 [%s]，请使用 release_YYYYMMDD、YYYYMMDD 或 MMDD（4 位）"
      % arg
  )


def _bump_minor_version(version_text):
  parts = version_text.split(".")
  if len(parts) != 4:
    fatal("release new: version 须为 major.minor.patch.build 四段数字，当前为: " + version_text)
  try:
    a, b, c, d = (int(x) for x in parts)
  except ValueError:
    fatal("release new: 无效的 version: " + version_text)
  return "%d.%d.%d.%d" % (a, b + 1, 0, 0)


def _load_project_json(path):
  if not os.path.isfile(path):
    return None
  with open(path, "r", encoding="utf-8") as f:
    return json.load(f)


def _save_project_json(path, data):
  with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
    f.write("\n")


_SEMVER_DIR_RE = re.compile(r"^\d+\.\d+\.\d+$")


def _dep_sort_key(ver_three, build_number):
  parts = ver_three.split(".")
  return (int(parts[0]), int(parts[1]), int(parts[2]), int(build_number))


def _format_smb_dep_line(dep, branch, ver_three, build_number):
  left = "%s@%s" % (dep.name, branch)
  if dep.dep_alias:
    left += "(%s)" % dep.dep_alias
  if getattr(dep, "buildtools", False):
    left += "[buildtools]"
  return "%s %s.%d" % (left, ver_three, build_number)


def _max_digit_build_folder(conn, share_name, version_path):
  try:
    folders = conn.ls(share_name, version_path)
  except Exception:
    return None
  max_n = -1
  for name in folders:
    if name in (".", ".."):
      continue
    if "tmp" in name.lower():
      continue
    if not name.isdigit():
      continue
    max_n = max(max_n, int(name))
  return max_n if max_n >= 0 else None


def _smb_latest_pkg_on_branch(conn, share_name, repo_root, dep_name, branch):
  """在 SMB 上查找 repo/<dep_name>/<branch>/ 下最新 (三段版本, build)，与 ugbt 依赖目录结构一致。"""
  branch_root = os.path.join(repo_root, dep_name, branch)
  if not conn.exists(share_name, branch_root):
    return None
  if not conn.isdir(share_name, branch_root):
    return None
  try:
    ver_dirs = conn.ls(share_name, branch_root)
  except Exception:
    return None
  best = None
  for ver in ver_dirs:
    if ver in (".", "..") or ver.startswith("."):
      continue
    if "tmp" in ver.lower():
      continue
    if not _SEMVER_DIR_RE.match(ver):
      continue
    vpath = os.path.join(branch_root, ver)
    if not conn.isdir(share_name, vpath):
      continue
    bmax = _max_digit_build_folder(conn, share_name, vpath)
    if bmax is None:
      continue
    key = _dep_sort_key(ver, bmax)
    if best is None or key > best[0]:
      best = (key, ver, bmax)
  if not best:
    return None
  return best[1], best[2]


def _cmd_update(env, interactive_finish=True, require_clean_workspace=True):
  root = UgProject.find_project_root()
  if require_clean_workspace:
    _assert_working_tree_clean(root, "release update")
  git_branch = _current_git_branch(root)
  if not os.environ.get("BRANCH", "").strip():
    os.environ["BRANCH"] = git_branch

  proj = UgProject.load(env, [])
  data = proj.get_data()
  if GS.DEPS not in data or not data[GS.DEPS]:
    info("release update: %s 中无 deps，跳过" % GS.FILENAME)
    return 0

  be = env.get_build_env()
  conn = SambaConnection.instance(be["SMB_HOST"])
  share = be["SMB_SHARE_NAME"]
  repo_root = be["SMB_REPO"]
  proj_file = os.path.join(root, GS.FILENAME)

  changed = False
  for i, depstr in enumerate(data[GS.DEPS]):
    dep = SmbDep.parse(depstr, git_branch, [proj_file])
    if getattr(dep, "buildtools", False):
      info("release update: [%s] 为 buildtools 依赖，跳过" % dep.name)
      continue
    found = _smb_latest_pkg_on_branch(conn, share, repo_root, dep.name, git_branch)
    if found is None:
      info(
          "release update: 依赖 [%s] 在 SMB 上无与当前分支 [%s] 对应的目录，跳过"
          % (dep.name, git_branch)
      )
      continue
    ver3, bnum = found
    new_line = _format_smb_dep_line(dep, git_branch, ver3, bnum)
    if new_line == depstr:
      info("release update: [%s] 已对齐 %s" % (dep.name, new_line))
      continue
    # 已处于当前分支时，避免把依赖写成比 yaml 更旧的版本；切换分支时则始终以 SMB 上该分支为准
    if dep.branch == git_branch:
      old_key = _dep_sort_key(dep.version, dep.build_number)
      new_key = _dep_sort_key(ver3, bnum)
      if new_key < old_key:
        warning(
            "release update: [%s] SMB [%s] 下最新为 %s.%s，低于当前 %s，跳过（避免降级）"
            % (dep.name, git_branch, ver3, bnum, dep.dep_ver)
        )
        continue
    info("release update: %s -> %s" % (depstr, new_line))
    data[GS.DEPS][i] = new_line
    changed = True

  if changed:
    proj.save()
  else:
    info("release update: 未修改 %s" % GS.FILENAME)

  if not interactive_finish:
    return 0
  return _prompt_after_release_update(root)


def _cmd_new(env):
  if len(sys.argv) < 4:
    fatal("usage: %s release new <iteration>" % env.cmdname)
  arg = sys.argv[3]
  root = UgProject.find_project_root()
  _assert_working_tree_clean(root, "release new")
  base_ymd = _assert_mainline_branch(root, "release new")
  _ymd, new_branch = _normalize_iteration_arg(arg, base_ymd)

  cur = _current_git_branch(root)
  if cur == new_branch:
    fatal("release new: 当前已在分支 %s，无需创建" % new_branch)

  exists, where = _release_new_branch_already_exists(root, new_branch)
  if exists:
    return _handle_release_new_branch_exists(root, new_branch, where)

  old_branch = cur
  run("cd %s && git checkout -b %s" % (root, new_branch), show_start_log=True)
  os.environ["BRANCH"] = new_branch

  proj = UgProject.load(env, [])
  data = proj.get_data()
  ver = data.get(GS.VERSION)
  if not ver:
    fatal("release new: %s 中缺少 version" % GS.FILENAME)
  data[GS.VERSION] = _bump_minor_version(str(ver).strip())
  if GS.RELEASE in data:
    data[GS.RELEASE] = GS.DEV
  proj.save()

  info("release new: 按新分支同步依赖（release update）…")
  _cmd_update(env, interactive_finish=False, require_clean_workspace=False)

  pj = os.path.join(root, "project.json")
  if os.path.isfile(pj):
    j = _load_project_json(pj)
    if "info" not in j:
      j["info"] = {}
    j["info"]["is_beta"] = True
    _save_project_json(pj, j)
    info("已设置 project.json info.is_beta = true")

  info("release new: 已创建分支 %s，version=%s" % (new_branch, data[GS.VERSION]))
  return _prompt_after_release_new(
      root, old_branch, new_branch, str(data[GS.VERSION]).strip()
  )


def _cmd_stable(env):
  proj = UgProject.load(env, [])
  root = proj.get_root()
  _assert_working_tree_clean(root, "release stable")
  _assert_mainline_branch(root, "release stable")
  data = proj.get_data()
  rel = data.get(GS.RELEASE, GS.DEV)
  if rel != GS.DEV:
    fatal("release stable: 期望 %s 中 release 为 dev，当前为 %s" % (GS.FILENAME, rel))

  pj = os.path.join(root, "project.json")
  if os.path.isfile(pj):
    j = _load_project_json(pj)
    if not j.get("info", {}).get("is_beta", False):
      fatal("release stable: 期望 project.json 中 info.is_beta 为 true")

  data[GS.RELEASE] = "stable"
  proj.save()
  info("release stable: 已将 release 设为 stable")
  return _prompt_after_simple_edit(
      root,
      "release stable",
      "release stable: 提测稳定包",
      [GS.FILENAME],
  )


def _cmd_release(env):
  fatal("release release: 已禁止将 %s 中 %s 设置为 %s" % (
      GS.FILENAME, GS.RELEASE, GS.RELEASE))


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(
        self,
        env,
        "release",
        "迭代发布：new / stable / update（须干净工作区；update 按 SMB 对齐依赖）",
        [],
        self_define=True,
    )

  def main(self):
    env = self.env
    if len(sys.argv) < 3:
      fatal(
          "usage:\n  %s release new <iteration>\n  %s release stable\n  %s release update"
          % (env.cmdname, env.cmdname, env.cmdname)
      )
    sub = sys.argv[2]
    if sub == "new":
      return _cmd_new(env)
    if sub == "stable":
      return _cmd_stable(env)
    if sub == "release":
      return _cmd_release(env)
    if sub == "update":
      return _cmd_update(env)
    fatal("未知子命令 %s，可用: new, stable, update" % sub)
