from ug_build_platform import BuildPlatform
from ug_utils import GS
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "prepare", "prepare deps of a project", [
        ('v', 'build-var', 'build vars', ""),
        ('d', 'dry-run', 'run dry-run mode', False),
    ])

  def main(self):
    vars = self.get_opts('build-var')
    proj = UgProject.load(self.env, vars)
    proj.gen_makefiles()
    proj.make(GS.PREPARE, dry_run=self.get_opt('dry-run'))
    return 0
