import atexit
import os

import ug_cmd_base
from ug_common import dump_yaml, env_is_true, error, fatal, glob_files, info, join_cmd, load_yaml, make_dir, md5, \
    read_file, run, uuid_gen, write_file


class Tool(ug_cmd_base.CommandTool):
  __SKIP_DIRS = [".git", "ugreen_build", "__pycache__", "logs", ".idea", ".vscode"]

  def __init__(self, env):
    opts = [
        ('c', "check-format", "check autopep8 format with diff mode", False),
        ('p', "python-format", "only run python format", False),
        ('y', "yaml-format", "only run yaml format", False),
        ('u', "unix-format", "only run dos2unix format", False),
        ('i', "check-py-import", "only check python import pattern", False),
        ('t', "test", "only run tests", False),
    ]
    ug_cmd_base.CommandTool.__init__(self, env, "premerge-check", "run premerge checks", opts)
    build_dir = os.path.join(self.env.root, "ugreen_build", "premerge-check")
    self.__snapshot_dir = os.path.join(build_dir, uuid_gen())
    atexit.register(self.__cleanup_snapshot_dir)

  def __cleanup_snapshot_dir(self):
    if not os.path.exists(self.__snapshot_dir):
      return
    cmd = "rm -rf " + join_cmd([self.__snapshot_dir])
    run(cmd, assert_ok=False, show_log=False)

  def __write_file_list(self, name, files):
    lines = []
    for path in files:
      lines.append(path)
    write_file(name, "\n".join(lines) + "\n", show_log=False)

  def __copy_snapshot_files(self, files):
    if not files:
      return
    make_dir(self.__snapshot_dir)
    list_file = os.path.join(self.__snapshot_dir, "copy.lst")
    self.__write_file_list(list_file, files)
    cmd = "cd %s && xargs -d '\\n' -a %s -P 8 -I{} sh -c %s sh %s '{}'" % (
        join_cmd([self.env.root]),
        join_cmd([list_file]),
        join_cmd([
            "dir=$(dirname \"$2\"); "
            "mkdir -p \"$1/$dir\" && "
            "cp --reflink=auto -- \"$2\" \"$1/$2\""
        ]),
        join_cmd([self.__snapshot_dir]),
    )
    run(cmd, show_start_log=True)

  def __snapshot_files(self, files):
    snapshot = {}
    for path in files:
      snapshot[path] = md5(os.path.join(self.env.root, path))
    return snapshot

  def __diff_file(self, rel_path, before, after):
    before_file = os.path.join(self.__snapshot_dir, rel_path) if rel_path in before else "/dev/null"
    after_file = os.path.join(self.env.root, rel_path) if rel_path in after else "/dev/null"
    args = ["diff", "-u", "--label", "before/" + rel_path, "--label", "after/" + rel_path, before_file, after_file]
    cmd = "cd %s && %s" % (join_cmd([self.env.root]), join_cmd(args))
    run(cmd, assert_ok=False)

  def __show_snapshot_diff(self, before, after):
    changed_paths = sorted(set(before.keys()) | set(after.keys()))
    if not changed_paths:
      return
    for path in changed_paths:
      message = ""
      if path not in before:
        message = "format added file: " + path
      elif path not in after:
        message = "format removed file: " + path
      elif before[path] != after[path]:
        message = "format changed file: " + path
      if not message:
        continue
      error(message)
      self.__diff_file(path, before, after)

  def __check_snapshot(self, before, files):
    after = self.__snapshot_files(files)
    if before == after:
      return
    self.__show_snapshot_diff(before, after)
    fatal("format tools changed files; please review and keep the formatted result")

  def __format_yamls(self):
    count_write = 0
    for path in glob_files(self.env.root, ["dev", "conf", "tpl"], (".yaml",), skip_dirs=self.__SKIP_DIRS):
      full_path = os.path.join(self.env.root, path)
      content = read_file(full_path)
      content_new = dump_yaml(load_yaml(content))
      if content != content_new:
        write_file(full_path, content_new)
        count_write += 1
      else:
        info("update to date - " + path)
    return 1 if count_write > 0 else 0

  def __python_format_step(self):
    files = glob_files(self.env.root, ["lib", "plugin"], (".py",), skip_dirs=self.__SKIP_DIRS)
    files.extend(glob_files(self.env.root, [], (".py",), skip_dirs=self.__SKIP_DIRS))
    files = sorted(set(files))
    before = None
    if not self.__check_format:
      self.__copy_snapshot_files(files)
      before = self.__snapshot_files(files)
    list_file = os.path.join(self.__snapshot_dir, "autopep8.lst")
    self.__write_file_list(list_file, files)
    args = [os.path.join(self.env.root, "script/python3"), "-m", "autopep8", "--exit-code"]
    if self.__check_format:
      args.append("--diff")
    else:
      args.append("--in-place")
    cmd = "cd %s && xargs -d '\\n' -a %s -n 200 %s" % (
        join_cmd([self.env.root]),
        join_cmd([list_file]),
        join_cmd(args),
    )
    run(cmd, show_start_log=True)
    if before is not None:
      self.__check_snapshot(before, files)

  def __yaml_format_step(self):
    files = glob_files(self.env.root, ["dev", "conf", "tpl"], (".yaml",), skip_dirs=self.__SKIP_DIRS)
    self.__copy_snapshot_files(files)
    before = self.__snapshot_files(files)
    self.__format_yamls()
    self.__check_snapshot(before, files)

  def __unix_format_step(self):
    files = glob_files(self.env.root, None, (".py", ".yaml"), skip_dirs=self.__SKIP_DIRS)
    self.__copy_snapshot_files(files)
    before = self.__snapshot_files(files)
    list_file = os.path.join(self.__snapshot_dir, "dos2unix.lst")
    self.__write_file_list(list_file, files)
    cmd = "cd %s && xargs -d '\\n' -a %s -P 8 dos2unix >/dev/null 2>&1" % (
        join_cmd([self.env.root]),
        join_cmd([list_file]),
    )
    run(cmd, show_start_log=True)
    self.__check_snapshot(before, files)

  def __check_py_import_step(self):
    script = os.path.join(self.env.root, "script/check_py_import.sh")
    cmd = "cd %s && %s" % (
        join_cmd([self.env.root]),
        join_cmd([script]),
    )
    info("check py import ...")
    run(cmd, show_start_log=True)

  def __test_step(self):
    args = [os.path.join(self.env.root, "script/python3"), "-m", "pytest", "-n", "8", "-v", "-ra"]
    cmd = "cd %s && %s" % (
        join_cmd([self.env.root]),
        join_cmd(args),
    )
    info("pytest ...")
    run(cmd, show_start_log=True)

  def __full_check(self):
    self.__python_format_step()
    self.__yaml_format_step()
    self.__unix_format_step()
    self.__check_py_import_step()
    self.__test_step()

  def __get_selected_step(self):
    steps = [
        ("python-format", self.get_opt("python-format")),
        ("yaml-format", self.get_opt("yaml-format")),
        ("unix-format", self.get_opt("unix-format")),
        ("check-py-import", self.get_opt("check-py-import")),
        ("test", self.get_opt("test")),
    ]
    selected = [name for name, enabled in steps if enabled]
    if len(selected) > 1:
      fatal("premerge-check only supports one single-step option at a time: " + ", ".join(selected))
    return selected[0] if selected else ""

  def main(self):
    self.__check_format = self.get_opt("check-format") or env_is_true("CHECK_CODE_FORMAT")
    selected_step = self.__get_selected_step()
    if selected_step == "python-format":
      self.__python_format_step()
    elif selected_step == "yaml-format":
      self.__yaml_format_step()
    elif selected_step == "unix-format":
      self.__unix_format_step()
    elif selected_step == "check-py-import":
      self.__check_py_import_step()
    elif selected_step == "test":
      self.__test_step()
    else:
      self.__full_check()
    info("premerge check OK")
    return 0
