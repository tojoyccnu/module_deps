from collections import OrderedDict
import ug_cmd_base
from ug_common import dump_yaml, write_file


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "init-proj", "init an empty project yaml file", [
        ('n', 'name', 'name of the project', None),
    ])

  def main(self):
    # TODO
    return 0
