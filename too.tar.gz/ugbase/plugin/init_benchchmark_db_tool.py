import os
import tarfile
import shutil
from typing import OrderedDict
import ug_cmd_base
from ug_common import fatal, info, runex
from smb.SMBConnection import SMBConnection


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    # NOTE: 按需求把原来的 `ugbt pgsql` 改成 `ugbt init_benchmark_db`
    ug_cmd_base.CommandTool.__init__(self, env, "init_benchmark_db", "install and start PostgreSQL from samba (TCP)", [
        ('c', 'credential', 'smb credential file', "${HOME}/.smb-credentials"),
        ('s', "share_name", "share name of the samba service", "产品研发事业中心"),
        ('H', "host", "samba server host", "172.16.16.6"),
        ('p', 'postgres-path', 'PostgreSQL version path in samba',
         "产品经营部/NAS组/repo/blitz/3rd/postgres/release_1.17.4/1.17.4/6/cpu_arch_amd64"),
        ('t', 'target', 'target directory to install PostgreSQL (default: ./pgsql)', "pgsql"),
        ('L', 'listen-address', 'PostgreSQL listen address (default: auto-detect, use 0.0.0.0 for all interfaces)', ""),
        ('n', 'no_start', 'install only, do NOT start PostgreSQL (default: start)', False),
        ('f', 'force_install', 'force re-download and re-extract even if target already exists (DANGEROUS)', False),
    ])

  def connect(self):
    env = self.env
    conn = SMBConnection(
        username=env.smb_username,
        password=env.smb_password,
        my_name=env.local_ip,
        remote_name=env.host,
        use_ntlm_v2=True
    )

    info(f"connecting to {env.host} 445 ...")
    conn.connect(env.host, 445)
    info("connect OK")
    env.conn = conn

  def init_credential(self):
    cfile_path = self.get_opt('credential')
    cfile_path = os.path.expandvars(cfile_path)
    ct = OrderedDict()
    with open(cfile_path, 'r') as f:
      for line in f:
        line = line.strip()
        tokens = line.split('=')
        if len(tokens) <= 1:
          continue
        if len(tokens) != 2:
          fatal(f"invalid line: {line} in {cfile_path}")
        ct[tokens[0].strip()] = tokens[1].strip()
    env = self.env
    if "username" not in ct:
      fatal(f"username not found in {cfile_path}")
    if "password" not in ct:
      fatal(f"password not found in {cfile_path}")
    env.smb_username = ct["username"]
    env.smb_password = ct["password"]
    env.share_name = self.get_opt('share_name')
    env.host = self.get_opt('host')
    env.local_ip = runex("hostname -I | awk '{print $1}'")
    env.me = runex("whoami")

  def download_pgsql_package(self):
    """从 samba 下载 PostgreSQL 压缩包"""
    version_path = self.get_opt('postgres-path')
    target_dir = self.get_opt('target')

    # 处理相对路径，转换为绝对路径
    if not os.path.isabs(target_dir):
      # 相对路径，基于当前工作目录
      target_dir = os.path.abspath(target_dir)

    # 查找压缩包文件名
    package_name = "release_1.17.4-blitz_3rd_postgres-1.17.4.6-amd64.tar.gz"
    samba_path = f"{version_path}/{package_name}"

    info(f"downloading PostgreSQL package from samba: {samba_path}")
    self.connect()

    # 临时下载文件路径（在目标目录的父目录）
    temp_package = os.path.join(os.path.dirname(target_dir) or ".", f"pgsql_temp_{package_name}")

    # 下载文件
    info(f"downloading {samba_path} to {temp_package}...")
    try:
      os.makedirs(os.path.dirname(temp_package), exist_ok=True)
      with open(temp_package, "wb") as fp:
        self.env.conn.retrieveFile(self.env.share_name, samba_path, fp)
      info(f"download OK: {temp_package}")
    except Exception as e:
      fatal(f"failed to download {samba_path}: {e}")

    return temp_package

  def extract_pgsql_package(self, package_file):
    """解压 PostgreSQL 压缩包"""
    target_dir = self.get_opt('target')

    # 处理相对路径，转换为绝对路径
    if not os.path.isabs(target_dir):
      target_dir = os.path.abspath(target_dir)

    # 如果目标目录已存在，检查是否需要重新解压
    if os.path.exists(target_dir) and os.path.isdir(target_dir):
      if os.path.exists(os.path.join(target_dir, "bin", "pg_ctl")):
        info(f"PostgreSQL already extracted at {target_dir}")
        return target_dir

    info(f"extracting {package_file} to {target_dir}...")

    # 解压到临时目录
    extract_parent = os.path.dirname(target_dir) or "."
    temp_extract_dir = os.path.join(extract_parent, "pgsql_temp_extract")
    os.makedirs(temp_extract_dir, exist_ok=True)

    # 解压文件
    with tarfile.open(package_file, 'r:gz') as tar:
      tar.extractall(path=temp_extract_dir)

    # 查找解压后的目录根：支持直接解压或一级嵌套（不要层层兜底）
    actual_dir = None
    if os.path.exists(os.path.join(temp_extract_dir, "bin", "pg_ctl")):
      actual_dir = temp_extract_dir
    else:
      for name in os.listdir(temp_extract_dir):
        cand = os.path.join(temp_extract_dir, name)
        if os.path.isdir(cand) and os.path.exists(os.path.join(cand, "bin", "pg_ctl")):
          actual_dir = cand
          break

    if actual_dir is None:
      fatal(f"extraction failed, bin/pg_ctl not found under {temp_extract_dir}")

    # 如果目标目录已存在，先删除
    if os.path.exists(target_dir):
      info(f"removing existing directory: {target_dir}")
      shutil.rmtree(target_dir)

    # 移动到目标目录
    shutil.move(actual_dir, target_dir)
    info(f"moved {actual_dir} to {target_dir}")

    # 清理临时目录
    try:
      if os.path.exists(temp_extract_dir):
        shutil.rmtree(temp_extract_dir)
    except Exception:
      pass

    info(f"extraction OK: {target_dir}")
    return target_dir

  def configure_pg_hba(self, pgsql_dir):
    """配置 pg_hba.conf 以允许远程连接"""
    pg_data_dir = os.environ.get('PG_DATA_DIR', os.path.join(pgsql_dir, 'data'))
    hba_file = os.path.join(pg_data_dir, 'pg_hba.conf')

    # 如果数据目录不存在，说明还没初始化，会在 _init_db.sh 中处理
    if not os.path.exists(hba_file):
      return

    info(f"configuring pg_hba.conf to allow remote connections...")

    # 读取现有配置
    hba_content = ""
    if os.path.exists(hba_file):
      with open(hba_file, 'r') as f:
        hba_content = f.read()

    # 检查是否已经配置了远程访问
    if 'host    all' in hba_content and '0.0.0.0/0' in hba_content:
      info("pg_hba.conf already configured for remote access")
      return

    # 添加远程访问配置（允许所有 IP，使用 scram-sha-256 认证）
    # 注释掉原有的 host 行（如果有），添加新的配置
    lines = hba_content.split('\n')
    new_lines = []
    host_found = False

    for line in lines:
      stripped = line.strip()
      # 保留注释和空行
      if not stripped or stripped.startswith('#'):
        new_lines.append(line)
        continue

      # 如果是 host 行，注释掉（保留原有配置作为备份）
      if stripped.startswith('host') and 'all' in stripped:
        new_lines.append(f"# {line}  # commented out, replaced by remote access config")
        host_found = True
      else:
        new_lines.append(line)

    # 添加远程访问配置（在文件末尾）
    # 总是添加，确保有远程访问配置
    new_lines.append("")
    new_lines.append("# Remote access configuration (added by ugbt init_benchmark_db)")
    new_lines.append("# Allow connections from any IP address")
    new_lines.append("host    all    all    0.0.0.0/0    scram-sha-256")

    # 写回文件
    with open(hba_file, 'w') as f:
      f.write('\n'.join(new_lines))

    info(f"pg_hba.conf configured for remote access")

  def start_postgres(self, pgsql_dir):
    """启动 PostgreSQL 服务"""
    if self.get_opt('no_start'):
      info("skipping PostgreSQL start (--no_start specified)")
      return

    # 直接使用默认路径，不兜底探测
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    ugbase_dir = os.path.dirname(plugin_dir)
    start_script_path = os.path.join(ugbase_dir, "benchmark", "_init_db.sh")

    if not os.path.exists(start_script_path):
      fatal(f"_init_db.sh not found at: {start_script_path}")

    info(f"starting PostgreSQL using {start_script_path}...")

    # 设置环境变量（让 ugbt pgsql 一条命令完成：初始化实例(data) + 创建库/用户 + 拉起 TCP 服务）
    os.environ['blitz_3rd_postgres_ROOT'] = pgsql_dir

    # TCP 连接参数
    os.environ.setdefault('PG_PORT', '5433')

    # 监听地址设置：允许远程访问
    listen_address = self.get_opt('listen-address')
    if listen_address and listen_address.strip():
      # 用户指定了监听地址
      pg_listen = listen_address
      # 如果指定的是 0.0.0.0，连接时使用本机 IP
      if listen_address == '0.0.0.0' or listen_address == '*':
        pg_host = runex("hostname -I | awk '{print $1}'").strip()
        if not pg_host:
          pg_host = '127.0.0.1'
      else:
        pg_host = listen_address
    else:
      # 自动检测：默认监听所有接口以允许远程访问
      pg_listen = '0.0.0.0'  # 监听所有接口
      pg_host = runex("hostname -I | awk '{print $1}'").strip()
      if not pg_host:
        pg_host = '127.0.0.1'

    os.environ['PG_HOST'] = pg_host
    os.environ['PG_LISTEN_ADDRESSES'] = pg_listen
    # 实例(data)目录和日志文件：默认放到 pgsql 目录下
    os.environ.setdefault('PG_DATA_DIR', os.path.join(pgsql_dir, 'data'))
    os.environ.setdefault('PG_LOG_FILE', os.path.join(pgsql_dir, 'logs', 'postgresql.log'))
    # 目标库/用户/密码（你要求的固定值）
    os.environ.setdefault('PG_APP_DB', 'ugreen_test')
    os.environ.setdefault('PG_APP_USER', 'ugreen')
    os.environ.setdefault('PG_APP_PASSWORD', '123456')
    # 超级用户默认值（用于初始化/建库建用户）；可通过环境变量覆盖
    os.environ.setdefault('PG_SUPERUSER', 'postgres')
    os.environ.setdefault('PG_SUPERUSER_PASSWORD', 'postgres')

    # 直接使用默认路径，不兜底探测
    init_sql = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "benchmark", "init_db.sql")

    if not os.path.exists(init_sql):
      fatal(f"init_db.sql not found: {init_sql}")
    os.environ['PG_INIT_SQL'] = init_sql

    # 执行启动脚本（会初始化数据库并在完成后关闭）
    info(f"setting blitz_3rd_postgres_ROOT={pgsql_dir}")
    info(f"setting PG_DATA_DIR={os.environ['PG_DATA_DIR']}")
    info(f"setting PG_LOG_FILE={os.environ['PG_LOG_FILE']}")
    info(f"setting PG_HOST={os.environ['PG_HOST']} PG_PORT={os.environ['PG_PORT']}")
    info(f"setting PG_LISTEN_ADDRESSES={os.environ['PG_LISTEN_ADDRESSES']} (allows remote access)")
    info(f"setting PG_APP_DB={os.environ['PG_APP_DB']} PG_APP_USER={os.environ['PG_APP_USER']}")
    info(f"setting PG_SUPERUSER={os.environ['PG_SUPERUSER']}")
    if 'PG_INIT_SQL' in os.environ:
      info(f"setting PG_INIT_SQL={os.environ['PG_INIT_SQL']}")
    runex(f"bash {start_script_path}")

    # 配置 pg_hba.conf 以允许远程连接（在初始化后配置）
    self.configure_pg_hba(pgsql_dir)

    info("PostgreSQL initialization completed (database is stopped)")

  def write_env_config(self, pgsql_dir):
    """将所有必需的环境变量写入配置文件，供后续脚本使用"""
    # 写入到用户主目录的配置文件
    home_dir = os.path.expanduser("~")
    ugreen_dir = os.path.join(home_dir, ".ugreen")
    os.makedirs(ugreen_dir, exist_ok=True)
    env_file = os.path.join(ugreen_dir, "benchmark_pgsql.env")

    try:
      # 获取所有实际使用的环境变量值
      pg_data_dir = os.environ.get('PG_DATA_DIR', os.path.join(pgsql_dir, 'data'))
      pg_log_file = os.environ.get('PG_LOG_FILE', os.path.join(pgsql_dir, 'logs', 'postgresql.log'))
      pg_host = os.environ.get('PG_HOST', '127.0.0.1')
      pg_port = os.environ.get('PG_PORT', '5433')
      pg_app_db = os.environ.get('PG_APP_DB', 'ugreen_test')
      pg_app_user = os.environ.get('PG_APP_USER', 'ugreen')
      pg_app_password = os.environ.get('PG_APP_PASSWORD', '123456')
      pg_superuser = os.environ.get('PG_SUPERUSER', 'postgres')
      pg_superuser_password = os.environ.get('PG_SUPERUSER_PASSWORD', 'postgres')
      pg_listen_addresses = os.environ.get('PG_LISTEN_ADDRESSES', pg_host)

      with open(env_file, 'w') as f:
        f.write(f"# PostgreSQL environment variables (auto-generated by ugbt init_benchmark_db)\n")
        f.write(f"# DO NOT EDIT THIS FILE MANUALLY\n")
        f.write(f"\n")
        f.write(f"# PostgreSQL installation path\n")
        f.write(f"export blitz_3rd_postgres_ROOT={pgsql_dir}\n")
        f.write(f"\n")
        f.write(f"# PostgreSQL data and log directories\n")
        f.write(f"export PG_DATA_DIR={pg_data_dir}\n")
        f.write(f"export PG_LOG_FILE={pg_log_file}\n")
        f.write(f"\n")
        f.write(f"# PostgreSQL TCP connection settings\n")
        f.write(f"export PG_HOST={pg_host}\n")
        f.write(f"export PG_PORT={pg_port}\n")
        f.write(f"export PG_LISTEN_ADDRESSES={pg_listen_addresses}\n")
        f.write(f"\n")
        f.write(f"# PostgreSQL superuser (for initialization)\n")
        f.write(f"export PG_SUPERUSER={pg_superuser}\n")
        f.write(f"export PG_SUPERUSER_PASSWORD={pg_superuser_password}\n")
        f.write(f"\n")
        f.write(f"# PostgreSQL application database and user\n")
        f.write(f"export PG_APP_DB={pg_app_db}\n")
        f.write(f"export PG_APP_USER={pg_app_user}\n")
        f.write(f"export PG_APP_PASSWORD={pg_app_password}\n")

      info(f"Environment variables written to: {env_file}")
      info(f"To use in your shell, run: source {env_file}")
      info(f"Or add to your ~/.bashrc or ~/.zshrc: source {env_file}")

    except Exception as e:
      # 如果写入失败，只警告，不中断流程
      info(f"WARNING: Failed to write environment config to {env_file}: {e}")
      info(f"Please manually set the required environment variables")

  def main(self):
    self.init_credential()

    # 目标目录处理成绝对路径
    target_dir = self.get_opt('target')
    if not os.path.isabs(target_dir):
      target_dir = os.path.abspath(target_dir)

    # 如果已经安装过，就不要重复下载/解压（否则会覆盖目录，导致正在运行的进程/当前工作目录异常）
    if (not self.get_opt('force_install')
            and os.path.exists(os.path.join(target_dir, "bin", "pg_ctl"))):
      info(
          f"PostgreSQL already installed at {target_dir}, skipping download/extract "
          "(use --force_install to re-install)")
      pgsql_dir = target_dir
    else:
      # 步骤1: 下载 PostgreSQL 包
      package_file = self.download_pgsql_package()
      # 步骤2: 解压 PostgreSQL 包
      pgsql_dir = self.extract_pgsql_package(package_file)

    # 步骤3: 启动 PostgreSQL（如果启用）
    self.start_postgres(pgsql_dir)

    # 步骤4: 持久化环境变量到配置文件
    self.write_env_config(pgsql_dir)

    info("PostgreSQL installation and initialization completed!")
    info(f"PostgreSQL directory: {pgsql_dir}")
    info(f"Data directory: {os.path.join(pgsql_dir, 'data')}")
    info("")
    info("Database is currently stopped (initialization completed).")
    info("To start the database, run:")
    info(f"  bash ugbase/benchmark/start_db.sh")
    info("")
    # 获取实际使用的连接信息
    pg_host = os.environ.get('PG_HOST', '127.0.0.1')
    pg_port = os.environ.get('PG_PORT', '5433')
    pg_listen = os.environ.get('PG_LISTEN_ADDRESSES', '0.0.0.0')

    info("Default TCP connection info:")
    info(f"  Listen Address: {pg_listen} (allows remote access)")
    info(f"  Connect Host: {pg_host}")
    info(f"  Port: {pg_port}")
    info("  Database: ugreen_test")
    info("  User: ugreen")
    info("  Password: 123456")
    info("")
    info("Local connection:")
    info(f"  PGPASSWORD=123456 {pgsql_dir}/bin/psql -h {pg_host} -p {pg_port} -U ugreen -d ugreen_test")
    info("")
    info("Remote connection (from other machines):")
    info(f"  PGPASSWORD=123456 psql -h {pg_host} -p {pg_port} -U ugreen -d ugreen_test")

    return 0
