import os
import ug_cmd_base
from ug_common import dump_yaml, fatal, info, load_json, run, runex


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "podman", "list files of a layer in podman", [
        ('t', 'docker-tag', 'docker tag', ""),
        ('1', 'assert-1-layer', 'must be only 1 layer', False),
        ('o', 'output', 'output file', "img.squashfs"),
        ('e', 'exclude', 'exclude file list', ""),
    ])

  def main(self):
    env = self.env

    docker_tag = self.get_opt("docker-tag")
    if self.get_targets() == 0:
      fatal("run 'ugbt podman <cmd>'")

    cmd = self.get_targets()[0]
    if cmd == "list":
      cmd = "ssh localhost \"podman image inspect %s\"" % docker_tag
      content = runex(cmd)
      info(content)
      xobj = load_json(content)
      layer_dir = xobj[0]["GraphDriver"]["Data"]["UpperDir"]
      run("sudo du -sh " + layer_dir)
    elif cmd == "mksquashfs":
      if os.environ["CPU_ARCH"] == "amd64":
        opt = "x86"
      elif os.environ["CPU_ARCH"] == "arm64":
        opt = "arm"
      else:
        fatal("??")

      cmd = "ssh localhost \"podman image inspect %s\"" % docker_tag
      content = runex(cmd)
      xobj = load_json(content)
      layers = xobj[0]["RootFS"]["Layers"]
      if self.get_opt("assert-1-layer"):
        if len(layers) != 1:
          fatal("layer is not 1 : " + dump_yaml(layers))
      data_dir = xobj[0]["GraphDriver"]["Data"]["UpperDir"]
      output_file = os.path.expandvars(self.get_opt('output'))
      cmd = "ugbt mksquashfs -s -i %s -o %s" % (data_dir, output_file)
      if self.get_opt('exclude'):
        cmd += " -e " + self.get_opt('exclude')
      run(cmd)
    else:
      fatal("Unknown command: [%s]" % cmd)
    return 0
