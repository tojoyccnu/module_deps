from collections import OrderedDict
from email.utils import parseaddr
import os
import sys
import requests

import ug_cmd_base
from ug_common import dump_json, dump_yaml, full_stack, green, load_yaml_f, read_file, runex, \
    fatal, info, warning


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "notify", "notify dingding message", [
        ('a', 'at', 'with -c opition to @ somebody', ""),
        ('A', 'at-all', 'at every one', False),
        ('w', 'user-locating-way', 'by which way to locate an user by email(without @ugreen.com)|gitlab|name|ename|dingding|eid', "gitlab"),
        ('m', 'mode', 'send mode markdown|action_card|text', 'text'),
        ('t', 'title', 'message title, only in action-card mode', ""),
        ('s', 'skip-at-content', 'do not append @somebody at the end of the content', False),
        ('S', 'skip-audit-content', 'do not append audit info at the end of the content', False),
        ('i', 'input', 'the input of message content, if default, use stdin', "stdin"),
        ('v', 'verbose', 'show verbose information', False),
        ('T', "template", 'use the tpl/notify template to send dingding message', ''),
        ('M', "mock", 'do not send dingding message, only for test', False)
    ])

  def send_msg(self, token, content, at_users, at_all, send_mode, title):
    max_len = 16 * 1024
    if len(content) > max_len:
      warning("input contetent len %s, trucate to %s" % (len(content, max_len)))
      content = content[0:max_len]

    if not self.get_opt('skip-audit-content'):
      me = runex("whoami")
      ip = runex("hostname -I|awk '{print $1}'")
      if send_mode == "action_card":
        content = content.strip() + "\n## by %s from %s\n" % (me, ip)
      elif send_mode == "markdown":
        content = content.strip() + "\n\n>by %s from %s\n\n" % (me, ip)
      else:
        content = content.strip() + "\n  -- by %s from %s\n" % (me, ip)

    at_user_ids = []
    for at_user in at_users:
      if "did" in at_user:
        did = at_user["did"]
        if not did in at_user_ids:
          at_user_ids.append(did)
      else:
        warning("dingding id (did) not found in profile of [%s]" % dump_yaml(at_user))

    try:
      url = "https://oapi.dingtalk.com/robot/send?access_token=" + token
      header = {}
      header["Host"] = "oapi.dingtalk.com"
      header["Content-Type"] = "application/json"
      header["Date"] = runex("date -R")
      msg = {}
      if send_mode == "markdown":
        msg["msgtype"] = "markdown"
        msg["markdown"] = {}
        msg["markdown"]["text"] = content
        if title:
          msg["markdown"]["title"] = title
      elif send_mode == "action_card":
        msg["msgtype"] = "actionCard"
        msg["actionCard"] = {}
        msg["actionCard"]["text"] = content
        if title:
          msg["actionCard"]["title"] = title
      else:
        msg["msgtype"] = "text"
        msg["text"] = {}
        msg["text"]["content"] = content

      msg["at"] = {}
      msg["at"]["atUserIds"] = at_user_ids
      if self.get_opt("verbose"):
        info("at users -> " + str(at_user_ids))
      # msg["at"]["atMobiles"] = ["??"]
      # info("at phone -> " + str(msg["at"]["atMobiles"]))
      msg["at"]["isAtAll"] = at_all

      if self.get_opt("verbose"):
        info("msg: " + dump_json(msg))
        info(f'url: {url}')
      info("start to call oapi.dingtalk.com/robot/send ...")
      if self.get_opt('mock'):
        info("mock call")
        return 0
      response = requests.post(url=url, json=msg, headers=header)
      res = response.json()
      info(f'res: {res}')
      code = int(response.status_code)
      if code >= 200 and code < 300:
        info("send msg ret %d" % code)
        errcode = int(res['errcode'])
        if errcode == 0:
          info("send OK")
        else:
          fatal("send msg ERROR, errcoe %s" % errcode)
      else:
        fatal("send msg ERROR, %s %s" % (response.status, response.reason))
    except Exception as e:
      stack = full_stack()
      fatal("send msg ERROR:" + str(e) + " on " + stack)

  def get_tokens(self, group_names):
    env = self.env
    tokens = []

    if not group_names:
      group_names = ["dev"]
    obj = load_yaml_f(os.path.join(env.root, "dev", "dingding_groups.yaml"))
    tokens = []
    for name in obj.keys():
      token = obj[name]
      if name in group_names:
        tokens.append((name, token))
    if len(tokens) == 0:
      fatal("no dingding group bot token found")
    return tokens

  def read_content(self):
    file = self.get_opt('input')
    content = ""
    if file == "stdin":
      while True:
        line = sys.stdin.readline()
        if len(line) == 0:
          break
        content += line
    else:
      content = read_file(file)
    return content

  def __build_user_index(self, user_conf, key_name):
    index = OrderedDict()
    for k in user_conf:
      v = user_conf[k]
      if not key_name in v:
        fatal("%s is not found in user [%s] -> %s" % (key_name, k, dump_yaml(v)))
      new_k = v[key_name]
      if new_k in index:
        fatal("%s is duplicate in user [%s] -> %s and [%s] -> %s" % (
            key_name, k, dump_yaml(v), index[new_k]["email"], dump_yaml(index[new_k])))
      index[new_k] = v
    return index

  def get_at_users(self):
    env = self.env
    user_conf_file = os.path.join(env.root, "dev", "users.yaml")
    user_conf = load_yaml_f(user_conf_file)
    for k in user_conf.keys():
      # email is key
      user_conf[k]["email"] = k
    user_conf_ex = OrderedDict()
    user_locating_way = self.get_opt("user-locating-way")
    if user_locating_way == "gitlab":
      user_conf_ex = self.__build_user_index(user_conf, "gitlab")
    elif user_locating_way == "name":
      user_conf_ex = self.__build_user_index(user_conf, "name")
    elif user_locating_way == "ename":
      user_conf_ex = self.__build_user_index(user_conf, "ename")
    elif user_locating_way == "dingding":
      user_conf_ex = self.__build_user_index(user_conf, "dingding")
    elif user_locating_way == "eid":
      user_conf_ex = self.__build_user_index(user_conf, "eid")
    elif user_locating_way == "email":
      user_conf_ex = user_conf
    else:
      fatal("Unknown user_locating_way [%s]" % user_locating_way)

    users = []
    ats = self.get_opts("at")
    for at in ats:
      if at in user_conf_ex:
        u = user_conf_ex[at]
        if not "did" in u:
          warning("at %s skipped, 'did' not found in %s" % (at, dump_yaml(u)))
        else:
          users.append(user_conf_ex[at])
      else:
        warning("at skipped, %s is not a valid user" % at)
    return users

  def get_at_content(self, send_mode, at_users):
    skip_at_content = self.get_opt('skip-at-content')
    content = ""
    if send_mode == 'text':
      skip_at_content = True
    if not skip_at_content:
      at_prefix = ">" if send_mode == "markdown" else ""
      mentions = []
      for at_user in at_users:
        if "did" in at_user:
          mentions.append("@" + str(at_user["did"]))
        else:
          warning("did not found in " + dump_yaml(at_user))
          mentions.append("@" + str(at_user["email"]))
      content += at_prefix + " ".join(mentions)
    return content

  def tpl_expand_vars(self, tpl_file, tpl, content):
    envs = tpl.get('env', [])
    for env_name in envs:
      if not env_name in os.environ:
        fatal(env_name + " not found in env, but defeined in " + tpl_file)

    for env_name in envs:
      content = content.replace("${%s}" % env_name, os.environ[env_name].strip())
    return content

  def tpl_get_at_users(self, tpl_file, tpl):
    ats = tpl.get('at', [])
    if len(ats) == 0:
      return []

    env = self.env
    user_conf_file = os.path.join(env.root, "dev", "users.yaml")
    user_conf = load_yaml_f(user_conf_file)
    for k in user_conf.keys():
      # email is key
      user_conf[k]["email"] = k

    gitlab_index = None
    ret = []
    ret_emails = set()
    for at in ats:
      tokens = at.split(' ')
      if len(tokens) != 2:
        fatal("invalid at %s in template %s" % (at, tpl_file))
      at_mode = tokens[0]
      at = tokens[1].strip()
      at = self.tpl_expand_vars(tpl_file, tpl, at)
      at = at.replace("'", "")
      at = at.replace("\"", "")
      if at_mode == "gitlab":
        if not gitlab_index:
          gitlab_index = self.__build_user_index(user_conf, "gitlab")
        if not at in gitlab_index:
          warning(at + " not found in registered users")
        else:
          if not gitlab_index[at]["email"] in ret_emails:
            ret.append(gitlab_index[at])
            ret_emails.add(gitlab_index[at]["email"])
            info("add at user: " + at + " by gitlab")
      elif at_mode == "email":
        _, email = parseaddr(at)
        email_prefix = email.split('@')[0]
        if not email_prefix in user_conf:
          warning(
              at + " not found in registered users (email prefix:%s) (at: [%s]) (email: [%s])" % (email_prefix, at, email))
        else:
          if not email_prefix in ret_emails:
            ret.append(user_conf[email_prefix])
            ret_emails.add(email_prefix)
            info("add at user: " + at + " by email " + email_prefix)
      elif at_mode == "owner":
        if at in os.environ:
          msg = os.environ[at]
          msg = msg.replace("'", "")
          msg = msg.replace("\"", "")
          info("at msg: [%s]" % msg)
          if msg.startswith("auto ugbt update for owners ["):
            msg = msg.replace("auto ugbt update for owners [", "")
            msg = msg.replace("]", "")
            users = msg.split(',')
            for user in users:
              if not user in user_conf:
                warning(user + " not found in registered users")
                continue
              if not user in ret_emails:
                ret.append(user_conf[user])
                ret_emails.add(user)
                info("add at user: " + user + " by owner")
        else:
          warning(at + " not found in env")
      else:
        fatal("unknown at mode [%s] in %s" % (at_mode, tpl_file))
    return ret

  def send_by_template(self, template):
    env = self.env
    tpl_file = os.path.join(env.root, "tpl", "notify", template + ".yaml")
    tpl = load_yaml_f(tpl_file)
    to_gropus = tpl.get("to-group", [])
    tokens = self.get_tokens(to_gropus)
    send_mode = tpl.get("mode", 'text')
    at_all = self.get_opt('at-all')
    content_file = tpl.get("content", '')
    if not content_file:
      fatal("content not found in " + tpl_file)
    content_path = os.path.join(env.root, "tpl", "notify", content_file)
    content = read_file(content_path)
    at_all = self.get_opt('at-all')
    at_users = self.tpl_get_at_users(tpl_file, tpl)

    content = self.tpl_expand_vars(tpl_file, tpl, content)
    content += self.get_at_content(send_mode, at_users)
    if self.get_opt('verbose'):
      info("content: " + content)
    title = tpl.get("title", "")
    if not title:
      fatal("title not found")
    title = self.tpl_expand_vars(tpl_file, tpl, title)
    for name, token in tokens:
      info("Send message %d bytes to %s %s" % (len(content), name, green("OK")))
      self.send_msg(token, content, at_users, at_all, send_mode, title)

  def send_by_command(self):
    tokens = self.get_tokens(self.get_targets())
    send_mode = self.get_opt('mode')
    at_users = self.get_at_users()
    at_all = self.get_opt('at-all')
    content = self.read_content()
    content += self.get_at_content(send_mode, at_users)
    title = self.get_opt('title')
    for name, token in tokens:
      info("Send message %d bytes to %s %s" % (len(content), name, green("OK")))
      self.send_msg(token, content, at_users, at_all, send_mode, title)

  def main(self):
    template = self.get_opt('template').strip()
    if template:
      self.send_by_template(template)
    else:
      self.send_by_command()
    return 0
