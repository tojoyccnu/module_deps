"""ugbt beta_run_foreach 命令入口：展开 SMB platform_dir 并并发执行 beta_run_once。"""

import os

import ug_cmd_base
from ug_common import SambaConnection, fatal, info, join_cmd, make_dir, parallel_run, parse_smb_url, run


def _safe_log_name(name):  # 把 platform_dir 转成安全日志名
  result = []
  for ch in str(name):
    if ch.isalnum() or ch in ("-", "_", ".", "+"):
      result.append(ch)
    else:
      result.append("_")
  return "".join(result) or "worker"


def _run_command_processes(labels, commands, jobs, log_dir):  # 并发执行 beta_run_once 命令
  if jobs <= 0:
    return
  make_dir(log_dir)

  def run_one(item):  # 每个 worker 用统一的 run() 执行，输出重定向到独立日志
    label, cmd = item
    log_path = os.path.join(log_dir, _safe_log_name(label) + ".log")
    info("[%s] worker start log=%s" % (label, log_path))
    returncode = run("%s > %s 2>&1" % (join_cmd(cmd), join_cmd([log_path])), assert_ok=False, show_log=False)
    if returncode == 0:
      info("[%s] worker OK log=%s" % (label, log_path))
    else:
      info("[%s] worker FAILED ret=%s log=%s" % (label, returncode, log_path))
    return {
        "platform_dir": label,
        "cmd": cmd,
        "log_path": log_path,
        "returncode": returncode,
    }

  results = parallel_run(list(zip(labels, commands)), jobs, run_one)
  failures = [item for item in results if item["returncode"] != 0]
  if failures:
    detail = ", ".join("%s ret=%s log=%s" %
                       (item["platform_dir"], item["returncode"], item["log_path"]) for item in failures)
    fatal("worker process failed: %s" % detail)


class _BetaForeachContext(object):
  """保存 beta_run_foreach 单次运行的输入、中间状态和测试替身。"""

  def __init__(self, env, smb_url, target_command_args, samba_connection_cls=SambaConnection,
               command_runner=_run_command_processes, log_root=None, jobs="0"):
    self.env = env
    self.smb_url = smb_url
    self.target_command_args = target_command_args
    self.samba_connection_cls = samba_connection_cls
    self.command_runner = command_runner
    self.log_root = log_root or os.path.abspath("logs")
    self.location = parse_smb_url((smb_url or "").strip())
    self.jobs = jobs
    self.conn = None
    self.platform_dirs = []
    self.commands = []


def _discover_platform_dirs(ctx):
  if not ctx.conn.isdir(ctx.location.share, ctx.location.remote_path):
    fatal("smb path is not a directory: %s" % ctx.smb_url)
  for platform_dir in sorted(ctx.conn.ls(ctx.location.share, ctx.location.remote_path)):
    if platform_dir in (".", "..") or platform_dir.endswith(".tmp"):
      continue
    remote_platform_dir = "/".join([ctx.location.remote_path.rstrip("/"), platform_dir])
    if ctx.conn.isdir(ctx.location.share, remote_platform_dir):
      ctx.platform_dirs.append(platform_dir)
  if not ctx.platform_dirs:
    fatal("smb path has no platform directories: %s" % ctx.smb_url)


def _run_beta_foreach(ctx):
  if not ctx.target_command_args:
    fatal("target command is required after --")
  if not any("{}" in str(arg) for arg in ctx.target_command_args):
    fatal("target command must contain {} placeholder")

  ctx.conn = ctx.samba_connection_cls(ctx.location.host)
  ctx.conn.connect()
  _discover_platform_dirs(ctx)
  ctx.commands = [
      [str(arg).replace("{}", platform_dir) for arg in ctx.target_command_args]
      for platform_dir in ctx.platform_dirs
  ]
  jobs = int(ctx.jobs)
  # jobs=0 means one subprocess per discovered platform_dir.
  jobs = len(ctx.platform_dirs) if jobs == 0 else min(jobs, len(ctx.platform_dirs))
  ctx.command_runner(ctx.platform_dirs, ctx.commands, jobs, ctx.log_root)
  return ctx.platform_dirs


class _BetaForeachRunner(object):
  """兼容测试和调用点的 foreach 执行入口，实际流程集中在 _run_beta_foreach。"""

  def __init__(self, ctx):
    self.ctx = ctx

  def execute(self):
    return _run_beta_foreach(self.ctx)


class Tool(ug_cmd_base.CommandTool):
  """beta/GA 发布任务分配入口。"""

  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "beta_run_foreach",
                                     "run beta_run_once for each firmware or suite platform_dir", [
                                         ("u", "smb-url", "smb input path", None),
                                     ])

  def main(self):
    ctx = _BetaForeachContext(self.env, self.get_opt("smb-url"), self.get_targets())
    _BetaForeachRunner(ctx).execute()
    return 0
