from collections import OrderedDict
import os
import ug_cmd_base
from ug_common import fatal, info, run, runex, sort_dict, write_file, read_file


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "mksquashfs", "make squashfs and list file", [
        ('i', 'input', 'input directory to make', None),
        ('o', 'output', 'output file', "img.squashfs"),
        ('s', 'sudo', 'sudo or not', False),
        ('e', 'exclude', 'eclude file', ""),
    ])

  def __record_file_list(self, sudos, data_dir, lst_file):
    info("generate file list in " + data_dir + " ...")
    cmd = "cd %s" % data_dir + " && " + sudos
    cmd += "find . -mindepth 1 -printf '%y %m %s %p\\n'"
    skip_files = [".gitignore", ".gitkeep", ".git", "dev", "proc", "run", "sys", "tmp"]
    if self.get_opt('exclude'):
      user_input_skip_content = read_file(self.get_opt('exclude'))
      lines = user_input_skip_content.split('\n')
      for line in lines:
        line = line.strip()
        if line and not line in skip_files:
          skip_files.append(line)
    content = runex(cmd)
    lines = content.split('\n')
    dd = OrderedDict()
    for line in lines:
      parts = line.split(' ', 3)
      fname = parts[3]
      skip = False
      for skip_file in skip_files:
        if fname == "./" + skip_file or fname.startswith("./" + skip_file + "/"):
          skip = True
          break
      if skip:
        continue
      dd[fname] = line
    dd = sort_dict(dd)
    new_lines = []
    for k in dd.keys():
      new_lines.append(dd[k])
    content = '\n'.join(new_lines) + '\n'
    content = content.replace(" ./", " ")
    write_file(lst_file, content)

  def main(self):
    env = self.env

    if os.environ["CPU_ARCH"] == "amd64":
      opt = "x86"
    elif os.environ["CPU_ARCH"] == "arm64":
      opt = "arm"
    else:
      fatal("unknown CPU_ARCH %s" % os.environ["CPU_ARCH"])

    data_dir = os.path.expandvars(self.get_opt('input'))
    output_file = os.path.expandvars(self.get_opt('output'))
    sudos = ""
    if self.get_opt('sudo'):
      sudos = "sudo "
    cmd = sudos + "mksquashfs %s %s" % (data_dir, output_file)
    if self.get_opt('exclude'):
      tmp_file = env.get_temp_file()
      run("cat /usr/local/ugreen/ugbase/res/excludelist > " + tmp_file)
      run("cat %s >> %s" % (self.get_opt('exclude'), tmp_file))
      cmd += " -ef " + tmp_file
      run("cat " + tmp_file)
    else:
      cmd += " -ef /usr/local/ugreen/ugbase/res/excludelist"
    cmd += " -noappend -root-owned"
    cmd += " -comp xz -Xbcj " + opt
    cmd += " -b " + str(1024 * 1024)
    cmd += " -p '/dev d 755 0 0' -p '/dev/console c 600 0 0 5 1'"
    nproc = int(runex("nproc").strip())
    nproc = min(16, nproc)
    cmd += " -processors " + str(nproc)
    run(cmd, show_start_log=True)
    if sudos:
      run(sudos + "chown `whoami`:`id -nG` " + output_file)
    self.__record_file_list(sudos, data_dir, output_file + ".filelst")
    return 0
