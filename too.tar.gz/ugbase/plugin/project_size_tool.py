import os
import json
import time
import ug_cmd_base
from ug_common import info, dump_json
from ug_utils import UgProject


def pretty_json(data) -> str:
  return json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True)


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "project-size", "get project size", [
        ('v', 'verbose', 'show verbose information', False),
        ("f", "file", "output file", "project_size_report.html"),
    ])

  def main(self):
    start_time = time.time()
    proj = UgProject.load(self.env, [])
    project_size_infos, version = proj.get_project_size()
    tpl = proj.get_project_size_report_tpl()
    file = self.get_opt('file')
    UgProject.generate_size_html(tpl, version, project_size_infos, file)
    end_time = time.time()
    elapsed_time = end_time - start_time
    info("generate size html report to %s, execution time: %.2f seconds" % (file, elapsed_time))
    return 0
