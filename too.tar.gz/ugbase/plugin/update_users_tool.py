import hashlib
import hmac
import os
import time

import requests

import ug_cmd_base
from ug_common import dump_yaml, fatal, info, load_yaml_f, read_file, write_file


class Tool(ug_cmd_base.CommandTool):
  """根据 users.yaml 中的员工工号刷新钉钉用户 ID。"""

  # 员工服务认证和员工信息查询接口。
  DEFAULT_HOST_URL = "https://webapi.ugreensmart.com"
  AUTH_API_PATH = "/auth/sys/app/user/login"
  EMPLOYEE_INFO_API_PATH = "/ugreen-ehr-app/employee/info/simple"
  SIGN_METHOD = "HmacSHA256"
  REQUEST_TIMEOUT_SECONDS = 15

  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "update_users", "refresh dev/users.yaml did", [])

  def __load_config_file(self, path):
    # ~/.employee 使用 KEY=VALUE 格式，允许空行和注释。
    if not os.path.exists(path):
      return {}
    config = {}
    for line_number, raw_line in enumerate(read_file(path).splitlines(), start=1):
      line = raw_line.strip()
      if not line or line.startswith("#"):
        continue
      if "=" not in line:
        fatal("invalid employee config line %d in %s, expected KEY=VALUE" % (line_number, path))
      key, value = line.split("=", 1)
      config[key.strip()] = value.strip()
    return config

  def __init_employee_client(self):
    # 环境变量优先；本地开发环境也可以通过 ~/.employee 提供认证信息。
    config_path = os.path.expanduser("~/.employee")
    config = self.__load_config_file(config_path)
    self.env.update_users_app_key = os.environ.get("UGREEN_IT_APP_KEY") or config.get("UGREEN_IT_APP_KEY")
    self.env.update_users_app_secret = (os.environ.get("UGREEN_IT_APP_SECRET") or
                                        config.get("UGREEN_IT_APP_SECRET"))
    self.env.update_users_host_url = (os.environ.get("UGREEN_IT_HOST_URL") or
                                      config.get("UGREEN_IT_HOST_URL") or self.DEFAULT_HOST_URL).rstrip("/")
    if not self.env.update_users_app_key or not self.env.update_users_app_secret:
      fatal("set UGREEN_IT_APP_KEY and UGREEN_IT_APP_SECRET in environment or %s" % config_path)
    self.env.update_users_session = requests.Session()
    self.env.update_users_access_token = None

  def __create_signature(self, params, method, api_path):
    # 按员工服务约定排序请求参数，并使用 App Secret 生成 HMAC-SHA256 签名。
    sign_params = dict(params)
    sign_params["method"] = method
    payload = [api_path]
    for key in sorted(sign_params):
      value = sign_params[key]
      if key and key.lower() != "sign" and value:
        payload.extend((key, value))
    return hmac.new(self.env.update_users_app_secret.encode("utf-8"),
                    "".join(payload).encode("utf-8"), hashlib.sha256).hexdigest().upper()

  def __login(self):
    # 登录一次取得 Access Token，后续全部员工查询共用同一个 Token。
    headers = {
        "App-Key": self.env.update_users_app_key,
        "Sign-Method": self.SIGN_METHOD,
        "Timestamp": str(int(time.time() * 1000)),
    }
    headers["Sign"] = self.__create_signature(headers, "POST", self.AUTH_API_PATH)
    headers["Content-Type"] = "application/json"
    response = self.env.update_users_session.post(
        self.env.update_users_host_url + self.AUTH_API_PATH,
        headers=headers,
        data=b"",
        timeout=self.REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    payload = response.json()
    if not payload.get("success"):
      fatal("employee service authentication failed: %s" % payload.get("errMessage"))
    self.env.update_users_access_token = str(payload["data"]["accessToken"])

  def __get_employee(self, employee_code):
    # eid 对应员工接口的 employeeCode，返回值中包含需要写入的 dtUserid。
    params = {"employeeCode": employee_code}
    headers = {
        "App-Key": self.env.update_users_app_key,
        "Sign-Method": self.SIGN_METHOD,
        "Timestamp": str(int(time.time() * 1000)),
        "Access-Token": self.env.update_users_access_token,
    }
    sign_params = dict(headers)
    sign_params.update(params)
    headers["Sign"] = self.__create_signature(sign_params, "GET", self.EMPLOYEE_INFO_API_PATH)
    response = self.env.update_users_session.get(
        self.env.update_users_host_url + self.EMPLOYEE_INFO_API_PATH,
        params=params,
        headers=headers,
        timeout=self.REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    payload = response.json()
    if not payload.get("success"):
      fatal("employee query failed for eid %s: %s" % (employee_code, payload.get("errMessage")))
    return payload.get("data")

  def main(self):
    if self.get_targets():
      fatal("update_users does not accept targets")

    # 固定刷新 ugbase 自身维护的 dev/users.yaml。
    users_file = os.path.join(self.env.root, "dev", "users.yaml")
    groups_file = os.path.join(self.env.root, "dev", "groups.yaml")
    users = load_yaml_f(users_file)
    groups = load_yaml_f(groups_file)
    self.__init_employee_client()
    departed_users = []
    try:
      self.__login()
      # 先在内存中刷新全部用户；任何查询失败都会在写文件前退出。
      for index, (user_key, user) in enumerate(users.items(), start=1):
        employee_code = str(user["eid"])
        info("[%d/%d] update user [%s] eid=%s" % (index, len(users), user_key, employee_code))
        employee = self.__get_employee(employee_code)
        if not employee:
          info("[remove] employee not found: user [%s] eid=%s" % (user_key, employee_code))
          departed_users.append(user_key)
          continue
        dt_userid = employee["dtUserid"]
        if dt_userid is None or not str(dt_userid).strip():
          fatal("dtUserid is empty for user [%s] eid=%s" % (user_key, employee_code))
        # did 必须是字符串，避免纯数字 ID 被 YAML 解析成整数或丢失前导零。
        user["did"] = str(dt_userid).strip()
    except requests.RequestException as error:
      fatal("employee service request failed: %s" % error)

    # 员工查不到时，从用户表和所有分组中删除他的配置。
    for user_key in departed_users:
      del users[user_key]
    for group, members in groups.items():
      groups[group] = [user_key for user_key in members if user_key not in departed_users]

    # 全部查询成功后统一写回，避免配置只更新一部分。
    if departed_users:
      write_file(groups_file, dump_yaml(groups))
    write_file(users_file, dump_yaml(users))
    info("updated users=%d removed users=%d" % (len(users), len(departed_users)))
    return 0
