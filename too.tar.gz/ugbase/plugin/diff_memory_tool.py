import os
from typing import OrderedDict
import ug_cmd_base
from ug_common import fatal, green, info, read_file, red, set_verbose, sort_dict


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "diff-mem", "diff two memory file, use 'ps -eo rsz,args' to get the content", [
        ('v', 'verbose', "show verbose log", False),
        ('s', 'skip', "skip item whose bytes <", "1024"),
    ])

  def main(self):
    env = self.env
    if self.get_opt('verbose'):
      set_verbose(True)
      info("verbose is enabled")
    skip_bytes = int(self.get_opt('skip'))
    files = self.get_targets()
    if len(files) != 2:
      fatal("invalid input")

    f1 = os.path.expandvars(files[0])
    f2 = os.path.expandvars(files[1])
    fs = [f1, f2]
    cs = []
    ms = []
    for f in fs:
      if not os.path.exists(f):
        fatal(f + " not found")
      cs.append(read_file(f))
      x = OrderedDict()
      lines = cs[-1].split('\n')
      if len(lines) > 0 and "RSZ " in lines[0]:
        lines = lines[1:]
      for line in lines:
        line = line.strip()
        if line:
          tokens = line.split(maxsplit=1)
          rsz = int(tokens[0])
          name = tokens[1].strip()
          if rsz > 0:
            if name in x:
              x[name] += rsz
            else:
              x[name] = rsz
      ms.append(x)

    s1 = set(ms[0].keys())
    s2 = set(ms[1].keys())

    info("s1 - s2:")
    count = 0
    for x in s1 - s2:
      if ms[0][x] > skip_bytes:
        info("%d %s" % (ms[0][x], x))
      count += ms[0][x]
    info("s1 - s2 -> %d" % count)
    info("-----")
    count = 0
    d = OrderedDict()
    for x in s1.intersection(s2):
      c1 = ms[0][x]
      c2 = ms[1][x]
      delta = c1 - c2
      if delta >= 0:
        s = "%10s %d %d %s" % (green(str(delta)), c1, c2, x)
      else:
        s = "%10s %d %d %s" % (red(str(delta)), c1, c2, x)
      if abs(delta) > skip_bytes:
        if delta in d:
          d[delta].append(s)
        else:
          d[delta] = [s]
      count += delta
    d = sort_dict(d, reverse=True)
    for k in d.keys():
      for item in d[k]:
        info(item)
    info("delta -> %d" % count)
    info("-----")
    info("s2 - s1:")
    count = 0
    for x in s2 - s1:
      if ms[1][x] > skip_bytes:
        info("%d %s" % (ms[1][x], x))
      count += ms[1][x]
    info("s2 - s1 -> %d" % count)

    return 0
