import os
import ug_cmd_base
from ug_common import info
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "request_for_testing", "send testing request email", [
        ('v', 'verbose', 'show verbose information', False),
        ('m', 'to-myself', 'send email to myself for verification', False),
    ])

  def main(self):
    proj = UgProject.load(self.env, [])
    me = os.environ["GITLAB_USER_LOGIN"]
    proj.request_for_testing(self.get_opt('to-myself'), me)
    return 0
