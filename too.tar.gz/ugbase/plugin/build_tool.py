from ug_common import tool_set_verbose, tool_set_job_count
from ug_build_platform import BuildPlatform
from ug_utils import GS
import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "build", "build project", [
        ('v', 'build-var', 'build vars', ""),
        ('p', 'platform', 'use platform string instead of --build-var -v', ""),
        ('V', 'verbose', 'show verbose information', False),
        ('d', 'dry-run', 'run dry-run mode', False),
        ('j', 'job', 'task count of running jobs, default `nproc`, if > 16 then 16', ""),
    ])

  def main(self):
    env = self.env
    tool_set_verbose(self)
    tool_set_job_count(self)
    targets = self.get_targets()
    vars = self.get_opts('build-var')

    # 初始化proj
    pstr = self.get_opt("platform")
    if pstr:
      platform = BuildPlatform.parse(env, pstr)
      proj = UgProject.load(env, {}, platform=platform)
    else:
      vars = self.get_opts('build-var')
      proj = UgProject.load(env, vars)

    proj.gen_makefiles()
    if len(targets) == 0:
      proj.make(GS.BUILD, dry_run=self.get_opt('dry-run'))
    else:
      proj.make(targets, dry_run=self.get_opt('dry-run'))
    return 0
