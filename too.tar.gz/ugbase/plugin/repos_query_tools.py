import json
import os
import re
import shlex
import subprocess
import sys
import threading
import time

import ug_cmd_base

CONTENT_MAX_LEN = 200
GREP_LINE_RE = re.compile(r"^(.+):(\d+):(.*)$")
PROGRESS_INTERVAL_SEC = 0.25
COUNT_REPORT_EVERY = 200
# git clone/pull 走 SSH 时自动接受新主机密钥，避免每次交互 yes/no
GIT_SSH_COMMAND = "ssh -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR"

DEFAULT_CONFIG = {
    "ssh_user": "repos",
    "ssh_password": "@WSX3edc",
    "ssh_port": "22",
    "local_search_dir": "/data/repos/code",
    "default_search_dir": "/data/repos/code",
    "allowed_extensions": "",
}

ENV_MAP = {
    "ssh_user": "UG_REPOS_SSH_USER",
    "ssh_password": "UG_REPOS_SSH_PASSWORD",
    "ssh_port": "UG_REPOS_SSH_PORT",
    "local_search_dir": "UG_REPOS_LOCAL_DIR",
    "default_search_dir": "UG_REPOS_DEFAULT_DIR",
    "allowed_extensions": "UG_REPOS_ALLOWED_EXTS",
}


def _ugbase_root(env):
  return getattr(env, "root", sys.path[0])


def _config_paths(env):
  root = _ugbase_root(env)
  home = getattr(env, "home", os.environ.get("HOME", ""))
  paths = [os.path.join(root, "repos_query.conf")]
  if home:
    paths.append(os.path.join(home, ".ugbt", "repos_query.conf"))
  return paths


def _parse_conf_file(path):
  result = {}
  if not os.path.isfile(path):
    return result
  with open(path, "r", encoding="utf-8") as f:
    for line in f:
      line = line.strip()
      if not line or line.startswith("#"):
        continue
      if "=" not in line:
        continue
      key, val = line.split("=", 1)
      result[key.strip()] = val.strip()
  return result


def load_config(env):
  """加载配置：内置默认 < 环境变量 < 配置文件（后读覆盖先读）。"""
  cfg = dict(DEFAULT_CONFIG)
  for path in _config_paths(env):
    file_cfg = _parse_conf_file(path)
    for key in DEFAULT_CONFIG:
      if key in file_cfg:
        cfg[key] = file_cfg[key]
  for key, env_name in ENV_MAP.items():
    if env_name in os.environ and os.environ[env_name].strip() != "":
      cfg[key] = os.environ[env_name].strip()
  return cfg


def parse_query_vars(var_list):
  """将 -v key=value 列表解析为字典，后者覆盖前者。"""
  params = {}
  for item in var_list:
    item = item.strip()
    if not item:
      continue
    if "=" not in item:
      continue
    key, val = item.split("=", 1)
    params[key.strip()] = val.strip()
  return params


def parse_bool(val, default=False):
  if val is None or val == "":
    return default
  if isinstance(val, bool):
    return val
  s = str(val).strip().lower()
  if s in ("1", "true", "yes", "on"):
    return True
  if s in ("0", "false", "no", "off"):
    return False
  return default


def parse_extensions(ext_str):
  if not ext_str or not str(ext_str).strip():
    return []
  parts = [p.strip() for p in str(ext_str).split(",")]
  exts = []
  for p in parts:
    if not p:
      continue
    if p.startswith("*."):
      p = p[1:]
    elif p.startswith("*"):
      p = "." + p[1:]
    elif not p.startswith("."):
      p = "." + p
    exts.append(p)
  return exts


def resolve_search_dir(cli, addr, cfg):
  """
  解析搜索根目录：
  - 本机：-v dir= > local_search_dir > default_search_dir
  - 远程：-v remote_dir= > -v dir= > default_search_dir
  """
  if addr:
    directory = cli.get("remote_dir", "").strip()
    if not directory:
      directory = cli.get("dir", "").strip()
    if not directory:
      directory = cfg.get("default_search_dir", "").strip()
    if not directory:
      return "", "remote"
    return os.path.expanduser(directory), "remote"
  directory = cli.get("dir", "").strip()
  if not directory:
    directory = cfg.get("local_search_dir", "").strip()
  if not directory:
    directory = cfg.get("default_search_dir", "").strip()
  if not directory:
    return "", "local"
  return os.path.abspath(os.path.expanduser(directory)), "local"


def _include_glob(ext):
  """扩展名 .cpp -> grep glob *.cpp"""
  if ext.startswith("."):
    return "*%s" % ext
  return "*.%s" % ext


def build_grep_argv(keyword, directory, extensions):
  argv = ["grep", "-rnE"]
  if extensions:
    for ext in extensions:
      argv.append("--include=%s" % _include_glob(ext))
  else:
    argv.append("--include=*")
  argv.append(keyword)
  argv.append(directory)
  return argv


def build_grep_shell_cmd(keyword, directory, extensions):
  parts = ["grep", "-rnE"]
  if extensions:
    for ext in extensions:
      parts.append("--include='%s'" % _include_glob(ext))
  else:
    parts.append("--include='*'")
  parts.append(shlex.quote(keyword))
  parts.append(shlex.quote(directory))
  return " ".join(parts)


class ScanProgress:
  """扫描进度输出到 stderr，不污染 stdout（JSON 结果）。"""

  def __init__(self, enabled):
    self.enabled = enabled
    self._tty = sys.stderr.isatty()
    self._lock = threading.Lock()

  def stage(self, message):
    if not self.enabled:
      return
    with self._lock:
      self._write(message + "\n")

  def pulse_count(self, count, directory):
    if not self.enabled:
      return
    with self._lock:
      msg = "Counting files in %s ... %d" % (directory, count)
      self._write_line(msg)

  def pulse_wait(self, message, elapsed_sec):
    if not self.enabled:
      return
    with self._lock:
      self._write_line("%s ... %.1fs" % (message, elapsed_sec))

  def pulse_search(self, keyword, elapsed_sec, file_count):
    if not self.enabled:
      return
    with self._lock:
      if file_count > 0:
        msg = "Searching '%s' in %d files ... %.1fs" % (keyword, file_count, elapsed_sec)
      else:
        msg = "Searching '%s' ... %.1fs" % (keyword, elapsed_sec)
      self._write_line(msg)

  def clear(self):
    if not self.enabled or not self._tty:
      return
    with self._lock:
      sys.stderr.write("\r\x1b[K")
      sys.stderr.flush()

  def _write(self, text):
    sys.stderr.write(text)
    sys.stderr.flush()

  def _write_line(self, text):
    if self._tty:
      sys.stderr.write("\r\x1b[K" + text)
    else:
      sys.stderr.write(text + "\n")
    sys.stderr.flush()


def progress_enabled(cli, use_json):
  val = cli.get("progress", "")
  if val != "":
    return parse_bool(val, default=True)
  if use_json:
    return False
  return sys.stderr.isatty()


def _wait_channel_with_progress(channel, progress, keyword, file_count, phase):
  t0 = time.perf_counter()
  while not channel.exit_status_ready():
    if progress is not None:
      elapsed = time.perf_counter() - t0
      if phase == "count":
        progress.pulse_wait("Counting files on remote", elapsed)
      else:
        progress.pulse_search(keyword, elapsed, file_count)
    time.sleep(PROGRESS_INTERVAL_SEC)
  return channel.recv_exit_status()


def _file_matches_extensions(filename, extensions):
  if not extensions:
    return True
  lower = filename.lower()
  for ext in extensions:
    if lower.endswith(ext.lower()):
      return True
  return False


def count_local_files(directory, extensions, progress=None):
  """统计目录下符合扩展名白名单的文件数量。"""
  total = 0
  since_report = 0
  for _, _, files in os.walk(directory):
    for name in files:
      if _file_matches_extensions(name, extensions):
        total += 1
        since_report += 1
        if progress is not None and since_report >= COUNT_REPORT_EVERY:
          progress.pulse_count(total, directory)
          since_report = 0
  if progress is not None and total > 0:
    progress.pulse_count(total, directory)
  return total


def build_find_count_shell_cmd(directory, extensions):
  """构造远程 find 统计文件数的 shell 命令。"""
  dir_q = shlex.quote(directory)
  if extensions:
    parts = []
    for ext in extensions:
      parts.append("-name '%s'" % _include_glob(ext))
    name_expr = " -o ".join(parts)
    return "find %s -type f \\( %s \\) 2>/dev/null | wc -l" % (dir_q, name_expr)
  return "find %s -type f 2>/dev/null | wc -l" % dir_q


def run_local_grep(grep_argv, progress=None, keyword="", file_count=0):
  try:
    proc = subprocess.Popen(
        grep_argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
    )
  except OSError as e:
    return None, "grep execution failed: %s" % str(e)
  t0 = time.perf_counter()
  while proc.poll() is None:
    if progress is not None:
      progress.pulse_search(keyword, time.perf_counter() - t0, file_count)
    time.sleep(PROGRESS_INTERVAL_SEC)
  out, err = proc.communicate()
  if progress is not None:
    progress.clear()
  if proc.returncode > 1:
    msg = (err or out or "unknown error").strip()
    return None, "grep execution failed: %s" % msg
  return out, None


def _ssh_read_output(stdout, stderr):
  out = stdout.read()
  err = stderr.read()
  if isinstance(out, bytes):
    out = out.decode("utf-8", errors="replace")
  if isinstance(err, bytes):
    err = err.decode("utf-8", errors="replace")
  return out, err


def _parse_remote_file_count(text):
  text = text.strip()
  if not text:
    return 0
  try:
    return int(text.splitlines()[-1].strip())
  except ValueError:
    return 0


def run_remote_grep(addr, cfg, grep_shell_cmd, directory, extensions, progress=None, keyword=""):
  try:
    import paramiko
  except ImportError:
    return None, 0, 0.0, "paramiko is not installed, run: pip install paramiko"

  port = int(cfg.get("ssh_port") or "22")
  user = cfg.get("ssh_user") or ""
  password = cfg.get("ssh_password") or ""
  client = paramiko.SSHClient()
  client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  if progress is not None:
    progress.stage("Connecting to %s ..." % addr)
  try:
    client.connect(
        addr,
        port=port,
        username=user,
        password=password,
        timeout=30,
        allow_agent=False,
        look_for_keys=False,
    )
  except Exception as e:
    return None, 0, 0.0, "Cannot connect to %s - %s" % (addr, str(e))

  try:
    test_cmd = "test -d %s" % shlex.quote(directory)
    _, stdout, stderr = client.exec_command(test_cmd, timeout=60)
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
      return None, 0, 0.0, "Remote directory not found: %s" % directory

    if progress is not None:
      progress.stage("Counting files on remote: %s" % directory)
    count_cmd = build_find_count_shell_cmd(directory, extensions)
    _, stdout, stderr = client.exec_command(count_cmd, timeout=600)
    exit_status = _wait_channel_with_progress(stdout.channel, progress, keyword, 0, "count")
    count_out, _ = _ssh_read_output(stdout, stderr)
    if exit_status != 0:
      file_count = 0
    else:
      file_count = _parse_remote_file_count(count_out)
    if progress is not None:
      progress.pulse_count(file_count, directory)

    t0 = time.perf_counter()
    _, stdout, stderr = client.exec_command(grep_shell_cmd, timeout=600)
    exit_status = _wait_channel_with_progress(stdout.channel, progress, keyword, file_count, "grep")
    scan_sec = time.perf_counter() - t0
    out, err = _ssh_read_output(stdout, stderr)
    if progress is not None:
      progress.clear()
    if exit_status > 1:
      msg = err.strip() or out.strip() or "unknown error"
      return None, file_count, scan_sec, "grep execution failed: %s" % msg
    return out, file_count, scan_sec, None
  finally:
    client.close()


def parse_grep_line(line):
  line = line.rstrip("\n")
  if not line:
    return None
  m = GREP_LINE_RE.match(line)
  if not m:
    return None
  return {
      "file_path": m.group(1),
      "line": int(m.group(2)),
      "content": m.group(3),
  }


def truncate_content(content):
  if len(content) <= CONTENT_MAX_LEN:
    return content
  return content[:CONTENT_MAX_LEN] + "..."


def enrich_match(search_dir, raw):
  file_path = raw["file_path"]
  search_dir = os.path.abspath(search_dir)
  abs_file = os.path.abspath(file_path) if os.path.isabs(file_path) else os.path.abspath(
      os.path.join(search_dir, file_path))
  try:
    rel = os.path.relpath(abs_file, search_dir)
  except ValueError:
    rel = file_path
  rel = rel.replace("\\", "/")
  if rel.startswith("./"):
    rel = rel[2:]
  parts = rel.split("/")
  if len(parts) <= 1:
    first_level = "."
    rel_path = rel
  else:
    first_level = parts[0]
    rel_path = "/".join(parts[1:])
  return {
      "first_level_dir": first_level,
      "relative_path": rel_path,
      "line": raw["line"],
      "content": truncate_content(raw["content"]),
  }


def parse_grep_output(search_dir, stdout):
  matches = []
  if not stdout:
    return matches
  for line in stdout.splitlines():
    raw = parse_grep_line(line)
    if raw is None:
      continue
    matches.append(enrich_match(search_dir, raw))
  return matches


def host_label(addr):
  if addr:
    return addr
  return "localhost"


def format_scan_summary(scanned_files, scan_time_sec, total_matches):
  if total_matches > 0:
    return "=====\nFound %d matches, scanned %d files in %.2fs." % (total_matches, scanned_files, scan_time_sec)
  return "=====\nFound 0 matches, scanned %d files in %.2fs." % (scanned_files, scan_time_sec)


def format_table(matches, keyword, directory, scanned_files, scan_time_sec):
  total_matches = len(matches)
  if total_matches == 0:
    print("No matches found for keyword '%s' in directory %s." % (keyword, directory))
  else:
    print("Found %d matches:" % total_matches)
    print("\n=====")
    for m in matches:
      path_line = "%s:%d: %s" % (m["relative_path"], m["line"], m["content"])
      print("%s | %s" % (m["first_level_dir"], path_line))
  print(format_scan_summary(scanned_files, scan_time_sec, total_matches))


def format_json_success(keyword, directory, host, matches, scanned_files, scan_time_sec):
  obj = {
      "status": "success",
      "keyword": keyword,
      "directory": directory,
      "host": host,
      "scanned_files": scanned_files,
      "scan_time_sec": round(scan_time_sec, 3),
      "matches": matches,
      "total_matches": len(matches),
  }
  print(json.dumps(obj, indent=2, ensure_ascii=False))


def format_json_error(error_message, keyword, directory, host):
  obj = {
      "status": "error",
      "error_message": error_message,
      "keyword": keyword or "",
      "directory": directory or "",
      "host": host,
  }
  print(json.dumps(obj, indent=2, ensure_ascii=False))


def emit_error(use_json, message, keyword, directory, host):
  if use_json:
    format_json_error(message, keyword, directory, host)
  else:
    print("ERROR: %s" % message, file=sys.stdout)
  return 1


REPOS_UPDATE_MENU = (
    "=== 菜单 ===\n"
    "0. exit 退出\n"
    "1. clone 删除源目录，克隆仓库\n"
    "2. checkout 切换到指定分支\n"
    "3. pull 拉取最新代码\n"
)


def validate_repos_update_files(directory):
  """检查目录下必须同时存在 git.sh 与 repos.txt。"""
  git_sh = os.path.join(directory, "git.sh")
  repos_txt = os.path.join(directory, "repos.txt")
  missing = []
  if not os.path.isfile(git_sh):
    missing.append("git.sh")
  if not os.path.isfile(repos_txt):
    missing.append("repos.txt")
  if missing:
    return "Missing required file(s) in %s: %s" % (directory, ", ".join(missing))
  return None


def parse_repos_action(cli):
  """解析 git.sh repos 菜单选项，默认 3（pull）。"""
  action = cli.get("repos_action", "3").strip()
  if action not in ("0", "1", "2", "3"):
    return None, "Invalid repos_action '%s', must be 0-3" % action
  return action, None


def _update_repos_env():
  env = os.environ.copy()
  env["GIT_SSH_COMMAND"] = GIT_SSH_COMMAND
  return env


def build_update_repos_shell_cmd(directory, repos_action):
  dir_q = shlex.quote(directory)
  action_q = shlex.quote(repos_action)
  git_ssh = shlex.quote(GIT_SSH_COMMAND)
  return (
      "export GIT_SSH_COMMAND=%s && cd %s && printf '%%s\\n' %s | bash ./git.sh repos repos.txt"
      % (git_ssh, dir_q, action_q)
  )


def _stream_ssh_pty(channel, stdin_data=None):
  """实时将 SSH PTY 输出写到当前终端。"""
  if stdin_data is not None:
    channel.send(stdin_data)
    channel.shutdown_write()
  while True:
    if channel.recv_ready():
      data = channel.recv(4096)
      if data:
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()
    if channel.exit_status_ready():
      while channel.recv_ready():
        data = channel.recv(4096)
        if data:
          sys.stdout.buffer.write(data)
          sys.stdout.buffer.flush()
      break
    time.sleep(0.05)
  return channel.recv_exit_status()


def _connect_ssh(addr, cfg):
  try:
    import paramiko
  except ImportError:
    return None, "paramiko is not installed, run: pip install paramiko"
  port = int(cfg.get("ssh_port") or "22")
  user = cfg.get("ssh_user") or ""
  password = cfg.get("ssh_password") or ""
  client = paramiko.SSHClient()
  client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  try:
    client.connect(
        addr,
        port=port,
        username=user,
        password=password,
        timeout=30,
        allow_agent=False,
        look_for_keys=False,
    )
  except Exception as e:
    return None, "Cannot connect to %s - %s" % (addr, str(e))
  return client, None


def validate_repos_update_files_remote(client, directory):
  dir_q = shlex.quote(directory.rstrip("/"))
  cmd = "test -d %s && test -f %s/git.sh && test -f %s/repos.txt" % (dir_q, dir_q, dir_q)
  _, stdout, stderr = client.exec_command(cmd, timeout=60)
  exit_status = stdout.channel.recv_exit_status()
  if exit_status != 0:
    return "Missing required file(s) or directory on remote %s: git.sh and repos.txt must both exist" % directory
  return None


def run_update_repos(directory, repos_action, host_label_text="localhost"):
  """本机：在指定目录执行 git.sh repos，实时输出。"""
  directory = os.path.abspath(os.path.expanduser(directory))
  if not os.path.isdir(directory):
    return 1, "Directory not found: %s" % directory

  err = validate_repos_update_files(directory)
  if err:
    return 1, err

  print("Running update_repos on %s in %s (menu choice: %s)" % (host_label_text, directory, repos_action))
  print(REPOS_UPDATE_MENU, end="")
  print("Auto select: %s" % repos_action)

  try:
    proc = subprocess.Popen(
        ["bash", os.path.join(directory, "git.sh"), "repos", "repos.txt"],
        cwd=directory,
        stdin=subprocess.PIPE,
        stdout=None,
        stderr=None,
        env=_update_repos_env(),
    )
    proc.communicate(input=(repos_action + "\n").encode("utf-8"))
  except OSError as e:
    return 1, "Failed to run git.sh: %s" % str(e)

  if proc.returncode != 0:
    return proc.returncode, "git.sh repos exited with code %d" % proc.returncode
  return 0, None


def run_remote_update_repos(addr, cfg, directory, repos_action):
  """远程：SSH 到目标机指定目录执行 git.sh repos，实时输出。"""
  directory = os.path.expanduser(directory).rstrip("/")
  client, err = _connect_ssh(addr, cfg)
  if err:
    return 1, err

  print("Running update_repos on %s in %s (menu choice: %s)" % (addr, directory, repos_action))
  print(REPOS_UPDATE_MENU, end="")
  print("Auto select: %s" % repos_action)

  try:
    val_err = validate_repos_update_files_remote(client, directory)
    if val_err:
      return 1, val_err

    cmd = build_update_repos_shell_cmd(directory, repos_action)
    _, stdout, _ = client.exec_command(cmd, get_pty=True, timeout=3600)
    channel = stdout.channel
    exit_status = _stream_ssh_pty(channel)
    if exit_status != 0:
      return exit_status, "git.sh repos exited with code %d on remote" % exit_status
    return 0, None
  finally:
    client.close()


def format_update_repos_json(directory, repos_action, host, status, error_message=""):
  obj = {
      "status": status,
      "directory": directory,
      "host": host,
      "repos_action": repos_action,
  }
  if error_message:
    obj["error_message"] = error_message
  print(json.dumps(obj, indent=2, ensure_ascii=False))


def execute_update_repos(cli, addr, cfg, directory, use_json, host):
  repos_action, action_err = parse_repos_action(cli)
  if action_err:
    return emit_error(use_json, action_err, "", directory, host)
  if not directory:
    return emit_error(
        use_json,
        "Missing directory for update_repos: use -v dir= / -v remote_dir= or config default",
        "",
        "",
        host,
    )

  if addr:
    exit_code, run_err = run_remote_update_repos(addr, cfg, directory, repos_action)
  else:
    if not os.path.isdir(directory):
      return emit_error(use_json, "Local directory not found: %s" % directory, "", directory, host)
    exit_code, run_err = run_update_repos(directory, repos_action, host)

  if use_json:
    status = "success" if exit_code == 0 else "error"
    format_update_repos_json(directory, repos_action, host, status, run_err or "")
  elif run_err:
    print("ERROR: %s" % run_err, file=sys.stdout)
  else:
    print("update_repos completed successfully on %s: %s" % (host, directory))
  return exit_code


def execute_grep_search(cli, addr, cfg, directory, use_json, host):
  keyword = cli.get("grep", "")
  if not keyword:
    return emit_error(use_json, "Missing required parameter 'grep'", keyword, "", host)

  if not directory:
    if addr:
      hint = "set default_search_dir in repos_query.conf or -v remote_dir= / -v dir="
    else:
      hint = "use -v dir=PATH or set local_search_dir/default_search_dir"
    return emit_error(use_json, "Missing search directory: %s" % hint, keyword, "", host)

  extensions = parse_extensions(cfg.get("allowed_extensions", ""))
  show_progress = progress_enabled(cli, use_json)
  progress = ScanProgress(show_progress)

  if not addr:
    if not os.path.isdir(directory):
      return emit_error(use_json, "Local directory not found: %s" % directory, keyword, directory, host)
    progress.stage("Counting files: %s" % directory)
    scanned_files = count_local_files(directory, extensions, progress)
    progress.clear()
    grep_argv = build_grep_argv(keyword, directory, extensions)
    t0 = time.perf_counter()
    stdout, err = run_local_grep(grep_argv, progress, keyword, scanned_files)
    scan_time_sec = time.perf_counter() - t0
    if err:
      return emit_error(use_json, err, keyword, directory, host)
  else:
    grep_cmd = build_grep_shell_cmd(keyword, directory, extensions)
    stdout, scanned_files, scan_time_sec, err = run_remote_grep(
        addr, cfg, grep_cmd, directory, extensions, progress, keyword)
    if err:
      return emit_error(use_json, err, keyword, directory, host)

  matches = parse_grep_output(directory, stdout)
  if use_json:
    format_json_success(keyword, directory, host, matches, scanned_files, scan_time_sec)
  else:
    format_table(matches, keyword, directory, scanned_files, scan_time_sec)
  return 0


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "query-repos",
                                     "search keyword in local or remote repo directories", [
                                         ("v", "query-var",
                                          "opts: grep=KW and/or update_repos=true [repos_action=0-3] "
                                          "[dir=] [addr=] [remote_dir=] [json=true]", ""),
                                     ])

  def main(self):
    cfg = load_config(self.env)
    cli = parse_query_vars(self.get_opts("query-var"))

    addr = cli.get("addr", "").strip()
    use_json = parse_bool(cli.get("json"), False)
    host = host_label(addr)
    do_update = parse_bool(cli.get("update_repos"), False)
    do_grep = bool(cli.get("grep", "").strip())

    if not do_update and not do_grep:
      return emit_error(
          use_json,
          "Specify at least one action: -v grep=KEYWORD and/or -v update_repos=true",
          "",
          "",
          host,
      )

    directory, _ = resolve_search_dir(cli, addr, cfg)
    last_code = 0

    if do_update:
      update_code = execute_update_repos(cli, addr, cfg, directory, use_json, host)
      if update_code != 0:
        return update_code
      last_code = update_code

    if do_grep:
      grep_code = execute_grep_search(cli, addr, cfg, directory, use_json, host)
      if grep_code != 0:
        return grep_code
      last_code = grep_code

    return last_code
