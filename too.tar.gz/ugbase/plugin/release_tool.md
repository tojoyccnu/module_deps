# 迭代发布管理工具

此工具用于管理的发布迭代，方便迭代特定时间点需要修改迭代配置时，减少人为操作。

**前置条件（new / stable / update 适用）**：执行时当前 git 仓库须**完全干净**——`git status --porcelain` 无任何输出（无已暂存/未暂存修改、无未跟踪且未被 `.gitignore` 忽略的文件等）。不满足则立即 `fatal` 并打印简要 `porcelain` 列表。`release new` 在通过校验、开始修改文件后，内嵌的 `update` 不再重复此项检查。

工具需要实现如下主功能：
- 创建迭代(release new)
- 按 SMB 与当前分支更新依赖(release update)
- 迭代提测稳定包(release stable)
- 禁止上线状态(release release 会直接 fatal，不再写入 `release: release`)

## 创建迭代(子命令：new)
创建分支时，以当前分支为基础，拉一个新分支出来。若**目标迭代分支已存在**（本地已有 `refs/heads/<分支>`，或已配置的默认 `git remote` 上存在同名分支、或已有对应的 `refs/remotes/<remote>/<分支>`），则**立即终止** `release new`（不会改 version / deps / `project.json`），并在交互式终端询问是否切换到该分支：**[y]** 执行 `git checkout`（必要时 `fetch`）；**[n]** 保持当前分支退出。若当前已在目标分支则直接 `fatal` 提示无需创建。非 TTY 时给出 `fatal` 与手动 `fetch`/`checkout` 提示。若配置了 remote 但无法访问以确认远程是否存在同名分支，也会 `fatal` 要求排除网络问题后重试。

创建成功并写入 `ugreen_project.yaml` 的 version 后，若已有 release 字段则重置为 dev；若没有 release 字段则保持省略，后续逻辑按 dev 处理。之后**会自动执行一次与 `release update` 相同的依赖同步**（按 SMB 与新建分支名对齐非 buildtools 的 `deps`；需 SMB 可用，失败则整条 `release new` 失败）。

完成后会先展示带颜色的 `git diff --stat` 与 `git diff`（`--color=always`，输出到终端 stderr；过长则省略正文，请本地执行 `git diff --color=always`）。在**交互式终端**下会等待你选择：
- **[c]**：仅 `git add` `ugreen_project.yaml` 与（若存在）`project.json` 后 `git commit`（说明含分支名与版本），再 `git push -u origin <新分支>`，避免把同仓库其它已改文件一并提交
- **[n]**：不提交、不推送，保留未提交修改后退出
- **[r]**：在新分支上 `git reset --hard` 丢弃本次产生的修改，切回创建前的分支，再 `git branch -D` 删除刚建分支。**回滚会丢弃该分支上所有未提交改动**；若切分支前工作区尚有其它未提交文件并随 `checkout -b` 带到新分支，也会被一并丢弃，建议在干净工作区执行。

非交互环境（如 CI、无 TTY）仅打印 diff 与上述回滚提示，不弹出选择、不自动提交。

迭代分支格式为：release_20060102，固定以release_开头，后面接一个8位日期格式的迭代号。
工具接受一个参数：新迭代的迭代号，可以是release_20060102，也可以是20060102，也可以是0102
- 如果是4位日期，则直接推测当前年份为对应年份，不过要验证组合后的迭代号应该是晚于基础分支的。如从20251224迭代，通过0128创建分支，则应该是20260128，而不是20250128（即使当前仍在2025年）

拉新分支后，还需读取 ugreen_project.yaml 文件，并参照语义化版本号，升级其次版本号。

``` yaml
name: firmware/service/storage_serv
version: 1.15.0.57
ugbase: ssh://git@gitlab.ugnas.com/scm/ugbase.git release_v1 067eb412dde01bd0fb22208c74749aa4ba28021e
template: ugtools-upk
release-name: 存储管理
release: dev
platform:
- cpu_arch
output:
  format: both
deps:
- devtools/ugtools@release_v2[buildtools] 1.1.0.16
- frontend/com.ugreen.pro.storagemgr@release_20260422(www) 1.15.0.4163
```

如上是一个ugreen_project.yaml的举例，其中```version: 1.15.0.57```即当前版本号。当创建新迭代时，应当将其更新为1.16.0.0。
release 字段可以不存在；如果不存在，则认为它的值是 dev。如果 ugreen_project.yaml 包含 release 字段，`release new` 会将其值改为 dev。

可选的，如果项目包含project.json，则将其info.is_beta改为true，下面是一个project.json文件的举例
``` json
{
  "info": {
    "app_id": "com.ugreen.storagemgr",
    "service_name": "storage_serv.service",
    "route": "/storagemgr",
    "depend_fw_version": "1.0.0.0000",
    "app_type": "system",
    "is_beta": true,
    "only_admin": true,
    "i18n": [
      {
        "name": "存储管理",
        "description": "存储管理是一款管理应用程序，可以帮助管理员组织、管理、监控绿联云上的存储容量。并提供Hot Spare、SSD 缓存等各种高级选项，以提升存储可靠性和读写速度等。",
        "author": "UGREEN",
        "langName": "zh-CN",
        "publisher": "UGREEN",
        "official": "https://www.ugreen.com"
      }
    ],
    "base_access_info": {
      "accessMode": 0,
      "innerInfo": {},
      "portInfo": {
        "httpsEnable": false,
        "port": "",
        "httpsPort": "",
        "urlPath": ""
      },
      "portalInfo": {
        "urlPath": ""
      },
      "supports": null,
      "isAuthRequired": false,
      "openType": ""
    },
    "version": "1.8.0",
    "category": "category.system.manage",
    "tag_types": [
      "system"
    ],
    "publisher_type": "ugos"
  }
}
```

## 更新依赖(子命令：update)

根据依赖拉取逻辑，从 SMB（`conf/build_env.yaml` 中 `SMB_REPO` 等）上检查 `deps` 里每个依赖是否在仓库路径下存在与**当前 git 分支同名**的目录：`{SMB_REPO}/{dep.name}/{当前分支}/`。若存在，则在该目录下按与 ugbt 一致的布局扫描子目录：三段语义化版本号目录（如 `1.15.0`），其下仅取**纯数字**子目录作为 build 号，得到字典序最大的 `(version, build)`，将对应依赖行写回 `ugreen_project.yaml`（`@` 后分支改为当前分支，版本号为 `major.minor.patch.build`）。保留原有 `(alias)` 等写法。**带 `[buildtools]` 的依赖不参与 update**（由工具链单独约定版本，避免被迭代分支逻辑改写）。

用法：在工程根目录执行 `ugbt release update`（需可访问 SMB 及本机 `~/.ugreen/ugbt.config.json` / `~/.smb-credentials` 等与 `ugbt install` 相同的环境）。若某依赖在 SMB 上无该分支目录，则跳过该条并打日志。若依赖行**已是当前分支**，且 SMB 上解析出的最新 `(version, build)` 低于 yaml 中现有值，则跳过该条并告警，避免误降级；若 yaml 中仍为其它分支而 SMB 上存在当前分支产物，则按 SMB 结果改写（视为跟迭代切分支）。

**结束时**（存在 `deps` 且走完逻辑后）：若所列文件相对 HEAD 无未提交差异，则只打一行日志并退出，**不**展示 diff、不询问。否则仅对这些文件展示彩色 `git diff`，并在交互式终端下提示 **[c]提交并推送** / **[n]取消** / **[r]回滚**（**[c]** 仅 `git add` 本次涉及的 `ugreen_project.yaml`，不用 `commit -a`）。回滚仅 `git restore` / `checkout HEAD --` 还原上述文件。非 TTY 仅打印说明。`release new` 内嵌的 update **不会**单独弹出此轮，只在 `new` 全部完成后统一 diff 与选择。

## 提测稳定包(子命令：stable)

提测稳定包，预期当前项目处于新建后的状态，即 ugreen_project.yaml 中 release 为 dev 或不存在；如有project.json则info.is_beta: true
验证通过后，将ugreen_project.yaml中release改为stable，project.json的info.is_beta保持true

完成后若 `ugreen_project.yaml` 相对 HEAD 无差异则直接退出；否则仅对该文件展示彩色 `git diff` 与 **[c]提交并推送 / [n]取消 / [r]回滚**（**[c]** 只 `git add` 该文件再 `commit`，规则同 `release update`）。**[r]** 仅还原 `ugreen_project.yaml` 至 HEAD。

## 发布迭代(子命令：release)

`ugreen_project.yaml` 的 `release` 字段不能为 `release`。执行 `ugbt release release` 会直接 `fatal`，不会修改 `ugreen_project.yaml` 或 `project.json`。
