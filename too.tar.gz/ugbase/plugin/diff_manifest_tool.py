import os
import ug_cmd_base
from ug_common import info, dump_yaml, fatal, load_yaml_f, read_file, set_verbose, write_file
from ug_utils import ManifestLoader


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "diff-manifest", "diff two manifest.yaml", [
        ('v', 'verbose', "show verbose log", False),
        ('i', 'input', "input file", None),
        ('n', 'name', "module name", None),
        ('o', 'output', "output file", "diff.yaml"),
    ])

  def main(self):
    env = self.env
    if self.get_opt('verbose'):
      set_verbose(True)
      info("verbose is enabled")

    input_file = os.path.expandvars(self.get_opt('input'))
    content = read_file(input_file)
    lines = content.split('\n')
    files = []
    for line in lines:
      line = line.strip()
      if line:
        if line.startswith("#"):
          continue
        file = os.path.expandvars(line)
        if not os.path.exists(file):
          fatal(file + " not found")
        files.append(file)
    if len(files) <= 1:
      fatal("input len < 2")
    branch = load_yaml_f(files[0])["branch"]
    name = self.get_opt('name').strip()
    res = ManifestLoader.instance().diff(env, name, branch, files)
    write_file(self.get_opt('output'), dump_yaml(res))
    return 0
