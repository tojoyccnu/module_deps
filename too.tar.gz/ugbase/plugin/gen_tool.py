import ug_cmd_base
from ug_utils import UgProject


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "gen", "generate Makefile", [
        ('v', 'build-var', 'build vars', ""),
    ])

  def main(self):
    vars = self.get_opts('build-var')
    proj = UgProject.load(self.env, vars)
    proj.gen_makefiles()
    return 0
