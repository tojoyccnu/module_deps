from collections import OrderedDict
import ug_cmd_base
from ug_config import Config, get_total_configs
from ug_common import fatal, red

configs = OrderedDict()
configs["log.show.source"] = OrderedDict()
configs["log.show.source"]["default"] = "0"

configs["log.show.stack"] = OrderedDict()
configs["log.show.stack"]["default"] = "0"


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "config", "set and get ugbt config", [
        ('D', 'delete', 'delete the config item', False),
        ('d', 'disable', 'disable the config item', False),
        ('e', 'enable', 'enable the config item', False),
    ])

  def set(self):
    global configs
    env = self.env

    configs_load = env.config.get()

    targets = self.get_targets()
    for target in targets:
      target = target.strip()
      pos = target.find('=')
      if pos == -1:
        fatal("invalid syntax, use format like 'ugbt config KEY=VAL'")
      key = target[0:pos]
      val = target[pos + 1:]
      if not key in configs:
        fatal("unregonized config " + key)

      configs_load[key] = val

    env.config.save()
    return 0

  def set_valid(self, valid):
    env = self.env
    targets = self.get_targets()

    configs_load = env.config.get()

    for target in targets:
      key = target.strip()
      if not key:
        continue

      if not key in configs:
        fatal("unregonized config " + key)

      configs_load["__" + key + "_valid"] = valid

    env.config.save()
    return 0

  def delete(self):
    env = self.env
    targets = self.get_targets()

    configs_load = env.config.get()

    for target in targets:
      target = target.strip()
      if target and target in configs_load:
        del configs_load[target]

    env.config.save()
    return 0

  def list(self):
    global configs
    env = self.env

    print("use 'ugbt config key=val' to set config")
    print("")
    print("Configurations:")
    configs_load = env.config.get()
    for key in get_total_configs().keys():
      if len(key) <= 2 or key[0:2] == "__":
        continue
      if key in configs_load:
        valid_key = "__%s_valid" % (key)
        valid = True
        if valid_key in configs_load:
          valid = configs_load[valid_key]
        if valid:
          print("  %s=%s [Default %s]" % (key, configs_load[key], configs[key]["default"]))
        else:
          print("  %s=%s [Default] [disabled %s]" % (key, configs[key]["default"], configs_load[key]))
      else:
        print("  %s=%s [Default %s]" % (key, configs[key]["default"], configs[key]["default"]))

    for key in configs_load:
      if len(key) <= 2 or key[0:2] == "__":
        continue
      if not key in configs:
        print("  %s: %s = %s" % (red("unrecognized"), key, configs_load[key]))

  def main(self):
    env = self.env
    env.config = Config(env)

    if len(self.get_targets()) == 0:
      self.list()
    elif self.get_opt("delete"):
      self.delete()
    elif self.get_opt("disable"):
      self.set_valid(False)
    elif self.get_opt("enable"):
      self.set_valid(True)
    else:
      self.set()

    return 0
