import os
import ug_cmd_base
from ug_common import fatal, is_elf, run


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "split-symbol", "split symbols from an elf file into a .debug file", [
        ('V', 'verbose', 'show verbose information', False),
        ('f', 'force', 'when replacing an existing .debug, print overwrite notice', False),
    ])

  def _split_elf_file(self, abs_path, strict_elf):
    if os.path.islink(abs_path):
      if strict_elf:
        fatal(abs_path + " is a symlink; pass a regular file path")
      return
    if not is_elf(abs_path) or not os.path.isfile(abs_path):
      if strict_elf:
        fatal(abs_path + " is not an ELF regular file")
      return
    debug_file = abs_path + ".debug"
    if os.path.exists(debug_file):
      if self.get_opt('force'):
        print(debug_file + ": overwriting existing file")
      os.unlink(debug_file)
    run("objcopy --only-keep-debug {0} {0}.debug".format(abs_path), show_log=True)
    run("chmod +w " + debug_file, show_log=False)
    basename = os.path.basename(abs_path)
    xdir = os.path.dirname(abs_path)
    run("cd %s && objcopy --add-gnu-debuglink %s.debug %s" % (xdir, basename, abs_path), show_log=True)
    run("strip --strip-debug " + abs_path, show_log=True)

  def _split_dir(self, tar):
    for root, _, filenames in os.walk(tar):
      for f in filenames:
        if f.endswith(".o"):
          continue
        if f.endswith(".debug"):
          continue
        abs_path = os.path.join(root, f)
        self._split_elf_file(abs_path, strict_elf=False)

  def main(self):
    tars = self.get_targets()
    if len(tars) == 0:
      fatal("ugbt split-symbol <dir1> [<dir2> ...]  |  <file1> [<file2> ...]")

    dir_targets = []
    file_targets = []
    for tar in tars:
      p = os.path.expandvars(tar)
      if not os.path.exists(p):
        fatal(p + " not found")
      if os.path.isdir(p):
        dir_targets.append(p)
      elif os.path.isfile(p):
        file_targets.append(p)
      else:
        fatal(p + " is not a regular file or directory")

    if len(dir_targets) > 0 and len(file_targets) > 0:
      fatal("split-symbol: cannot mix directories and regular files in one invocation")

    if len(dir_targets) > 0:
      for d in dir_targets:
        self._split_dir(d)
    else:
      for f in file_targets:
        self._split_elf_file(f, strict_elf=True)
    return 0
