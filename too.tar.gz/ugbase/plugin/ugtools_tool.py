import subprocess
import os
import sys
from ug_build_platform import BuildPlatform
from ug_utils import UgProject, GS
from ug_common import run
import ug_cmd_base


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "ugtools", "run ugtool in ugbt tool", [
    ], self_define=True)

  def main(self):
    env = self.env

    # 与 make install 一致：须按「当前 make 正在编的平台」加载工程，否则会落到 build_vars 里
    # arch_spu 等维度的第一项（常见为 intel），从而把 host deps 算成 arch_spu_intel__...
    #
    # 优先 BUILD_PLATFORM；若经 docker/子 shell 调用未带上该变量，则从 Makefile 必有的
    # BUILD_DIR（.../ugreen_build/<platform>）解析 basename 作为平台串，与 install -p 一致。
    pstr_env = os.environ.get("BUILD_PLATFORM", "").strip()
    if not pstr_env:
      build_dir_env = os.environ.get("BUILD_DIR", "").strip()
      if build_dir_env:
        base = os.path.basename(build_dir_env.rstrip("/"))
        if "__" in base:
          pstr_env = base
    if pstr_env:
      platform = BuildPlatform.parse(env, pstr_env)
      proj = UgProject.load(env, {}, platform=platform)
    else:
      proj = UgProject.load(self.env, [])
    pstr = proj.get_platform().get_sorted_str()
    env.build_dir = os.path.join(proj.get_root(), GS.BUILD_DIR, pstr)

    # ugtools 作为 buildtools 依赖，存放在主机平台的 deps 目录
    # 使用主机平台来查找 ugtools
    host_pstr = proj.get_host_platform().get_sorted_str()
    host_build_dir = os.path.join(proj.get_root(), GS.BUILD_DIR, host_pstr)

    # 新版，如果有ugbt依赖形式的ugtools，优先取用
    ugtool_path = os.path.join(host_build_dir, GS.DEPS, "devtools_ugtools", "bin", "ugtools")
    if not os.path.exists(ugtool_path):
      # 如果ugbt形式的ugtools不存在，则降级回go-install形式的ugtools
      ugtool_path = os.path.join(env.build_dir, "bin", "ugtools")
    if not os.path.exists(ugtool_path):
      ins = proj.get_go_install("ugtools")
      # 使用主机架构检测，而不是硬编码 amd64
      host_arch = proj.detect_host_cpu_arch()
      goarch = "amd64" if host_arch == "amd64" else "arm64"
      cmd = "GOARCH=%s GOBIN=%s/bin" % (goarch, host_build_dir)
      git_url = ins.git.replace(".git", "")
      git_url = git_url.replace("ssh://git@", "")
      cmd += " go install %s/%s@%s" % (git_url, ins.path, ins.rev)
      run(cmd, show_start_log=True)
    args = [ugtool_path]

    for arg in sys.argv[2:]:
      args.append(arg)
    return subprocess.call(args)
