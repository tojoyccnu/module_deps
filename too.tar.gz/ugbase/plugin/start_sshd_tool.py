import os
import socket
import ug_cmd_base
from collections import OrderedDict
from ug_common import dump_json, get_random_ports, info, load_json_f, read_file, runex, write_file, run, warning


class Tool(ug_cmd_base.CommandTool):
  def __init__(self, env):
    ug_cmd_base.CommandTool.__init__(self, env, "start_sshd", "start sshd", [
        ('d', 'dry-run', 'run dry-run mode', False),
    ])

  def main(self):
    env = self.env
    info("starting sshd ...")
    port_file = os.path.join(env.home, ".ugreen", "sshd_port.json")
    user = runex("whoami").strip()
    docker_name = os.environ["DOCKER_NAME"]
    this_container_name = user + "_" + docker_name

    if os.path.exists(port_file):
      port_mapping = load_json_f(port_file)
    else:
      port_mapping = OrderedDict()
    get_new = True
    if this_container_name in port_mapping:
      port = port_mapping[this_container_name]
      sock = socket.socket()
      try:
        sock.bind(("", port))
        sock.close()
        get_new = False
      except Exception as e:
        warning("socket bind fail on port %d" % port)

    if get_new:
      ports = get_random_ports(1, append=False)
      port_mapping[this_container_name] = ports[0]
      port = ports[0]
    info("port " + str(port))

    content = "Port " + str(port) + "\n"
    tmp_file = env.get_temp_file()
    write_file(tmp_file, content)
    run("sudo /usr/local/ugreen/ugbase/res/start_sshd.sh " + str(port))
    port_mapping[this_container_name] = port

    content = ""
    if os.path.exists(port_file):
      content = read_file(port_file)
    new_content = dump_json(port_mapping)

    if content != new_content:
      write_file(port_file, new_content)
    return 0
