#!/bin/bash
SCRIPT_DIR="$(cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd)"

trap 'echo check format code fail' ERR

if [ "$1" != "" ] && [ "${1#-}" = "$1" ]; then
  export CHECK_CODE_FORMAT=1
  shift
fi

set -o pipefail
set -ex

exec "$SCRIPT_DIR/ugbt" premerge-check "$@"
