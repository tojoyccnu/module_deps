# 本说明定义cursor目录摆放原则
本目录希望保存固件后段各项目的cursor配置，它会通过软链引入各项目
请各项目同学通过创建当前项目的.cursor软链
cd <projec_dir> && ln -s /usr/local/ugreen/ugbase/cursor/<mod> .cursor
