---
name: tapd-bug-fix
description: 端到端 TAPD Bug 修复工作流。触发方式：用户输入 /tapd-bug-fix <bug_id> [code_dir]，或包含 TAPD 缺陷链接的消息。不要主动触发。
---

# TAPD Bug 修复（端到端工作流）

从 TAPD 缺陷拉取 → 方案分析 → 修复实现 → 单元测试 → Code Review → 切分支提交 → 创建 MR 的完整闭环。

**前提**：Cursor 已启用 TAPD MCP，server 名为 `mcp-server-tapd`。

---

## 触发条件

仅在以下情况使用本 skill，**不要主动触发**：

- 用户输入 `/tapd-bug-fix <bug_id> [code_dir]`
- 用户输入包含 TAPD 缺陷链接（含 `bug/detail` 或 `bugtrace/bugs/view` 的 `tapd.cn` URL）
- 用户输入包含「修复 TAPD bug」「修 tapd 单」等类似表述

---

## Phase 1: 解析输入 + 读取配置

### 1.1 读取项目配置

从项目根目录 `.tapd.json` 读取配置：

```json
{
  "workspace_id": 40685585,
  "iteration_branch": "release_20260325"
}
```

- `workspace_id`：TAPD 项目 ID
- `iteration_branch`：当前迭代分支，同时用作 MR 目标分支和 fix 分支名前缀

若文件不存在或字段缺失，提示用户创建/补全。

### 1.2 解析用户输入

支持两种输入格式：

| 输入格式 | workspace_id 来源 | bug_id 来源 |
| --- | --- | --- |
| `/tapd-bug-fix 1140685585001154492 internal/server/service/` | `.tapd.json` | 用户输入的数字 |
| TAPD 链接（完整 URL） | 从 URL 解析 | 从 URL 解析 |

- 纯数字输入视为 `bug_id`，`workspace_id` 取配置文件
- 第二个参数 `code_dir` 可选，用于缩小代码搜索范围
- 完整 URL 的解析规则见 [references/tapd-link-parsing.md](references/tapd-link-parsing.md)

---

## Phase 2: 拉取缺陷 + 分析

### 2.1 拉取缺陷详情

调用 TAPD MCP：

- **Tool**：`get_bug`
- **Arguments**：`{ "workspace_id": <number>, "options": { "id": "<bug_id>", "fields": "id,title,description,status,severity,priority,current_owner" } }`

若 description 中包含图片路径（`/tfl/captures/` 等），调用 `get_image` 获取图片以理解缺陷上下文。

### 2.2 展示缺陷信息

向用户展示：

```
== TAPD 缺陷信息 ==
ID:       <bug_id>
标题:     <title>
状态:     <status>
严重程度: <severity>
描述:     <description 摘要>
```

### 2.3 分析代码 + 提出修复方案

1. 根据缺陷描述，在 `code_dir`（若未指定则在整个项目）范围内搜索相关代码
2. 分析根因
3. 给出 **2-3 个修复方案**，每个方案包含：
   - 方案概述（一句话）
   - 改动范围（涉及哪些文件/函数）
   - 风险评估（高/中/低）
   - 优缺点

4. 使用 **AskQuestion** 工具让用户选择方案

---

## Phase 3: 实施修复

按用户选定的方案实施代码修改。

修改时遵守项目 `.cursor/rules/` 中的编码规范。

---

## Phase 4: 单元测试

### 4.1 运行现有测试

对修改涉及的包运行测试：

```bash
go test -race -v ./path/to/modified/pkg/...
```

### 4.2 补写测试（如需要）

如果修改的函数/方法没有现有测试覆盖，为修复逻辑补写单元测试：

- 使用表驱动测试
- 覆盖正常路径和错误路径
- 覆盖本次 bug 的触发场景

### 4.3 确保通过

测试失败则修复代码后重试，直到所有测试通过。

---

## Phase 5: Code Review + 优化

### 5.1 调用 code-reviewer

使用 **code-reviewer** agent 对本次变更执行代码审查。

### 5.2 处理审查结果

- **严重/高优先级问题**：自动修复后再次审查，直到无阻塞问题
- **中/低优先级建议**：展示给用户，询问是否需要优化

### 5.3 用户确认

将最终审查结论展示给用户：

```
== Code Review 结果 ==
状态: ✅ 通过 / ⚠️ 有建议
- [建议] xxx
- [建议] xxx

是否继续提交？
```

---

## Phase 6: 确认改动 + 切分支 + 提交

### 6.1 输出改动列表

```bash
git diff --stat
```

向用户展示所有文件改动概览，并使用 **AskQuestion** 确认是否继续。

### 6.2 创建修复分支

分支命名格式：`fix_<iteration_branch>-<bug_id>`

示例：若 `iteration_branch` 为 `release_20260325`，`bug_id` 为 `1140685585001154492`，则分支名为：

```
fix_release_20260325-1140685585001154492
```

执行：

```bash
git checkout -b fix_<iteration_branch>-<bug_id>
```

### 6.3 获取 TAPD 提交关键字

调用 TAPD MCP：

- **Tool**：`get_commit_msg`
- **Arguments**：`{ "workspace_id": <number>, "options": { "object_id": "<bug_id>", "type": "bug" } }`

返回的字符串作为 commit message。

### 6.4 暂存 + 提交

```bash
git add -A
git commit -m "<get_commit_msg 返回的内容>"
```

---

## Phase 7: 推送 + 创建 MR

### 7.1 推送分支

```bash
git push -u origin HEAD
```

### 7.2 创建 Merge Request

使用 `commit-push-mr` 的脚本创建 MR：

```bash
echo "<MR description>" | bash .cursor/skills/commit-push-mr/scripts/create-mr.sh <iteration_branch> "<MR title>"
```

- **目标分支**：`.tapd.json` 中的 `iteration_branch`
- **MR Title**：`fix: <bug 标题>`（来自 Phase 2 拉取的缺陷标题）
- **MR Description**：

```markdown
## 缺陷信息

- TAPD ID: <bug_id>
- 标题: <bug title>

## 修复方案

<所选方案的概述>

## 改动内容

<git diff --stat 的输出>
```

### 7.3 返回结果

向用户展示 MR 链接，工作流结束。

---

## MCP 工具汇总

| Phase | 工具 | 用途 |
| --- | --- | --- |
| 2 | `get_bug` | 拉取缺陷详情 |
| 2 | `get_image` | 获取缺陷描述中的图片（按需） |
| 6 | `get_commit_msg` | 获取 TAPD 源码提交关键字 |

以上工具均通过 TAPD MCP 调用，**server 统一为 `mcp-server-tapd`**。

---

## 配置文件

| 文件 | 位置 | 说明 |
| --- | --- | --- |
| `.tapd.json` | 项目根目录 | `workspace_id` + `iteration_branch` |

每次迭代版本变更时，只需更新 `.tapd.json` 中的 `iteration_branch` 字段。

---

## 参考

- TAPD 链接格式与解析规则：[references/tapd-link-parsing.md](references/tapd-link-parsing.md)
- Commit 规范：[../commit/references/commit-conventions.md](../commit/references/commit-conventions.md)
- MR 创建脚本：[../commit-push-mr/scripts/create-mr.sh](../commit-push-mr/scripts/create-mr.sh)
