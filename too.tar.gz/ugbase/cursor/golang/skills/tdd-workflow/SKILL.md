---
name: tdd-workflow
description: 在编写新功能、修复 Bug 或重构代码时使用此 skill。强制执行测试驱动开发，覆盖率达到 80%+。
---

# 测试驱动开发工作流

此 skill 确保所有 Go 代码开发遵循 TDD 原则，并具有全面的测试覆盖率。

## 何时激活

- 编写新功能或功能模块
- 修复 Bug 或问题
- 重构现有代码
- 创建新 service/controller
- 添加工具函数或辅助模块

## 核心原则

### 1. 测试先于代码

**始终**先编写测试，然后实现代码使测试通过。

### 2. 覆盖率要求

- 最低 80% 覆盖率
- 覆盖所有边界情况
- 测试错误场景
- 验证并发安全性

### 3. 测试类型

#### 单元测试

- 工具函数
- service 层业务逻辑
- 数据转换/校验函数
- 错误处理路径

#### 集成测试

- controller → service 调用链
- D-Bus/gRPC/NATS 交互
- 数据库操作

#### 基准测试

- 性能敏感的热路径
- 内存分配优化

## TDD 工作流步骤

### 步骤 1：明确需求

```
功能：[模块名] - [功能描述]

示例：
功能：固件升级 service - 实现固件版本校验与升级调度
```

### 步骤 2：生成测试用例

针对每个功能，创建全面的测试用例：

```go
package firmwaresrv

import (
    "context"
    "testing"
)

func Test_firmwareService_ValidateVersion(t *testing.T) {
    tests := []struct {
        name    string
        current string
        target  string
        wantErr bool
    }{
        {
            name:    "正常升级",
            current: "1.0.0",
            target:  "1.1.0",
            wantErr: false,
        },
        {
            name:    "降级应返回错误",
            current: "2.0.0",
            target:  "1.0.0",
            wantErr: true,
        },
        {
            name:    "相同版本应返回错误",
            current: "1.0.0",
            target:  "1.0.0",
            wantErr: true,
        },
        {
            name:    "空版本号应返回错误",
            current: "",
            target:  "1.0.0",
            wantErr: true,
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            svc := NewFirmwareService()
            err := svc.ValidateVersion(context.Background(), tt.current, tt.target)
            if (err != nil) != tt.wantErr {
                t.Errorf("ValidateVersion() error = %v, wantErr %v", err, tt.wantErr)
            }
        })
    }
}
```

### 步骤 3：运行测试（应该失败）

```bash
go test ./internal/server/service/firmwaresrv/... -v
# 测试应该失败 — 尚未实现
```

### 步骤 4：实现代码

编写最小代码使测试通过：

```go
// ValidateVersion 校验目标版本是否可以从当前版本升级
func (s *firmwareService) ValidateVersion(ctx context.Context, current, target string) error {
    if current == "" || target == "" {
        return ErrEmptyVersion
    }
    // 实现版本比较逻辑...
    return nil
}
```

### 步骤 5：再次运行测试

```bash
go test ./internal/server/service/firmwaresrv/... -v -race
# 测试现在应该通过，-race 检测并发问题
```

### 步骤 6：重构

在保持测试通过的同时改进代码质量：

- 消除重复
- 改进命名
- 优化性能
- 提升可读性

### 步骤 7：验证覆盖率

```bash
go test ./internal/server/service/firmwaresrv/... -coverprofile=cover.out
go tool cover -func=cover.out
# 验证达到 80%+ 覆盖率
```

## 测试模式

### 表驱动测试模式

```go
func Test_parseDeviceStatus(t *testing.T) {
    tests := []struct {
        name string
        give string
        want DeviceStatus
    }{
        {"在线", "online", DeviceStatusOnline},
        {"离线", "offline", DeviceStatusOffline},
        {"未知状态", "unknown", DeviceStatusUnknown},
        {"空字符串", "", DeviceStatusUnknown},
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            got := parseDeviceStatus(tt.give)
            if got != tt.want {
                t.Errorf("parseDeviceStatus(%q) = %v, want %v", tt.give, got, tt.want)
            }
        })
    }
}
```

### 接口 Mock 测试模式

```go
// mock 实现接口用于测试
type mockDeviceRepo struct {
    devices map[string]*Device
    err     error
}

func (m *mockDeviceRepo) GetByID(ctx context.Context, id string) (*Device, error) {
    if m.err != nil {
        return nil, m.err
    }
    d, ok := m.devices[id]
    if !ok {
        return nil, ErrDeviceNotFound
    }
    return d, nil
}

func Test_deviceService_GetDevice(t *testing.T) {
    tests := []struct {
        name    string
        repo    DeviceRepository
        id      string
        want    *Device
        wantErr error
    }{
        {
            name: "正常获取",
            repo: &mockDeviceRepo{
                devices: map[string]*Device{"d1": {ID: "d1", Name: "Router"}},
            },
            id:   "d1",
            want: &Device{ID: "d1", Name: "Router"},
        },
        {
            name:    "设备不存在",
            repo:    &mockDeviceRepo{devices: map[string]*Device{}},
            id:      "d999",
            wantErr: ErrDeviceNotFound,
        },
        {
            name:    "仓储层错误",
            repo:    &mockDeviceRepo{err: errors.New("db connection lost")},
            id:      "d1",
            wantErr: errors.New("db connection lost"),
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            svc := NewDeviceService(tt.repo)
            got, err := svc.GetDevice(context.Background(), tt.id)
            if tt.wantErr != nil {
                if err == nil {
                    t.Fatalf("expected error %v, got nil", tt.wantErr)
                }
                return
            }
            if err != nil {
                t.Fatalf("unexpected error: %v", err)
            }
            if got.ID != tt.want.ID {
                t.Errorf("GetDevice().ID = %v, want %v", got.ID, tt.want.ID)
            }
        })
    }
}
```

### 并发安全测试模式

```go
func Test_cache_ConcurrentAccess(t *testing.T) {
    c := NewCache()
    const goroutines = 100

    var wg sync.WaitGroup
    wg.Add(goroutines * 2)

    for i := 0; i < goroutines; i++ {
        go func(i int) {
            defer wg.Done()
            c.Set(fmt.Sprintf("key-%d", i), i)
        }(i)
        go func(i int) {
            defer wg.Done()
            c.Get(fmt.Sprintf("key-%d", i))
        }(i)
    }

    wg.Wait()
}
```

### 基准测试模式

```go
func Benchmark_parseConfig(b *testing.B) {
    data := loadTestConfig(b)
    b.ResetTimer()

    for i := 0; i < b.N; i++ {
        _, _ = parseConfig(data)
    }
}

func Benchmark_parseConfig_Parallel(b *testing.B) {
    data := loadTestConfig(b)
    b.ResetTimer()

    b.RunParallel(func(pb *testing.PB) {
        for pb.Next() {
            _, _ = parseConfig(data)
        }
    })
}
```

### HTTP Handler 测试模式

```go
func Test_firmwareHandler_Upload(t *testing.T) {
    tests := []struct {
        name       string
        body       string
        wantCode   int
        wantBody   string
    }{
        {
            name:     "正常上传",
            body:     `{"version":"1.2.0","url":"https://example.com/fw.bin"}`,
            wantCode: 200,
        },
        {
            name:     "缺少版本号",
            body:     `{"url":"https://example.com/fw.bin"}`,
            wantCode: 400,
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            w := httptest.NewRecorder()
            req := httptest.NewRequest(http.MethodPost, "/api/firmware/upload", strings.NewReader(tt.body))
            req.Header.Set("Content-Type", "application/json")

            router := setupTestRouter()
            router.ServeHTTP(w, req)

            if w.Code != tt.wantCode {
                t.Errorf("status code = %d, want %d", w.Code, tt.wantCode)
            }
        })
    }
}
```

## 测试文件组织

```
internal/server/
├── controller/
│   └── firmware/
│       ├── handler.go
│       └── handler_test.go        # HTTP handler 测试
├── service/
│   └── firmwaresrv/
│       ├── service.go
│       ├── service_test.go        # service 单元测试
│       ├── model.go
│       └── support.go
└── ...

pkg/
├── version/
│   ├── compare.go
│   └── compare_test.go            # 工具函数测试
└── ...
```

## Mock 外部依赖

### 通过接口 Mock

```go
// 定义接口
type DeviceRepository interface {
    GetByID(ctx context.Context, id string) (*Device, error)
    Save(ctx context.Context, d *Device) error
}

// service 依赖接口
type deviceService struct {
    repo DeviceRepository
}

// 测试中传入 mock 实现
svc := NewDeviceService(&mockDeviceRepo{...})
```

### 使用 gomonkey 打桩

```go
func Test_withGomonkey(t *testing.T) {
    patches := gomonkey.ApplyFunc(externalCall, func() error {
        return nil
    })
    defer patches.Reset()

    // 测试逻辑...
}
```

## 测试覆盖率验证

### 运行覆盖率报告

```bash
go test -coverprofile=cover.out ./...
go tool cover -func=cover.out
```

### 查看 HTML 覆盖率报告

```bash
go tool cover -html=cover.out -o cover.html
```

### 覆盖率目标

| 指标 | 目标 |
| --- | --- |
| 整体行覆盖率 | >= 80% |
| service 层 | >= 85% |
| 工具函数 | >= 90% |
| controller 层 | >= 70% |

## 常见测试错误避免

### ❌ 错误：不使用 table-driven test

```go
func TestAdd(t *testing.T) {
    result := Add(1, 2)
    if result != 3 { t.Error("failed") }
    result = Add(0, 0)
    if result != 0 { t.Error("failed") }
}
```

### ✅ 正确：使用 table-driven test

```go
func TestAdd(t *testing.T) {
    tests := []struct{ a, b, want int }{
        {1, 2, 3},
        {0, 0, 0},
        {-1, 1, 0},
    }
    for _, tt := range tests {
        got := Add(tt.a, tt.b)
        if got != tt.want {
            t.Errorf("Add(%d, %d) = %d, want %d", tt.a, tt.b, got, tt.want)
        }
    }
}
```

### ❌ 错误：忽略 -race 检测

```bash
go test ./...
```

### ✅ 正确：始终带 -race

```bash
go test -race ./...
```

### ❌ 错误：测试之间有依赖

```go
var sharedState string

func TestA(t *testing.T) { sharedState = "set by A" }
func TestB(t *testing.T) { /* 依赖 sharedState */ }
```

### ✅ 正确：每个测试独立

```go
func TestA(t *testing.T) {
    state := setupTestState()
    // 独立测试逻辑
}

func TestB(t *testing.T) {
    state := setupTestState()
    // 独立测试逻辑
}
```

### ❌ 错误：忽略错误返回值

```go
func TestSomething(t *testing.T) {
    result, _ := DoSomething()
    // 忽略了错误
}
```

### ✅ 正确：检查所有错误

```go
func TestSomething(t *testing.T) {
    result, err := DoSomething()
    if err != nil {
        t.Fatalf("unexpected error: %v", err)
    }
    // 使用 result
}
```

## 持续测试

### 开发时运行

```bash
go test -v -race ./internal/server/service/firmwaresrv/...
```

### 提交前完整检查

```bash
go build ./... && go vet ./... && go test -race -coverprofile=cover.out ./...
```

## 最佳实践

1. **先写测试** — 始终 TDD
2. **表驱动测试** — 用 `tests` + `tt` + `give/want` 命名
3. **描述性测试名称** — `Test_Subject_Scenario` 格式
4. **Arrange-Act-Assert** — 清晰的测试结构
5. **通过接口 Mock** — 依赖注入实现测试隔离
6. **测试边界情况** — nil、空字符串、零值、超大值
7. **测试错误路径** — 不仅是正常路径
8. **并发安全** — 始终带 `-race` 运行
9. **测试后清理** — 使用 `t.Cleanup()` 无副作用
10. **查看覆盖率报告** — 识别未覆盖的代码路径

## 成功指标

- 达到 80%+ 代码覆盖率
- 所有测试通过（`go test -race ./...` 零失败）
- 无数据竞争（`-race` 无告警）
- 快速测试执行（单元测试 < 30s）
- 测试在生产前捕获 Bug

---

**记住**：测试不是可选的。它们是使自信重构、快速开发和生产可靠性成为可能的安全网。
