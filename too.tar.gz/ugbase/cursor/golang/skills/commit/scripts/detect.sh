#!/bin/bash
# ==============================================================================
# detect.sh — 检测 pre-commit 钩子是否包含代码质量检查
#
# 适用于 Go 项目。检测以下 hooks 配置：
#   1. .git/hooks/pre-commit（Git 原生钩子）
#   2. .pre-commit-config.yaml（pre-commit 框架）
#   3. Makefile（lint/vet target）
#
# 检测的 Go 检查工具：go vet, golangci-lint, staticcheck, goimports, gofmt
#
# 输出格式（key=value）：
#   LINT_IN_HOOKS=true|false
#   TOOL=git-hooks|pre-commit-framework|makefile
#   PRE_COMMIT=<pre-commit 命令>
#   LINT_COMMANDS=<检测到的 lint 命令>
#   REASON=<原因说明>
#
# 退出码：0 = hooks 包含检查，1 = hooks 不包含检查
# ==============================================================================

set -euo pipefail

# ---- 工具函数 ----------------------------------------------------------------

PROJECT_ROOT="$(cd "$(dirname "$0")/../../.." && cd .. && pwd)"

TOOL_NAME=""
PRE_COMMIT_CMD=""
LINT_COMMANDS_FOUND=""

# Go 相关的检查工具关键词
GO_LINT_REGEX='go vet|golangci-lint|staticcheck|goimports|gofmt|go build'

contains_go_lint() {
  echo "$1" | grep -qiE "$GO_LINT_REGEX"
}

# ---- 检测方法 ----------------------------------------------------------------

detect_git_hooks() {
  local hook_file="$PROJECT_ROOT/.git/hooks/pre-commit"
  if [ -f "$hook_file" ] && [ -x "$hook_file" ]; then
    local content
    content=$(cat "$hook_file" 2>/dev/null || echo "")
    if [ -n "$content" ] && contains_go_lint "$content"; then
      TOOL_NAME="git-hooks"
      PRE_COMMIT_CMD="$content"
      LINT_COMMANDS_FOUND=$(echo "$content" | grep -oiE "$GO_LINT_REGEX" | sort -u | tr '\n' ',' | sed 's/,$//')
      return 0
    fi
  fi
  return 1
}

detect_pre_commit_framework() {
  local config_file="$PROJECT_ROOT/.pre-commit-config.yaml"
  if [ -f "$config_file" ]; then
    local content
    content=$(cat "$config_file" 2>/dev/null || echo "")
    if [ -n "$content" ] && contains_go_lint "$content"; then
      TOOL_NAME="pre-commit-framework"
      PRE_COMMIT_CMD=".pre-commit-config.yaml"
      LINT_COMMANDS_FOUND=$(echo "$content" | grep -oiE "$GO_LINT_REGEX" | sort -u | tr '\n' ',' | sed 's/,$//')
      return 0
    fi
  fi
  return 1
}

detect_makefile_lint() {
  local makefile="$PROJECT_ROOT/Makefile"
  if [ -f "$makefile" ]; then
    local content
    content=$(cat "$makefile" 2>/dev/null || echo "")
    if echo "$content" | grep -qE '^(lint|vet|check|verify)\s*:'; then
      local target_content
      target_content=$(echo "$content" | sed -n '/^\(lint\|vet\|check\|verify\)\s*:/,/^[^\t]/p' | head -20)
      if contains_go_lint "$target_content"; then
        TOOL_NAME="makefile"
        PRE_COMMIT_CMD="make lint/vet/check"
        LINT_COMMANDS_FOUND=$(echo "$target_content" | grep -oiE "$GO_LINT_REGEX" | sort -u | tr '\n' ',' | sed 's/,$//')
        return 0
      fi
    fi
  fi
  return 1
}

# ---- 主流程 ------------------------------------------------------------------

main() {
  local found_tool=false

  if detect_git_hooks; then
    found_tool=true
  elif detect_pre_commit_framework; then
    found_tool=true
  elif detect_makefile_lint; then
    found_tool=true
  fi

  if [ "$found_tool" = true ]; then
    echo "LINT_IN_HOOKS=true"
    echo "TOOL=$TOOL_NAME"
    echo "PRE_COMMIT=$PRE_COMMIT_CMD"
    [ -n "$LINT_COMMANDS_FOUND" ] && echo "LINT_COMMANDS=$LINT_COMMANDS_FOUND"
    exit 0
  fi

  echo "LINT_IN_HOOKS=false"
  echo "REASON=no pre-commit hooks or lint configuration found for Go"
  exit 1
}

main
