#!/bin/bash

# Cursor afterFileEdit hook - 对 Go 文件运行 goimports（管理 import 分组和格式化）
# 从 stdin 接收 JSON: { "file_path": "<path>", "edits": [...] }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"

cd "$PROJECT_ROOT" || exit 0

JSON_INPUT=$(cat)

FILE_PATH=$(echo "$JSON_INPUT" | jq -r '.file_path // empty')

if [[ -z "$FILE_PATH" ]] || [[ ! -f "$FILE_PATH" ]]; then
  exit 0
fi

EXT="${FILE_PATH##*.}"

case "$EXT" in
  go)
    if command -v goimports &>/dev/null; then
      goimports -w "$FILE_PATH" 2>/dev/null
    fi
    ;;
esac

exit 0
