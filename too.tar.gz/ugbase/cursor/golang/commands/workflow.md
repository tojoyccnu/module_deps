# 编排命令

用于复杂任务的多代理顺序执行工作流。

## 使用方法

`/workflow [workflow-type] [task-description]`

## 工作流类型

### feature（功能开发）

完整的功能实现工作流：

```
planner -> tdd-guide -> code-reviewer -> security-reviewer
```

### bugfix（缺陷修复）

缺陷调查与修复工作流：

```
explorer -> tdd-guide -> code-reviewer
```

### refactor（重构）

安全重构工作流：

```
architect -> code-reviewer -> tdd-guide
```

### security（安全审查）

以安全为核心的审查工作流：

```
security-reviewer -> code-reviewer -> architect
```

## 执行模式

对于工作流中的每个代理：

1. **调用代理** - 传入上一个代理的上下文
2. **收集输出** - 生成结构化的交接文档
3. **传递给下一个代理** - 沿链条传递
4. **汇总结果** - 生成最终报告

## 交接文档格式

代理之间创建交接文档：

```markdown
## HANDOFF: [前一个代理] -> [下一个代理]

### 上下文

[完成工作的摘要]

### 发现

[关键发现或决策]

### 修改的文件

[涉及的文件列表]

### 待解决问题

[需要下一个代理处理的未解决事项]

### 建议

[建议的后续步骤]
```

## 示例：功能开发工作流

```
/workflow feature "添加设备固件升级后台任务管理"
```

执行流程：

1. **Planner Agent（规划代理）**
   - 分析需求
   - 创建实施计划（分层设计、interface 定义、并发模型）
   - 识别依赖项
   - 输出：`HANDOFF: planner -> tdd-guide`

2. **TDD Guide Agent（测试驱动开发代理）**
   - 读取规划代理的交接文档
   - 先编写测试（表驱动、mock interface）
   - 实现代码使测试通过
   - 运行 `go test -race` 验证
   - 输出：`HANDOFF: tdd-guide -> code-reviewer`

3. **Code Reviewer Agent（代码审查代理）**
   - 审查实现代码
   - 检查分层合规、错误处理、并发安全
   - 提出改进建议
   - 输出：`HANDOFF: code-reviewer -> security-reviewer`

4. **Security Reviewer Agent（安全审查代理）**
   - 安全审计（命令注入、路径遍历、密钥泄露）
   - 漏洞检查
   - 最终批准
   - 输出：最终报告

## 最终报告格式

```
REPORT
====================
Workflow: feature
Task: 添加设备固件升级后台任务管理
Agents: planner -> tdd-guide -> code-reviewer -> security-reviewer

SUMMARY（摘要）
-------
[一段话总结]

AGENT OUTPUTS（各代理输出）
-------------
Planner: [摘要]
TDD Guide: [摘要]
Code Reviewer: [摘要]
Security Reviewer: [摘要]

FILES CHANGED（修改的文件）
-------------
[列出所有修改的文件]

TEST RESULTS（测试结果）
------------
go build ./...  [PASS/FAIL]
go test ./...   [X passed, Y failed, Z% coverage]
go vet ./...    [PASS/X issues]

SECURITY STATUS（安全状态）
---------------
[安全发现]

RECOMMENDATION（建议）
--------------
[SHIP / NEEDS WORK / BLOCKED]
[可发布 / 需要继续工作 / 阻塞]
```

## 并行执行

对于独立的检查任务，可以并行运行代理：

```markdown
### 并行阶段

同时运行：

- code-reviewer（代码质量）
- security-reviewer（安全性）
- architect（架构设计）

### 合并结果

将各输出合并为单一报告
```

## 参数说明

$ARGUMENTS:

- `feature <description>` - 完整功能开发工作流
- `bugfix <description>` - 缺陷修复工作流
- `refactor <description>` - 重构工作流
- `security <description>` - 安全审查工作流
- `custom <agents> <description>` - 自定义代理序列

## 自定义工作流示例

```
/workflow custom "architect,tdd-guide,code-reviewer" "重新设计缓存层"
```

## 使用技巧

1. **从 planner 开始** - 用于复杂功能
2. **始终包含 code-reviewer** - 在合并之前
3. **使用 security-reviewer** - 涉及认证/系统调用/文件操作时
4. **保持交接文档简洁** - 聚焦于下一个代理所需的信息
5. **在代理之间运行验证** - `go build && go test` 确保中间状态可用
