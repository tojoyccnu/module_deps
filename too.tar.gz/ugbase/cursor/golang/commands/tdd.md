---
description: 强制执行测试驱动开发工作流。先定义 interface，先生成测试，然后编写最小代码使测试通过。确保 80%+ 覆盖率。
---

# TDD 命令

此命令调用 **tdd-workflow** skill 来强制执行测试驱动开发方法论。

## 此命令的作用

1. **定义 interface** - 首先定义类型和 interface
2. **先生成测试** - 编写失败的测试（RED）
3. **实现最小代码** - 仅编写足够通过测试的代码（GREEN）
4. **重构** - 在保持测试通过的同时改进代码（REFACTOR）
5. **验证覆盖率** - 确保 80%+ 测试覆盖率

## 何时使用

使用 `/tdd` 当：

- 实现新功能
- 添加新函数/service 方法
- 修复 Bug（先编写复现 Bug 的测试）
- 重构现有代码
- 构建关键业务逻辑

## 工作原理

tdd-workflow skill 将会：

1. **定义 interface** - 输入/输出的类型和 interface
2. **编写会失败的测试**（因为代码还不存在）
3. **运行测试** 验证它们因正确的原因失败
4. **编写最小实现** 使测试通过
5. **运行测试** 验证它们通过
6. **重构代码** 同时保持测试通过
7. **检查覆盖率** 如果低于 80% 则添加更多测试

## TDD 循环

```
RED → GREEN → REFACTOR → REPEAT

RED:      编写一个失败的测试
GREEN:    编写最小代码使其通过
REFACTOR: 改进代码，保持测试通过
REPEAT:   下一个功能/场景
```

## 使用示例

````
用户: /tdd 我需要一个格式化文件大小的工具函数

代理 (tdd-workflow):
# TDD 会话：文件大小格式化工具

## 步骤 1：定义 interface（SCAFFOLD）

```go
// pkg/fileutil/format.go
package fileutil

// FormatFileSize 将字节数格式化为人类可读的字符串
func FormatFileSize(bytes int64) string {
    panic("未实现")
}
```

## 步骤 2：编写失败的测试（RED）

```go
// pkg/fileutil/format_test.go
package fileutil

import (
    "testing"

    "github.com/stretchr/testify/assert"
)

func TestFormatFileSize(t *testing.T) {
    tests := []struct {
        name  string
        bytes int64
        want  string
    }{
        {name: "零字节", bytes: 0, want: "0 B"},
        {name: "字节", bytes: 500, want: "500 B"},
        {name: "KB", bytes: 1024, want: "1.0 KB"},
        {name: "KB带小数", bytes: 1536, want: "1.5 KB"},
        {name: "MB", bytes: 1048576, want: "1.0 MB"},
        {name: "GB", bytes: 1073741824, want: "1.0 GB"},
        {name: "负数", bytes: -1024, want: "-1.0 KB"},
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            got := FormatFileSize(tt.bytes)
            assert.Equal(t, tt.want, got)
        })
    }
}
```

## 步骤 3：运行测试 - 验证失败

```bash
go test ./pkg/fileutil/...

--- FAIL: TestFormatFileSize (0.00s)
    --- FAIL: TestFormatFileSize/零字节 (0.00s)
        panic: 未实现

FAIL
```

✅ 测试按预期失败。准备实现。

## 步骤 4：实现最小代码（GREEN）

```go
// pkg/fileutil/format.go
package fileutil

import "fmt"

var _units = []string{"B", "KB", "MB", "GB", "TB", "PB"}

// FormatFileSize 将字节数格式化为人类可读的字符串
func FormatFileSize(bytes int64) string {
    negative := bytes < 0
    if negative {
        bytes = -bytes
    }

    size := float64(bytes)
    unitIdx := 0
    for size >= 1024 && unitIdx < len(_units)-1 {
        size /= 1024
        unitIdx++
    }

    prefix := ""
    if negative {
        prefix = "-"
    }

    if unitIdx == 0 {
        return fmt.Sprintf("%s%d B", prefix, bytes)
    }
    return fmt.Sprintf("%s%.1f %s", prefix, size, _units[unitIdx])
}
```

## 步骤 5：运行测试 - 验证通过

```bash
go test ./pkg/fileutil/...

ok  pkg/fileutil  0.003s
```

✅ 所有测试通过！

## 步骤 6：检查覆盖率

```bash
go test -coverprofile=cover.out ./pkg/fileutil/...
go tool cover -func=cover.out

pkg/fileutil/format.go:10:  FormatFileSize  100.0%
total:                      (statements)    100.0%

覆盖率: 100% ✅ (目标: 80%)
```

✅ TDD 会话完成！
````

## TDD 最佳实践

**应该：**

- ✅ 在任何实现之前先编写测试
- ✅ 运行测试并在实现前验证它们失败
- ✅ 编写最小代码使测试通过
- ✅ 仅在测试通过后重构
- ✅ 添加边界情况和错误场景
- ✅ 追求 80%+ 覆盖率（关键代码 100%）
- ✅ 使用表驱动测试减少重复

**不应该：**

- ❌ 在测试之前编写实现
- ❌ 每次修改后跳过运行测试
- ❌ 一次编写太多代码
- ❌ 忽略失败的测试
- ❌ 测试实现细节（应测试行为）
- ❌ Mock 所有东西（优先通过 interface 注入）

## 要包含的测试类型

**单元测试**（函数/方法级别）：

- 正常路径场景
- 边界情况（nil、空 slice/map、零值）
- 错误条件
- 边界值

**Service 层测试**（mock interface）：

- 业务逻辑正确性
- 错误路径和错误包装
- context 取消和超时
- 并发安全

**基准测试**（热点路径）：

- 性能关键函数
- 内存分配情况

## 覆盖率要求

- **最低 80%** 适用于所有代码
- **必须 100%** 适用于：
  - 核心业务逻辑
  - 数据处理函数
  - 关键工具函数

## 重要说明

**强制要求**：测试必须在实现之前编写。TDD 循环是：

1. **RED** - 编写失败的测试
2. **GREEN** - 实现使其通过
3. **REFACTOR** - 改进代码

永远不要跳过 RED 阶段。永远不要在测试之前编写代码。

## 与其他命令的集成

- 使用 `/plan` 先理解要构建什么
- 使用 `/tdd` 带测试实现
- 使用 `/build-fix` 如果发生构建错误
- 使用 `/test-coverage` 验证覆盖率
