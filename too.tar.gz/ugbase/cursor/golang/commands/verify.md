# 验证命令

对当前代码库状态运行全面验证检查。

## 说明

按以下顺序执行验证：

1. **构建检查**
   - 运行 `go build ./...`
   - 如果失败，报告错误并停止

2. **静态分析**
   - 运行 `go vet ./...`
   - 报告所有问题，包含 文件:行号

3. **代码格式**
   - 运行 `gofmt -l .` 检查格式
   - 报告未格式化的文件

4. **测试套件**
   - 运行 `go test -race ./...`
   - 报告通过/失败数量
   - 报告覆盖率百分比

5. **依赖检查**
   - 运行 `go mod tidy -diff`
   - 报告未使用或缺失的依赖

6. **密钥审计**
   - 搜索硬编码的密码、Token、API Key
   - 报告位置

7. **Git 状态**
   - 显示未提交的更改
   - 显示自上次提交以来修改的文件

## 输出格式

生成简洁的验证报告：

```
VERIFICATION: [PASS/FAIL]

Build:    [OK/FAIL]
Vet:      [OK/X issues]
Format:   [OK/X files]
Tests:    [X/Y passed, Z% coverage]
Deps:     [OK/X issues]
Secrets:  [OK/X found]

Ready for PR: [YES/NO]
```

如有任何关键问题，列出并提供修复建议。

## 参数说明

$ARGUMENTS 可以是：

- `quick` - 仅构建 + vet
- `full` - 所有检查（默认）
- `pre-commit` - 构建 + vet + 格式 + 测试
- `pre-pr` - 完整检查加安全扫描
