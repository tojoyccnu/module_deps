#!/bin/bash
set -x
set -euo pipefail
source "${BUILD_DIR}/ug_env.sh"


# ==================== 目录与文件准备 ====================
PROGRAM_NAME="$1"
PACK_DIR="${BUILD_DIR}_pack"
ROOTFS_DIR="${BUILD_DIR}/rootfs"

mkdir -p "${ROOTFS_DIR}/"{sbin,lib}
mkdir -p "${PACK_DIR}"

# 复制二进制与配置
echo "Copying binaries and configs..."
# cp -r "${BUILD_DIR}/lib/"* "${ROOTFS_DIR}/lib/"
# cp -r "${BUILD_DIR}/bin/"* "${ROOTFS_DIR}/sbin/"
cp -f ${PROJECT_DIR}/project.json "${BUILD_DIR}/project.json"


# 同步rootfs文件（通用+架构专属+产品线专属）
if [ -d "${PROJECT_DIR}/rootfs_common" ]; then
    ugbt ensure_no_elf "${PROJECT_DIR}/rootfs_common"
    rsync -a --exclude='*.git*' "${PROJECT_DIR}/rootfs_common/" "${ROOTFS_DIR}/"
fi
if [ -n "${CPU_ARCH:-}" ] && [ -d "${PROJECT_DIR}/rootfs_${CPU_ARCH}" ]; then
    rsync -a --exclude='*.git*' "${PROJECT_DIR}/rootfs_${CPU_ARCH}/" "${ROOTFS_DIR}/"
fi
if [ -n "${PRODUCT_SERIES:-}" ] && [ -d "${PROJECT_DIR}/rootfs_${PRODUCT_SERIES}" ]; then
    rsync -a --exclude='*.git*' "${PROJECT_DIR}/rootfs_${PRODUCT_SERIES}/" "${ROOTFS_DIR}/"
fi
if [ -n "${CPU_ARCH:-}" ] && [ -n "${PRODUCT_SERIES:-}" ] && [ -d "${PROJECT_DIR}/rootfs_${CPU_ARCH}_${PRODUCT_SERIES}" ]; then
    rsync -a --exclude='*.git*' "${PROJECT_DIR}/rootfs_${CPU_ARCH}_${PRODUCT_SERIES}/" "${ROOTFS_DIR}/"
fi
if [ -d "${ROOTFS_DIR}/logrotate" ]; then
    find "${ROOTFS_DIR}/logrotate" -type f -exec chmod 0644 {} +
fi


# ==================== 打包 ====================
USER=$(whoami)
PACKPARAM="-sign v1"
# 根据用户设置打包签名参数
#if [[ $USER == "gitlab" || $USER == "jenkins" ]]; then
#    PACKPARAM="-sign v2 -signAPI \"${UG_SIGN_V2_API}\" -signKey \"${UG_SIGN_V2_KEY}\""
#else
#    PACKPARAM="-sign v1"
#fi

export TARGET_ROOTFS_DIR="${ROOTFS_DIR}"

pushd "${PROJECT_DIR}"  # 切换到项目根目录，因为ugtools config需要读取project.json
echo "Packing UPK: generate config file -buildnum ${BUILD_NUMBER}"
BUILD_ARCH="${CPU_ARCH:-}" PRODUCT_SERIES="${PRODUCT_SERIES:-}" ${devtools_ugtools_ROOT}/bin/ugtools config -buildnum ${BUILD_NUMBER}
echo "Packing UPK: generate pack file -d ${BUILD_DIR} ${PACKPARAM}"
BUILD_ARCH="${CPU_ARCH:-}" PRODUCT_SERIES="${PRODUCT_SERIES:-}" ${devtools_ugtools_ROOT}/bin/ugtools pack -d ${BUILD_DIR} ${PACKPARAM}
echo "Packing UPK: install pack file -d ${BUILD_DIR} ${PACKPARAM}"
cp -f ${BUILD_DIR}/pkgs/upk/*.upk ${PACK_DIR}
# touch ${BUILD_DIR}/pack-complete
popd

echo "✅ Packing UPK: pack file is in ${PACK_DIR}"
