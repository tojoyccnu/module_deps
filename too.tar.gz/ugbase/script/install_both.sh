#!/bin/bash
set -o pipefail
set -ex

rm -rf ${INSTALL_DIR}
TMP_INSTALL_DIR=${INSTALL_DIR}-$(uuidgen).tmp
mkdir -p ${TMP_INSTALL_DIR}
cd ${BUILD_DIR}_pack
tar cfz ${TMP_INSTALL_DIR}/${PACK_NAME}.tar.gz .
"${UGBASE_ROOT}/ugbt" manifest -d ${TMP_INSTALL_DIR} -p ${PACK_NAME}
mkdir -p ${TMP_INSTALL_DIR}/${PACK_NAME}
tar -xf ${TMP_INSTALL_DIR}/${PACK_NAME}.tar.gz -C ${TMP_INSTALL_DIR}/${PACK_NAME}
mv ${TMP_INSTALL_DIR} ${INSTALL_DIR}
