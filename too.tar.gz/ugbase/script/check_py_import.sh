#!/bin/bash
set -x

echo check python import pattern ...
COUNT=`grep -r --include="*.py" --exclude-dir=.git --exclude-dir=ugreen_build "from lib " | wc -l`
if [ "$COUNT" != "0" ]; then
  echo "[from lib ] pattern found:"
  grep -r --include="*.py" "from lib "
  echo "check pattern fail"
  exit 1
fi

COUNT=`grep -r --include="*.py" --exclude-dir=.git --exclude-dir=ugreen_build import| grep " lib\\." | wc -l`
if [ "$COUNT" != "0" ]; then
  echo "[import + lib.] pattern found:"
  grep -r --include="*.py" import | grep " lib\\."
  echo "check pattern fail"
  exit 1
fi

echo check python import pattern OK
