#!/bin/bash
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)

set -o pipefail
set -e

CURRENT_DIR=`pwd`
UGBASE_DIR=`readlink -f "$SCRIPT_DIR/.."`
UGBASE_DIR_IN_DOCKER=/usr/local/ugreen/ugbase

if [ -z "$DOCKER_ARCH_TYPE" ]; then
  _HOST_ARCH=$(uname -m)
  if [[ "$_HOST_ARCH" == "aarch64" ]] || [[ "$_HOST_ARCH" == "arm64" ]]; then
    export DOCKER_ARCH_TYPE=arm64
  else
    export DOCKER_ARCH_TYPE=amd64
  fi
fi

cd "$SCRIPT_DIR"

DEV_DOCKER_TAG=`cat "$SCRIPT_DIR/../DOCKER-VERSION"`
ARM_DOCKER_TAG=`cat "$SCRIPT_DIR/../DOCKER-ARM-VERSION"`

if [ "$UG_RUN_CMD" == "1" ]; then
  # run a command with a new docker container
  DOCKER_OPTS=""
  if [ -n "$DOCKER_RUN_MEMORY_LIMIT" ]; then
    DOCKER_OPTS="--memory=${DOCKER_RUN_MEMORY_LIMIT}"
  fi
  if [[ "$DOCKER_ARCH_TYPE" == "arm" ]] || [[ "$DOCKER_ARCH_TYPE" == "arm64" ]]; then
    DOCKER_OPTS="${DOCKER_OPTS} -e DOCKER_NAME=arm_runner"
  else
    export DOCKER_ARCH_TYPE=amd64
    DOCKER_OPTS="${DOCKER_OPTS} -e DOCKER_NAME=runner"
  fi
else
  # start a docker container for dev and vscode
  DOCKER_OPTS="--replace --name `whoami`_${DOCKER_NAME} -it -e DOCKER_NAME=$DOCKER_NAME"
fi
touch $HOME/.vimrc $HOME/.bashrc $HOME/.bash_profile

if [ -f ${CURRENT_DIR}/ugreen_build/env.sh ]; then
  DOCKER_OPTS="${DOCKER_OPTS} --env-file=${CURRENT_DIR}/ugreen_build/env.sh"
fi

if [ -f $HOME/.ugreen/docker.opt ]; then
  DOCKER_OPTS="${DOCKER_OPTS} `cat $HOME/.ugreen/docker.opt`"
fi

export COREDUMP_DIR=$HOME/.ugreen.tmp/coredump/$DOCKER_NAME
mkdir -p $COREDUMP_DIR
_ME=`whoami`
HOST=`hostname -I | awk '{print $1}'`
echo "Current Docker Arch is $DOCKER_ARCH_TYPE, whoami: $_ME, HOST: $HOST"

if [[ "$DOCKER_ARCH_TYPE" == "arm" ]] || [[ "$DOCKER_ARCH_TYPE" == "arm64" ]]; then
  podman run --cap-add SYS_PTRACE --security-opt seccomp=unconfined --cap-add PERFMON --cap-add SYS_ADMIN --cap-add SYS_NICE --net=host ${DOCKER_OPTS} --rm\
 --userns=keep-id -v "$HOME:$HOME" \
 -v "$UGBASE_DIR:$UGBASE_DIR_IN_DOCKER"\
 -v "$UGBASE_DIR/res/bashrc:/$HOME/.bashrc"\
 -v "$UGBASE_DIR/res/bash_profile:/$HOME/.bash_profile"\
 -v "$UGBASE_DIR/res/vimrc:/$HOME/.vimrc"\
 -v /dev/shm:/dev/shm\
 -w "$CURRENT_DIR"\
 -e "HOME=$HOME"\
 -e "GOPRIVATE=gitlab.ugnas.com"\
 -e "GOPROXY=https://goproxy.cn,direct"\
 -v /etc/localtime:/etc/localtime:ro\
 -v /etc/timezone:/etc/timezone:ro\
 -v $COREDUMP_DIR:/coredump\
 -e UGBASE_DIR=${UGBASE_DIR}\
 -e PATH=$UGBASE_DIR_IN_DOCKER:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/go/bin\
 -e GOPATH=$HOME/go-src\
 -e PYTHONPATH=${UGBASE_DIR_IN_DOCKER}/lib:${UGBASE_DIR_IN_DOCKER}/plugin\
 -e LANG="C.UTF-8" -e LC_ALL="C.UTF-8"\
 -e DOCKER_TAG=${ARM_DOCKER_TAG}\
 -e DOCKER_ARCH_TYPE=${DOCKER_ARCH_TYPE}\
 ${ARM_DOCKER_TAG} "$@"
else
  mkdir -p $HOME/.ugreen.tmp/bashrc
  TMP_BASHRC_FILE=$HOME/.ugreen.tmp/bashrc/`whoami`_${DOCKER_NAME}_bashrc
  rm -f $TMP_BASHRC_FILE && touch $TMP_BASHRC_FILE
  echo "export HOME=$HOME" >> $TMP_BASHRC_FILE
  echo "export GOPRIVATE=gitlab.ugnas.com" >> $TMP_BASHRC_FILE
  echo "export GOPROXY=https://goproxy.cn,direct" >> $TMP_BASHRC_FILE
  echo "export UGBASE_DIR=${UGBASE_DIR}" >> $TMP_BASHRC_FILE
  echo "export PATH=$UGBASE_DIR_IN_DOCKER:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/go/bin" >> $TMP_BASHRC_FILE
  echo "export GOPATH=$HOME/go-src" >> $TMP_BASHRC_FILE
  echo "export PYTHONPATH=${UGBASE_DIR_IN_DOCKER}/lib:${UGBASE_DIR_IN_DOCKER}/plugin" >> $TMP_BASHRC_FILE
  echo "export LANG=C.UTF-8" >> $TMP_BASHRC_FILE
  echo "export LC_ALL=C.UTF-8" >> $TMP_BASHRC_FILE
  echo "export DOCKER_TAG=${DEV_DOCKER_TAG}" >> $TMP_BASHRC_FILE
  echo "export DOCKER_ARCH_TYPE=${DOCKER_ARCH_TYPE}" >> $TMP_BASHRC_FILE
  echo 'export DOCKER_NAME=${DOCKER_NAME:-runner}' >> $TMP_BASHRC_FILE
  cat $UGBASE_DIR/res/bashrc >> $TMP_BASHRC_FILE

  podman run --cap-add SYS_PTRACE --security-opt seccomp=unconfined --cap-add PERFMON --cap-add SYS_ADMIN --cap-add SYS_NICE --net=host ${DOCKER_OPTS} --rm\
 --userns=keep-id -v "$HOME:$HOME" \
 -v "$UGBASE_DIR:$UGBASE_DIR_IN_DOCKER"\
 -v "$TMP_BASHRC_FILE:/$HOME/.bashrc"\
 -v "$UGBASE_DIR/res/bash_profile:/$HOME/.bash_profile"\
 -v "$UGBASE_DIR/res/vimrc:/$HOME/.vimrc"\
 -v /dev/shm:/dev/shm\
 -w "$CURRENT_DIR"\
 -e "HOME=$HOME"\
 -e "GOPRIVATE=gitlab.ugnas.com"\
 -e "GOPROXY=https://goproxy.cn,direct"\
 -v /etc/localtime:/etc/localtime:ro\
 -v /etc/timezone:/etc/timezone:ro\
 -v $COREDUMP_DIR:/coredump\
 -e UGBASE_DIR=${UGBASE_DIR}\
 -e PATH=$UGBASE_DIR_IN_DOCKER:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/go/bin\
 -e GOPATH=$HOME/go-src\
 -e PYTHONPATH=${UGBASE_DIR_IN_DOCKER}/lib:${UGBASE_DIR_IN_DOCKER}/plugin\
 -e LANG="C.UTF-8" -e LC_ALL="C.UTF-8"\
 -e DOCKER_TAG=${DEV_DOCKER_TAG}\
 -e DOCKER_ARCH_TYPE=${DOCKER_ARCH_TYPE}\
 ${DEV_DOCKER_TAG} "$@"
fi
