#!/bin/bash
if [ "$DOCKER_NAME" != "" ]; then
  echo You are in a docker container now, run out of the container!
  exit 1
fi
export UG_RUN_CMD=1
export DOCKER_RUN_MEMORY_LIMIT=${DOCKER_RUN_MEMORY_LIMIT:-16g}
_ME=`whoami`

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)
exec "$SCRIPT_DIR/script/docker_util.sh" bash -c 'source ~/.bashrc && exec "$@"' docker_run_cmd "$@"
