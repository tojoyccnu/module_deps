#!/bin/sh
set -eu

# ===================== 自动加载环境变量配置文件 =====================
# 优先从用户主目录的配置文件加载（由 ugbt init_benchmark_db 自动生成）
if [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 配置 =====================
# 所有配置必须通过环境变量设置，无默认值
if [ -z "${PG_PORT:-}" ] || [ -z "${PG_HOST:-}" ] || [ -z "${PG_APP_DB:-}" ] || [ -z "${PG_APP_USER:-}" ] || [ -z "${PG_APP_PASSWORD:-}" ] || [ -z "${PG_DATA_DIR:-}" ]; then
  echo "ERROR: Required environment variables not set: PG_PORT, PG_HOST, PG_APP_DB, PG_APP_USER, PG_APP_PASSWORD, PG_DATA_DIR" >&2
  exit 1
fi

BACKUP_DIR="${PG_DIR}/backups"

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 检查 PostgreSQL 可执行文件 =====================
PG_DUMP="$PG_DIR/bin/pg_dump"
PG_ISREADY="$PG_DIR/bin/pg_isready"
PG_CTL="$PG_DIR/bin/pg_ctl"

if [ ! -x "$PG_DUMP" ] || [ ! -x "$PG_ISREADY" ] || [ ! -x "$PG_CTL" ]; then
  echo "ERROR: PostgreSQL binaries not found or not executable" >&2
  exit 1
fi

# ===================== 检查数据库运行状态 =====================
if ! "$PG_ISREADY" -h "$PG_HOST" -p "$PG_PORT" >/dev/null 2>&1; then
  echo "ERROR: PostgreSQL is not running or not ready" >&2
  echo "Please start PostgreSQL first:" >&2
  echo "  $(dirname "$0")/start_db.sh" >&2
  exit 1
fi

# ===================== 创建备份目录 =====================
mkdir -p "$BACKUP_DIR"
if [ ! -d "$BACKUP_DIR" ] || [ ! -w "$BACKUP_DIR" ]; then
  echo "ERROR: Cannot create or write to backup directory: $BACKUP_DIR" >&2
  exit 1
fi

# ===================== 生成备份文件名 =====================
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/${PG_APP_DB}_backup_${TIMESTAMP}.sql.gz"

# ===================== 显示备份信息 =====================
echo "===== PostgreSQL Database Backup =====" >&2
echo "Database: $PG_APP_DB" >&2
echo "Backup File: $(basename "$BACKUP_FILE")" >&2

# ===================== 执行备份 =====================
START_TIME=$(date +%s)
echo "Backing up database '$PG_APP_DB'..." >&2

export PGPASSWORD="$PG_APP_PASSWORD"
if ! "$PG_DUMP" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_APP_USER" -d "$PG_APP_DB" --clean --if-exists --create 2>&1 | gzip > "$BACKUP_FILE"; then
  echo "ERROR: Failed to backup database '$PG_APP_DB'" >&2
  rm -f "$BACKUP_FILE"
  unset PGPASSWORD
  exit 1
fi
unset PGPASSWORD

# ===================== 验证备份文件 =====================
if [ ! -f "$BACKUP_FILE" ] || [ ! -s "$BACKUP_FILE" ]; then
  echo "ERROR: Backup file was not created or is empty: $BACKUP_FILE" >&2
  exit 1
fi

if ! gzip -t "$BACKUP_FILE" 2>/dev/null; then
  echo "ERROR: Backup file is corrupted" >&2
  rm -f "$BACKUP_FILE"
  exit 1
fi

# ===================== 清理旧备份（保留最近 10 个）=====================
OLD_BACKUPS=$(ls -t "$BACKUP_DIR"/${PG_APP_DB}_backup_*.sql.gz 2>/dev/null | tail -n +11)
if [ -n "$OLD_BACKUPS" ]; then
  echo "$OLD_BACKUPS" | xargs rm -f
fi

# ===================== 显示备份结果 =====================
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
DURATION=$(( $(date +%s) - START_TIME ))
echo "===== Backup Completed Successfully =====" >&2
echo "Backup File: $BACKUP_FILE" >&2
echo "File Size: $BACKUP_SIZE" >&2
echo "Duration: ${DURATION} seconds" >&2
echo "" >&2
echo "To restore: gunzip < $BACKUP_FILE | $PG_DIR/bin/psql -h $PG_HOST -p $PG_PORT -U $PG_APP_USER -d $PG_APP_DB" >&2

