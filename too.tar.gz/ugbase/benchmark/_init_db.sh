#!/bin/sh
set -eu

# ===================== 自动加载环境变量配置文件 =====================
# 只在环境变量未设置时才从配置文件加载（由 ugbt init_benchmark_db 自动生成）
# 这样可以优先使用传入的环境变量，避免配置文件覆盖
if [ -z "${blitz_3rd_postgres_ROOT:-}" ] && [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 配置 =====================
# 所有配置必须通过环境变量设置，无默认值
if [ -z "${PG_PORT:-}" ] || [ -z "${PG_HOST:-}" ] || [ -z "${PG_DATA_DIR:-}" ] || [ -z "${PG_LOG_FILE:-}" ] || [ -z "${PG_SUPERUSER:-}" ] || [ -z "${PG_SUPERUSER_PASSWORD:-}" ] || [ -z "${PG_APP_USER:-}" ] || [ -z "${PG_APP_PASSWORD:-}" ] || [ -z "${PG_APP_DB:-}" ]; then
  echo "ERROR: Required environment variables not set: PG_PORT, PG_HOST, PG_DATA_DIR, PG_LOG_FILE, PG_SUPERUSER, PG_SUPERUSER_PASSWORD, PG_APP_USER, PG_APP_PASSWORD, PG_APP_DB" >&2
  exit 1
fi

PG_LISTEN_ADDRESSES="${PG_LISTEN_ADDRESSES:-$PG_HOST}"

echo "===== Starting PostgreSQL (TCP mode) =====" >&2
echo "PostgreSQL Dir: $PG_DIR" >&2
echo "Data Dir: $PG_DATA_DIR" >&2
echo "TCP Endpoint: $PG_HOST:$PG_PORT (listen_addresses=${PG_LISTEN_ADDRESSES})" >&2
echo "App DB/User: $PG_APP_DB / $PG_APP_USER" >&2
echo "Log File: $PG_LOG_FILE" >&2

# ===================== 检查 PostgreSQL 可执行文件 =====================
PG_CTL="$PG_DIR/bin/pg_ctl"
PG_ISREADY="$PG_DIR/bin/pg_isready"
PG_PSQL="$PG_DIR/bin/psql"
PG_INITDB="$PG_DIR/bin/initdb"

if [ ! -x "$PG_CTL" ]; then
  echo "ERROR: pg_ctl not found or not executable: $PG_CTL" >&2
  exit 1
fi

if [ ! -x "$PG_ISREADY" ]; then
  echo "ERROR: pg_isready not found or not executable: $PG_ISREADY" >&2
  exit 1
fi

if [ ! -x "$PG_PSQL" ]; then
  echo "ERROR: psql not found or not executable: $PG_PSQL" >&2
  exit 1
fi

if [ ! -x "$PG_INITDB" ]; then
  echo "ERROR: initdb not found or not executable: $PG_INITDB" >&2
  exit 1
fi

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 切换到 PostgreSQL 目录 =====================
cd "$PG_DIR" || {
  echo "ERROR: Cannot cd to PostgreSQL directory: $PG_DIR" >&2
  exit 1
}

# ===================== 停止已有实例 =====================
if [ -f "$PG_DATA_DIR/postmaster.pid" ]; then
  PID=$(head -1 "$PG_DATA_DIR/postmaster.pid")
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    echo "Stopping existing PostgreSQL instance (pid $PID)..." >&2
    "$PG_CTL" -D "$PG_DATA_DIR" stop
    sleep 2
  fi
  rm -f "$PG_DATA_DIR/postmaster.pid"
fi

# ===================== 准备日志目录 =====================
mkdir -p "$(dirname "$PG_LOG_FILE")"

# ===================== 初始化数据目录（如果不存在）=====================
SUPERUSER_PWFILE=""
cleanup_pwfile() {
  if [ -n "$SUPERUSER_PWFILE" ] && [ -f "$SUPERUSER_PWFILE" ]; then
    rm -f "$SUPERUSER_PWFILE"
  fi
}
trap cleanup_pwfile EXIT

if [ ! -d "$PG_DATA_DIR" ] || [ ! -f "$PG_DATA_DIR/PG_VERSION" ]; then
  echo "Data directory does not exist, initializing..." >&2
  mkdir -p "$(dirname "$PG_DATA_DIR")"
  SUPERUSER_PWFILE="$(mktemp /tmp/pg_superuser_pw.XXXXXX)"
  printf "%s\n" "$PG_SUPERUSER_PASSWORD" > "$SUPERUSER_PWFILE"
  if ! "$PG_INITDB" -D "$PG_DATA_DIR" --username="$PG_SUPERUSER" --pwfile="$SUPERUSER_PWFILE" --auth-local=scram-sha-256 --auth-host=scram-sha-256 >&2; then
    echo "ERROR: Failed to initialize database cluster" >&2
    exit 1
  fi
  echo "Database cluster initialized successfully with superuser: $PG_SUPERUSER" >&2
  
  # 配置 pg_hba.conf 以允许远程连接（在初始化后立即配置）
  HBA_FILE="$PG_DATA_DIR/pg_hba.conf"
  if [ -f "$HBA_FILE" ]; then
    echo "Configuring pg_hba.conf to allow remote connections..." >&2
    # 检查是否已经配置了远程访问
    if ! grep -q "^host[[:space:]]*all[[:space:]]*all[[:space:]]*0\.0\.0\.0/0" "$HBA_FILE"; then
      # 添加远程访问配置
      {
        echo ""
        echo "# Remote access configuration (added by ugbt init_benchmark_db)"
        echo "# Allow connections from any IP address"
        echo "host    all    all    0.0.0.0/0    scram-sha-256"
      } >> "$HBA_FILE"
      echo "pg_hba.conf configured for remote access" >&2
    else
      echo "pg_hba.conf already configured for remote access" >&2
    fi
  fi
fi

# ===================== 确保 pg_hba.conf 配置正确（即使数据目录已存在）=====================
HBA_FILE="$PG_DATA_DIR/pg_hba.conf"
if [ -f "$HBA_FILE" ]; then
  # 检查是否已经配置了远程访问
  if ! grep -q "^host[[:space:]]*all[[:space:]]*all[[:space:]]*0\.0\.0\.0/0" "$HBA_FILE"; then
    echo "Configuring pg_hba.conf to allow remote connections..." >&2
    {
      echo ""
      echo "# Remote access configuration (added by ugbt init_benchmark_db)"
      echo "# Allow connections from any IP address"
      echo "host    all    all    0.0.0.0/0    scram-sha-256"
    } >> "$HBA_FILE"
    echo "pg_hba.conf configured for remote access" >&2
  fi
fi

# ===================== 启动 PostgreSQL（TCP 模式） =====================
echo "Starting PostgreSQL server (TCP mode)..." >&2
if ! "$PG_CTL" -D "$PG_DATA_DIR" -l "$PG_LOG_FILE" -o "-p $PG_PORT -c listen_addresses='${PG_LISTEN_ADDRESSES}' -c unix_socket_directories='' -c password_encryption=scram-sha-256" start; then
  echo "ERROR: Failed to start PostgreSQL" >&2
  echo "Check log file: $PG_LOG_FILE" >&2
  if [ -f "$PG_LOG_FILE" ]; then
    echo "Last 20 lines of log:" >&2
    tail -20 "$PG_LOG_FILE" >&2
  fi
  exit 1
fi

# ===================== 等待 PostgreSQL 就绪 =====================
echo "Waiting for PostgreSQL to be ready (TCP mode)..." >&2
ATTEMPTS=30
SLEEP=0.5
i=0
export PGPASSWORD="$PG_SUPERUSER_PASSWORD"
while [ $i -lt $ATTEMPTS ]; do
  if "$PG_ISREADY" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" >/dev/null 2>&1; then
    echo "PostgreSQL is ready!" >&2
    break
  fi
  i=$((i + 1))
  sleep "$SLEEP"
done

if [ $i -ge $ATTEMPTS ]; then
  echo "ERROR: PostgreSQL start timeout after $((ATTEMPTS * SLEEP)) seconds" >&2
  if [ -f "$PG_LOG_FILE" ]; then
    echo "Last 20 lines of log:" >&2
    tail -20 "$PG_LOG_FILE" >&2
  fi
  exit 1
fi

# ===================== 创建/更新应用用户和数据库 =====================
ESCAPED_APP_PASSWORD=$(printf "%s" "$PG_APP_PASSWORD" | sed "s/'/''/g")

can_psql_as_superuser() {
  PGPASSWORD="$PG_SUPERUSER_PASSWORD" "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -tAc "SELECT 1" >/dev/null 2>&1
}

ensure_role_and_db() {
  # 这里假设当前 pg_hba 已允许我们连接（scram 或 trust 都行）
  echo "Ensuring role '${PG_APP_USER}' exists..." >&2
  if ! "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='${PG_APP_USER}'" 2>/dev/null | grep -q 1; then
    echo "Creating role '${PG_APP_USER}'..." >&2
    if ! "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -c "CREATE ROLE ${PG_APP_USER} WITH LOGIN PASSWORD '${ESCAPED_APP_PASSWORD}';" >/dev/null 2>&1; then
      echo "ERROR: Failed to create role ${PG_APP_USER}" >&2
      exit 1
    fi
  else
    echo "Updating password for role '${PG_APP_USER}'..." >&2
    if ! "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -c "ALTER ROLE ${PG_APP_USER} WITH LOGIN PASSWORD '${ESCAPED_APP_PASSWORD}';" >/dev/null 2>&1; then
      echo "ERROR: Failed to update password for role ${PG_APP_USER}" >&2
      exit 1
    fi
  fi

  echo "Ensuring database '${PG_APP_DB}' exists..." >&2
  if ! "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='${PG_APP_DB}'" 2>/dev/null | grep -q 1; then
    echo "Creating database '${PG_APP_DB}' owned by '${PG_APP_USER}'..." >&2
    if ! "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -c "CREATE DATABASE ${PG_APP_DB} OWNER ${PG_APP_USER};" >/dev/null 2>&1; then
      echo "ERROR: Failed to create database ${PG_APP_DB}" >&2
      exit 1
    fi
  else
    echo "Database '${PG_APP_DB}' already exists" >&2
  fi
}

# ===================== 执行初始化 SQL（可选）=====================
run_init_sql_if_needed() {
  if [ -z "${PG_INIT_SQL:-}" ]; then
    return 0
  fi
  if [ ! -f "$PG_INIT_SQL" ]; then
    echo "ERROR: PG_INIT_SQL file not found: $PG_INIT_SQL" >&2
    exit 1
  fi

  echo "Applying init SQL to database '${PG_APP_DB}': $PG_INIT_SQL" >&2

  # 严格模式：只用应用用户执行，失败直接报错退出（避免隐式切换身份/改 owner）
  if ! PGPASSWORD="$PG_APP_PASSWORD" "$PG_PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_APP_USER" -d "$PG_APP_DB" -v ON_ERROR_STOP=1 -f "$PG_INIT_SQL"; then
    echo "ERROR: Failed to apply init SQL as user '${PG_APP_USER}': $PG_INIT_SQL" >&2
    exit 1
  fi
  echo "Init SQL applied as user '${PG_APP_USER}'" >&2
}

# 严格模式：必须能用 superuser 密码连接；连接不上直接报错（不再自动改 pg_hba trust 自举）
if ! can_psql_as_superuser; then
  echo "ERROR: Cannot connect as superuser '${PG_SUPERUSER}' with provided password (scram-sha-256). Set PG_SUPERUSER_PASSWORD correctly, or remove the data dir and re-init." >&2
  exit 1
fi

export PGPASSWORD="$PG_SUPERUSER_PASSWORD"
ensure_role_and_db
run_init_sql_if_needed
unset PGPASSWORD

# ===================== 显示启动成功状态 =====================
PID=$(head -1 "$PG_DATA_DIR/postmaster.pid")
echo "===== PostgreSQL Initialization Completed Successfully =====" >&2
echo "Database: $PG_APP_DB" >&2
echo "User: $PG_APP_USER" >&2
echo "Data Dir: $PG_DATA_DIR" >&2
echo "Log File: $PG_LOG_FILE" >&2
echo "" >&2

# ===================== 关闭数据库（初始化完成后）=====================
echo "Stopping PostgreSQL (initialization completed)..." >&2
if ! "$PG_CTL" -D "$PG_DATA_DIR" stop; then
  echo "ERROR: Failed to stop PostgreSQL" >&2
  exit 1
fi
echo "PostgreSQL stopped successfully." >&2

echo "" >&2
echo "To start the database, run:" >&2
echo "  bash ugbase/benchmark/start_db.sh" >&2
echo "" >&2
echo "Or connect directly (will auto-start if needed):" >&2
echo "  PGPASSWORD=$PG_APP_PASSWORD $PG_DIR/bin/psql -h $PG_HOST -p $PG_PORT -U $PG_APP_USER -d $PG_APP_DB" >&2
