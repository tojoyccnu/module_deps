#!/bin/sh
set -eu

# ===================== 自动加载环境变量配置文件 =====================
# 优先从用户主目录的配置文件加载（由 ugbt init_benchmark_db 自动生成）
if [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 配置 =====================
# 所有配置必须通过环境变量设置，无默认值
if [ -z "${PG_PORT:-}" ] || [ -z "${PG_HOST:-}" ] || [ -z "${PG_APP_DB:-}" ] || [ -z "${PG_SUPERUSER:-}" ] || [ -z "${PG_SUPERUSER_PASSWORD:-}" ]; then
  echo "ERROR: Required environment variables not set: PG_PORT, PG_HOST, PG_APP_DB, PG_SUPERUSER, PG_SUPERUSER_PASSWORD" >&2
  exit 1
fi

BACKUP_DIR="${PG_DIR}/backups"

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 检查 PostgreSQL 可执行文件 =====================
PSQL="$PG_DIR/bin/psql"
PG_ISREADY="$PG_DIR/bin/pg_isready"

if [ ! -x "$PSQL" ] || [ ! -x "$PG_ISREADY" ]; then
  echo "ERROR: PostgreSQL binaries not found or not executable" >&2
  exit 1
fi

# ===================== 检查数据库运行状态 =====================
if ! "$PG_ISREADY" -h "$PG_HOST" -p "$PG_PORT" >/dev/null 2>&1; then
  echo "ERROR: PostgreSQL is not running or not ready" >&2
  echo "Please start PostgreSQL first:" >&2
  echo "  $(dirname "$0")/start_db.sh" >&2
  exit 1
fi

# ===================== 确定备份文件 =====================
if [ $# -eq 0 ]; then
  # 如果没有指定备份文件，使用最新的备份
  BACKUP_FILE=$(ls -t "$BACKUP_DIR"/${PG_APP_DB}_backup_*.sql.gz 2>/dev/null | head -1)
  if [ -z "$BACKUP_FILE" ]; then
    echo "ERROR: No backup file found in $BACKUP_DIR" >&2
    exit 1
  fi
else
  BACKUP_FILE="$1"
fi

if [ ! -f "$BACKUP_FILE" ]; then
  echo "ERROR: Backup file not found: $BACKUP_FILE" >&2
  exit 1
fi

if ! gzip -t "$BACKUP_FILE" 2>/dev/null; then
  echo "ERROR: Backup file is corrupted: $BACKUP_FILE" >&2
  exit 1
fi

# ===================== 显示还原信息 =====================
echo "===== PostgreSQL Database Restore =====" >&2
echo "Database: $PG_APP_DB" >&2
echo "Backup File: $(basename "$BACKUP_FILE")" >&2

# ===================== 执行还原 =====================
START_TIME=$(date +%s)
echo "Restoring database '$PG_APP_DB'..." >&2

export PGPASSWORD="$PG_SUPERUSER_PASSWORD"
RESTORE_OUTPUT=$(gunzip < "$BACKUP_FILE" | "$PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_SUPERUSER" -d postgres -q 2>&1)
RESTORE_STATUS=$?
if [ $RESTORE_STATUS -ne 0 ] || echo "$RESTORE_OUTPUT" | grep -qE "(ERROR|FATAL)"; then
  echo "$RESTORE_OUTPUT" | grep -E "(ERROR|FATAL|WARNING)" >&2 || echo "$RESTORE_OUTPUT" >&2
  echo "" >&2
  echo "ERROR: Failed to restore database '$PG_APP_DB'" >&2
  unset PGPASSWORD
  exit 1
fi
unset PGPASSWORD

# ===================== 显示还原结果 =====================
DURATION=$(( $(date +%s) - START_TIME ))
echo "===== Restore Completed Successfully =====" >&2
echo "Duration: ${DURATION} seconds" >&2
echo "" >&2

