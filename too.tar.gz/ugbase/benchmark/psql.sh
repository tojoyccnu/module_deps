#!/bin/sh
set -eu



# ===================== 自动加载环境变量配置文件 =====================
# 优先从用户主目录的配置文件加载（由 ugbt init_benchmark_db 自动生成）
if [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 配置 =====================
# 所有配置必须通过环境变量设置，无默认值
if [ -z "${PG_PORT:-}" ] || [ -z "${PG_HOST:-}" ] || [ -z "${PG_APP_DB:-}" ] || [ -z "${PG_APP_USER:-}" ] || [ -z "${PG_APP_PASSWORD:-}" ]; then
  echo "ERROR: Required environment variables not set: PG_PORT, PG_HOST, PG_APP_DB, PG_APP_USER, PG_APP_PASSWORD" >&2
  exit 1
fi

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 检查 PostgreSQL 可执行文件 =====================
PSQL="$PG_DIR/bin/psql"
PG_ISREADY="$PG_DIR/bin/pg_isready"

if [ ! -x "$PSQL" ]; then
  echo "ERROR: psql binary not found or not executable: $PSQL" >&2
  exit 1
fi


# ===================== 检查服务是否运行 =====================
if [ ! -x "$PG_ISREADY" ]; then
  echo "ERROR: pg_isready not found or not executable: $PG_ISREADY" >&2
  exit 1
fi

if ! "$PG_ISREADY" -h "$PG_HOST" -p "$PG_PORT" >/dev/null 2>&1; then
  echo "ERROR: PostgreSQL is not running or not ready" >&2
  echo "" >&2
  echo "Please start PostgreSQL first:" >&2
  echo "  $(dirname "$0")/start_db.sh" >&2
  echo "" >&2
  exit 1
fi

# ===================== 连接数据库 =====================
echo "===== Connecting to PostgreSQL =====" >&2
echo "Endpoint: $PG_HOST:$PG_PORT" >&2
echo "Database: $PG_APP_DB" >&2
echo "User: $PG_APP_USER" >&2
echo "" >&2

export PGPASSWORD="$PG_APP_PASSWORD"
exec "$PSQL" -h "$PG_HOST" -p "$PG_PORT" -U "$PG_APP_USER" -d "$PG_APP_DB"

