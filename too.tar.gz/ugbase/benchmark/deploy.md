# Benchmark 数据库部署

## 设备上安装

1. 准备包：`release_1.17.4-blitz_3rd_postgres-1.17.4.6-amd64.tar.gz` 放到设备。

2. 安装：
```bash
python3 install_benchmark_db.py -l /path/to/xxx.tar.gz
# 指定目录和监听: -t /home/ugreen/benchmark/pgsql -L 0.0.0.0

# 仅解压不初始化: -n
```

3. 日常：
```bash
source ~/.ugreen/benchmark_pgsql.env
bash benchmark/start_db.sh
bash benchmark/psql.sh
bash benchmark/stop_db.sh
bash benchmark/backup_db.sh
bash benchmark/restore_db.sh
```

## NAS 上执行 init_db.sql

```bash
PGPASSWORD=123456 /home/ugreen/benchmark/pgsql/bin/psql \
  -h 172.17.60.169 -p 5433 -U ugreen -d ugreen_test -f init_db.sql
```

`-h` 改为实际数据库主机；`init_db.sql` 需在 NAS 可访问路径。

## 默认连接

| 项   | 值          |
|------|-------------|
| 端口 | 5433        |
| 库   | ugreen_test |
| 用户 | ugreen      |
| 密码 | 123456     |

主机见 `~/.ugreen/benchmark_pgsql.env` 中 `PG_HOST`。
