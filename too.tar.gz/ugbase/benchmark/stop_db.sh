#!/bin/sh
set -eu

# ===================== 自动加载环境变量配置文件 =====================
# 优先从用户主目录的配置文件加载（由 ugbt init_benchmark_db 自动生成）
if [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 数据目录配置 =====================
# 数据目录必须通过环境变量设置，无默认值
if [ -z "${PG_DATA_DIR:-}" ]; then
  echo "ERROR: PG_DATA_DIR environment variable is not set" >&2
  exit 1
fi

echo "===== Stopping PostgreSQL =====" >&2
echo "PostgreSQL Dir: $PG_DIR" >&2
echo "Data Dir: $PG_DATA_DIR" >&2

# ===================== 检查 PostgreSQL 可执行文件 =====================
PG_CTL="$PG_DIR/bin/pg_ctl"

if [ ! -x "$PG_CTL" ]; then
  echo "ERROR: pg_ctl not found or not executable: $PG_CTL" >&2
  exit 1
fi

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 切换到 PostgreSQL 目录 =====================
cd "$PG_DIR" || {
  echo "ERROR: Cannot cd to PostgreSQL directory: $PG_DIR" >&2
  exit 1
}

# ===================== 停止 PostgreSQL =====================
if [ ! -f "$PG_DATA_DIR/postmaster.pid" ]; then
  echo "No PID file found. PostgreSQL is not running." >&2
  exit 0
fi

PID=$(head -1 "$PG_DATA_DIR/postmaster.pid")
if [ -z "$PID" ] || ! kill -0 "$PID" 2>/dev/null; then
  echo "PostgreSQL is not running (stale PID file)" >&2
  rm -f "$PG_DATA_DIR/postmaster.pid"
  exit 0
fi

echo "Stopping PostgreSQL (pid $PID)..." >&2

if ! "$PG_CTL" -D "$PG_DATA_DIR" stop; then
  echo "ERROR: Failed to stop PostgreSQL" >&2
  exit 1
fi

rm -f "$PG_DATA_DIR/postmaster.pid"
echo "PostgreSQL stopped successfully" >&2

