-- ============================================
-- 性能测试数据库表设计（按模式分表）- PostgreSQL 版本
-- 设计理念：按测试模式分表（延迟模式 vs 吞吐量模式），而非按业务类型
-- 延迟模式：关注延迟指标（平均延迟、P95、P99等）
-- 吞吐量模式：关注吞吐量指标（OPS、总操作数、耗时等）
-- ============================================

-- ============================================
-- 延迟模式表（Latency Mode）
-- ============================================
CREATE TABLE IF NOT EXISTS benchmark_latency (
    id BIGSERIAL PRIMARY KEY,
    test_name VARCHAR(255) NOT NULL,
    business_type VARCHAR(50) NOT NULL,
    
    -- 延迟指标（核心指标）
    latency_unit SMALLINT DEFAULT 0 NOT NULL,
    avg_latency DECIMAL(10, 2) NOT NULL,
    p95_latency DECIMAL(10, 2) DEFAULT NULL,
    p99_latency DECIMAL(10, 2) DEFAULT NULL,
    
    -- 测试元信息
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    machine_host VARCHAR(255) NOT NULL,
    executor VARCHAR(100) DEFAULT NULL
);

-- 添加表注释
COMMENT ON TABLE benchmark_latency IS '性能测试结果表(延迟模式：关注延迟指标，如平均延迟、P95、P99等)';

-- 添加列注释
COMMENT ON COLUMN benchmark_latency.id IS '主键ID';
COMMENT ON COLUMN benchmark_latency.test_name IS '测试名称/标识，唯一标识一次测试';
COMMENT ON COLUMN benchmark_latency.business_type IS '业务类型: LOG, GATEWAY, DATABASE, CACHE等';
COMMENT ON COLUMN benchmark_latency.latency_unit IS '延迟单位: 0=微秒(us), 1=毫秒(ms), 2=秒(s)';
COMMENT ON COLUMN benchmark_latency.avg_latency IS '平均延迟（必填）';
COMMENT ON COLUMN benchmark_latency.p95_latency IS 'P95延迟';
COMMENT ON COLUMN benchmark_latency.p99_latency IS 'P99延迟';
COMMENT ON COLUMN benchmark_latency.start_time IS '测试开始时间';
COMMENT ON COLUMN benchmark_latency.end_time IS '测试结束时间';
COMMENT ON COLUMN benchmark_latency.machine_host IS '执行测试的机器标识（主机名或IP）';
COMMENT ON COLUMN benchmark_latency.executor IS '执行测试的用户/执行者';

-- ============================================
-- TPS 模式表（Throughput / TPS Mode）
-- ============================================
CREATE TABLE IF NOT EXISTS benchmark_tps (
    id BIGSERIAL PRIMARY KEY,
    test_name VARCHAR(255) NOT NULL,
    business_type VARCHAR(50) NOT NULL,
    
    -- TPS 指标（核心指标）
    tps DECIMAL(18, 2) NOT NULL,
    total_count BIGINT NOT NULL,
    
    -- 测试元信息
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    machine_host VARCHAR(255) NOT NULL,
    executor VARCHAR(100) DEFAULT NULL
);

-- 添加表注释
COMMENT ON TABLE benchmark_tps IS '性能测试结果表(TPS模式：关注每秒事务数/操作数)';

-- 添加列注释
COMMENT ON COLUMN benchmark_tps.id IS '主键ID';
COMMENT ON COLUMN benchmark_tps.test_name IS '测试名称/标识，唯一标识一次测试';
COMMENT ON COLUMN benchmark_tps.business_type IS '业务类型: LOG, GATEWAY, DATABASE, CACHE等';
COMMENT ON COLUMN benchmark_tps.tps IS 'TPS - 每秒事务数(transactions per second)（必填）';
COMMENT ON COLUMN benchmark_tps.total_count IS '总事务数/总操作数（必填）';
COMMENT ON COLUMN benchmark_tps.start_time IS '测试开始时间';
COMMENT ON COLUMN benchmark_tps.end_time IS '测试结束时间';
COMMENT ON COLUMN benchmark_tps.machine_host IS '执行测试的机器标识（主机名或IP）';
COMMENT ON COLUMN benchmark_tps.executor IS '执行测试的用户/执行者';

-- ============================================
-- 使用示例
-- ============================================
-- 
-- 1. 延迟模式测试（日志延迟测试，延迟单位: 0=微秒）:
-- INSERT INTO benchmark_latency (test_name, business_type, latency_unit, avg_latency, p95_latency, p99_latency, start_time, end_time, machine_host, executor)
-- VALUES ('log_rsyslog_latency_100k', 'LOG', 0, 50.5, 120.3, 250.8, '2024-01-21 10:00:00', '2024-01-21 10:00:05', 'test-server-01', 'user1');
--
-- 2. TPS 模式测试（网关 TPS 测试）:
-- INSERT INTO benchmark_tps (test_name, business_type, tps, total_count, start_time, end_time, machine_host, executor)
-- VALUES ('gateway_user_login_tps', 'GATEWAY', 10000.00, 100000, '2024-01-21 11:00:00', '2024-01-21 11:00:10', 'test-server-02', 'user2');
--
-- 3. 查询延迟模式测试结果（最近7天）:
-- SELECT business_type, AVG(avg_latency) as avg_latency, AVG(p95_latency) as avg_p95, AVG(p99_latency) as avg_p99
-- FROM benchmark_latency
-- WHERE start_time >= NOW() - INTERVAL '7 days'
-- GROUP BY business_type;
--
-- 4. 查询 TPS 模式测试结果（最近7天）:
-- SELECT business_type, AVG(tps) as avg_tps, MAX(tps) as max_tps
-- FROM benchmark_tps
-- WHERE start_time >= NOW() - INTERVAL '7 days'
-- GROUP BY business_type;
--
-- 5. 查询特定测试的所有指标（延迟模式）:
-- SELECT * FROM benchmark_latency WHERE test_name = 'log_rsyslog_latency_100k';
--
-- 6. 查询特定测试的所有指标（TPS 模式）:
-- SELECT * FROM benchmark_tps WHERE test_name = 'gateway_user_login_tps';
