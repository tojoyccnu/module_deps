#!/bin/sh
set -eu

# ===================== 自动加载环境变量配置文件 =====================
# 优先从用户主目录的配置文件加载（由 ugbt init_benchmark_db 自动生成）
if [ -f "${HOME}/.ugreen/benchmark_pgsql.env" ]; then
  . "${HOME}/.ugreen/benchmark_pgsql.env"
fi

# ===================== 配置 PostgreSQL 路径（TCP 模式） =====================
if [ -z "${blitz_3rd_postgres_ROOT:-}" ]; then
  echo "ERROR: blitz_3rd_postgres_ROOT environment variable is not set" >&2
  echo "" >&2
  echo "Please either:" >&2
  echo "  1. Run 'ugbt init_benchmark_db' first (it will auto-generate ~/.ugreen/benchmark_pgsql.env)" >&2
  echo "  2. Or manually set: export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "  3. Or source the config: source ~/.ugreen/benchmark_pgsql.env" >&2
  echo "" >&2
  exit 1
fi

PG_DIR="$blitz_3rd_postgres_ROOT"

if [ ! -d "$PG_DIR/bin" ]; then
  echo "ERROR: PostgreSQL bin directory not found: $PG_DIR/bin" >&2
  echo "" >&2
  echo "Please set:" >&2
  echo "  export blitz_3rd_postgres_ROOT=/path/to/pgsql" >&2
  echo "" >&2
  exit 1
fi

# ===================== 配置 =====================
# 所有配置必须通过环境变量设置，无默认值
if [ -z "${PG_PORT:-}" ] || [ -z "${PG_HOST:-}" ] || [ -z "${PG_DATA_DIR:-}" ] || [ -z "${PG_LOG_FILE:-}" ]; then
  echo "ERROR: Required environment variables not set: PG_PORT, PG_HOST, PG_DATA_DIR, PG_LOG_FILE" >&2
  exit 1
fi

echo "===== Starting PostgreSQL =====" >&2
echo "Data Dir: $PG_DATA_DIR" >&2
echo "Endpoint: $PG_HOST:$PG_PORT" >&2

# ===================== 检查 PostgreSQL 可执行文件 =====================
PG_CTL="$PG_DIR/bin/pg_ctl"
PG_ISREADY="$PG_DIR/bin/pg_isready"

if [ ! -x "$PG_CTL" ] || [ ! -x "$PG_ISREADY" ]; then
  echo "ERROR: PostgreSQL binaries not found or not executable" >&2
  exit 1
fi

# ===================== 设置库路径 =====================
export LD_LIBRARY_PATH="$PG_DIR/lib:${LD_LIBRARY_PATH:-}"

# ===================== 切换到 PostgreSQL 目录 =====================
cd "$PG_DIR" || {
  echo "ERROR: Cannot cd to PostgreSQL directory: $PG_DIR" >&2
  exit 1
}

# ===================== 检查数据目录是否存在 =====================
if [ ! -d "$PG_DATA_DIR" ] || [ ! -f "$PG_DATA_DIR/PG_VERSION" ]; then
  echo "ERROR: Data directory does not exist or is not initialized: $PG_DATA_DIR" >&2
  echo "Please run 'ugbt init_benchmark_db' first to initialize the database." >&2
  exit 1
fi

# ===================== 检查服务是否已在运行 =====================
PG_WAS_RUNNING=0
if [ -f "$PG_DATA_DIR/postmaster.pid" ]; then
  PID=$(head -1 "$PG_DATA_DIR/postmaster.pid")
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    PG_WAS_RUNNING=1
    echo "PostgreSQL is already running (pid $PID)" >&2
    exit 0
  else
    rm -f "$PG_DATA_DIR/postmaster.pid"
  fi
fi

# ===================== 启动数据库（如果未运行）=====================
if [ "$PG_WAS_RUNNING" -eq 0 ]; then
  # ===================== 准备日志目录 =====================
  mkdir -p "$(dirname "$PG_LOG_FILE")"

  # ===================== 启动 PostgreSQL =====================
  echo "Starting PostgreSQL..." >&2
  if ! "$PG_CTL" -D "$PG_DATA_DIR" -l "$PG_LOG_FILE" -o "-p $PG_PORT -c listen_addresses='$PG_HOST' -c unix_socket_directories='' -c password_encryption=scram-sha-256" start; then
    echo "ERROR: Failed to start PostgreSQL" >&2
    [ -f "$PG_LOG_FILE" ] && tail -20 "$PG_LOG_FILE" >&2
    exit 1
  fi

  # ===================== 等待 PostgreSQL 就绪 =====================
  echo "Waiting for PostgreSQL to be ready..." >&2
  for i in $(seq 1 30); do
    if "$PG_ISREADY" -h "$PG_HOST" -p "$PG_PORT" >/dev/null 2>&1; then
      echo "PostgreSQL is ready!" >&2
      break
    fi
    [ $i -eq 30 ] && {
      echo "ERROR: PostgreSQL start timeout" >&2
      [ -f "$PG_LOG_FILE" ] && tail -20 "$PG_LOG_FILE" >&2
      exit 1
    }
    sleep 0.5
  done
fi

# ===================== 显示状态 =====================
PID=$(head -1 "$PG_DATA_DIR/postmaster.pid")
if [ "$PG_WAS_RUNNING" -eq 0 ]; then
  echo "===== PostgreSQL Started Successfully =====" >&2
else
  echo "===== PostgreSQL is Running =====" >&2
fi
echo "PID: $PID" >&2
echo "Endpoint: $PG_HOST:$PG_PORT" >&2
echo "" >&2
echo "To connect to the database, run:" >&2
echo "  $(dirname "$0")/psql.sh" >&2
