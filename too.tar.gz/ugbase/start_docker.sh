#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)

# 显示使用帮助
show_help() {
    cat << EOF
用法: $0 [docker_name] [cpu_arch]

参数:
  docker_name     虚拟容器的自定义名字 (默认: amd64: `whoami`_dev; arm64: `whoami`_arm)
  cpu_arch        cpu结构 (默认: 根据当前机器自适应，可选arm/arm64/x86/amd64)

示例:
  $0                            # 默认按当前机器自适应，名字叫作`whoami`_dev或`whoami`_arm的debian开发容器
  $0 ugreen                     # 默认按当前机器自适应，名字叫作ugreen的debian开发容器
  $0 ugreen arm                 # 启动一个arm，名字叫作ugreen的debian开发容器
  $0 ugreen arm64               # 启动一个arm，名字叫作ugreen的debian开发容器
EOF
}

get_default_cpu_arch() {
  local machine
  machine=$(uname -m)
  case "$machine" in
    x86_64)
      echo amd64
      ;;
    aarch64)
      echo arm64
      ;;
    *)
      echo "Unknown CPU architecture: $machine" >&2
      exit 1
      ;;
  esac
}

# 检查参数
if [[ "$1" == "-h" ]] || [[ "$1" == "--help" ]]; then
    show_help
    exit 0
fi

# 检查参数个数
if [ "$3" != "" ]; then
  show_help
  exit 0
fi

# 设置默认参数
if [ "$2" == "" ]; then
  export DOCKER_ARCH_TYPE=$(get_default_cpu_arch)
else
  export DOCKER_ARCH_TYPE=$2
fi

# 检查正确参数
if [[ "$DOCKER_ARCH_TYPE" != "arm" ]] && [[ "$DOCKER_ARCH_TYPE" != "arm64" ]] && [[ "$DOCKER_ARCH_TYPE" != "x86" ]] && [[ "$DOCKER_ARCH_TYPE" != "amd64" ]]; then
    show_help
    exit 0
fi

if [ "$1" == "" ]; then
  if [[ "$DOCKER_ARCH_TYPE" == "arm" ]] || [[ "$DOCKER_ARCH_TYPE" == "arm64" ]]; then
    export DOCKER_NAME=arm
  else
    export DOCKER_NAME=dev
  fi
else
  export DOCKER_NAME=$1
fi


pushd .
cd $SCRIPT_DIR
git pull -r
popd

if [[ "$DOCKER_ARCH_TYPE" == "arm" ]] || [[ "$DOCKER_ARCH_TYPE" == "arm64" ]]; then
  "$SCRIPT_DIR/script/docker_util.sh" sh -c "bash"
else
  "$SCRIPT_DIR/script/docker_util.sh" sh -c "sudo usermod -s /bin/bash `whoami` && /usr/local/ugreen/ugbase/ugbt start_sshd && bash"
fi
