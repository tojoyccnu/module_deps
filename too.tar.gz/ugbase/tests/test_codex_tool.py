import json
import os

import codex_tool


class FakeEnv:
  def __init__(self, root, opts=None):
    self.root = root
    self.opts = opts or {}
    self.opts_multiple = {}
    self.args = []


def test_codex_first_install_prompts_api_url_before_plaintext_api_key(tmp_path, monkeypatch):
  root = tmp_path / "ugbase"
  resource_dir = root / "res"
  resource_dir.mkdir(parents=True)
  (resource_dir / "codex_config.toml").write_text(
      'model_provider = "custom"\n'
      '[model_providers.custom]\n'
      'base_url = "{base_url}"\n',
      encoding="utf-8")
  monkeypatch.setenv("HOME", str(tmp_path / "home"))
  prompts = []
  answers = iter(["  https://codex.example.com/v1  ", "test-api-key"])

  def fake_input(prompt):
    prompts.append(prompt)
    return next(answers)

  monkeypatch.setattr("builtins.input", fake_input)
  assert not hasattr(codex_tool, "getpass")
  tool = codex_tool.Tool(FakeEnv(str(root)))
  tool.build_index()

  assert tool.main() == 0
  assert len(prompts) == 2
  assert prompts[0].startswith("请输入 API 地址")
  assert "https://fireware.ai.ugreencloud.com/v1" in prompts[0]
  assert prompts[1] == "请输入 API Key："

  codex_dir = tmp_path / "home" / ".codex"
  assert json.loads((codex_dir / "auth.json").read_text(encoding="utf-8")) == {
      "auth_mode": "apikey",
      "OPENAI_API_KEY": "test-api-key",
  }
  assert 'base_url = "https://codex.example.com/v1"' in (
      codex_dir / "config.toml").read_text(encoding="utf-8")
  assert os.stat(codex_dir / "auth.json").st_mode & 0o777 == 0o600
  assert os.stat(codex_dir / "config.toml").st_mode & 0o777 == 0o600


def test_codex_accepts_api_address_without_http_scheme(tmp_path, monkeypatch):
  root = tmp_path / "ugbase"
  resource_dir = root / "res"
  resource_dir.mkdir(parents=True)
  (resource_dir / "codex_config.toml").write_text(
      '[model_providers.custom]\nbase_url = "{base_url}"\n', encoding="utf-8")
  monkeypatch.setenv("HOME", str(tmp_path / "home"))
  answers = iter(["codex.example.com/v1", "test-api-key"])
  monkeypatch.setattr("builtins.input", lambda prompt: next(answers))
  tool = codex_tool.Tool(FakeEnv(str(root)))
  tool.build_index()

  assert tool.main() == 0
  config_file = tmp_path / "home" / ".codex" / "config.toml"
  assert 'base_url = "codex.example.com/v1"' in config_file.read_text(encoding="utf-8")
