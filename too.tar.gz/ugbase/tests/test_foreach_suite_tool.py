import hashlib
import json
import os
import shutil
import tarfile
from pathlib import Path

import pytest
import yaml

import beta_once_tool as suite_publish_tool


SMB_URL = "smb://172.16.16.6/产品研发事业中心/产品经营部/NAS组/repo/firmware/service/snapshot_serv/release_20260624/1.11.0/35"
RELEASE_NAME = "release_20260624-firmware_service_snapshot_serv-1.11.0.35-amd64"


class FakeEnv:
  def get_build_vars(self):
    return {
        "cpu_arch": ["amd64", "arm64"],
    }


def worker_ctx(platform_dir, mode, tasks_root, report_root, remote_tmp_root="tmp_remote", tools_dir="/tools"):
  class Ctx:
    pass

  ctx = Ctx()
  ctx.env = FakeEnv()
  ctx.smb_url = SMB_URL
  ctx.platform_dir = platform_dir
  ctx.mode = mode
  ctx.tasks_root = str(tasks_root)
  ctx.report_root = str(report_root)
  ctx.remote_tmp_root = remote_tmp_root
  ctx.tools_dir = tools_dir
  return ctx


def suite_worker(root, platform_dir="cpu_arch_amd64", mode="ga", tools_dir="/tools"):
  return suite_publish_tool._SuiteWorker(worker_ctx(
      platform_dir,
      mode,
      root / "_tasks",
      root / "_reports",
      tools_dir=tools_dir,
  ))


def test_suite_worker_pack_stem_uses_release_branch_from_third_last_path_segment(tmp_path):
  ctx = worker_ctx(
      "cpu_arch_amd64",
      "beta",
      tmp_path / "tasks",
      tmp_path / "reports",
  )
  ctx.smb_url = (
      "smb://host/share/root/repo/firmware/dockerapp/release_helper20260728/lucky/"
      "release_a35_20260728/1.3.0/10"
  )

  worker = suite_publish_tool._SuiteWorker(ctx)

  assert worker._pack_stem() == (
      "release_a35_20260728-firmware_dockerapp_release_helper20260728_lucky-"
      "1.3.0.10-amd64"
  )


def test_suite_worker_pack_stem_requires_branch_in_third_last_segment(tmp_path, monkeypatch):
  ctx = worker_ctx(
      "cpu_arch_amd64",
      "beta",
      tmp_path / "tasks",
      tmp_path / "reports",
  )
  ctx.smb_url = (
      "smb://host/share/root/repo/firmware/dockerapp/lucky/"
      "release_a35_20260728/1.3.0"
  )
  monkeypatch.setattr(
      suite_publish_tool,
      "fatal",
      lambda message: (_ for _ in ()).throw(RuntimeError(message)),
  )

  worker = suite_publish_tool._SuiteWorker(ctx)

  with pytest.raises(RuntimeError, match="must contain release_ branch"):
    worker._pack_stem()


def md5_file(path):
  digest = hashlib.md5()
  with open(path, "rb") as fp:
    for chunk in iter(lambda: fp.read(4096), b""):
      digest.update(chunk)
  return digest.hexdigest()


def write_json(path, data):
  path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def simulate_setbeta_output(target_upk, beta, content):
  target_upk.write_bytes(b"UGREEN-PKG-V2-FORMAT" + content)
  product_path = target_upk.with_suffix(".product.json")
  product = json.loads(product_path.read_text(encoding="utf-8"))
  product["version"]["beta"] = beta
  product["version"]["size"] = target_upk.stat().st_size
  product["hash"] = md5_file(target_upk)
  product_path.write_text(json.dumps(product, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def create_platform_fixture(root, arch="cpu_arch_amd64", beta=True):
  arch_dir = root / arch
  release_name = RELEASE_NAME
  release_dir = arch_dir / release_name
  release_dir.mkdir(parents=True)
  upk = release_dir / "amd64_com.ugreen.dlna_1.15.0.0028.upk"
  upk.write_bytes(b"UGREEN-PKG-V2-FORMAT" + b"old-upk")
  product = release_dir / "amd64_com.ugreen.dlna_1.15.0.0028.product.json"
  write_json(product, {
      "appId": "com.ugreen.dlna",
      "version": {
          "beta": beta,
          "size": upk.stat().st_size,
          "models": ["DXP4800", "DXP6800"],
      },
      "futureUnknownField": {"value": 123},
      "hash": md5_file(upk),
  })
  (release_dir / "unused.txt").write_text("unused\n", encoding="utf-8")
  tar_path = arch_dir / (release_name + ".tar.gz")
  with tarfile.open(tar_path, "w:gz", format=tarfile.GNU_FORMAT) as tf:
    root_info = tarfile.TarInfo("./")
    root_info.type = tarfile.DIRTYPE
    root_info.mode = 0o755
    tf.addfile(root_info)
    for name in sorted(os.listdir(release_dir)):
      tf.add(release_dir / name, arcname="./" + name)
  manifest = arch_dir / (release_name + ".manifest.yaml")
  manifest.write_text(yaml.safe_dump({
      "branch": "release_20260624",
      "beta": beta,
      "md5": md5_file(tar_path),
  }, allow_unicode=True), encoding="utf-8")
  return arch_dir


def test_suite_worker_downloads_only_tar_and_manifest(tmp_path, monkeypatch):
  downloads = []

  class FakeConn:
    def __init__(self, host):
      assert host == "172.16.16.6"

    def connect(self):
      return None

    def ls(self, share, remote_path):
      raise AssertionError("suite download should not list SMB directory")

    def isdir(self, share, remote_path):
      raise AssertionError("suite download should not probe SMB directory")

    def download(self, share, remote_path, local_path):
      downloads.append((remote_path, os.path.basename(local_path)))
      with open(local_path, "wb") as fp:
        fp.write(b"downloaded")

  monkeypatch.setattr(suite_publish_tool, "SambaConnection", FakeConn)

  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))
  worker._download()

  assert downloads == [
      (
          "产品经营部/NAS组/repo/firmware/service/snapshot_serv/release_20260624/1.11.0/35/cpu_arch_amd64/%s.tar.gz" % RELEASE_NAME,
          RELEASE_NAME + ".tar.gz",
      ),
      (
          "产品经营部/NAS组/repo/firmware/service/snapshot_serv/release_20260624/1.11.0/35/cpu_arch_amd64/%s.manifest.yaml" % RELEASE_NAME,
          RELEASE_NAME + ".manifest.yaml",
      ),
  ]
  assert os.path.isdir(tmp_path / "tasks" / "cpu_arch_amd64" / "work")
  assert not os.path.exists(tmp_path / "tasks" / "cpu_arch_amd64" / "source")
  assert not os.path.exists(tmp_path / "tasks" / "cpu_arch_amd64" / "output")
  work_dir = tmp_path / "tasks" / "cpu_arch_amd64" / "work"
  assert sorted(os.listdir(work_dir)) == sorted([RELEASE_NAME + ".tar.gz", RELEASE_NAME + ".manifest.yaml"])


def test_suite_archive_files_use_platform_and_smb_path(tmp_path):
  arch_dir = create_platform_fixture(tmp_path)
  shutil.rmtree(next(path for path in arch_dir.iterdir() if path.is_dir()))

  worker = suite_worker(tmp_path)
  worker.work_dir = str(arch_dir)
  files = worker._archive_files()

  assert os.path.basename(files["tar"]) == RELEASE_NAME + ".tar.gz"
  assert os.path.basename(files["manifest"]) == RELEASE_NAME + ".manifest.yaml"


def test_suite_worker_process_outputs_upk_product_and_manifest_only(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  arch_dir = create_platform_fixture(tasks_root / "cpu_arch_amd64", arch="work")
  shutil.rmtree(next(path for path in arch_dir.iterdir() if path.is_dir()))
  calls = []

  def fake_setbeta(self, source_upk, target_upk, beta_value):
    calls.append((source_upk, target_upk, beta_value))
    simulate_setbeta_output(Path(target_upk), beta_value, b"new-nobeta-upk")

  monkeypatch.setattr(suite_publish_tool._SuiteWorker, "_sign_upk_with_setbeta", fake_setbeta)

  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tasks_root,
      tmp_path / "reports",
  ))
  os.makedirs(worker.tmp_dir)
  report = worker._process()

  work_dir = tasks_root / "cpu_arch_amd64" / "work"
  upk = work_dir / "amd64_com.ugreen.dlna_1.15.0.0028.upk"
  product_path = work_dir / "amd64_com.ugreen.dlna_1.15.0.0028.product.json"
  manifest_path = work_dir / (RELEASE_NAME + ".manifest.yaml")
  assert calls and calls[0][2] is False
  assert calls[0][0] == calls[0][1]
  assert sorted(path.name for path in work_dir.iterdir()) == sorted([
      upk.name,
      product_path.name,
      manifest_path.name,
  ])
  assert report == {
      "filename": upk.name,
      "old_beta": True,
      "new_beta": False,
      "old_md5": hashlib.md5((b"UGREEN-PKG-V2-FORMAT" + b"old-upk")).hexdigest(),
      "new_md5": md5_file(upk),
  }
  assert report["old_md5"] != report["new_md5"]
  assert upk.read_bytes().startswith(b"UGREEN-PKG-V2-FORMAT")
  product = json.load(open(product_path, encoding="utf-8"))
  assert product["version"]["beta"] is False
  assert product["version"]["size"] == os.path.getsize(upk)
  assert product["version"]["models"] == ["DXP4800", "DXP6800"]
  assert product["futureUnknownField"] == {"value": 123}
  assert product["hash"] == md5_file(upk)
  assert "\n" not in product_path.read_text(encoding="utf-8")
  manifest = yaml.safe_load(open(manifest_path, encoding="utf-8"))
  assert manifest["beta"] is False
  assert manifest["md5"] == {
      upk.name: md5_file(upk),
      product_path.name: md5_file(product_path),
  }


def test_suite_worker_process_updates_beta_package(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  arch_dir = create_platform_fixture(tasks_root / "cpu_arch_amd64", arch="work", beta=False)
  shutil.rmtree(next(path for path in arch_dir.iterdir() if path.is_dir()))
  calls = []

  def fake_setbeta(self, source_upk, target_upk, beta_value):
    calls.append((source_upk, target_upk, beta_value))
    simulate_setbeta_output(Path(target_upk), beta_value, b"new-beta-upk")

  monkeypatch.setattr(suite_publish_tool._SuiteWorker, "_sign_upk_with_setbeta", fake_setbeta)

  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "beta",
      tasks_root,
      tmp_path / "reports",
  ))
  os.makedirs(worker.tmp_dir)
  report = worker._process()

  work_dir = tasks_root / "cpu_arch_amd64" / "work"
  upk = work_dir / "amd64_com.ugreen.dlna_1.15.0.0028.upk"
  product_path = work_dir / "amd64_com.ugreen.dlna_1.15.0.0028.product.json"
  manifest_path = work_dir / (RELEASE_NAME + ".manifest.yaml")
  product = json.load(open(product_path, encoding="utf-8"))
  manifest = yaml.safe_load(open(manifest_path, encoding="utf-8"))

  assert calls and calls[0][2] is True
  assert report["old_beta"] is False
  assert report["new_beta"] is True
  assert product["version"]["beta"] is True
  assert manifest["beta"] is True
  assert manifest["md5"] == {
      upk.name: md5_file(upk),
      product_path.name: md5_file(product_path),
  }


def test_suite_worker_process_leaves_final_verification_to_worker_run(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  arch_dir = create_platform_fixture(tasks_root / "cpu_arch_amd64", arch="work")
  shutil.rmtree(next(path for path in arch_dir.iterdir() if path.is_dir()))

  def fake_setbeta(self, source_upk, target_upk, beta_value):
    with open(target_upk, "wb") as fp:
      fp.write(b"UGREEN-PKG-V2-FORMAT" + b"new-nobeta-upk")

  def unexpected_verify(self):
    raise AssertionError("process_arch should not run final verification")

  monkeypatch.setattr(suite_publish_tool._SuiteWorker, "_sign_upk_with_setbeta", fake_setbeta)
  monkeypatch.setattr(suite_publish_tool._SuiteWorker, "_verify", unexpected_verify)

  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tasks_root,
      tmp_path / "reports",
  ))
  os.makedirs(worker.tmp_dir)
  worker._process()


def test_verify_suite_archive_reports_verified_ga_result(tmp_path):
  tasks_root = tmp_path / "tasks"
  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tasks_root,
      tmp_path / "reports",
  ))
  arch_dir = create_platform_fixture(tasks_root / "cpu_arch_amd64", arch="work", beta=False)
  shutil.rmtree(next(path for path in arch_dir.iterdir() if path.is_dir()))
  files = worker._archive_files()
  extract_dir = tmp_path / "extract-summary"
  worker._extract_release_tar(files["tar"], str(extract_dir))
  payload = worker._find_release_payload_files(str(extract_dir))
  shutil.move(payload["upk"], tasks_root / "cpu_arch_amd64" / "work" / os.path.basename(payload["upk"]))
  shutil.move(payload["product"], tasks_root / "cpu_arch_amd64" / "work" / os.path.basename(payload["product"]))
  os.remove(files["tar"])
  worker._update_manifest_yaml(
      files["manifest"],
      str(tasks_root / "cpu_arch_amd64" / "work" / os.path.basename(payload["upk"])),
      str(tasks_root / "cpu_arch_amd64" / "work" / os.path.basename(payload["product"])),
      False,
  )

  summary = worker._verify()

  assert summary["sign"] == "v2"
  assert summary["beta"] is False
  assert summary["upk"] == os.path.basename(payload["upk"])


def test_run_setbeta_uses_jenkins_secret_env_without_logging_secret(tmp_path, monkeypatch):
  upk = tmp_path / "source.upk"
  tools_dir = tmp_path / "tools"
  tools_dir.mkdir()
  (tools_dir / "ugtools").write_text("#!/bin/sh\n", encoding="utf-8")
  (tools_dir / "ugreenRoot.pub").write_text("pub\n", encoding="utf-8")
  upk.write_bytes(b"source")
  monkeypatch.setenv("UGBT_SUITE_SIGN_API", "https://sign")
  monkeypatch.setenv("UGBT_SUITE_SIGN_KEY", "plain-secret-key")
  attempts = []

  def fake_run(cmd, assert_ok=True, show_log=True, retry_interval=None, retry_times=None):
    attempts.append((cmd, assert_ok, show_log, retry_interval, retry_times))
    upk.write_bytes(b"UGREEN-PKG-V2-FORMAT" + b"signed")
    return 0

  monkeypatch.setattr(suite_publish_tool, "run", fake_run)

  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
      tools_dir=str(tools_dir),
  ))
  worker.sign_retry_interval = 3

  worker._sign_upk_with_setbeta(str(upk), str(upk), False)

  assert len(attempts) == 1
  assert attempts[0][0].startswith("cd %s && " % str(tmp_path))
  assert '-signAPI "${UGBT_SUITE_SIGN_API}" -signKey "${UGBT_SUITE_SIGN_KEY}"' in attempts[0][0]
  assert "https://sign" not in attempts[0][0]
  assert "plain-secret-key" not in attempts[0][0]
  assert attempts[0][1:] == (False, True, 3, worker.sign_max_attempts)
  assert upk.read_bytes().startswith(b"UGREEN-PKG-V2-FORMAT")


def test_run_setbeta_fails_when_run_retry_exhausts(tmp_path, monkeypatch):
  upk = tmp_path / "source.upk"
  tools_dir = tmp_path / "tools"
  tools_dir.mkdir()
  (tools_dir / "ugtools").write_text("#!/bin/sh\n", encoding="utf-8")
  (tools_dir / "ugreenRoot.pub").write_text("pub\n", encoding="utf-8")
  upk.write_bytes(b"source")
  monkeypatch.setenv("UGBT_SUITE_SIGN_API", "https://sign")
  monkeypatch.setenv("UGBT_SUITE_SIGN_KEY", "plain-secret-key")
  attempts = []

  def fake_run(cmd, assert_ok=True, show_log=True, retry_interval=None, retry_times=None):
    attempts.append((cmd, assert_ok, show_log, retry_interval, retry_times))
    return 1

  monkeypatch.setattr(suite_publish_tool, "run", fake_run)

  with pytest.raises(SystemExit):
    worker = suite_publish_tool._SuiteWorker(worker_ctx(
        "cpu_arch_amd64",
        "ga",
        tmp_path / "tasks",
        tmp_path / "reports",
        tools_dir=str(tools_dir),
    ))
    worker.sign_retry_interval = 3
    worker.sign_max_attempts = 2
    worker._sign_upk_with_setbeta(str(upk), str(upk), False)

  assert len(attempts) == 1
  assert attempts[0][0].startswith("cd %s && " % str(tmp_path))
  assert attempts[0][1:] == (False, True, 3, 2)


def test_resolve_suite_sign_config_reads_jenkins_secret_env(tmp_path, monkeypatch):
  monkeypatch.setenv("UGBT_SUITE_SIGN_API", "https://api-zh.ugnas.com")
  monkeypatch.setenv("UGBT_SUITE_SIGN_KEY", "suite-sign-key")
  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))

  sign_api, sign_key = worker._resolve_sign_config(worker.SIGN_API_ENV, worker.SIGN_KEY_ENV)

  assert sign_api == "UGBT_SUITE_SIGN_API"
  assert sign_key == "UGBT_SUITE_SIGN_KEY"


def test_resolve_suite_sign_config_fails_without_jenkins_secret_env(tmp_path, monkeypatch):
  monkeypatch.delenv("UGBT_SUITE_SIGN_API", raising=False)
  monkeypatch.delenv("UGBT_SUITE_SIGN_KEY", raising=False)
  worker = suite_publish_tool._SuiteWorker(worker_ctx(
      "cpu_arch_amd64",
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))

  with pytest.raises(SystemExit):
    worker._resolve_sign_config(worker.SIGN_API_ENV, worker.SIGN_KEY_ENV)
