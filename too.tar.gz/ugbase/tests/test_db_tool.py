import io
import os
import shlex
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "plugin"))

import db_tool


def test_parse_query_vars_branch():
  assert db_tool.parse_query_vars(["branch=release_20260715_blitz"]) == {
      "branch": "release_20260715_blitz",
  }


def test_parse_query_vars_ignores_blank_and_no_equal():
  assert db_tool.parse_query_vars(["", "  ", "no_equal_sign", "branch=foo"]) == {
      "branch": "foo",
  }


def test_validate_branch_accepts_release_branch():
  assert db_tool.validate_branch("release_20260715_blitz") is None


def test_validate_branch_rejects_empty():
  msg = db_tool.validate_branch("")
  assert msg is not None
  assert "missing required parameter 'branch'" in msg


def test_validate_branch_rejects_whitespace():
  assert db_tool.validate_branch("release foo") is not None
  assert db_tool.validate_branch("release\trelease") is not None


def test_validate_branch_rejects_shell_metachars():
  for bad in (
      "release;rm",
      "release|cat",
      "release&ls",
      "release$IFS",
      "release`id`",
      "release\\n",
      "release\"q\"",
      "release'q'",
      "release<x",
      "release>x",
      "release*",
      "release?",
      "release(",
      "release)",
      "release[",
      "release]",
      "release{",
      "release}",
  ):
    assert db_tool.validate_branch(bad) is not None, "should reject %r" % bad


def test_parse_repos_action_default_is_1():
  action, err = db_tool.parse_repos_action({})
  assert err is None
  assert action == "1"


def test_parse_repos_action_blank_falls_back_to_default():
  action, err = db_tool.parse_repos_action({"repos_action": "  "})
  assert err is None
  assert action == "1"


def test_parse_repos_action_accepts_all_valid_choices():
  for choice in ("0", "1", "2", "3"):
    action, err = db_tool.parse_repos_action({"repos_action": choice})
    assert err is None, "unexpected error for %s: %s" % (choice, err)
    assert action == choice


def test_parse_repos_action_rejects_invalid():
  action, err = db_tool.parse_repos_action({"repos_action": "9"})
  assert action is None
  assert err is not None
  assert "Invalid repos_action" in err


def test_parse_repos_action_rejects_non_digit():
  action, err = db_tool.parse_repos_action({"repos_action": "clone"})
  assert action is None
  assert err is not None
  assert "Invalid repos_action" in err


def test_build_container_name_for_release_branch():
  assert (
      db_tool.build_container_name("release_20260715_blitz")
      == "repos_release_20260715_blitz"
  )


def test_build_container_name_uses_ssh_user_prefix():
  name = db_tool.build_container_name("foo")
  assert name.startswith(db_tool.SSH_USER + "_")


def test_build_check_container_cmd_uses_podman_ps_and_exact_filter():
  cmd = db_tool.build_check_container_cmd("repos_release_20260715_blitz")
  assert cmd == (
      "podman ps -a --filter 'name=^repos_release_20260715_blitz$' "
      "--format '{{.Names}}' 2>/dev/null"
  )


def test_build_stop_container_cmd_uses_podman_stop_with_fallback():
  cmd = db_tool.build_stop_container_cmd("repos_release_20260715_blitz")
  assert cmd == "podman stop repos_release_20260715_blitz 2>&1 || true"


def test_build_force_rm_container_cmd_uses_podman_rm_f_with_fallback():
  cmd = db_tool.build_force_rm_container_cmd("repos_release_20260715_blitz")
  assert cmd == "podman rm -f repos_release_20260715_blitz 2>&1 || true"


def test_build_force_rm_container_cmd_quotes_unsafe_name():
  cmd = db_tool.build_force_rm_container_cmd("repos_weird name")
  assert "'repos_weird name'" in cmd
  assert cmd.endswith("|| true")


def test_parse_force_flag_default_is_false():
  force, err = db_tool.parse_force_flag({})
  assert err is None
  assert force is False


def test_parse_force_flag_blank_is_false():
  force, err = db_tool.parse_force_flag({"force": "   "})
  assert err is None
  assert force is False


def test_parse_force_flag_accepts_truthy_values():
  for raw in ("1", "true", "TRUE", "True", "yes", "Y", "on", "ON"):
    force, err = db_tool.parse_force_flag({"force": raw})
    assert err is None, "unexpected error for %s: %s" % (raw, err)
    assert force is True, "expected True for %r" % raw


def test_parse_force_flag_accepts_falsy_values():
  for raw in ("0", "false", "FALSE", "no", "N", "off", "OFF"):
    force, err = db_tool.parse_force_flag({"force": raw})
    assert err is None, "unexpected error for %s: %s" % (raw, err)
    assert force is False, "expected False for %r" % raw


def test_parse_force_flag_rejects_invalid():
  for raw in ("maybe", "2", "yes please", "truthy"):
    force, err = db_tool.parse_force_flag({"force": raw})
    assert force is None, "expected reject for %r" % raw
    assert err is not None
    assert "Invalid force" in err


def test_build_inner_repo_update_cmd_default_action_is_1():
  cmd = db_tool.build_inner_repo_update_cmd("release_20260715_blitz")
  assert cmd == (
      "printf '%s\\n' 1 | bash ./git.sh repo "
      "git@gitlab.ugnas.com:ugos-pro/package/release-firmware.git@release_20260715_blitz"
  )


def test_build_inner_repo_update_cmd_with_explicit_action():
  cmd = db_tool.build_inner_repo_update_cmd("release_20260715_blitz", "3")
  assert "printf '%s\\n' 3" in cmd
  assert "release-firmware.git@release_20260715_blitz" in cmd


def test_build_inner_repo_update_cmd_excludes_cd_and_export():
  """inner 命令不含 cd / GIT_SSH_COMMAND export，这些由 dockerized 包装层负责。"""
  cmd = db_tool.build_inner_repo_update_cmd("release_20260715_blitz")
  assert "cd " not in cmd
  assert "GIT_SSH_COMMAND" not in cmd
  assert "export " not in cmd


def test_build_inner_release_flow_cmd_simple_form():
  cmd = db_tool.build_inner_release_flow_cmd("release_20260715_blitz")
  assert cmd == (
      "python3 $HOME/ugreen/ugbase/pipelines/release_flow.py "
      "--branch release_20260715_blitz"
  )


def test_build_inner_release_flow_cmd_quotes_when_needed():
  cmd = db_tool.build_inner_release_flow_cmd("weird branch")
  assert "--branch 'weird branch'" in cmd


def test_build_inner_release_flow_cmd_excludes_cd():
  cmd = db_tool.build_inner_release_flow_cmd("release_20260715_blitz")
  assert "cd " not in cmd


def inner_script_from_dockerized_cmd(cmd):
  parts = shlex.split(cmd)
  return parts[parts.index("-lc") + 1]


def test_build_dockerized_pipeline_cmd_runs_docker_util_with_command_arg():
  cmd = db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  parts = shlex.split(cmd)
  assert parts[:10] == [
      "cd",
      "$HOME/ugreen/ugbase",
      "&&",
      "git",
      "pull",
      "-r",
      "&&",
      "export",
      "DOCKER_ARCH_TYPE=amd64",
      "DOCKER_NAME=release_20260715_blitz",
  ]
  assert parts[10:14] == ["&&", "./script/docker_util.sh", "bash", "-lc"]


def test_build_dockerized_pipeline_cmd_does_not_use_heredoc_or_interactive_bash():
  cmd = db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  assert "<<'__UGBT_DB_INNER_EOF__'" not in cmd
  assert "start_docker.sh" not in cmd


def test_build_dockerized_pipeline_cmd_enables_console_logging():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  assert "unset PS1 PS2 PROMPT_COMMAND" in inner
  assert "stty -echo" not in inner
  assert "exec 2>&1" in inner
  assert "export PYTHONUNBUFFERED=1" in inner
  assert "export PS4='+ [container] '" in inner
  assert "set -e" in inner
  assert "set -x" in inner
  assert "===== [container] update release-firmware =====" in inner
  assert "===== [container] run release_flow.py =====" in inner


def test_build_dockerized_pipeline_cmd_exports_git_ssh_command_inside_container():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  assert (
      "export GIT_SSH_COMMAND='ssh -o StrictHostKeyChecking=accept-new "
      "-o LogLevel=ERROR'"
  ) in inner


def test_build_dockerized_pipeline_cmd_starts_sshd_inside_container():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  assert "sudo usermod -s /bin/bash $(whoami)" in inner
  assert "/usr/local/ugreen/ugbase/ugbt start_sshd" in inner


def test_build_dockerized_pipeline_cmd_includes_inner_repo_and_flow_with_default_action():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  assert "cd $HOME/ugreen || exit $?" in inner
  assert (
      "printf '%s\\n' 1 | bash ./git.sh repo "
      "git@gitlab.ugnas.com:ugos-pro/package/release-firmware.git@release_20260715_blitz"
      " || exit $?"
  ) in inner
  assert (
      "python3 $HOME/ugreen/ugbase/pipelines/release_flow.py "
      "--branch release_20260715_blitz || exit $?"
  ) in inner


def test_build_dockerized_pipeline_cmd_passes_through_explicit_action():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz", "3")
  )
  assert "printf '%s\\n' 3 | bash ./git.sh repo" in inner


def test_build_dockerized_pipeline_cmd_sets_pipefail():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  assert "set -o pipefail" in inner


class FakeSshChannel:
  def __init__(self):
    self.stdout_chunks = [b"stdout-1\n", b"stdout-2\n"]
    self.stderr_chunks = [b"stderr-1\n"]

  def recv_ready(self):
    return len(self.stdout_chunks) > 0

  def recv(self, _size):
    return self.stdout_chunks.pop(0)

  def recv_stderr_ready(self):
    return len(self.stderr_chunks) > 0

  def recv_stderr(self, _size):
    return self.stderr_chunks.pop(0)

  def exit_status_ready(self):
    return not self.stdout_chunks and not self.stderr_chunks

  def recv_exit_status(self):
    return 7


def test_stream_ssh_pty_mirrors_stdout_and_stderr(monkeypatch):
  stdout = io.StringIO()
  stderr = io.StringIO()
  monkeypatch.setattr(db_tool.sys, "stdout", stdout)
  monkeypatch.setattr(db_tool.sys, "stderr", stderr)

  status = db_tool._stream_ssh_pty(FakeSshChannel())

  assert status == 7
  assert stdout.getvalue() == "stdout-1\nstdout-2\n"
  assert stderr.getvalue() == "stderr-1\n"


def test_build_dockerized_pipeline_cmd_inner_script_ends_with_exit_0():
  inner = inner_script_from_dockerized_cmd(
      db_tool.build_dockerized_pipeline_cmd("release_20260715_blitz")
  )
  lines = [ln for ln in inner.splitlines() if ln != ""]
  assert lines[-1] == "exit 0"


def test_container_busy_msg_has_chinese_template():
  msg = db_tool.CONTAINER_BUSY_MSG % "repos_release_20260715_blitz"
  assert msg == (
      "当前正在有任务运行中，执行容器为repos_release_20260715_blitz，"
      "请稍后再试！！！"
  )


def test_container_force_rm_msg_renders_with_container_name():
  msg = db_tool.CONTAINER_FORCE_RM_MSG % "repos_release_20260715_blitz"
  assert "repos_release_20260715_blitz" in msg
  assert "force=true" in msg
  assert "强行删除" in msg


def test_constants_match_requirements():
  assert db_tool.SSH_HOST == "192.168.75.171"
  assert db_tool.SSH_PORT == 22
  assert db_tool.SSH_USER == "repos"
  assert db_tool.SSH_PASSWORD == "@WSX3edc"
  assert db_tool.REMOTE_WORKDIR == "$HOME/ugreen"
  assert db_tool.REMOTE_UGBASE_DIR == "$HOME/ugreen/ugbase"
  assert db_tool.DOCKER_UTIL_SCRIPT == "./script/docker_util.sh"
  assert db_tool.DOCKER_ARCH == "amd64"
  assert (
      db_tool.RELEASE_FIRMWARE_REPO
      == "git@gitlab.ugnas.com:ugos-pro/package/release-firmware.git"
  )
  assert (
      db_tool.RELEASE_FLOW_SCRIPT
      == "$HOME/ugreen/ugbase/pipelines/release_flow.py"
  )
  assert db_tool.DEFAULT_REPOS_ACTION == "1"
  assert db_tool.VALID_REPOS_ACTIONS == ("0", "1", "2", "3")
  assert "accept-new" in db_tool.GIT_SSH_COMMAND
  assert db_tool.START_SSHD_CMD == "/usr/local/ugreen/ugbase/ugbt start_sshd"
  assert db_tool.CONTAINER_NAME_FMT == "%s_%s"
  assert "请稍后再试" in db_tool.CONTAINER_BUSY_MSG
  assert "强行删除" in db_tool.CONTAINER_FORCE_RM_MSG
  assert db_tool.DEFAULT_FORCE is False
  assert "true" in db_tool.FORCE_TRUE_VALUES
  assert "1" in db_tool.FORCE_TRUE_VALUES
  assert "false" in db_tool.FORCE_FALSE_VALUES
  assert "0" in db_tool.FORCE_FALSE_VALUES
  assert "" in db_tool.FORCE_FALSE_VALUES
