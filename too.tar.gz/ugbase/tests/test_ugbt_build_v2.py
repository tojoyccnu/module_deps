import os

from ug_common import copy_dir, load_yaml_f, make_dir
from ug_test import PROJECT_ROOT, init_git_repo, run_ugbt


RES = os.path.join(PROJECT_ROOT, "tests", "res", "test_ugbt_build_v2")
PROJECT_PATH = "projects/schema-v2-cmake"


def _init_workspace(workspace):
  project_dir = os.path.join(workspace, PROJECT_PATH)
  copy_dir(os.path.join(RES, "workspace"), workspace)
  copy_dir(os.path.join(RES, "cmake_c"), project_dir, ignore_patterns=["ugreen_build"])
  make_dir(os.path.join(workspace, "home"))
  init_git_repo(project_dir, "ssh://git@example.com/tests/schema-v2-cmake.git", branch="master")
  return project_dir


def test_ugbt_schema_v2_prepare_build_pack_install_upload(tmp_path):
  workspace = os.path.join(str(tmp_path), "workspace")
  project_dir = _init_workspace(workspace)
  home = os.path.join(workspace, "home")

  for command in ["prepare", "build", "pack", "install", "upload --mock"]:
    assert run_ugbt(project_dir, command, isolate=True, home=home, use_project_ugdata=False) == 0

  install_dir = os.path.join(
      workspace, ".ugreen.tmp", "repo", "tests", "schema-v2-cmake",
      "master", "1.2.3", "4", "cpu_arch_amd64")
  pack_name = "master-tests_schema-v2-cmake-1.2.3.4-amd64"
  assert os.path.isfile(os.path.join(install_dir, pack_name + ".tar.gz"))
  manifest = load_yaml_f(os.path.join(install_dir, pack_name + ".manifest.yaml"))
  assert manifest["author"] == "gitlab:ugbt-test"
  assert manifest["url"] == "http://example.com/ugbt-test"
  assert manifest["branch"] == "master"
  assert manifest["dirty"] is False
  assert manifest["ugbase"].endswith("8bc6f5918708cbd94f0896b2923dd9ac5b117b08")
  assert not os.path.exists(os.path.join(home, ".ugreen.tmp"))
