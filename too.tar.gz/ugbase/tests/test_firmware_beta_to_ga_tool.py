import hashlib
import io
import os
import shlex
import subprocess
import tarfile

import pytest

import beta_once_tool as beta_once
from ug_common import dump_json, load_json, load_yaml, read_file, write_file


PACKAGE_DIR_NAME = "arch_spu_intel__build_type_release__cpu_arch_amd64__kernel_6.12.30+"
IMAGE_NAME = "release_20260526-firmware_image-1.16.0.91-intel_release_amd64_6.12.30+.img"
PRODUCT_NAME = "release_20260526-firmware_image-1.16.0.91-intel_release_amd64_6.12.30+.product.json"
MANIFEST_NAME = "release_20260526-firmware_image-1.16.0.91-intel_release_amd64_6.12.30+.manifest.yaml"
UPK_NAME = "01_amd64_com.ugreen.logmgr.upk"
SMB_URL = "smb://127.0.0.1/share/repo/firmware/image/release_20260526/1.16.0/91"


class FakeEnv:
  def get_build_vars(self):
    return {
        "arch_spu": ["intel", "rk3588", "rk3576"],
        "build_type": ["release", "debug"],
        "cpu_arch": ["amd64", "arm64"],
        "kernel": ["6.12.30+", "6.1.27"],
    }


def worker_ctx(platform_dir, mode, tasks_root, report_root, remote_tmp_root="tmp_remote", tools_dir="/tools"):
  class Ctx:
    pass

  ctx = Ctx()
  ctx.env = FakeEnv()
  ctx.smb_url = SMB_URL
  ctx.platform_dir = platform_dir
  ctx.mode = mode
  ctx.tasks_root = str(tasks_root)
  ctx.report_root = str(report_root)
  ctx.remote_tmp_root = remote_tmp_root
  ctx.tools_dir = tools_dir
  return ctx


def firmware_worker(tmp_path, platform_dir=PACKAGE_DIR_NAME, mode="ga", tools_dir="/tools"):
  return beta_once._FirmwareWorker(worker_ctx(
      platform_dir,
      mode,
      tmp_path / "tasks",
      tmp_path / "reports",
      tools_dir=tools_dir,
  ))


def md5_bytes(data):
  return hashlib.md5(data).hexdigest()


def file_md5(path):
  digest = hashlib.md5()
  with open(path, "rb") as fp:
    for chunk in iter(lambda: fp.read(4096), b""):
      digest.update(chunk)
  return digest.hexdigest()


def add_dir(tf, name):
  info = tarfile.TarInfo(name)
  info.type = tarfile.DIRTYPE
  info.mode = 0o755
  info.mtime = 0
  info.uid = 0
  info.gid = 0
  tf.addfile(info)


def add_file(tf, name, data, mode=0o644):
  if isinstance(data, str):
    data = data.encode("utf-8")
  info = tarfile.TarInfo(name)
  info.size = len(data)
  info.mode = mode
  info.mtime = 0
  info.uid = 0
  info.gid = 0
  tf.addfile(info, io.BytesIO(data))


def build_tar(path, entries):
  with tarfile.open(path, "w", format=tarfile.GNU_FORMAT) as tf:
    add_dir(tf, "./")
    for name, data in entries:
      if data is None:
        add_dir(tf, name)
      else:
        add_file(tf, name, data)


def build_oem_squashfs(tmp_path, os_beta=True):
  root_dir = tmp_path / "oem_root"
  output = tmp_path / "oem.squashfs"
  os_release = root_dir / "usr" / "lib" / "os-release"
  os_release.parent.mkdir(parents=True)
  os_release.write_text("OS_IS_BETA=%s\n" % ("True" if os_beta else "False"), encoding="utf-8")
  subprocess.check_call([
      "mksquashfs",
      str(root_dir),
      str(output),
      "-noappend",
      "-comp",
      "xz",
      "-b",
      "1048576",
      "-Xbcj",
      "x86",
      "-quiet",
      "-no-progress",
  ])
  return output.read_bytes()


def squashfs_cat(squashfs_path, filename):
  return subprocess.check_output(["unsquashfs", "-cat", str(squashfs_path), filename]).decode("utf-8")


def build_product(img_md5, img_size, beta=True):
  return {
      "version": "1.0",
      "固件": {
          "是否beta": beta,
          "固件MD5值": img_md5,
          "升级包大小": "%.2f" % (img_size / 1000.0),
      },
      "firmware": {
          "isBeta": beta,
          "md5": img_md5,
          "size": img_size,
      },
  }


def write_product(path, product):
  write_file(path, dump_json(product) + "\n", show_log=False)


def create_fixture(tmp_path, beta=True, os_beta=True):
  source_root = tmp_path / "91"
  package_dir = source_root / PACKAGE_DIR_NAME
  package_dir.mkdir(parents=True)

  upk_content = b"logmgr-upk"
  inner_tar = package_dir / "ugreen.bz2.fixture"
  build_tar(str(inner_tar), [
      ("./@cache/", None),
      ("./@cache/" + UPK_NAME, upk_content),
      ("./project.json", "{}\n"),
  ])
  inner_data = inner_tar.read_bytes()
  inner_tar.unlink()

  os_release = "OS_IS_BETA=%s\n" % ("True" if os_beta else "False")
  oem_data = build_oem_squashfs(tmp_path, os_beta)
  ugreen_txt = "%s  %s\n" % (md5_bytes(upk_content), UPK_NAME)
  md5sum = "".join([
      "%s  os-release\n" % md5_bytes(os_release.encode("utf-8")),
      "%s  oem.squashfs\n" % md5_bytes(oem_data),
      "%s  ugreen.txt\n" % md5_bytes(ugreen_txt.encode("utf-8")),
      "%s  ugreen.bz2\n" % md5_bytes(inner_data),
      "%s  version.txt\n" % md5_bytes(b"1.16.0\n"),
  ])

  img_path = package_dir / IMAGE_NAME
  build_tar(str(img_path), [
      ("./os-release", os_release),
      ("./oem.squashfs", oem_data),
      ("./ugreen.txt", ugreen_txt),
      ("./ugreen.bz2", inner_data),
      ("./md5sum.txt", md5sum),
      ("./version.txt", "1.16.0\n"),
  ])

  product_path = package_dir / PRODUCT_NAME
  write_product(str(product_path), build_product(file_md5(str(img_path)), os.path.getsize(str(img_path)), beta))

  manifest_path = package_dir / MANIFEST_NAME
  manifest_path.write_text(
      "author: test\n"
      "md5:\n"
      "  %s: %s\n"
      "  %s: %s\n"
      "beta: %s\n" % (
          IMAGE_NAME,
          file_md5(str(img_path)),
          PRODUCT_NAME,
          file_md5(str(product_path)),
          "true" if beta else "false",
      ),
      encoding="utf-8",
  )
  return source_root, package_dir


def parse_checksum_text(content):
  result = {}
  for line in content.splitlines():
    stripped = line.strip()
    if not stripped:
      continue
    digest, name = stripped.split()
    result[name] = digest
  return result


def test_process_firmware_package_updates_work_dir_in_place(tmp_path):
  _, package_dir = create_fixture(tmp_path)
  work_img = package_dir / IMAGE_NAME
  old_img_md5 = file_md5(str(work_img))
  with tarfile.open(work_img, "r") as tf:
    old_ugreen_txt_content = tf.extractfile("./ugreen.txt").read().decode("utf-8")
    old_ugreen_tar_data = tf.extractfile("./ugreen.bz2").read()

  worker = beta_once._FirmwareWorker(worker_ctx(
      PACKAGE_DIR_NAME,
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))
  worker.work_dir = str(package_dir)
  worker._process_package()
  target_img = os.path.join(package_dir, IMAGE_NAME)

  assert file_md5(str(work_img)) != old_img_md5

  with tarfile.open(target_img, "r") as tf:
    os_release = tf.extractfile("./os-release").read().decode("utf-8")
    oem_data = tf.extractfile("./oem.squashfs").read()
    ugreen_txt_content = tf.extractfile("./ugreen.txt").read().decode("utf-8")
    md5sum_content = tf.extractfile("./md5sum.txt").read().decode("utf-8")
    ugreen_tar_data = tf.extractfile("./ugreen.bz2").read()
    version_data = tf.extractfile("./version.txt").read()

  assert "OS_IS_BETA=False" in os_release
  target_oem = tmp_path / "target_oem.squashfs"
  target_oem.write_bytes(oem_data)
  assert "OS_IS_BETA=False" in squashfs_cat(target_oem, "usr/lib/os-release")

  ugreen_txt = parse_checksum_text(ugreen_txt_content)
  assert ugreen_txt_content == old_ugreen_txt_content
  assert list(ugreen_txt.keys()) == [UPK_NAME]
  assert ugreen_tar_data == old_ugreen_tar_data
  with tarfile.open(fileobj=io.BytesIO(ugreen_tar_data), mode="r") as tf:
    assert "./@cache/" + UPK_NAME in tf.getnames()
    upk_data = tf.extractfile("./@cache/" + UPK_NAME).read()
  assert ugreen_txt[UPK_NAME] == md5_bytes(upk_data)

  md5sum = parse_checksum_text(md5sum_content)
  assert md5sum["os-release"] == md5_bytes(os_release.encode("utf-8"))
  assert md5sum["oem.squashfs"] == md5_bytes(oem_data)
  assert md5sum["ugreen.txt"] == md5_bytes(ugreen_txt_content.encode("utf-8"))
  assert md5sum["ugreen.bz2"] == md5_bytes(ugreen_tar_data)
  assert md5sum["version.txt"] == md5_bytes(version_data)

  product = load_json(read_file(os.path.join(package_dir, PRODUCT_NAME)))
  assert product["固件"]["是否beta"] is False
  assert product["firmware"]["isBeta"] is False
  assert product["固件"]["固件MD5值"] == file_md5(target_img)
  assert product["firmware"]["md5"] == file_md5(target_img)
  assert product["firmware"]["size"] == os.path.getsize(target_img)
  assert product["固件"]["升级包大小"] == "%.2f" % (os.path.getsize(target_img) / 1000.0)

  manifest = load_yaml(open(os.path.join(package_dir, MANIFEST_NAME), encoding="utf-8").read())
  assert manifest["beta"] is False
  assert manifest["md5"][IMAGE_NAME] == file_md5(target_img)
  assert manifest["md5"][PRODUCT_NAME] == file_md5(os.path.join(package_dir, PRODUCT_NAME))


def test_update_os_release_uses_run_for_sed_command(tmp_path, monkeypatch):
  unpack_dir = tmp_path / "unpack"
  unpack_dir.mkdir()
  os_release = unpack_dir / "os-release"
  os_release.write_text("OS_IS_BETA=True\n", encoding="utf-8")
  calls = []

  def fake_run(cmd):
    calls.append(shlex.split(cmd))
    os_release.write_text("OS_IS_BETA=False\n", encoding="utf-8")

  def fail_runex(cmd, **kwargs):
    raise AssertionError("runex should not be used for sed command: %s" % cmd)

  monkeypatch.setattr(beta_once, "run", fake_run)
  monkeypatch.setattr(beta_once, "runex", fail_runex)

  firmware_worker(tmp_path)._update_os_release(str(unpack_dir))

  assert calls == [["sed", "-i", "s/OS_IS_BETA=True/OS_IS_BETA=False/", str(os_release)]]
  assert os_release.read_text(encoding="utf-8") == "OS_IS_BETA=False\n"


def test_update_oem_squashfs_edits_extracted_os_release_as_text(tmp_path, monkeypatch):
  unpack_dir = tmp_path / "unpack"
  unpack_dir.mkdir()
  squashfs_path = unpack_dir / "oem.squashfs"
  squashfs_path.write_bytes(b"old squashfs")
  calls = []

  def fake_runex(cmd, err_output=False):
    args = shlex.split(cmd)
    calls.append(args)
    if args[:2] == ["unsquashfs", "-lln"]:
      return ""
    raise AssertionError("unexpected runex command: %s" % cmd)

  def fake_run(cmd):
    args = shlex.split(cmd)
    calls.append(args)
    if args[0] == "unsquashfs":
      assert "-pf" not in args
      root = args[args.index("-d") + 1]
      os_release = os.path.join(root, "usr/lib/os-release")
      os.makedirs(os.path.dirname(os_release))
      write_file(os_release, "OS_IS_BETA=True\n", show_log=False)
      return ""
    if args[0] == "mksquashfs":
      assert "-pf" not in args
      with open(args[2], "wb") as fp:
        fp.write(b"new squashfs")
      return ""
    raise AssertionError("unexpected command: %s" % cmd)

  monkeypatch.setattr(beta_once._FirmwareWorker, "_squashfs_build_options",
                      lambda self, path: ["-comp", "xz", "-b", "1048576"])
  monkeypatch.setattr(beta_once, "runex", fake_runex)
  monkeypatch.setattr(beta_once, "run", fake_run)

  firmware_worker(tmp_path)._update_oem_squashfs(str(unpack_dir))

  assert squashfs_path.read_bytes() == b"new squashfs"
  assert calls[0][0] == "unsquashfs"
  assert calls[1][0] == "unsquashfs"
  assert calls[2][0] == "mksquashfs"


def test_squashfs_device_pseudo_definitions_parse_numeric_unsquashfs_listing(monkeypatch, tmp_path):
  output = "\n".join([
      "drwxr-xr-x 1005/1005                37 2026-06-30 03:32 squashfs-root",
      "drwxr-xr-x 1005/1005                30 2026-06-30 03:32 squashfs-root/dev",
      "crw------- 0/0                   5,  1 2026-06-30 03:32 squashfs-root/dev/console",
      "brw-rw---- 0/6                   8,  0 2026-06-30 03:32 squashfs-root/dev/sda",
      "-rw-r--r-- 1005/1005                16 2026-06-30 03:32 squashfs-root/usr/lib/os-release",
  ])

  monkeypatch.setattr(beta_once, "runex", lambda cmd, err_output=False: output)

  assert firmware_worker(tmp_path)._squashfs_device_pseudo_definitions("/tmp/oem.squashfs") == [
      "dev/console c 600 0 0 5 1",
      "dev/sda b 660 0 6 8 0",
  ]


def test_update_oem_squashfs_preserves_device_nodes_for_non_root_extract(tmp_path, monkeypatch):
  unpack_dir = tmp_path / "unpack"
  unpack_dir.mkdir()
  squashfs_path = unpack_dir / "oem.squashfs"
  squashfs_path.write_bytes(b"old squashfs")
  calls = []

  def fake_runex(cmd, err_output=False):
    args = shlex.split(cmd)
    calls.append(args)
    if args[:2] == ["unsquashfs", "-lln"]:
      return "crw------- 0/0                   5,  1 2026-06-30 03:32 squashfs-root/dev/console\n"
    raise AssertionError("unexpected runex command: %s" % cmd)

  def fake_run(cmd):
    args = shlex.split(cmd)
    calls.append(args)
    if args[0] == "unsquashfs":
      assert "-ignore-errors" in args
      assert "-no-exit-code" in args
      root = args[args.index("-d") + 1]
      os_release = os.path.join(root, "usr/lib/os-release")
      os.makedirs(os.path.dirname(os_release))
      write_file(os_release, "OS_IS_BETA=True\n", show_log=False)
      return ""
    if args[0] == "mksquashfs":
      assert "-pf" in args
      pseudo_path = args[args.index("-pf") + 1]
      assert read_file(pseudo_path) == "dev/console c 600 0 0 5 1\n"
      with open(args[2], "wb") as fp:
        fp.write(b"new squashfs")
      return ""
    raise AssertionError("unexpected command: %s" % cmd)

  monkeypatch.setattr(beta_once._FirmwareWorker, "_squashfs_build_options",
                      lambda self, path: ["-comp", "xz", "-b", "1048576"])
  monkeypatch.setattr(beta_once, "runex", fake_runex)
  monkeypatch.setattr(beta_once, "run", fake_run)

  firmware_worker(tmp_path)._update_oem_squashfs(str(unpack_dir))

  assert squashfs_path.read_bytes() == b"new squashfs"


def test_check_size_diff_rejects_more_than_limit(tmp_path):
  limit = beta_once._FirmwareWorker.MAX_SIZE_DIFF_BYTES
  worker = firmware_worker(tmp_path)
  worker._check_size_diff("sample", 100, 100 + limit)
  with pytest.raises(SystemExit):
    worker._check_size_diff("sample", 100, 101 + limit)
