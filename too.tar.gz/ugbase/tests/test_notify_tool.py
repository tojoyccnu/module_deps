import notify_tool


class _Env:
  opts = {}
  opts_multiple = {}
  args = []


def test_markdown_at_content_separates_multiple_users():
  tool = notify_tool.Tool(_Env())
  tool.build_index()

  content = tool.get_at_content("markdown", [
      {"did": "02405932551233489"},
      {"did": "01094332096729301774"},
  ])

  assert content == ">@02405932551233489 @01094332096729301774"
