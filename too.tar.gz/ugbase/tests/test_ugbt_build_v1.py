import os

from ug_common import copy_dir
from ug_test import PROJECT_ROOT, init_git_repo, run_ugbt


RES = os.path.join(PROJECT_ROOT, "tests", "res", "test_ugbt_build_v1")


def test_ugbt_build_v1_legacy_ugbase_cmake_cpp_coverage(tmp_path):
  project_dir = tmp_path / "cmake_cpp_coverage"
  copy_dir(os.path.join(RES, "cmake_cpp_coverage"), str(project_dir), ignore_patterns=["ugreen_build"])
  assert run_ugbt(project_dir, "test -c", isolate=True) == 0


def test_ugbt_build_v1_legacy_ugbase_ugtools_upk_go(tmp_path):
  project_dir = tmp_path / "ugtools_upk_go"
  copy_dir(os.path.join(RES, "ugtools_upk_go"), str(project_dir), ignore_patterns=["ugreen_build"])
  assert run_ugbt(project_dir, "test", isolate=True) == 0


def test_ugbt_build_v1_default_template_without_template_key(tmp_path):
  project_dir = tmp_path / "default_template_lz4"
  copy_dir(os.path.join(RES, "default_template_lz4"), str(project_dir), ignore_patterns=["ugreen_build"])
  assert run_ugbt(project_dir, "test", isolate=True) == 0


def test_ugbt_install_dep_can_be_referenced_by_another_module(tmp_path):
  work_dir = tmp_path / "ugreen_build"
  module_a_dir = work_dir / "projects" / "module_a"
  module_b_dir = work_dir / "projects" / "module_b"
  copy_dir(os.path.join(RES, "install_dep_reference", "module_a"), str(module_a_dir),
           ignore_patterns=["ugreen_build"])
  copy_dir(os.path.join(RES, "install_dep_reference", "module_b"), str(module_b_dir),
           ignore_patterns=["ugreen_build"])
  init_git_repo(module_a_dir, "ssh://git@example.com/tests/install-dep-a.git")

  ugdata = work_dir / ".ugreen.tmp"
  env = {
      "HOME": work_dir / "home",
      "UGDATA": ugdata,
      "LOCAL_REPO": ugdata / "repo",
      "XDG_CACHE_HOME": work_dir / "cache",
      "GOCACHE": work_dir / "cache" / "go-build",
      "GOMODCACHE": work_dir / "cache" / "go-mod",
  }
  assert run_ugbt(module_a_dir, "install", isolate=True, extra_env=env) == 0
  assert run_ugbt(module_b_dir, "test", isolate=True, extra_env=env) == 0
  assert os.path.exists(os.path.join(str(ugdata), "repo", "tests", "install-dep-a"))
  assert not os.path.exists(os.path.join(str(env["HOME"]), ".ugreen.tmp"))
