import os
import sys


def _ensure_repo_paths():
  root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
  for p in (root, os.path.join(root, "lib"), os.path.join(root, "plugin")):
    if p not in sys.path:
      sys.path.insert(0, p)


def _init_ug_log():
  from ug_common import log_set_show_date, log_set_show_pid, log_set_show_src, log_set_show_stack, \
      log_set_show_tid, log_set_show_verbose

  log_set_show_date(False)
  log_set_show_pid(False)
  log_set_show_tid(False)
  log_set_show_src(True)
  log_set_show_verbose(False)
  log_set_show_stack(True)


_ensure_repo_paths()
_init_ug_log()
