#pragma once

int schema_v2_add(int left, int right);
