#include "schema_v2.h"

int schema_v2_add(int left, int right) {
  return left + right;
}
