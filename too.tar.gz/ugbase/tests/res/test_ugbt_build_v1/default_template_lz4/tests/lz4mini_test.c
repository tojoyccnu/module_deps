#include "lz4mini.h"

int main(void) {
  return lz4mini_bound(32) == 48 ? 0 : 1;
}
