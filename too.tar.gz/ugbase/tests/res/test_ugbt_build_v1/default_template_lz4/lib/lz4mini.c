#include "lz4mini.h"

int lz4mini_bound(int input_size) {
  return input_size + 16;
}
