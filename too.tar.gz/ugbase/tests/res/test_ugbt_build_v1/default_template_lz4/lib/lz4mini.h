#pragma once

int lz4mini_bound(int input_size);
