build: ${BUILD_DIR}/build-ok

${BUILD_DIR}/build-ok: lib/lz4mini.c lib/lz4mini.h
	mkdir -p ${BUILD_DIR}
	${CC} -Ilib -c lib/lz4mini.c -o ${BUILD_DIR}/lz4mini.o
	touch ${BUILD_DIR}/build-ok

test: build
	${CC} -Ilib tests/lz4mini_test.c ${BUILD_DIR}/lz4mini.o -o ${BUILD_DIR}/lz4mini_test
	${BUILD_DIR}/lz4mini_test
