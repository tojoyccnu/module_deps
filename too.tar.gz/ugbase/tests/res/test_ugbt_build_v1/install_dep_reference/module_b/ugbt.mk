test: ${BUILD_DIR}/prepare-ok
	test -f ${module_a_ROOT}/include/module_a_value.h
	grep -q "MODULE_A_VALUE 42" ${module_a_ROOT}/include/module_a_value.h
	test -L ${BUILD_DIR}/deps/module_a
