module storage_serv

go 1.20
