package calc

func Add(left, right int) int {
	return left + right
}
