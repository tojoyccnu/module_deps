package main

import "storage_serv/internal/calc"

func main() {
	_ = calc.Add(1, 1)
}
