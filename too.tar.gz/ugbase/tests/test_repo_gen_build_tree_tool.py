import os
import shlex

import pytest

from ug_common import load_yaml_f, make_dir, read_file, run, write_file


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "tests", "res", "repo_gen_build_tree")
SUCCESS_CASES = ["ok", "multi_version", "dep_prefix", "dep_multi_version", "external_project"]
FAIL_CASES = ["missing_dep", "missing_project_dir", "missing_project_list", "cycle", "schema_v2"]


def _case_repo(name):
  return os.path.join(RES, name, "repo")


def _case_build_dir(tmp_path, name):
  build_dir = tmp_path / name / "build"
  make_dir(str(build_dir))
  return build_dir


def _run_repo_gen_build_tree(workspace, build_dir):
  output_file = build_dir / "building.yaml"
  version_output_file = build_dir / "building.version.yaml"
  write_file(str(output_file), "stale")
  write_file(str(version_output_file), "stale")
  external_conf = os.path.join(os.path.dirname(workspace), "extenal_project.conf")
  if os.path.isfile(external_conf):
    write_file(str(build_dir / "extenal_project.conf"), read_file(external_conf))
  cmd = "cd %s && %s repo-gen-build-tree --workspace %s" % (
      shlex.quote(str(build_dir)),
      shlex.quote(os.path.join(ROOT, "ugbt")),
      shlex.quote(str(workspace)),
  )
  return run(cmd, assert_ok=False), output_file, version_output_file


def _assert_build_outputs(name, building_file, version_file):
  expected_dir = os.path.join(RES, name, "expected")
  assert load_yaml_f(str(building_file)) == load_yaml_f(os.path.join(expected_dir, "building.yaml"))
  assert load_yaml_f(str(version_file)) == load_yaml_f(os.path.join(expected_dir, "building.version.yaml"))


def _assert_success_case(tmp_path, name):
  ret, building_file, version_file = _run_repo_gen_build_tree(_case_repo(name), _case_build_dir(tmp_path, name))
  assert ret == 0
  _assert_build_outputs(name, building_file, version_file)
  return load_yaml_f(str(building_file)), load_yaml_f(str(version_file))


def _assert_fail_case(tmp_path, name):
  ret, _, _ = _run_repo_gen_build_tree(_case_repo(name), _case_build_dir(tmp_path, name))
  assert ret != 0


@pytest.mark.parametrize("name", SUCCESS_CASES)
def test_repo_gen_build_tree_success(tmp_path, name):
  _assert_success_case(tmp_path, name)


@pytest.mark.parametrize("name", FAIL_CASES)
def test_repo_gen_build_tree_fail(tmp_path, name):
  _assert_fail_case(tmp_path, name)


def test_repo_gen_build_tree_multi_version_same_module(tmp_path):
  building, _ = _assert_success_case(tmp_path, "multi_version")
  assert building["app_v1"]["name"] == "app"
  assert building["app_v2"]["name"] == "app"
  assert building["app_v1"]["version-ref"] != building["app_v2"]["version-ref"]


def test_repo_gen_build_tree_dep_ref_for_multi_version_module(tmp_path):
  _assert_success_case(tmp_path, "dep_multi_version")


def test_repo_gen_build_tree_ugbase_versions_in_version_yaml(tmp_path):
  building, version_data = _assert_success_case(tmp_path, "ok")
  for data in building.values():
    assert "ugbase" not in data
  assert version_data["ugbase"]["versions"]["v1"] == "ssh://git@gitlab.ugnas.com/scm/ugbase.bak.git release_v1 cdefgh"
  assert version_data["ugbase"]["versions"]["v2"] == "ssh://git@gitlab.ugnas.com/scm/ugbase.git master 0000000"
  assert version_data["ugbase"]["versions"]["v3"] == "ssh://git@gitlab.ugnas.com/scm/ugbase.git release_v1 cdefgh"
  assert version_data["ugbase"]["modules"]["ref-1"] == "v2"
  assert version_data["ugbase"]["modules"]["ref-2"] == "v3"
  assert version_data["ugbase"]["modules"]["ref-3"] == "v1"
