import json
import os

import pytest

import beta_jenkins_tool
import beta_foreach_tool
from ug_common import join_cmd


FIRMWARE_URL = "smb://host/share/root/repo/firmware/image/release_20260624/1/2"


class DummyError(Exception):
  pass


class FakeConn:
  instances = []

  def __init__(self, host):
    self.host = host
    self.mkdirs = []
    self.moves = []
    self.deleted_dirs = []
    FakeConn.instances.append(self)

  def connect(self):
    return None

  def isdir(self, share, remote_path):
    return remote_path in (
        "root/repo/firmware/image/release_20260624/1/2",
        "root/repo/firmware/image/release_20260624/1/2/arch_spu_a",
        "root/repo/firmware/image/release_20260624/1/2/arch_spu_b",
        "root/repo/firmware/image/release_20260624/1/2/plain_task",
        "root/repo/firmware/image/release_20260624/1/2/upload.tmp",
    )

  def ls(self, share, remote_path):
    return [".", "..", "arch_spu_b", "README.md", "plain_task", "upload.tmp", "arch_spu_a"]

  def exists(self, share, remote_path):
    return False

  def mkdir(self, share, remote_path):
    self.mkdirs.append((share, remote_path))

  def mv(self, share, source, target):
    self.moves.append((share, source, target))

  def delete_dir_recursive(self, share, remote_path):
    self.deleted_dirs.append((share, remote_path))


class FailingDeleteConn(FakeConn):
  def delete_dir_recursive(self, share, remote_path):
    self.deleted_dirs.append((share, remote_path))
    raise DummyError("delete failed: %s" % remote_path)


class FailingMoveConn(FakeConn):
  def mv(self, share, source, target):
    self.moves.append((share, source, target))
    raise DummyError("mv failed: %s -> %s" % (source, target))


def test_beta_run_foreach_expands_smb_platform_dirs_to_target_command_args(tmp_path):
  calls = []

  def fake_command_runner(labels, commands, jobs, log_dir):
    calls.append((labels, commands, jobs, log_dir))

  ctx = beta_foreach_tool._BetaForeachContext(
      None,
      FIRMWARE_URL,
      [
          "ugbt",
          "beta_run_once",
          "--smb-url",
          FIRMWARE_URL,
          "--type",
          "firmware",
          "--mode",
          "ga",
          "--platform-dir",
          "{}",
      ],
      samba_connection_cls=FakeConn,
      command_runner=fake_command_runner,
      log_root=str(tmp_path / "work" / "logs"),
  )
  platform_dirs = beta_foreach_tool._BetaForeachRunner(ctx).execute()

  assert platform_dirs == ["arch_spu_a", "arch_spu_b", "plain_task"]
  labels, commands, jobs, log_dir = calls[0]
  assert labels == ["arch_spu_a", "arch_spu_b", "plain_task"]
  assert jobs == 3
  assert log_dir == str(tmp_path / "work" / "logs")
  assert commands[0] == [
      "ugbt",
      "beta_run_once",
      "--smb-url",
      FIRMWARE_URL,
      "--type",
      "firmware",
      "--mode",
      "ga",
      "--platform-dir",
      "arch_spu_a",
  ]


def test_beta_run_jenkins_publish_owns_tmp_release_mv_mail_and_cleanup(tmp_path, monkeypatch):
  FakeConn.instances = []
  sent = []
  foreach_calls = []
  monkeypatch.chdir(tmp_path)

  def fake_run_foreach_command(cmd):
    foreach_calls.append(cmd)
    report_root = str(tmp_path / "ugbt" / "beta_run_jenkins" / "run123" / "reports")
    os.makedirs(report_root, exist_ok=True)
    for platform_dir in ("arch_spu_a", "arch_spu_b"):
      with open(os.path.join(report_root, platform_dir + ".json"), "w", encoding="utf-8") as fp:
        json.dump({
            "filename": platform_dir + ".img",
            "old_beta": True,
            "new_beta": False,
            "old_md5": "old-" + platform_dir,
            "new_md5": "new-" + platform_dir,
        }, fp)
    return 0

  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")
  monkeypatch.setattr(beta_jenkins_tool, "run", fake_run_foreach_command)
  def fake_send_success(self, reports):
    sent.append({
        "publish_url": self.ctx.publish_url,
        "reports": reports,
    })

  monkeypatch.setattr(beta_jenkins_tool._BetaPublishMailer, "send_success", fake_send_success)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), FIRMWARE_URL, "ga", samba_connection_cls=FakeConn)
  ctx.mail_to = "qa@ugreen.com"
  publisher = beta_jenkins_tool._BetaPublisher(ctx)
  result = publisher.run()
  publisher._cleanup()  # pytest 进程不会在单个用例结束时退出，这里模拟 atexit 清理。

  assert result == "smb://host/share/root/release/image/release_20260624/GA/firmware/image/1/2"
  assert not (tmp_path / "ugbt" / "beta_run_jenkins" / "run123").exists()
  publish_conn = FakeConn.instances[0]
  assert publish_conn.mkdirs == [
      ("share", "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp"),
      ("share", "root/release/image/release_20260624/GA/firmware/image/1"),
  ]
  assert publish_conn.moves == [
      (
          "share",
          "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp",
          "root/release/image/release_20260624/GA/firmware/image/1/2",
      ),
  ]
  run_work_root = str(tmp_path / "ugbt" / "beta_run_jenkins" / "run123")
  ugbt_bin = str(tmp_path / "ugbase" / "ugbt")
  foreach_cmd = [
      ugbt_bin,
      "beta_run_foreach",
      "--smb-url",
      FIRMWARE_URL,
      "--",
  ]
  foreach_cmd.extend([
      ugbt_bin,
      "beta_run_once",
      "--smb-url",
      FIRMWARE_URL,
      "--type",
      "firmware",
      "--mode",
      "ga",
      "--remote-tmp-root",
      "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp",
      "--platform-dir",
      "{}",
  ])
  assert foreach_calls[0] == "cd %s && %s" % (join_cmd([run_work_root]), join_cmd(foreach_cmd))
  assert sent[0]["publish_url"] == result
  assert [item["filename"] for item in sent[0]["reports"]] == ["arch_spu_a.img", "arch_spu_b.img"]


def test_beta_run_jenkins_publish_removes_remote_tmp_when_foreach_fails(tmp_path, monkeypatch):
  FakeConn.instances = []
  monkeypatch.chdir(tmp_path)

  def fail_foreach(cmd):
    raise DummyError("worker failed")

  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")
  monkeypatch.setattr(beta_jenkins_tool, "run", fail_foreach)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), FIRMWARE_URL, "ga", samba_connection_cls=FakeConn)
  publisher = beta_jenkins_tool._BetaPublisher(ctx)
  with pytest.raises(DummyError, match="worker failed"):
    publisher.run()
  publisher._cleanup()  # 模拟进程退出时 atexit 调用清理函数。

  assert not (tmp_path / "ugbt" / "beta_run_jenkins" / "run123").exists()
  assert FakeConn.instances[0].deleted_dirs == [
      ("share", "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp")
  ]


def test_beta_run_jenkins_publish_uses_exit_cleanup_when_mail_fails(tmp_path, monkeypatch):
  FakeConn.instances = []
  monkeypatch.chdir(tmp_path)

  def fake_run_foreach_command(cmd):
    report_root = str(tmp_path / "ugbt" / "beta_run_jenkins" / "run123" / "reports")
    os.makedirs(report_root, exist_ok=True)
    return 0

  def fail_send_success(self, reports):
    raise SystemExit(8)

  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")
  monkeypatch.setattr(beta_jenkins_tool, "run", fake_run_foreach_command)
  monkeypatch.setattr(beta_jenkins_tool._BetaPublishMailer, "send_success", fail_send_success)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), FIRMWARE_URL, "ga", samba_connection_cls=FakeConn)
  publisher = beta_jenkins_tool._BetaPublisher(ctx)
  with pytest.raises(SystemExit) as e:
    publisher.run()
  assert e.value.code == 8

  publish_conn = FakeConn.instances[0]
  assert publish_conn.deleted_dirs == []

  publisher._cleanup()  # 模拟进程退出时 atexit 统一清理。

  assert publish_conn.deleted_dirs == [
      ("share", "root/release/image/release_20260624/GA/firmware/image/1/2")
  ]
  assert not (tmp_path / "ugbt" / "beta_run_jenkins" / "run123").exists()


def test_beta_run_jenkins_publish_removes_remote_tmp_when_final_mv_fails(tmp_path, monkeypatch):
  FakeConn.instances = []
  monkeypatch.chdir(tmp_path)

  def fake_run_foreach_command(cmd):
    report_root = str(tmp_path / "ugbt" / "beta_run_jenkins" / "run123" / "reports")
    os.makedirs(report_root, exist_ok=True)
    return 0

  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")
  monkeypatch.setattr(beta_jenkins_tool, "run", fake_run_foreach_command)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), FIRMWARE_URL, "ga", samba_connection_cls=FailingMoveConn)
  publisher = beta_jenkins_tool._BetaPublisher(ctx)
  with pytest.raises(DummyError, match="mv failed"):
    publisher.run()
  publisher._cleanup()

  publish_conn = FakeConn.instances[0]
  assert publish_conn.moves == [
      (
          "share",
          "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp",
          "root/release/image/release_20260624/GA/firmware/image/1/2",
      ),
  ]
  assert publish_conn.deleted_dirs == [
      ("share", "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp")
  ]
  assert not (tmp_path / "ugbt" / "beta_run_jenkins" / "run123").exists()


def test_beta_run_jenkins_cleanup_still_removes_work_dir_when_remote_delete_fails(tmp_path, monkeypatch):
  FakeConn.instances = []
  monkeypatch.chdir(tmp_path)

  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), FIRMWARE_URL, "ga", samba_connection_cls=FailingDeleteConn)
  ctx.conn = FailingDeleteConn(ctx.location.host)
  ctx.staging_created = True
  make_work_dir = tmp_path / "ugbt" / "beta_run_jenkins" / "run123"
  make_work_dir.mkdir(parents=True)

  publisher = beta_jenkins_tool._BetaPublisher(ctx)
  with pytest.raises(DummyError, match="delete failed"):
    publisher._cleanup()

  assert ctx.conn.deleted_dirs == [
      ("share", "root/release.tmp/image/release_20260624/GA/firmware/image/1/2.run123.tmp")
  ]
  assert not make_work_dir.exists()
