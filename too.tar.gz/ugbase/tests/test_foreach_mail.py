import beta_jenkins_tool as package_mail
from datetime import datetime as real_datetime


def mailer_ctx(package_type="固件", mode="GA", executor="", source_url="smb://host/share/repo/image/pkg",
               publish_url="smb://host/share/release/GA/image/pkg", mail_to=None):
  class Ctx:
    pass

  ctx = Ctx()
  ctx.executor = executor
  ctx.mode = mode
  ctx.package_attrs = {
      "mail_package_type": package_type,
  }
  ctx.source_url = source_url
  ctx.publish_url = publish_url
  ctx.mail_to = mail_to or ["qa@ugreen.com"]
  return ctx


def test_beta_run_jenkins_team_recipients_are_hard_coded():
  assert package_mail._beta_run_jenkins_team_addrs() == [
      "NAS-测试组 <nas-test@ugreen.com>",
      "NAS-软件开发组 <nas-develop@ugreen.com>",
      "NAS-PRO-产品小组 <nas-pro-product@ugreen.com>",
      "NAS-UI设计组 <nas-ui@ugreen.com>",
      "NAS-产品运营组 <nas-cpyy@ugreen.com>",
      "NAS-音视频组 <nas-media@ugreen.com>",
      "NAS-系统安全组 <nas-security@ugreen.com>",
      "NAS-系统 <nas-os@ugreen.com>",
      "NAS-云端组 <nas-cloud@ugreen.com>",
      "NAS-软件项目组 <nas-project@ugreen.com>",
      "NAS-AI <nas-ai@ugreen.com>",
      "NAS-DQE组 <pz-nasdqe@ugreen.com>",
      "NAS-硬件开发 <nas-hwyf@ugreen.com>",
  ]


def test_resolve_executor_prefers_explicit_value(monkeypatch):
  monkeypatch.setenv("BUILD_USER", "Jenkins User")
  monkeypatch.setenv("BUILD_USER_EMAIL", "jenkins@ugreen.com")

  mailer = package_mail._BetaPublishMailer(mailer_ctx(executor="张三 <zhangsan@ugreen.com>"))
  assert mailer._resolve_executor() == "张三 <zhangsan@ugreen.com>"


def test_resolve_executor_uses_build_user_only_even_with_email(monkeypatch):
  monkeypatch.delenv("USER", raising=False)
  monkeypatch.setenv("BUILD_USER", "Jenkins User")
  monkeypatch.setenv("BUILD_USER_EMAIL", "jenkins@ugreen.com")

  mailer = package_mail._BetaPublishMailer(mailer_ctx(executor=""))
  assert mailer._resolve_executor() == "Jenkins User"


def test_render_success_html_uses_template_and_escapes_values(tmp_path):
  template = tmp_path / "package_publish_success.html"
  template.write_text(
      "<h2>${TITLE}</h2><p>${EXECUTOR}</p><p>${PACKAGE_TYPE}</p><p>${BETA_CHANGE}</p>"
      "<p>${SOURCE_URL}</p><p>${PUBLISH_URL}</p><p>${RESULT_COUNT}</p>"
      "<p>${JENKINS_BUILD}</p><p>${RUN_TIME}</p><table>${REPORT_ROWS}</table>",
      encoding="utf-8",
  )
  reports = [{
      "platform_dir": "arch_spu_<amd64>",
      "filename": "release.img",
      "old_beta": True,
      "new_beta": False,
      "old_md5": "old&md5",
      "new_md5": "new<md5>",
  }]

  ctx = mailer_ctx(
      executor="张三 <zhangsan@ugreen.com>",
      package_type="固件",
      mode="GA",
      source_url="smb://host/share/repo/image/pkg",
      publish_url="smb://host/share/release/GA/image/pkg",
  )
  html = package_mail._BetaPublishMailer(ctx)._render_success_html(
      reports=reports,
      template_path=str(template),
      run_time="2026-06-22 10:00:00",
  )

  assert "${" not in html
  assert "张三 &lt;zhangsan@ugreen.com&gt;" in html
  assert "固件正式包发布成功" in html
  assert "arch_spu_&lt;amd64&gt;" not in html
  assert "old&amp;md5" in html
  assert "new&lt;md5&gt;" in html
  assert "true -&gt; false" in html
  assert "release.img" in html


def test_render_success_html_links_jenkins_build(monkeypatch):
  monkeypatch.setenv("JOB_NAME", "大网正式包")
  monkeypatch.setenv("BUILD_NUMBER", "58")
  monkeypatch.setenv("BUILD_URL", "https://jenkins.example/job/%E5%A4%A7%E7%BD%91/58/")

  ctx = mailer_ctx(executor="金富强")
  html = package_mail._BetaPublishMailer(ctx)._render_success_html(
      run_time="2026-06-22 10:00:00",
      reports=[],
  )

  assert "Jenkins构建：" in html
  assert "大网正式包" in html
  assert "<a href=\"https://jenkins.example/job/%E5%A4%A7%E7%BD%91/58/\">#58</a>" in html


def test_render_success_html_uses_dash_without_jenkins_build(monkeypatch):
  monkeypatch.delenv("JOB_NAME", raising=False)
  monkeypatch.delenv("BUILD_NUMBER", raising=False)
  monkeypatch.delenv("BUILD_URL", raising=False)

  ctx = mailer_ctx(executor="金富强")
  html = package_mail._BetaPublishMailer(ctx)._render_success_html(
      run_time="2026-06-22 10:00:00",
      reports=[],
  )

  assert "Jenkins构建：-" in html


def test_render_success_html_defaults_run_time_to_machine_timezone(monkeypatch):
  class FakeNow:
    def astimezone(self):
      return real_datetime(2026, 6, 22, 10, 0, 0)

  class FakeDatetime:
    @staticmethod
    def now(tz=None):
      assert tz is None
      return FakeNow()

  monkeypatch.setattr(package_mail, "datetime", FakeDatetime)

  ctx = mailer_ctx(executor="金富强")
  html = package_mail._BetaPublishMailer(ctx)._render_success_html(reports=[])

  assert "执行时间：2026-06-22 10:00:00" in html


def test_render_success_html_uses_beta_package_title():
  ctx = mailer_ctx(
      executor="金富强",
      package_type="套件",
      mode="beta",
      source_url="smb://host/share/repo/service/pkg",
      publish_url="smb://host/share/release/beta/service/pkg",
  )
  html = package_mail._BetaPublishMailer(ctx)._render_success_html(
      run_time="2026-06-22 10:00:00",
      reports=[{
          "platform_dir": "cpu_arch_amd64",
          "filename": "release.upk",
          "old_beta": True,
          "new_beta": True,
          "old_md5": "old",
          "new_md5": "new",
      }],
  )

  assert "套件beta包发布成功" in html
  assert "模式：" not in html
  assert "<th>entry</th>" not in html
  assert "<th>platform_dir</th>" not in html
  assert "<th>beta变化</th>" not in html
  assert "<th>文件名</th>" in html
  assert "cpu_arch_amd64" not in html
  assert "true -&gt; true" in html


def test_send_package_publish_success_mail_uses_package_title(monkeypatch):
  calls = []
  monkeypatch.setattr(package_mail, "send_notify_mail", lambda **kwargs: calls.append(kwargs))

  ctx = mailer_ctx(
      executor="金富强",
      package_type="固件",
      mode="GA",
      source_url="smb://host/share/repo/image/pkg",
      publish_url="smb://host/share/release/GA/image/pkg",
      mail_to=["qa@ugreen.com"],
  )
  package_mail._BetaPublishMailer(ctx).send_success([{
      "filename": "release.img",
      "old_beta": True,
      "new_beta": False,
      "old_md5": "old",
      "new_md5": "new",
  }])

  assert calls[0]["subject"] == "【固件正式包发布成功】"
  assert calls[0]["tos"] == ["qa@ugreen.com"]
