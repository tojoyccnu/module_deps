from ug_test import PROJECT_ROOT, run_ugbt


def test_user_list():
  assert run_ugbt(PROJECT_ROOT, "user list") == 0


def test_user_showgroup():
  assert run_ugbt(PROJECT_ROOT, "user showgroup") == 0
