import pytest

import release_tool


class _Env:
  cmdname = "ugbt"


def test_release_release_fatal(monkeypatch):
  def fake_fatal(message):
    raise RuntimeError(message)

  monkeypatch.setattr(release_tool, "fatal", fake_fatal)
  with pytest.raises(RuntimeError) as excinfo:
    release_tool._cmd_release(_Env())

  message = str(excinfo.value)
  assert "release release" in message
  assert "release 设置为 release" in message
