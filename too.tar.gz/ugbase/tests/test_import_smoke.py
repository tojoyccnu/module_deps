def test_import_ug_cmd_base():
  import ug_cmd_base

  assert hasattr(ug_cmd_base, "CommandTool")
