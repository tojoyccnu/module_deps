import inspect

import pytest

import ug_common


def test_samba_connection_upload_dir_recursive_uses_one_smbclient_session(tmp_path, monkeypatch):
  local_dir = tmp_path / "payload"
  nested_dir = local_dir / "nested"
  nested_dir.mkdir(parents=True)
  (nested_dir / "file.txt").write_text("content")

  conn = ug_common.SambaConnection.__new__(ug_common.SambaConnection)
  conn._SambaConnection__host = "smb-host"
  conn._SambaConnection__cred = "/tmp/smb-cred"

  commands = []
  monkeypatch.setattr(ug_common, "run", lambda command, show_start_log=False: commands.append((command, show_start_log)))

  conn.upload_dir_recursive(str(local_dir), "share", "remote/release")

  assert len(commands) == 1
  command, show_start_log = commands[0]
  assert show_start_log is True
  assert "smbclient //smb-host/share -A /tmp/smb-cred" in command
  assert "recurse on" in command
  assert "prompt off" in command
  assert "cd remote/release" in command
  assert "lcd %s" % str(local_dir) in command
  assert "mput *" in command


def test_samba_connection_download_dir_recursive_uses_one_smbclient_session(tmp_path, monkeypatch):
  local_dir = tmp_path / "download"
  local_dir.mkdir()

  conn = ug_common.SambaConnection.__new__(ug_common.SambaConnection)
  conn._SambaConnection__host = "smb-host"
  conn._SambaConnection__cred = "/tmp/smb-cred"

  commands = []
  def fake_run(command, show_start_log=False, **kwargs):
    if command.startswith("smbclient "):
      commands.append((command, show_start_log))
  monkeypatch.setattr(ug_common, "run", fake_run)

  conn.download_dir_recursive("share", "remote/release", str(local_dir))

  assert len(commands) == 1
  command, show_start_log = commands[0]
  assert show_start_log is True
  assert "smbclient //smb-host/share -A /tmp/smb-cred" in command
  assert "recurse on" in command
  assert "prompt off" in command
  assert "lcd %s" % str(local_dir) in command
  assert "cd remote/release" in command
  assert "mget *" in command


def test_smb_helpers_are_common_exports():
  for name in [
      "SmbLocation",
      "parse_smb_url",
      "require_dir",
  ]:
    assert hasattr(ug_common, name)


def test_samba_connection_has_no_remote_repo_fallback():
  source = inspect.getsource(ug_common.SambaConnection)

  assert "remote_repo" not in source
  assert "/bin/cp" not in source
  assert "rm -rf" not in source


def test_publish_helpers_are_not_common_exports():
  foreach_only_helpers = [
      "unique_run_name",
      "cleanup_work_dir",
      "ensure_path_not_exists",
      "parse_nonnegative_int",
      "retry_with_backoff",
      "effective_jobs",
      "safe_log_name",
      "run_beta_run_once_processes",
      "download_smb_dir_recursive",
      "upload_smb_dir_recursive",
  ]

  for name in foreach_only_helpers:
    assert not hasattr(ug_common, name)


def test_parse_smb_url_accepts_windows_unc_path():
  location = ug_common.parse_smb_url(
      "\\\\172.16.16.6\\产品研发事业中心\\产品经营部\\NAS组\\repo\\firmware\\image\\release_20260728\\1.18.0\\1"
  )

  assert location.host == "172.16.16.6"
  assert location.share == "产品研发事业中心"
  assert location.remote_path == "产品经营部/NAS组/repo/firmware/image/release_20260728/1.18.0/1"


def test_parse_smb_url_accepts_shell_collapsed_unc_path():
  location = ug_common.parse_smb_url(
      "\\172.16.16.6\\产品研发事业中心\\产品经营部\\NAS组\\repo\\firmware\\image\\release_20260624\\1.17.0\\10"
  )

  assert location.host == "172.16.16.6"
  assert location.share == "产品研发事业中心"
  assert location.remote_path == "产品经营部/NAS组/repo/firmware/image/release_20260624/1.17.0/10"


def test_parse_smb_url_rejects_mixed_unc_separators():
  with pytest.raises(ValueError, match="smb-url"):
    ug_common.parse_smb_url("\\\\172.16.16.6/产品研发事业中心\\产品经营部")


def test_parse_smb_url_rejects_unc_without_remote_path():
  with pytest.raises(ValueError, match="remote path"):
    ug_common.parse_smb_url("\\\\172.16.16.6\\产品研发事业中心")
