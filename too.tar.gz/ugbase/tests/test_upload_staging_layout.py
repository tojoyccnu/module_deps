import os
import inspect

import ug_utils


class FakePlatform:
  def get_sorted_str(self):
    return "cpu_arch_amd64__product_series_nasync"


class FakeProject:
  _UgProject__output_format = ug_utils.GS.TGZ

  def source_envs(self):
    pass

  def get_platform(self):
    return FakePlatform()

  def get_install_path(self):
    return "install/platform"

  def get_build_number(self):
    return 42

  def get_name(self):
    return "jobmgr_serv"

  def get_version(self):
    return "1.3.0"

  def _UgProject__get_install_files(self):
    return "package.tgz", "manifest.yaml"


class FakeEnv:
  def __init__(self, repo_root):
    self.repo_root = repo_root

  def get_local_repo_root(self):
    return self.repo_root

  def get_build_env(self):
    return {
        "SMB_HOST": "smb-host",
        "SMB_SHARE_NAME": "share",
        "SMB_REPO": "repo",
    }


class FakeConn:
  def __init__(self):
    self.mkdirs = []
    self.uploads = []
    self.moves = []
    self.deleted_dirs = []
    self.existing_paths = set()

  def exists(self, share_name, path):
    return path in self.existing_paths

  def mkdir(self, share_name, path):
    self.mkdirs.append((share_name, path))

  def upload(self, local_path, share_name, remote_path):
    self.uploads.append((local_path, share_name, remote_path))

  def mv(self, share_name, source, target):
    self.moves.append((share_name, source, target))

  def isdir(self, share_name, path):
    return True

  def ls(self, share_name, path):
    return ["41-older-pipeline.tmp"]

  def delete_dir_recursive(self, share_name, path):
    self.deleted_dirs.append((share_name, path))


def test_platform_upload_writes_directly_to_outer_staging_directory(tmp_path, monkeypatch):
  install_dir = tmp_path / "install" / "platform"
  install_dir.mkdir(parents=True)
  (install_dir / "package.tgz").write_text("package", encoding="utf-8")
  (install_dir / "manifest.yaml").write_text("dirty: false\n", encoding="utf-8")
  monkeypatch.setattr(ug_utils.UgProject, "load", lambda *args, **kwargs: FakeProject())
  conn = FakeConn()
  staging_root = "repo/version-commit.tmp"
  platform_dir = os.path.join(staging_root, "cpu_arch_amd64__product_series_nasync")

  ug_utils.UgProject._UgProject__upload_one_platform_to_staging(
      FakeEnv(str(tmp_path)), conn, "share", staging_root, "cpu_arch_amd64")

  assert conn.mkdirs == [("share", platform_dir)]
  assert [remote for _, _, remote in conn.uploads] == [
      os.path.join(platform_dir, "package.tgz"),
      os.path.join(platform_dir, "manifest.yaml"),
  ]
  assert conn.moves == []


def test_newer_pipeline_upload_does_not_delete_older_pipeline_staging(tmp_path, monkeypatch):
  conn = FakeConn()
  conn.existing_paths.update({
      "repo/jobmgr_serv/release/1.3.0",
      "repo/jobmgr_serv/release/1.3.0/41-older-pipeline.tmp",
  })
  monkeypatch.setattr(ug_utils.UgProject, "load", lambda *args, **kwargs: FakeProject())
  monkeypatch.setattr(ug_utils.UgProject, "get_branch", staticmethod(lambda: "release"))
  monkeypatch.setattr(ug_utils.SambaConnection, "instance", staticmethod(lambda host: conn))
  monkeypatch.setattr(
      ug_utils.UgProject,
      "_UgProject__upload_one_platform_to_staging",
      staticmethod(lambda *args, **kwargs: None))

  ug_utils.UgProject.upload_stage_platform(
      FakeEnv(str(tmp_path)), "cpu_arch_amd64", "current-pipeline")

  assert conn.deleted_dirs == []


def test_upload_paths_do_not_contain_automatic_cross_pipeline_tmp_cleanup():
  assert not hasattr(ug_utils.UgProject, "cleanup_remote_stale_upload_tmp")
  for method in (
      ug_utils.UgProject.upload_stage_platform,
      ug_utils.UgProject.upload_finalize,
      ug_utils.UgProject.upload_all,
  ):
    assert "cleanup_remote_stale_upload_tmp" not in inspect.getsource(method)
