import os
import sys
import types

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))

if "smb.SMBConnection" not in sys.modules:
  smb_mod = types.ModuleType("smb")
  smb_conn_mod = types.ModuleType("smb.SMBConnection")

  class SMBConnection:
    pass

  smb_conn_mod.SMBConnection = SMBConnection
  sys.modules["smb"] = smb_mod
  sys.modules["smb.SMBConnection"] = smb_conn_mod

import ug_utils


def test_go_mod_git_rev_keeps_pseudo_version_commit():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents/llmorganizer",
          "v0.0.0-20260508093311-0a6626429ffc",
      )
      == "0a6626429ffc"
  )


def test_go_mod_git_rev_keeps_pseudo_version_with_prerelease_commit():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/third/fsnotify",
          "v1.0.1-0.20240914112828-a79f1e1de9aa",
      )
      == "a79f1e1de9aa"
  )


def test_go_mod_git_rev_prefixes_gitlab_submodule_semver_tag():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents/llmorganizer",
          "v1.0.3",
      )
      == "llmorganizer/v1.0.3"
  )


def test_go_mod_git_rev_keeps_root_module_semver_tag():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents",
          "v1.0.3",
      )
      == "v1.0.3"
  )


def test_go_mod_git_rev_prefers_existing_root_tag():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents/llmorganizer",
          "v1.0.3",
          lambda rev: rev == "v1.0.3",
      )
      == "v1.0.3"
  )


def test_go_mod_git_rev_falls_back_to_existing_submodule_tag():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents/llmorganizer",
          "v1.0.3",
          lambda rev: rev == "llmorganizer/v1.0.3",
      )
      == "llmorganizer/v1.0.3"
  )


def test_go_mod_git_rev_handles_major_version_submodule_suffix():
  assert (
      ug_utils.go_module_version_to_git_rev(
          "gitlab.ugnas.com/library/go-agents/llmorganizer/v2",
          "v2.0.0",
          lambda rev: rev == "llmorganizer/v2.0.0",
      )
      == "llmorganizer/v2.0.0"
  )


def test_request_for_testing_manifest_files_requires_existing_dir():
  with pytest.raises(SystemExit):
    ug_utils.find_request_for_testing_manifest_files("/tmp/not-exists-for-request-mail")


def test_request_for_testing_manifest_files_requires_manifest(tmp_path):
  with pytest.raises(SystemExit):
    ug_utils.find_request_for_testing_manifest_files(str(tmp_path))


def test_request_for_testing_manifest_files_ignores_tmp_paths(tmp_path):
  platform_dir = tmp_path / "platform"
  tmp_platform_dir = tmp_path / "platform.tmp"
  platform_dir.mkdir()
  tmp_platform_dir.mkdir()
  (platform_dir / "ok.manifest.yaml").write_text("")
  (tmp_platform_dir / "skip.manifest.yaml").write_text("")

  assert (
      ug_utils.find_request_for_testing_manifest_files(str(tmp_path))
      == ["platform/ok.manifest.yaml"]
  )


def test_request_for_testing_manifest_files_allows_tmp_in_cache_root(tmp_path):
  cache_root = tmp_path / ".ugreen.tmp-root"
  platform_dir = cache_root / "platform"
  platform_dir.mkdir(parents=True)
  (platform_dir / "ok.manifest.yaml").write_text("")

  assert (
      ug_utils.find_request_for_testing_manifest_files(str(cache_root))
      == ["platform/ok.manifest.yaml"]
  )
