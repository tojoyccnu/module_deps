from types import SimpleNamespace

import pytest
import requests

from ug_common import load_yaml, read_file
from ug_test import PROJECT_ROOT, run_ugbt
import update_users_tool


class FakeResponse(object):
  def __init__(self, payload, status_code=200):
    self.payload = payload
    self.status_code = status_code

  def raise_for_status(self):
    if self.status_code >= 400:
      error = requests.HTTPError("status=%s" % self.status_code)
      error.response = self
      raise error

  def json(self):
    return self.payload


class FakeSession(object):
  def __init__(self, employees):
    self.employees = employees
    self.login_calls = []
    self.query_calls = []

  def post(self, url, headers, data, timeout):
    self.login_calls.append({"url": url, "headers": headers, "data": data, "timeout": timeout})
    return FakeResponse({"success": True, "data": {"accessToken": "test-token"}})

  def get(self, url, params, headers, timeout):
    self.query_calls.append({"url": url, "params": params, "headers": headers, "timeout": timeout})
    return FakeResponse({"success": True, "data": self.employees[params["employeeCode"]]})


def make_tool(tmp_path, monkeypatch, users_content, employees, groups_content="system:\n- alpha\n- beta\n"):
  dev_dir = tmp_path / "dev"
  dev_dir.mkdir()
  users_file = dev_dir / "users.yaml"
  users_file.write_text(users_content, encoding="utf-8")
  groups_file = dev_dir / "groups.yaml"
  groups_file.write_text(groups_content, encoding="utf-8")
  session = FakeSession(employees)
  monkeypatch.setattr(update_users_tool.requests, "Session", lambda: session)
  monkeypatch.setenv("HOME", str(tmp_path))
  monkeypatch.setenv("UGREEN_IT_APP_KEY", "test-app-key")
  monkeypatch.setenv("UGREEN_IT_APP_SECRET", "test-app-secret")
  monkeypatch.setenv("UGREEN_IT_HOST_URL", "https://employee.example.com")
  env = SimpleNamespace(root=str(tmp_path), args=[], opts={}, opts_multiple={})
  tool = update_users_tool.Tool(env)
  tool.build_index()
  return tool, users_file, groups_file, session


USERS_YAML = """alpha:
  name: Alpha
  eid: 1001
  did: 001289
  gitlab: alpha
beta:
  name: Beta
  eid: 1002
  gitlab: beta
"""


def test_update_users_refreshes_all_dids_as_strings(tmp_path, monkeypatch):
  tool, users_file, groups_file, session = make_tool(tmp_path, monkeypatch, USERS_YAML, {
      "1001": {"dtUserid": "001289"},
      "1002": {"dtUserid": 987654},
  })

  assert tool.main() == 0

  users = load_yaml(read_file(str(users_file)))
  assert users["alpha"]["did"] == "001289"
  assert users["beta"]["did"] == "987654"
  assert type(users["alpha"]["did"]).__name__ == "str"
  assert type(users["beta"]["did"]).__name__ == "str"
  assert load_yaml(read_file(str(groups_file))) == {"system": ["alpha", "beta"]}
  assert len(session.login_calls) == 1
  assert [item["params"]["employeeCode"] for item in session.query_calls] == ["1001", "1002"]


def test_update_users_failure_keeps_original_file(tmp_path, monkeypatch):
  tool, users_file, groups_file, _ = make_tool(tmp_path, monkeypatch, USERS_YAML, {
      "1001": {"dtUserid": "new-alpha"},
      "1002": {"dtUserid": None},
  })
  original_users = read_file(str(users_file))
  original_groups = read_file(str(groups_file))

  with pytest.raises(SystemExit):
    tool.main()

  assert read_file(str(users_file)) == original_users
  assert read_file(str(groups_file)) == original_groups


def test_update_users_removes_departed_user_and_group_membership(tmp_path, monkeypatch):
  tool, users_file, groups_file, _ = make_tool(tmp_path, monkeypatch, USERS_YAML, {
      "1001": {"dtUserid": "001289"},
      "1002": None,
  }, groups_content="system:\n- alpha\n- beta\nother:\n- beta\n")

  assert tool.main() == 0

  users = load_yaml(read_file(str(users_file)))
  groups = load_yaml(read_file(str(groups_file)))
  assert list(users) == ["alpha"]
  assert groups == {"system": ["alpha"], "other": []}


def test_update_users_command_is_discoverable():
  assert run_ugbt(PROJECT_ROOT, "update_users -h") == 1
