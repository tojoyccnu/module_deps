import hashlib
import json
import os

import pytest
import yaml

import beta_once_tool as firmware_publish_tool


SMB_URL = "smb://172.16.16.6/产品研发事业中心/产品经营部/NAS组/repo/firmware/image/release_20260624/1.17.0/57"
PLATFORM_DIR = "arch_spu_test"
RELEASE_STEM = "release_20260624-firmware_image-1.17.0.57-test"


class FakeEnv:
  def get_build_vars(self):
    return {
        "arch_spu": ["test"],
    }


def worker_ctx(platform_dir, mode, tasks_root, report_root, remote_tmp_root="tmp_remote", tools_dir="/tools",
               sign_retry_interval="10", sign_max_attempts="0"):
  class Ctx:
    pass

  ctx = Ctx()
  ctx.env = FakeEnv()
  ctx.smb_url = SMB_URL
  ctx.platform_dir = platform_dir
  ctx.mode = mode
  ctx.tasks_root = str(tasks_root)
  ctx.report_root = str(report_root)
  ctx.remote_tmp_root = remote_tmp_root
  ctx.tools_dir = tools_dir
  ctx.sign_retry_interval = sign_retry_interval
  ctx.sign_max_attempts = sign_max_attempts
  return ctx


def md5_file(path):
  digest = hashlib.md5()
  with open(path, "rb") as fp:
    for chunk in iter(lambda: fp.read(4096), b""):
      digest.update(chunk)
  return digest.hexdigest()


def create_signed_firmware_fixture(root, platform="arch_spu_test", beta=False, img_bytes=None):
  package_dir = root / platform
  package_dir.mkdir(parents=True)
  stem = RELEASE_STEM
  img = package_dir / (stem + ".img")
  img.write_bytes(img_bytes or (b"UGREEN-OTA-V2-FORMAT" + b"signed-img"))
  product = package_dir / (stem + ".product.json")
  product_data = {
      "固件": {
          "是否beta": beta,
          "固件MD5值": md5_file(img),
          "升级包大小": "%.2f" % (img.stat().st_size / 1000.0),
      },
      "firmware": {
          "isBeta": beta,
          "md5": md5_file(img),
          "size": img.stat().st_size,
      },
  }
  product.write_text(json.dumps(product_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
  manifest = package_dir / (stem + ".manifest.yaml")
  manifest.write_text(yaml.safe_dump({
      "beta": beta,
      "md5": {
          img.name: md5_file(img),
          product.name: md5_file(product),
      },
  }, allow_unicode=True), encoding="utf-8")
  return package_dir


def test_firmware_worker_downloads_only_expected_files(tmp_path, monkeypatch):
  downloads = []

  class FakeConn:
    def __init__(self, host):
      assert host == "172.16.16.6"

    def connect(self):
      return None

    def download_dir_recursive(self, share, remote_path, local_path):
      raise AssertionError("firmware download should not copy whole SMB directory")

    def download(self, share, remote_path, local_path):
      downloads.append((remote_path, os.path.basename(local_path)))
      with open(local_path, "wb") as fp:
        fp.write(b"downloaded")

  monkeypatch.setattr(firmware_publish_tool, "SambaConnection", FakeConn)

  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))
  worker._download()

  remote_platform_dir = "产品经营部/NAS组/repo/firmware/image/release_20260624/1.17.0/57/%s" % PLATFORM_DIR
  assert downloads == [
      (remote_platform_dir + "/" + RELEASE_STEM + ".img", RELEASE_STEM + ".img"),
      (remote_platform_dir + "/" + RELEASE_STEM + ".product.json", RELEASE_STEM + ".product.json"),
      (remote_platform_dir + "/" + RELEASE_STEM + ".manifest.yaml", RELEASE_STEM + ".manifest.yaml"),
  ]


def test_run_sign_command_logs_failure_and_uses_run_retry(monkeypatch, tmp_path):
  calls = []

  def fake_run(cmd, assert_ok=True, show_log=True, retry_interval=None, retry_times=None):
    calls.append((cmd, assert_ok, show_log, retry_interval, retry_times))
    return 7

  monkeypatch.setattr(firmware_publish_tool, "run", fake_run)

  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tmp_path / "tasks",
      tmp_path / "reports",
  ))
  worker.sign_retry_interval = 3
  worker.sign_max_attempts = 2

  failure = worker._run_sign_command(["sign tool", "-file", "image path"])

  assert calls == [("'sign tool' -file 'image path'", False, True, 3, 2)]
  assert failure == "command failed(7)"


def test_verify_firmware_package_reports_verified_ga_result(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tasks_root,
      tmp_path / "reports",
  ))
  create_signed_firmware_fixture(tasks_root / "arch_spu_test", platform="work", beta=False)
  monkeypatch.setattr(firmware_publish_tool._FirmwareWorker, "_verify_img_v2_signature",
                      lambda self, img: None)

  summary = worker._verify()

  assert summary["sign"] == "v2"
  assert summary["beta"] is False
  assert summary["img"].endswith(".img")


def test_verify_firmware_package_uses_ugpkgsign_v2_verify(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  tools_dir = tmp_path / "tools"
  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tasks_root,
      tmp_path / "reports",
      tools_dir=str(tools_dir),
  ))
  create_signed_firmware_fixture(
      tasks_root / "arch_spu_test",
      platform="work",
      beta=False,
      img_bytes=b"./" + b"\0" * 30 + b"signed-img",
  )
  tools_dir.mkdir()
  signer = tools_dir / "ugpkgsign"
  signer.write_text("#!/bin/sh\n", encoding="utf-8")
  verify_pub = tools_dir / "ugreenRoot.pub"
  verify_pub.write_text("pub\n", encoding="utf-8")
  calls = []

  def fake_run_sign_command(cmd):
    calls.append(cmd)
    return ""

  monkeypatch.setattr(firmware_publish_tool._FirmwareWorker, "_run_sign_command", staticmethod(fake_run_sign_command))

  summary = worker._verify()

  img_path = str(tasks_root / "arch_spu_test" / "work" / (RELEASE_STEM + ".img"))
  assert calls == [
      [str(signer), "-file", img_path, "-isVerify", "-signVersion", "2", "-verifyPub", str(verify_pub)],
  ]
  assert summary["sign"] == "v2"


def test_sign_img_v2_signs_and_verifies_package(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  tools_dir = tmp_path / "tools"
  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tasks_root,
      tmp_path / "reports",
      tools_dir=str(tools_dir),
  ))
  package_dir = tasks_root / "arch_spu_test" / "work"
  package_dir.mkdir(parents=True)
  stem = RELEASE_STEM
  (package_dir / (stem + ".img")).write_bytes(b"img")
  (package_dir / (stem + ".product.json")).write_text("{}\n", encoding="utf-8")
  (package_dir / (stem + ".manifest.yaml")).write_text("md5: {}\nbeta: true\n", encoding="utf-8")
  tools_dir.mkdir()
  signer = tools_dir / "ugpkgsign"
  signer.write_text("#!/bin/sh\n", encoding="utf-8")
  verify_pub = tools_dir / "ugreenRoot.pub"
  verify_pub.write_text("pub\n", encoding="utf-8")
  monkeypatch.setenv("UGBT_FIRMWARE_SIGN_API", "https://sign")
  monkeypatch.setenv("UGBT_FIRMWARE_SIGN_KEY", "encrypted-config-key")
  calls = []

  def fake_run_sign_command(cmd):
    calls.append(cmd)
    if len(calls) == 1:
      root = cmd[cmd.index("-root") + 1]
      config_path = os.path.join(root, "config.json")
      with open(config_path, encoding="utf-8") as fp:
        config = json.load(fp)
      assert config == {
          "node": "https://sign",
          "key": "encrypted-config-key",
      }
      assert sorted(os.listdir(root)) == ["config.json"]
      assert root != str(tools_dir)
    return ""

  monkeypatch.setattr(firmware_publish_tool._FirmwareWorker, "_run_sign_command", staticmethod(fake_run_sign_command))

  worker._sign_img_v2()

  img_path = str(package_dir / (stem + ".img"))
  assert calls == [
      [str(signer), "-file", img_path, "-signVersion", "2", "-root", calls[0][calls[0].index("-root") + 1]],
      [str(signer), "-file", img_path, "-isVerify", "-signVersion", "2", "-verifyPub", str(verify_pub)],
  ]
  assert not os.path.exists(calls[0][calls[0].index("-root") + 1])
  assert (package_dir / (stem + ".img")).read_bytes() == b"img"


def test_sign_img_v2_fails_when_sign_command_fails(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  tools_dir = tmp_path / "tools"
  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tasks_root,
      tmp_path / "reports",
      tools_dir=str(tools_dir),
  ))
  package_dir = tasks_root / "arch_spu_test" / "work"
  package_dir.mkdir(parents=True)
  stem = RELEASE_STEM
  img = package_dir / (stem + ".img")
  img.write_bytes(b"img")
  (package_dir / (stem + ".product.json")).write_text("{}\n", encoding="utf-8")
  (package_dir / (stem + ".manifest.yaml")).write_text("md5: {}\nbeta: true\n", encoding="utf-8")
  tools_dir.mkdir()
  (tools_dir / "ugpkgsign").write_text("#!/bin/sh\n", encoding="utf-8")
  (tools_dir / "ugreenRoot.pub").write_text("pub\n", encoding="utf-8")
  monkeypatch.setenv("UGBT_FIRMWARE_SIGN_API", "https://sign")
  monkeypatch.setenv("UGBT_FIRMWARE_SIGN_KEY", "encrypted-config-key")
  attempts = []

  def fake_run_sign_command(cmd):
    attempts.append(cmd)
    return "kms failure"

  monkeypatch.setattr(firmware_publish_tool._FirmwareWorker, "_run_sign_command", staticmethod(fake_run_sign_command))

  with pytest.raises(SystemExit):
    worker._sign_img_v2()

  assert len(attempts) == 1
  assert img.read_bytes() == b"img"


def test_sign_img_v2_fails_without_jenkins_secret_env(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  tools_dir = tmp_path / "tools"
  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "ga",
      tasks_root,
      tmp_path / "reports",
      tools_dir=str(tools_dir),
  ))
  package_dir = tasks_root / "arch_spu_test" / "work"
  package_dir.mkdir(parents=True)
  stem = RELEASE_STEM
  (package_dir / (stem + ".img")).write_bytes(b"img")
  (package_dir / (stem + ".product.json")).write_text("{}\n", encoding="utf-8")
  (package_dir / (stem + ".manifest.yaml")).write_text("md5: {}\nbeta: true\n", encoding="utf-8")
  tools_dir.mkdir()
  (tools_dir / "ugpkgsign").write_text("#!/bin/sh\n", encoding="utf-8")
  (tools_dir / "ugreenRoot.pub").write_text("pub\n", encoding="utf-8")
  monkeypatch.delenv("UGBT_FIRMWARE_SIGN_API", raising=False)
  monkeypatch.delenv("UGBT_FIRMWARE_SIGN_KEY", raising=False)

  with pytest.raises(SystemExit):
    worker._sign_img_v2()


def test_firmware_worker_process_returns_img_md5_report_for_beta_mode(tmp_path, monkeypatch):
  tasks_root = tmp_path / "tasks"
  package_dir = create_signed_firmware_fixture(tasks_root / "arch_spu_test", platform="work", beta=True)
  source_img = next(path for path in package_dir.iterdir() if path.name.endswith(".img"))
  old_md5 = md5_file(source_img)

  def fake_sign_img_v2(self):
    files = self._package_files()
    with open(files["img"], "ab") as fp:
      fp.write(b"-signed-again")

  monkeypatch.setattr(firmware_publish_tool._FirmwareWorker, "_sign_img_v2", fake_sign_img_v2)

  worker = firmware_publish_tool._FirmwareWorker(worker_ctx(
      PLATFORM_DIR,
      "beta",
      tasks_root,
      tmp_path / "reports",
  ))
  report = worker._process()

  target_img = tasks_root / "arch_spu_test" / "work" / source_img.name
  assert report == {
      "filename": source_img.name,
      "old_beta": True,
      "new_beta": True,
      "old_md5": old_md5,
      "new_md5": md5_file(target_img),
  }
  assert report["old_md5"] != report["new_md5"]
