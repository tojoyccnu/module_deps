import upload_tool


class _Env:
  home = "/tmp"
  opts = {}
  opts_multiple = {}
  args = []


class _Platform:
  def __init__(self, name):
    self.name = name


class _Project:
  def __init__(self):
    self.platform = _Platform("default")
    self.all_platforms = [_Platform("all-a"), _Platform("all-b")]

  def check_remote(self):
    pass

  def get_platform(self):
    return self.platform

  def get_all_platforms(self):
    return self.all_platforms


class _UgProject:
  loaded_build_vars = None
  uploaded_platforms = None

  @staticmethod
  def load(env, build_vars):
    _UgProject.loaded_build_vars = build_vars
    return _Project()

  @staticmethod
  def upload_all(env, platforms):
    _UgProject.uploaded_platforms = platforms


def _run_upload(monkeypatch, opts, opts_multiple):
  _UgProject.loaded_build_vars = None
  _UgProject.uploaded_platforms = None
  monkeypatch.setattr(upload_tool, "UgProject", _UgProject)
  monkeypatch.chdir("/tmp")
  env = _Env()
  env.opts = opts
  env.opts_multiple = opts_multiple
  tool = upload_tool.Tool(env)
  tool.build_index()

  assert tool.main() == 0
  return _UgProject.loaded_build_vars, [p.name for p in _UgProject.uploaded_platforms]


def test_upload_without_build_var_and_platform_uses_all_platforms(monkeypatch):
  build_vars, platforms = _run_upload(monkeypatch, {}, {})

  assert build_vars == [""]
  assert platforms == ["all-a", "all-b"]


def test_upload_with_build_var_and_without_platform_uses_all_platforms(monkeypatch):
  build_vars, platforms = _run_upload(
      monkeypatch, {"--build-var": "cpu_arch=amd64"}, {"--build-var": ["cpu_arch=amd64"]})

  assert build_vars == ["cpu_arch=amd64"]
  assert platforms == ["all-a", "all-b"]
