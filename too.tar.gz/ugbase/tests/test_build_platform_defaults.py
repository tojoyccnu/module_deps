import ug_build_platform
from ug_build_platform import BuildPlatform


class _Env:
  def get_build_vars(self):
    return {
        "build_type": ["release", "debug"],
        "cpu_arch": ["amd64", "arm64"],
        "arch_spu": ["intel", "rk3588", "rk3576"],
        "kernel": ["6.12.30+", "6.1.27", "6.18"],
        "product_series": ["nasync", "homeagent"],
    }

  def get_build_env(self):
    return {
        "DEFAULT_BUILD_VARS": {
            "amd64": {
                "cpu_arch": "amd64",
                "arch_spu": "intel",
                "kernel": "6.12.30+",
                "build_type": "release",
                "product_series": "nasync",
            },
            "arm64": {
                "cpu_arch": "arm64",
                "arch_spu": "rk3588",
                "kernel": "6.1.27",
                "build_type": "release",
                "product_series": "nasync",
            },
        },
    }


class _CpuOnlyEnv(_Env):
  def get_build_vars(self):
    return {
        "cpu_arch": ["amd64", "arm64"],
    }


PLATFORM = ["cpu_arch", "arch_spu", "kernel", "build_type", "product_series"]


def test_build_platform_uses_amd64_defaults(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "x86_64")

  platform = BuildPlatform(_Env(), [], PLATFORM)

  assert platform.get("cpu_arch") == "amd64"
  assert platform.get("arch_spu") == "intel"
  assert platform.get("kernel") == "6.12.30+"
  assert platform.get("build_type") == "release"
  assert platform.get("product_series") == "nasync"


def test_build_platform_uses_arm64_defaults(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "aarch64")

  platform = BuildPlatform(_Env(), [], PLATFORM)

  assert platform.get("cpu_arch") == "arm64"
  assert platform.get("arch_spu") == "rk3588"
  assert platform.get("kernel") == "6.1.27"
  assert platform.get("build_type") == "release"
  assert platform.get("product_series") == "nasync"


def test_build_platform_explicit_cpu_arch_does_not_change_current_defaults(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "x86_64")

  platform = BuildPlatform(_Env(), ["cpu_arch=arm64"], PLATFORM)

  assert platform.get("cpu_arch") == "arm64"
  assert platform.get("arch_spu") == "intel"
  assert platform.get("kernel") == "6.12.30+"


def test_build_platform_explicit_value_overrides_default(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "aarch64")

  platform = BuildPlatform(_Env(), ["arch_spu=rk3576"], PLATFORM)

  assert platform.get("cpu_arch") == "arm64"
  assert platform.get("arch_spu") == "rk3576"
  assert platform.get("kernel") == "6.1.27"


def test_build_platform_does_not_add_missing_project_dimensions(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "x86_64")

  platform = BuildPlatform(_CpuOnlyEnv(), [], ["cpu_arch"])

  assert platform.keys() == ["cpu_arch"]
  assert platform.get("cpu_arch") == "amd64"
  assert not platform.has("arch_spu")


def test_current_cpu_arch_only_initializes_once(monkeypatch):
  calls = []

  def fake_get_machine():
    calls.append(1)
    return "x86_64"

  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", fake_get_machine)

  assert ug_build_platform.get_current_cpu_arch() == "amd64"
  assert ug_build_platform.get_current_cpu_arch() == "amd64"
  assert len(calls) == 1


def test_unknown_current_cpu_arch_fails(monkeypatch):
  monkeypatch.setattr(ug_build_platform, "__current_cpu_arch", None)
  monkeypatch.setattr(ug_build_platform, "get_machine", lambda: "mips64")
  monkeypatch.setattr(ug_build_platform, "fatal", lambda message: (_ for _ in ()).throw(RuntimeError(message)))

  try:
    ug_build_platform.get_current_cpu_arch()
    assert False
  except RuntimeError as e:
    assert "Unknown CPU architecture: mips64" in str(e)
