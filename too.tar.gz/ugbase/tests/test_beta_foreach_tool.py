import pytest

import beta_foreach_tool
import beta_once_tool
from ug_common import join_cmd
from ug_utils import beta_default_tools_dir, beta_release_branch_index, beta_resolve_package_type


FIRMWARE_URL = "smb://host/share/root/firmware/image/release/1/2"
SUITE_URL = "smb://host/share/root/firmware/service/app/release/1/2"


def test_beta_default_tools_dir_uses_home_tools(tmp_path, monkeypatch):
  assert beta_default_tools_dir(str(tmp_path)) == str(tmp_path / "tools")


def test_beta_default_tools_dir_ignores_env_override(tmp_path, monkeypatch):
  monkeypatch.setenv("UGBT_TOOLS_DIR", "~/custom-tools")

  assert beta_default_tools_dir(str(tmp_path)) == str(tmp_path / "tools")


def test_beta_resolve_package_type_uses_smb_path_segments():
  assert beta_resolve_package_type(FIRMWARE_URL) == "firmware"
  assert beta_resolve_package_type(SUITE_URL) == "suite"


def test_beta_release_branch_index_only_accepts_third_last_path_segment():
  parts = [
      "repo",
      "firmware",
      "release_helper20260728",
      "lucky",
      "release_a35_20260728",
      "1.3.0",
      "10",
      "unexpected",
  ]

  assert beta_release_branch_index(parts) == -1


def test_beta_foreach_tool_registers_foreach_options(tmp_path):
  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {}
    opts_multiple = {}

  tool = beta_foreach_tool.Tool(FakeEnv())

  names = [op[1] for op in tool.opdesc if op[1] != "help"]

  assert tool.cmd == "beta_run_foreach"
  assert names == ["smb-url"]


def test_beta_once_tool_registers_only_runtime_worker_options(tmp_path):
  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {}
    opts_multiple = {}

  tool = beta_once_tool.Tool(FakeEnv())

  names = [op[1] for op in tool.opdesc if op[1] != "help"]

  assert names == [
      "smb-url",
      "type",
      "mode",
      "platform-dir",
      "remote-tmp-root",
  ]


def test_beta_foreach_tool_main_runs_foreach_runner(tmp_path, monkeypatch):
  calls = []
  target_command = ["ugbt", "beta_run_once", "--platform-dir", "{}"]

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {
        "--smb-url": FIRMWARE_URL,
    }
    opts_multiple = {}
    args = target_command

  def fake_runner_execute(self):
    calls.append(self.ctx)
    return []

  monkeypatch.setattr(beta_foreach_tool._BetaForeachRunner, "execute", fake_runner_execute)

  tool = beta_foreach_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  assert len(calls) == 1
  assert calls[0].smb_url == FIRMWARE_URL
  assert calls[0].target_command_args == target_command


def test_run_command_processes_uses_run_with_worker_log(tmp_path, monkeypatch):
  calls = []
  parallel_calls = []

  def fake_run(cmd, assert_ok=True, show_log=True):
    calls.append((cmd, assert_ok, show_log))
    return 0

  def fake_parallel_run(inputs, count, func):
    parallel_calls.append((inputs, count))
    return [func(item) for item in inputs]

  monkeypatch.setattr(beta_foreach_tool, "run", fake_run)
  monkeypatch.setattr(beta_foreach_tool, "parallel_run", fake_parallel_run)

  beta_foreach_tool._run_command_processes(
      ["arch/spu a"],
      [["ugbt", "beta_run_once", "--platform-dir", "arch/spu a"]],
      1,
      str(tmp_path),
  )

  assert parallel_calls == [(
      [("arch/spu a", ["ugbt", "beta_run_once", "--platform-dir", "arch/spu a"])],
      1,
  )]
  log_path = str(tmp_path / "arch_spu_a.log")
  assert calls == [(
      "%s > %s 2>&1" % (
          join_cmd(["ugbt", "beta_run_once", "--platform-dir", "arch/spu a"]),
          join_cmd([log_path]),
      ),
      False,
      False,
  )]


def test_run_command_processes_fails_when_any_worker_fails(tmp_path, monkeypatch):
  def fake_run(cmd, assert_ok=True, show_log=True):
    if "--platform-dir arch_spu_b" in cmd:
      return 7
    return 0

  monkeypatch.setattr(beta_foreach_tool, "run", fake_run)

  with pytest.raises(SystemExit):
    beta_foreach_tool._run_command_processes(
        ["arch_spu_a", "arch_spu_b"],
        [
            ["ugbt", "beta_run_once", "--platform-dir", "arch_spu_a"],
            ["ugbt", "beta_run_once", "--platform-dir", "arch_spu_b"],
        ],
        2,
        str(tmp_path),
    )


def test_beta_once_tool_main_runs_firmware_worker_with_default_task_roots(tmp_path, monkeypatch):
  calls = []
  monkeypatch.chdir(tmp_path)

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {
        "--smb-url": FIRMWARE_URL,
        "--type": "firmware",
        "--mode": "ga",
        "--platform-dir": "arch_spu_a",
        "--remote-tmp-root": "release/tmp",
    }
    opts_multiple = {}

  class FakeFirmwareWorker:
    def __init__(self, *args, **kwargs):
      calls.append((args, kwargs))

    def run(self):
      calls.append("run")

  monkeypatch.setattr(beta_once_tool, "_FirmwareWorker", FakeFirmwareWorker)

  tool = beta_once_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  ctx = calls[0][0][0]
  assert ctx.smb_url == FIRMWARE_URL
  assert ctx.platform_dir == "arch_spu_a"
  assert ctx.mode == "ga"
  assert ctx.tasks_root == str(tmp_path / "tasks")
  assert ctx.report_root == str(tmp_path / "reports")
  assert ctx.remote_tmp_root == "release/tmp"
  assert ctx.tools_dir == str(tmp_path / "home" / "tools")
  assert calls == [
      ((ctx,), {}),
      "run",
  ]


def test_beta_once_tool_main_runs_suite_worker_with_sign_args(tmp_path, monkeypatch):
  calls = []
  monkeypatch.chdir(tmp_path)

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {
        "--smb-url": SUITE_URL,
        "--type": "suite",
        "--mode": "ga",
        "--platform-dir": "cpu_arch_a",
        "--remote-tmp-root": "release/tmp",
    }
    opts_multiple = {}

  class FakeSuiteWorker:
    def __init__(self, *args, **kwargs):
      calls.append((args, kwargs))

    def run(self):
      calls.append("run")

  monkeypatch.setattr(beta_once_tool, "_SuiteWorker", FakeSuiteWorker)

  tool = beta_once_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  ctx = calls[0][0][0]
  assert ctx.smb_url == SUITE_URL
  assert ctx.platform_dir == "cpu_arch_a"
  assert ctx.mode == "ga"
  assert ctx.tasks_root == str(tmp_path / "tasks")
  assert ctx.report_root == str(tmp_path / "reports")
  assert ctx.remote_tmp_root == "release/tmp"
  assert ctx.tools_dir == str(tmp_path / "home" / "tools")
  assert calls == [
      ((ctx,), {}),
      "run",
  ]


def test_beta_once_tool_requires_explicit_type(tmp_path):
  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {
        "--smb-url": FIRMWARE_URL,
        "--type": "auto",
        "--mode": "ga",
        "--platform-dir": "arch_spu_a",
        "--remote-tmp-root": "release/tmp",
    }
    opts_multiple = {}

  tool = beta_once_tool.Tool(FakeEnv())
  tool.build_index()

  with pytest.raises(SystemExit):
    tool.main()
