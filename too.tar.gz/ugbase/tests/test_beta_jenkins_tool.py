import pytest

import beta_jenkins_tool
from ug_common import fatal


SMB_URL = "smb://host/share/root/repo/firmware/image/release_20260624/1/2"
SUITE_URL = "smb://host/share/root/repo/firmware/service/docker_serv/release_20260624/1.17.0/59"
DOCKERAPP_URL = "smb://host/share/root/repo/firmware/dockerapp/lucky/release_20260728/1.3.0/10"
DOCKERAPP_UNC = (
    r"\\172.16.16.6\产品研发事业中心\产品经营部\NAS组\repo\firmware"
    r"\dockerapp\lucky\release_20260728\1.3.0\10"
)


EXPECTED_TEAM_ADDRS = [
    "NAS-测试组 <nas-test@ugreen.com>",
    "NAS-软件开发组 <nas-develop@ugreen.com>",
    "NAS-PRO-产品小组 <nas-pro-product@ugreen.com>",
    "NAS-UI设计组 <nas-ui@ugreen.com>",
    "NAS-产品运营组 <nas-cpyy@ugreen.com>",
    "NAS-音视频组 <nas-media@ugreen.com>",
    "NAS-系统安全组 <nas-security@ugreen.com>",
    "NAS-系统 <nas-os@ugreen.com>",
    "NAS-云端组 <nas-cloud@ugreen.com>",
    "NAS-软件项目组 <nas-project@ugreen.com>",
    "NAS-AI <nas-ai@ugreen.com>",
    "NAS-DQE组 <pz-nasdqe@ugreen.com>",
    "NAS-硬件开发 <nas-hwyf@ugreen.com>",
]


def test_tool_main_builds_context_and_runs_publisher_with_defaults(tmp_path, monkeypatch):
  calls = []
  home_dir = tmp_path / "home"
  home_dir.mkdir()

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(home_dir)
    opts = {
        "--smb-url": SMB_URL,
        "--mode": "beta",
    }
    opts_multiple = {}

  def fake_publisher_run(self):
    calls.append(self.ctx)
    return "ok"

  monkeypatch.setattr(beta_jenkins_tool._BetaPublisher, "run", fake_publisher_run)

  tool = beta_jenkins_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  assert len(calls) == 1
  assert calls[0] is tool.ctx
  assert tool.ctx.smb_url == SMB_URL
  assert tool.ctx.mode == "beta"
  assert tool.ctx.mail_to == EXPECTED_TEAM_ADDRS


def test_tool_main_uses_hard_coded_team_recipients_without_executor_override(tmp_path, monkeypatch):
  calls = []
  home_dir = tmp_path / "home"
  home_dir.mkdir()

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(home_dir)
    opts = {
        "--smb-url": SMB_URL,
        "--mode": "beta",
    }
    opts_multiple = {}

  def fake_publisher_run(self):
    calls.append(self.ctx)
    return "ok"

  monkeypatch.setattr(beta_jenkins_tool._BetaPublisher, "run", fake_publisher_run)

  tool = beta_jenkins_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  assert calls[0].mail_to == EXPECTED_TEAM_ADDRS
  assert calls[0].executor == ""


def test_tool_registers_only_smb_url_and_mode(tmp_path):
  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(tmp_path / "home")
    opts = {}
    opts_multiple = {}

  tool = beta_jenkins_tool.Tool(FakeEnv())

  names = [op[1] for op in tool.opdesc if op[1] != "help"]

  assert tool.cmd == "beta_run_jenkins"
  assert names == ["smb-url", "mode"]
  assert not hasattr(tool, "_tmp_root")


def test_context_uses_workspace_root_when_started_from_workspace(tmp_path, monkeypatch):
  monkeypatch.chdir(tmp_path)
  (tmp_path / "ugbase").mkdir()
  (tmp_path / "ugbase" / "ugbt").write_text("", encoding="utf-8")

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), SMB_URL, "ga")

  assert ctx.workspace_root == str(tmp_path)
  assert ctx.ugbt_bin == str(tmp_path / "ugbase" / "ugbt")
  assert ctx.run_work_root.startswith(str(tmp_path / "ugbt" / "beta_run_jenkins"))


def test_context_uses_parent_workspace_when_started_from_ugbase_dir(tmp_path, monkeypatch):
  ugbase_dir = tmp_path / "ugbase"
  ugbase_dir.mkdir()
  (ugbase_dir / "ugbt").write_text("", encoding="utf-8")
  monkeypatch.chdir(ugbase_dir)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), SMB_URL, "ga")

  assert ctx.workspace_root == str(tmp_path)
  assert ctx.ugbt_bin == str(ugbase_dir / "ugbt")
  assert ctx.run_work_root.startswith(str(tmp_path / "ugbt" / "beta_run_jenkins"))


def test_context_builds_image_release_path_with_mode_under_release_branch(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), SMB_URL, "ga")

  assert ctx.release_remote_path == "root/release/image/release_20260624/GA/firmware/image/1/2"
  assert ctx.staging_remote_path.startswith(
      "root/release.tmp/image/release_20260624/GA/firmware/image/1/2."
  )
  assert ctx.release_remote_paths == {
      "beta": "root/release/image/release_20260624/beta/firmware/image/1/2",
      "ga": "root/release/image/release_20260624/GA/firmware/image/1/2",
  }


@pytest.mark.parametrize("request_mode", ["beta", "ga"])
@pytest.mark.parametrize(("existing_mode", "expected_message"), [
    ("beta", "该输入已经被转为 beta 包"),
    ("ga", "该输入已经被转为正式包"),
])
def test_publish_rejects_input_already_used_by_either_mode(
    tmp_path, monkeypatch, request_mode, existing_mode, expected_message):
  monkeypatch.chdir(tmp_path)

  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), SMB_URL, request_mode)
  existing_path = ctx.release_remote_paths[existing_mode]

  class FakeConn:
    def isdir(self, share, remote_path):
      return remote_path == ctx.location.remote_path

    def exists(self, share, remote_path):
      return remote_path == existing_path

  def raise_fatal(message):
    raise RuntimeError(message)

  ctx.conn = FakeConn()
  monkeypatch.setattr(beta_jenkins_tool, "fatal", raise_fatal)

  with pytest.raises(RuntimeError, match=expected_message):
    beta_jenkins_tool._BetaPublisher(ctx)._check_publish_paths()


def test_context_builds_suite_release_path_with_service_name_after_mode(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), SUITE_URL, "beta")

  assert ctx.release_remote_path == (
      "root/release/service/release_20260624/beta/firmware/service/docker_serv/1.17.0/59"
  )
  assert ctx.staging_remote_path.startswith(
      "root/release.tmp/service/release_20260624/beta/firmware/service/docker_serv/1.17.0/59."
  )


def test_context_publishes_dockerapp_suite_under_release_service(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), DOCKERAPP_URL, "beta")

  assert ctx.package_type == "suite"
  assert ctx.package_path_parts == ["firmware", "dockerapp", "lucky"]
  assert ctx.release_remote_path == (
      "root/release/service/release_20260728/beta/firmware/dockerapp/lucky/1.3.0/10"
  )
  assert ctx.staging_remote_path.startswith(
      "root/release.tmp/service/release_20260728/beta/firmware/dockerapp/lucky/1.3.0/10."
  )


def test_context_uses_release_branch_from_third_last_path_segment(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(
      FakeEnv(),
      (
          "smb://host/share/root/repo/firmware/dockerapp/release_helper20260728/lucky/"
          "release_a35_20260728/1.3.0/10"
      ),
      "beta",
  )

  assert ctx.package_path_parts == [
      "firmware", "dockerapp", "release_helper20260728", "lucky"
  ]
  assert ctx.release_remote_path == (
      "root/release/service/release_a35_20260728/beta/"
      "firmware/dockerapp/release_helper20260728/lucky/1.3.0/10"
  )


def test_context_accepts_user_dockerapp_unc_path(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(FakeEnv(), DOCKERAPP_UNC, "ga")

  assert ctx.package_type == "suite"
  assert ctx.package_path_parts == ["firmware", "dockerapp", "lucky"]
  assert ctx.release_remote_path == (
      "产品经营部/NAS组/release/service/release_20260728/GA/"
      "firmware/dockerapp/lucky/1.3.0/10"
  )


def test_context_treats_any_non_image_category_as_suite(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  ctx = beta_jenkins_tool._BetaJenkinsContext(
      FakeEnv(),
      "smb://host/share/root/repo/firmware/widgets/widget_a/release_20260728/2.0.0/7",
      "beta",
  )

  assert ctx.package_type == "suite"
  assert ctx.package_path_parts == ["firmware", "widgets", "widget_a"]
  assert ctx.release_remote_path == (
      "root/release/service/release_20260728/beta/firmware/widgets/widget_a/2.0.0/7"
  )


def test_staging_remote_path_uses_release_tmp_tree():
  assert beta_jenkins_tool._staging_remote_path(
      "root/release/image/release_20260624/beta/firmware/image/1.17.0/64",
      "run123",
  ) == "root/release.tmp/image/release_20260624/beta/firmware/image/1.17.0/64.run123.tmp"


def test_staging_remote_path_replaces_publish_release_segment_only():
  assert beta_jenkins_tool._staging_remote_path(
      "root/release/archive/release/image/release_20260624/beta/firmware/image/1.17.0/64",
      "run123",
  ) == (
      "root/release/archive/release.tmp/image/release_20260624/beta/"
      "firmware/image/1.17.0/64.run123.tmp"
  )


def test_context_rejects_suite_path_without_business_path(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  with pytest.raises(SystemExit):
    beta_jenkins_tool._BetaJenkinsContext(
        FakeEnv(),
        "smb://host/share/root/repo/firmware/release_20260728/1.3.0/10",
        "beta",
    )


@pytest.mark.parametrize(("smb_url", "package_type_label", "release_path"), [
    (
        DOCKERAPP_URL,
        "套件",
        "root/release/service/release_20260728/beta/firmware/dockerapp/lucky/1.3.0/10",
    ),
    (
        SMB_URL,
        "固件",
        "root/release/image/release_20260624/beta/firmware/image/1/2",
    ),
])
def test_tool_logs_chinese_input_type_and_final_path(
    tmp_path, monkeypatch, smb_url, package_type_label, release_path):
  logs = []
  home_dir = tmp_path / "home"
  home_dir.mkdir()

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(home_dir)
    opts = {
        "--smb-url": smb_url,
        "--mode": "beta",
    }
    opts_multiple = {}

  monkeypatch.setattr(beta_jenkins_tool, "info", lambda message: logs.append(message))
  monkeypatch.setattr(beta_jenkins_tool, "uuid_gen", lambda: "run123")
  monkeypatch.setattr(beta_jenkins_tool._BetaPublisher, "run", lambda self: "ok")

  tool = beta_jenkins_tool.Tool(FakeEnv())
  tool.build_index()

  assert tool.main() == 0
  assert logs == [
      "输入目录：%s" % smb_url,
      "包类型：%s" % package_type_label,
      r"最终目录：\\host\share\%s" % release_path.replace("/", "\\"),
  ]


def test_context_requires_release_segment(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  with pytest.raises(SystemExit):
    beta_jenkins_tool._BetaJenkinsContext(
        FakeEnv(),
        "smb://host/share/root/repo/firmware/image/1.16.0/80",
        "ga",
    )


def test_context_requires_release_segment_for_unc_path(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  with pytest.raises(SystemExit):
    beta_jenkins_tool._BetaJenkinsContext(
        FakeEnv(),
        r"\\host\share\root\repo\firmware\service\cameramgr_serv\1.0.0\744",
        "ga",
    )


def test_context_rejects_single_platform_dir_path(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  with pytest.raises(SystemExit):
    beta_jenkins_tool._BetaJenkinsContext(
        FakeEnv(),
        SMB_URL + "/arch_spu_intel__build_type_release__cpu_arch_amd64",
        "beta",
    )


def test_context_rejects_non_numeric_package_dir(tmp_path):
  class FakeEnv:
    home = str(tmp_path / "home")

  with pytest.raises(SystemExit):
    beta_jenkins_tool._BetaJenkinsContext(
        FakeEnv(),
        "smb://host/share/root/repo/firmware/image/release_20260624/1/64arch_spu_xxx",
        "beta",
    )


def test_tool_main_fatals_on_publish_error(tmp_path, monkeypatch):
  home_dir = tmp_path / "home"
  home_dir.mkdir()

  class FakeEnv:
    root = str(tmp_path / "ugbase")
    home = str(home_dir)
    opts = {
        "--smb-url": SMB_URL,
        "--mode": "ga",
    }
    opts_multiple = {}

  def fake_publisher_run(self):
    fatal("ERROR: failed")

  monkeypatch.setattr(beta_jenkins_tool._BetaPublisher, "run", fake_publisher_run)

  tool = beta_jenkins_tool.Tool(FakeEnv())
  tool.build_index()

  with pytest.raises(SystemExit) as e:
    tool.main()
  assert e.value.code == 1
