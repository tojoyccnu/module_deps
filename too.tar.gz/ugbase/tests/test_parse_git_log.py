import sys
import types

if "smb.SMBConnection" not in sys.modules:
  smb_mod = types.ModuleType("smb")
  smb_conn_mod = types.ModuleType("smb.SMBConnection")

  class SMBConnection:
    pass

  smb_conn_mod.SMBConnection = SMBConnection
  sys.modules["smb"] = smb_mod
  sys.modules["smb.SMBConnection"] = smb_conn_mod

import ug_utils


def test_parse_git_log_keeps_commit_with_empty_title():
  content = """commit b1865b80c44f54cb1e435277d053e9b5990075ad
Author: Guokai <guokai@ugreen.local>
Date:   Mon Jun 8 15:27:03 2026 +0800

commit 141e426a5d86c3ddc943bcc74fa7b5a6cd2c3f67
Author: Guokai <guokai@ugreen.local>
Date:   Mon Jun 8 15:16:08 2026 +0800

    修复自研 IPC 预置位默认值逻辑
"""

  assert ug_utils.parse_git_log(content) == [
      {
          "commit": "b1865b80c44f54cb1e435277d053e9b5990075ad",
          "Author": "Guokai <guokai@ugreen.local>",
          "Date": "Mon Jun 8 15:27:03 2026 +0800",
      },
      {
          "commit": "141e426a5d86c3ddc943bcc74fa7b5a6cd2c3f67",
          "Author": "Guokai <guokai@ugreen.local>",
          "Date": "Mon Jun 8 15:16:08 2026 +0800",
          "Title": "修复自研 IPC 预置位默认值逻辑",
      },
  ]
