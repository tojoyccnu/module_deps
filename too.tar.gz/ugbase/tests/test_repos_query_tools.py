import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "plugin"))

import repos_query_tools as rqt


def test_parse_query_vars():
  assert rqt.parse_query_vars(["grep=foo", "dir=/tmp"]) == {"grep": "foo", "dir": "/tmp"}
  assert rqt.parse_query_vars(["json=true"]) == {"json": "true"}


def test_parse_bool():
  assert rqt.parse_bool("true") is True
  assert rqt.parse_bool("false") is False
  assert rqt.parse_bool("", default=True) is True


def test_parse_extensions():
  assert rqt.parse_extensions(".cpp,.h") == [".cpp", ".h"]
  assert rqt.parse_extensions("cpp,h") == [".cpp", ".h"]
  assert rqt.parse_extensions("*.go,*.c") == [".go", ".c"]
  assert rqt.parse_extensions("") == []


def test_resolve_search_dir_remote_uses_dir():
  cfg = {"default_search_dir": "/data/repos/code", "local_search_dir": ""}
  cli = {"dir": "/data/repos/code/ctl_serv"}
  path, mode = rqt.resolve_search_dir(cli, "10.0.0.1", cfg)
  assert mode == "remote"
  assert path == "/data/repos/code/ctl_serv"


def test_validate_repos_update_files(tmp_path):
  err = rqt.validate_repos_update_files(str(tmp_path))
  assert "git.sh" in err
  assert "repos.txt" in err
  (tmp_path / "git.sh").write_text("#!/bin/bash\necho ok\n")
  (tmp_path / "repos.txt").write_text("# empty\n")
  assert rqt.validate_repos_update_files(str(tmp_path)) is None


def test_parse_repos_action():
  assert rqt.parse_repos_action({})[0] == "3"
  assert rqt.parse_repos_action({"repos_action": "2"})[0] == "2"
  assert rqt.parse_repos_action({"repos_action": "9"})[1] is not None


def test_build_update_repos_shell_cmd():
  cmd = rqt.build_update_repos_shell_cmd("/data/repos", "3")
  assert "cd /data/repos" in cmd
  assert "git.sh repos repos.txt" in cmd
  assert "GIT_SSH_COMMAND" in cmd
  assert "accept-new" in cmd


def test_parse_grep_line():
  raw = rqt.parse_grep_line("/data/a/b.c:42:hello world")
  assert raw["line"] == 42
  assert raw["content"] == "hello world"


def test_enrich_match():
  root = "/tmp/query-repos-test"
  raw = {"file_path": "/tmp/query-repos-test/storage/src/foo.c", "line": 10, "content": "x"}
  m = rqt.enrich_match(root, raw)
  assert m["first_level_dir"] == "storage"
  assert m["relative_path"] == "src/foo.c"
  assert m["line"] == 10


def test_build_grep_argv():
  argv = rqt.build_grep_argv("pat", "/tmp", [".cpp", ".h"])
  assert argv[0] == "grep"
  assert "--include=*.cpp" in argv
  assert "--include=*.h" in argv
  assert argv[-2] == "pat"
  assert argv[-1] == "/tmp"


def test_count_local_files(tmp_path):
  (tmp_path / "a.go").write_text("x")
  (tmp_path / "b.txt").write_text("y")
  sub = tmp_path / "sub"
  sub.mkdir()
  (sub / "c.go").write_text("z")
  assert rqt.count_local_files(str(tmp_path), [".go"]) == 2
  assert rqt.count_local_files(str(tmp_path), []) == 3


def test_format_scan_summary():
  assert "Found 0 matches" in rqt.format_scan_summary(123, 1.5, 0)
  text = rqt.format_scan_summary(123, 1.5, 7)
  assert "Found 7 matches" in text
  assert "scanned 123 files" in text


def test_build_find_count_shell_cmd():
  cmd = rqt.build_find_count_shell_cmd("/data/repos", [".go", ".c"])
  assert "find" in cmd
  assert "*.go" in cmd
  assert "wc -l" in cmd


def test_progress_enabled():
  assert rqt.progress_enabled({"progress": "false"}, False) is False
  assert rqt.progress_enabled({"progress": "true"}, True) is True
