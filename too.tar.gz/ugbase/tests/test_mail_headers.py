import sys
import types
from datetime import datetime, timezone, timedelta
from email.mime.multipart import MIMEMultipart
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))


if "smb.SMBConnection" not in sys.modules:
  smb_mod = types.ModuleType("smb")
  smb_conn_mod = types.ModuleType("smb.SMBConnection")

  class SMBConnection:
    pass

  smb_conn_mod.SMBConnection = SMBConnection
  sys.modules["smb"] = smb_mod
  sys.modules["smb.SMBConnection"] = smb_conn_mod

import ug_common


def test_format_mail_address_header_keeps_addr_spec_parseable():
  msg = MIMEMultipart('alternative')
  msg['To'] = ug_common.format_mail_address_header([
      "金富强 <fuqiang.jin@ugreen.com>",
  ])

  headers = msg.as_string().split("\n\n", 1)[0]

  assert "To: =?utf-8?" in headers
  assert "<fuqiang.jin@ugreen.com>" in headers
  assert "IDxmdXFpYW5nLmppbkB1Z3JlZW4uY29tPg==" not in headers


def test_format_mail_address_header_handles_multiple_named_recipients():
  msg = MIMEMultipart('mixed')
  msg['To'] = ug_common.format_mail_address_header([
      "张三方 <zhangsan@company.com>",
      "李四妈 <lisi@company.com>",
      "王五肖 <wangwu@other.com>",
  ])

  headers = msg.as_string().split("\n\n", 1)[0]

  assert "To: =?utf-8?" in headers
  assert "<zhangsan@company.com>" in headers
  assert "<lisi@company.com>" in headers
  assert "<wangwu@other.com>" in headers
  assert ",\n    =?utf-8?" in headers


def test_format_mail_date_header_uses_rfc5322_date_time():
  dt = datetime(2025, 7, 9, 14, 30, 0, tzinfo=timezone(timedelta(hours=8)))

  assert ug_common.format_mail_date_header(dt) == "Wed, 09 Jul 2025 14:30:00 +0800"


def test_send_notify_mail_sets_date_header(monkeypatch):
  calls = []

  class FakeSMTP:
    def __init__(self, host, port):
      calls.append({"host": host, "port": port})

    def login(self, user, password):
      calls[-1]["login"] = (user, password)

    def sendmail(self, user, recipients, body_content):
      calls[-1]["sendmail"] = (user, recipients, body_content)

    def quit(self):
      calls[-1]["quit"] = True

  monkeypatch.setattr(ug_common.smtplib, "SMTP_SSL", FakeSMTP)
  monkeypatch.setattr(ug_common, "_smtp_login_info", {
      "host": "smtp.example.com",
      "port": 465,
      "user": "sender-user",
      "password": "sender-pass",
      "address": "sender@example.com",
  })
  monkeypatch.setattr(
      ug_common,
      "format_mail_date_header",
      lambda now=None: "Wed, 09 Jul 2025 14:30:00 +0800",
  )

  ug_common.send_notify_mail(
      tos=["NAS-测试组 <nas-test@ugreen.com>"],
      subject="测试邮件",
      content="<p>OK</p>",
  )

  body_content = calls[0]["sendmail"][2]
  headers = body_content.split("\n\n", 1)[0]

  assert "Date: Wed, 09 Jul 2025 14:30:00 +0800" in headers
