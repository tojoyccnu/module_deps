import os
import shutil
from pathlib import Path

import pytest

import ug_utils
from ug_utils import GS, Repo, UgProject, init_ugdata


RES_DIR = Path(__file__).parent / "res" / "test_ug_project_schema"


class _Env:
  root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

  def get_build_vars(self):
    return {}


class _PlatformEnv(_Env):
  def get_build_vars(self):
    return {
        "cpu_arch": ["amd64", "arm64"],
        "product_series": ["nasync", "homeagent"],
    }


def test_ug_project_rejects_unknown_top_level_field(tmp_path):
  shutil.copytree(RES_DIR / "unknown_top_level_field", tmp_path, dirs_exist_ok=True)

  with pytest.raises(SystemExit):
    UgProject.load(_Env(), [], root=str(tmp_path))


def test_ug_project_unknown_top_level_field_message_lists_allowed_fields(tmp_path, monkeypatch):
  shutil.copytree(RES_DIR / "unknown_top_level_field_message", tmp_path, dirs_exist_ok=True)

  def fake_fatal(message):
    raise RuntimeError(message)

  monkeypatch.setattr(ug_utils, "fatal", fake_fatal)
  with pytest.raises(RuntimeError) as excinfo:
    UgProject.load(_Env(), [], root=str(tmp_path))

  message = str(excinfo.value)
  assert "unknown field: unexpected" in message
  assert "allowed fields:" in message
  assert "name" in message
  assert "version" in message
  assert "ugbase" in message


def test_ug_project_accepts_ota_incremental_fields(tmp_path):
  shutil.copytree(RES_DIR / "ota_incremental", tmp_path, dirs_exist_ok=True)

  UgProject.load(_Env(), [], root=str(tmp_path))


def test_ug_project_defaults_missing_release_to_dev(tmp_path):
  shutil.copytree(RES_DIR / "default_release", tmp_path, dirs_exist_ok=True)

  proj = UgProject.load(_Env(), [], root=str(tmp_path))

  assert GS.RELEASE not in proj.get_data()
  assert proj.get_release() == GS.DEV


@pytest.mark.parametrize(("build_number", "expected"), [
    (0, 3),
    (1, 3),
    (2, 5),
    (3, 5),
    (9996, 9999),
    (9997, 9999),
])
def test_ug_project_inc_build_number_generates_odd_number(build_number, expected):
  proj = UgProject(_Env(), [])
  proj._UgProject__version = "1.0.0"
  proj._UgProject__build_number = build_number
  proj._UgProject__data = {}

  proj.inc_build_number()

  assert proj.get_build_number() == expected
  assert proj.get_data()[GS.VERSION] == "1.0.0.%s" % expected


def test_ug_project_generate_build_number_defaults_to_plus_one():
  proj = UgProject(_Env(), [])
  proj._UgProject__build_number = 2

  assert proj._UgProject__generate_build_number() == 3


@pytest.mark.parametrize("build_number", [9998, 9999])
def test_ug_project_inc_build_number_rejects_number_over_limit(build_number, monkeypatch):
  proj = UgProject(_Env(), [])
  proj._UgProject__build_number = build_number

  def fake_fatal(message):
    raise RuntimeError(message)

  monkeypatch.setattr(ug_utils, "fatal", fake_fatal)
  with pytest.raises(RuntimeError, match="invalid build number: %s" % build_number):
    proj.inc_build_number()


def test_ug_project_v2_loads_version_and_ugbase_from_repo_manifests(tmp_path):
  shutil.copytree(RES_DIR / "v2_loads_version_and_ugbase", tmp_path, dirs_exist_ok=True)
  workspace = tmp_path / "workspace"
  project_dir = workspace / "projects" / "schema-v2"

  proj = UgProject.load(_PlatformEnv(), [], root=str(project_dir))

  assert proj.get_version_text() == "2.3.4.5"
  assert proj.get_version() == "2.3.4"
  assert proj.get_build_number() == 5
  assert proj.get_ugbase().git == "ssh://git@gitlab.ugnas.com/scm/ugbase.git"
  assert proj.get_ugbase().branch == "release_v1"
  assert proj.get_ugbase().revision == "abcdef0"


def test_ug_project_v2_requires_repo_workspace(tmp_path):
  shutil.copytree(RES_DIR / "v2_requires_repo_workspace", tmp_path, dirs_exist_ok=True)

  with pytest.raises(SystemExit):
    UgProject.load(_Env(), [], root=str(tmp_path))


def test_repo_caches_repo_file_parsing(tmp_path, monkeypatch):
  shutil.copytree(RES_DIR / "repo_cache_workspace", tmp_path, dirs_exist_ok=True)
  workspace = tmp_path / "workspace"
  project_dir = workspace / "projects" / "app"

  read_counts = {}
  yaml_counts = {}
  original_read_file = ug_utils.read_file
  original_load_yaml_f = ug_utils.load_yaml_f

  def count_read_file(path):
    read_counts[path] = read_counts.get(path, 0) + 1
    return original_read_file(path)

  def count_load_yaml_f(path):
    yaml_counts[path] = yaml_counts.get(path, 0) + 1
    return original_load_yaml_f(path)

  monkeypatch.setattr(ug_utils, "read_file", count_read_file)
  monkeypatch.setattr(ug_utils, "load_yaml_f", count_load_yaml_f)

  for _ in range(2):
    repo = Repo(str(workspace))
    assert repo.read_project_paths() == {"projects/app"}
    assert repo.get_project_branch("projects/app") == "master"
    repo.load_build_metadata(str(project_dir))

  project_list = str(workspace / ".repo" / "project.list")
  default_xml = str(workspace / ".repo" / "manifests" / "default.xml")
  building = str(workspace / ".repo" / "manifests" / "building.yaml")
  building_version = str(workspace / ".repo" / "manifests" / "building.version.yaml")
  assert read_counts == {project_list: 1, default_xml: 1}
  assert yaml_counts == {building: 1, building_version: 1}


def test_init_ugdata_uses_repo_workspace(tmp_path, monkeypatch):
  workspace = tmp_path / "workspace"
  project_dir = workspace / "projects" / "app"
  os.makedirs(workspace / ".repo")
  os.makedirs(project_dir)
  monkeypatch.delenv("UGDATA", raising=False)
  monkeypatch.delenv("LOCAL_REPO", raising=False)

  init_ugdata(str(project_dir), str(tmp_path / "home"))

  assert os.environ["UGDATA"] == str(workspace / ".ugreen.tmp")
  assert os.environ["LOCAL_REPO"] == str(workspace / ".ugreen.tmp" / "repo")


def test_init_ugdata_uses_home_outside_repo_workspace(tmp_path, monkeypatch):
  home = tmp_path / "home"
  monkeypatch.delenv("UGDATA", raising=False)
  monkeypatch.delenv("LOCAL_REPO", raising=False)

  init_ugdata(str(tmp_path / "project"), str(home))

  assert os.environ["UGDATA"] == str(home / ".ugreen.tmp")
  assert os.environ["LOCAL_REPO"] == str(home / ".ugreen.tmp" / "repo")


def test_init_ugdata_preserves_explicit_paths(tmp_path, monkeypatch):
  ugdata = tmp_path / "custom-data"
  local_repo = tmp_path / "custom-repo"
  monkeypatch.setenv("UGDATA", str(ugdata))
  monkeypatch.setenv("LOCAL_REPO", str(local_repo))

  init_ugdata(str(tmp_path), str(tmp_path / "home"))

  assert os.environ["UGDATA"] == str(ugdata)
  assert os.environ["LOCAL_REPO"] == str(local_repo)


def test_ug_project_rootfs_arch_product_series_overrides_more_general_dirs(tmp_path):
  shutil.copytree(RES_DIR / "rootfs_arch_product_series", tmp_path, dirs_exist_ok=True)

  proj = UgProject.load(_PlatformEnv(), ["cpu_arch=amd64", "product_series=nasync"], root=str(tmp_path))
  rootfs_files = proj._UgProject__get_root_files_str()

  assert "${ROOTFS_ARCH_PRODUCT_SERIES}/config/a.json" in rootfs_files
  assert "${ROOTFS_PRODUCT_SERIES}/config/a.json" not in rootfs_files
  assert "${ROOTFS_ARCH}/config/a.json" not in rootfs_files
  assert "${ROOTFS_COMMON}/config/a.json" not in rootfs_files
  assert "${ROOTFS_COMMON}/config/common.json" in rootfs_files
  assert "${ROOTFS_ARCH}/config/arch.json" in rootfs_files
  assert "${ROOTFS_PRODUCT_SERIES}/config/series.json" in rootfs_files


def test_ug_project_rejects_release_value_release(tmp_path, monkeypatch):
  shutil.copytree(RES_DIR / "release_value_release", tmp_path, dirs_exist_ok=True)

  def fake_fatal(message):
    raise RuntimeError(message)

  monkeypatch.setattr(ug_utils, "fatal", fake_fatal)
  with pytest.raises(RuntimeError) as excinfo:
    UgProject.load(_Env(), [], root=str(tmp_path))

  assert "invalid release: release" in str(excinfo.value)
  assert "release字段不能是release" in str(excinfo.value)


def test_request_for_testing_rejects_release_cname(monkeypatch):
  proj = UgProject(_Env(), [])
  proj._UgProject__release = GS.RELEASE

  def fake_fatal(message):
    raise RuntimeError(message)

  monkeypatch.setattr(ug_utils, "fatal", fake_fatal)
  with pytest.raises(RuntimeError) as excinfo:
    proj._UgProject__get_pack_release_cname()

  assert "request_for_testing不允许发送正式包邮件" in str(excinfo.value)


def test_ug_project_rejects_removed_running_in_another_arm_docker_field(tmp_path):
  shutil.copytree(RES_DIR / "removed_running_in_another_arm_docker", tmp_path, dirs_exist_ok=True)

  with pytest.raises(SystemExit):
    UgProject.load(_Env(), [], root=str(tmp_path))
