#!/bin/bash

#set -x

export UG_SSHD_PORT=$1

if [ "$UG_SSHD_PORT" == "" ]; then
  echo "UG_SSHD_PORT is empty"
  exit 1
fi

mkdir -p /run/sshd
/usr/sbin/sshd -p "$UG_SSHD_PORT" > /var/log/sshd.stdout 2>/var/log/sshd.stderr
RETVAL=$?
if [ $RETVAL -eq 0 ] ; then
  echo "$UG_SSHD_PORT" > /etc/sshd_port
  echo "sshd listen on port $UG_SSHD_PORT"
  exit 0
else
  exit $RETVAL
fi
