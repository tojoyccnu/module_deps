cmake_minimum_required(VERSION 3.25)

if (NOT EXISTS "/usr/local/ugreen/ugbase/")
  message(FATAL_ERROR "You must run this build in ugnas dev docker container!")
endif ()

if ("$ENV{UG_COVERAGE_TEST}" STREQUAL "1")
  set(COVERAGE_BUILD ON)
endif ()

set (GCC_VERSION 12.2.0 CACHE STRING "gcc version number")
set (GCC_VERSION 12.2.0 CACHE STRING "gcc version number")
set (GLIBC_VERSION 2.36 CACHE STRING "glibc version number")
set (LINUX_VERSION 12 CACHE STRING "Linux distribution version abbreviation")

option (BUILD_SHARED_LIBS "Build in shared libraries mode." ON)

set (CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

list(APPEND CMAKE_MODULE_PATH ${PROJECT_SOURCE_DIR}/cmake/modules)
include(${CMAKE_BINARY_DIR}/ugbt.cmake)
ugbt_init()

enable_testing()

set(COMMON_FLAGS "-Wextra -Wall -Werror -g -DBOOST_STACKTRACE_USE_ADDR2LINE -no-pie -fno-pie")
set(COMMON_FLAGS "${COMMON_FLAGS} -Wno-restrict")

if ("$ENV{BUILD_TYPE}" STREQUAL "debug")
  set(CMAKE_BUILD_TYPE Debug)
  set(COMMON_FLAGS "${COMMON_FLAGS} -fsanitize=address -DWITH_ASAN -O0 -fno-omit-frame-pointer")
endif ()

set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${COMMON_FLAGS}")
set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} ${COMMON_FLAGS}")

include_directories($ENV{BOOST_ROOT}/include)
link_directories($ENV{BOOST_ROOT}/lib)

option(UG_BUILD_USE_BOOST "use boost" ON)
option(UG_BUILD_USE_GLOG "use glog" ON)
option(UG_BUILD_USE_GTEST "use gtest" ON)
option(UG_BUILD_USE_GRPC "use grpc" ON)

if (UG_BUILD_USE_BOOST)
  set (CMAKE_MODULE_PATH "/usr/local/ugreen/ugbase/cmake;${CMAKE_MODULE_PATH}")
  find_package(Boost REQUIRED)
  if (NOT TARGET Boost::filesystem)
    message (FATAL_ERROR "boost not found")
  endif ()
  set(COMMON_LINK_FLAGS "backtrace;dl")
endif ()

if (UG_BUILD_USE_GLOG)
  find_package(GLog REQUIRED)
  if (NOT TARGET GLog::glog)
    message(FATAL_ERROR "glog not found")
  endif ()
endif()

if (UG_BUILD_USE_GTEST)
  find_package(GTest REQUIRED)
  if (NOT TARGET GTest::gtest)
    message(FATAL_ERROR "gtest not found")
  endif ()
  find_package(GMock REQUIRED)
  if (NOT TARGET GMock::gmock)
    message(FATAL_ERROR "gmock not found")
  endif ()
endif()

if (UG_BUILD_USE_GRPC)
  find_package(gRPC REQUIRED CONFIG)
  if (NOT TARGET gRPC::grpc)
    message(FATAL_ERROR "grpc not found")
  endif ()
  get_target_property(grpc_include_dir gRPC::grpc INTERFACE_INCLUDE_DIRECTORIES)
  if (NOT EXISTS "${grpc_include_dir}")
    message(FATAL_ERROR "grpc not found, include dir [${grpc_include_dir}] not exists")
  endif ()
endif()

function(ug_install_with_path DIR FILE_PATTERN TO_DIR)
  file(GLOB_RECURSE INST_FILES "${DIR}/${FILE_PATTERN}")
  foreach (INST_FILE ${INST_FILES})
    string(REPLACE "${DIR}/" "" INST_FILE "${INST_FILE}")
    get_filename_component(INST_DIR ${INST_FILE} DIRECTORY)
    install(FILES "${DIR}/${INST_FILE}" DESTINATION "${TO_DIR}/${INST_DIR}")
  endforeach ()
endfunction()

function(ug_add_library)
  cmake_parse_arguments(ARGS "" "DIR;NAME;LINK_TYPE" "CFLAGS;SRCS;LIBS" ${ARGN})
  if(NOT ARGS_NAME)
    message(FATAL_ERROR "NAME is not defined")
  endif()
  if(ARGS_DIR)
    file(GLOB_RECURSE LIB_SRCS "${ARGS_DIR}/*.cc")
  else()
    set(LIB_SRCS "${ARGS_SRCS}")
  endif()
  if (NOT LIB_SRCS)
    message(FATAL_ERROR "LIB_SRCS is empty")
  endif ()
  if (NOT ARGS_LINK_TYPE)
    set(ARGS_LINK_TYPE "SHARED")
  endif()
  add_library(${ARGS_NAME} ${ARGS_LINK_TYPE} ${LIB_SRCS})
  target_compile_options(${ARGS_NAME} PRIVATE ${ARGS_CFLAGS})
  target_link_libraries(${ARGS_NAME} ${ARGS_LIBS} ${COMMON_LINK_FLAGS})

  if(ARGS_LINK_TYPE STREQUAL "SHARED")
    add_custom_command(TARGET ${ARGS_NAME} POST_BUILD
      COMMAND bash -c "ugbt split-symbol -f $<TARGET_FILE:${ARGS_NAME}>"
      COMMENT "split-symbol: ${ARGS_NAME}"
      VERBATIM)
    install(FILES
      "$<TARGET_FILE:${ARGS_NAME}>"
      "$<TARGET_FILE:${ARGS_NAME}>.debug"
      DESTINATION lib)
  else()
    install(FILES
      "$<TARGET_FILE:${ARGS_NAME}>"
      DESTINATION lib)
  endif()

  if (COVERAGE_BUILD)
    target_compile_options(${ARGS_NAME} PRIVATE -g -O0 -fprofile-arcs -ftest-coverage)
    target_link_libraries(${ARGS_NAME} -lgcov)
  endif ()
endfunction()

function(ug_add_tests)
  cmake_parse_arguments(ARGS "" "DIR;NAME" "SRCS;LIBS;INCS" ${ARGN})

  if(ARGS_NAME)
    message(FATAL_ERROR "NAME is unnecessary")
  endif()
  if(ARGS_DIR)
    if (ARGS_SRCS)
      message(FATAL_ERROR "SRCS and DIR are conflict")
    endif ()
    file(GLOB_RECURSE ARGS_SRCS RELATIVE ${ARGS_DIR} "test_*.cc")
    set (NEW_ARGS_SRCS "")
    foreach (ARGS_SRC ${ARGS_SRCS})
      list(APPEND NEW_ARGS_SRCS "${ARGS_DIR}/${ARGS_SRC}")
    endforeach()
    set (ARGS_SRCS "${NEW_ARGS_SRCS}")
  endif()

  foreach(test_src ${ARGS_SRCS})
    string(REPLACE "${CMAKE_CURRENT_SOURCE_DIR}/" "" testname ${test_src})

    string(REPLACE "/" "_" testname ${testname})
    string(REPLACE ".cc" "" testname ${testname})
    string(REPLACE "test_" "" testname ${testname})
    set(testname "test_${testname}")
    message(STATUS "ADD TEST ${testname} ${test_src}")
    add_executable(${testname} ${test_src})
    if (ARGS_INCS)
      target_include_directories(${testname} PRIVATE ${ARGS_INCS})
    endif ()
    target_include_directories(${testname} PRIVATE ${GTEST_INCLUDE_DIRS})
    target_link_options(${testname} PUBLIC "-rdynamic")
    set(TEST_LINK_LIBS "${ARGS_LIBS}" GTest::gtest GMock::gmock ${COMMON_LINK_FLAGS})
    set_target_properties(${testname} PROPERTIES
      RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/test")
    if (COVERAGE_BUILD)
      target_compile_options(${testname} PRIVATE -g -O0 -fprofile-arcs -ftest-coverage)
      set(TEST_LINK_LIBS ${TEST_LINK_LIBS} -lgcov)
    endif ()
    target_link_libraries(${testname} ${TEST_LINK_LIBS})
    add_test(NAME ${testname} COMMAND bash -c "source ${CMAKE_BINARY_DIR}/ug_env.sh && $<TARGET_FILE:${testname}>")
  endforeach(test_src ${TEST_SOURCES})
endfunction()

function(ug_add_binary)
  cmake_parse_arguments(ARGS "" "SRC;NAME;OUTPUT_DIR" "SRCS;LIBS" ${ARGN})

  set(all_srcs "")
  if(ARGS_SRCS)
    set(all_srcs ${ARGS_SRCS})
  elseif(ARGS_SRC)
    set(all_srcs ${ARGS_SRC})
  else()
    message(FATAL_ERROR "ug_add_binary: Either SRCS (multiple files) or SRC (single file) must be defined!")
  endif()

  if(NOT ARGS_NAME)
    message(FATAL_ERROR "NAME is not defined")
  endif()
  add_executable(${ARGS_NAME} ${all_srcs})
  target_link_libraries(${ARGS_NAME} PUBLIC "${ARGS_LIBS}" ${COMMON_LINK_FLAGS})

  set (BIN_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/bin)
  if(ARGS_OUTPUT_DIR)
    set (BIN_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/${ARGS_OUTPUT_DIR})
  endif()

  set_target_properties(${ARGS_NAME} PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY ${BIN_OUTPUT_DIRECTORY})
  if (COVERAGE_BUILD)
    target_compile_options(${ARGS_NAME} PRIVATE -g -O0 -fprofile-arcs -ftest-coverage)
    target_link_libraries(${ARGS_NAME} PRIVATE -lgcov)
  endif ()

  add_custom_command(TARGET ${ARGS_NAME} POST_BUILD
    COMMAND bash -c "ugbt split-symbol -f $<TARGET_FILE:${ARGS_NAME}>"
    COMMENT "split-symbol: ${ARGS_NAME}"
    VERBATIM)
  install(FILES
    "$<TARGET_FILE:${ARGS_NAME}>"
    "$<TARGET_FILE:${ARGS_NAME}>.debug"
    DESTINATION bin)
endfunction()

function (ug_protobuf_generate LANGUAGE FILE_EXT OUTPUT_PB_FILES)
  cmake_parse_arguments(UG_PB_OPTS "" "PBFLAGS;PROTOC_OUT_DIR" PROTOS ${ARGN})
  set (PB_MAKEFILE "${CMAKE_CURRENT_BINARY_DIR}/Makefile_pb_${LANGUAGE}_${FILE_EXT}")
  set (PB_INCS "")
  set (PB_INC_LIST "")
  foreach (IMPORT_DIR ${Protobuf_IMPORT_DIRS})
    string(REPLACE "${CMAKE_CURRENT_SOURCE_DIR}" "\${SRCD}" IMPORT_DIR ${IMPORT_DIR})
    list(FIND PB_INC_LIST ${IMPORT_DIR} IMPORT_DIR_POS)
    if ("${IMPORT_DIR_POS}" STREQUAL "-1")
      set (PB_INCS "${PB_INCS} -I ${IMPORT_DIR}")
      list (APPEND PB_INC_LIST ${IMPORT_DIR})
    endif()
  endforeach ()

  set (OUTD ${CMAKE_CURRENT_BINARY_DIR})
  if (DEFINED UG_PB_OPTS_PROTOC_OUT_DIR)
    set (OUTD ${UG_PB_OPTS_PROTOC_OUT_DIR})
  endif()

  if ("${LANGUAGE}" STREQUAL "go")
    #set (PBFLAGS "--go_out=paths=source_relative:\${OUTD}")
    set (PBFLAGS "")
  elseif ("${LANGUAGE}" STREQUAL "cpp")
    # set (PBFLAGS "--cpp_out \${OUTD}")
    set (PBFLAGS "")
  elseif ("${LANGUAGE}" STREQUAL "grpc")
    # set (PBFLAGS "--grpc_out \${OUTD} --plugin=protoc-gen-grpc=$ENV{blitz_3rd_grpc_ROOT}/bin/grpc_cpp_plugin")
    if ("${FILE_EXT}" STREQUAL ".grpc.pb.cc")
      # C++ gRPC
    set (PBFLAGS "--plugin=protoc-gen-grpc=$ENV{blitz_3rd_grpc_ROOT}/bin/grpc_cpp_plugin")
    elseif ("${FILE_EXT}" STREQUAL "_grpc.pb.go")
      # Go gRPC
      set (PBFLAGS "--plugin=protoc-gen-go-grpc=/usr/bin/protoc-gen-go-grpc")
    else()
      message(FATAL_ERROR "Unknown grpc file extension: ${FILE_EXT}")
    endif()

  else()
    message(FATAL_ERROR "unknown language [${LANGUAGE}]")
  endif()

  if (DEFINED UG_PB_OPTS_PBFLAGS)
    set (UG_PB_OPTS_PBFLAGS " ${UG_PB_OPTS_PBFLAGS}")
  else()
    set (UG_PB_OPTS_PBFLAGS "")
  endif()

  set (PB_MAKEFILE_CONTENT "PROTOBUF_ROOT=$ENV{blitz_3rd_protobuf_ROOT}
PROTOC=LD_LIBRARY_PATH=\${PROTOBUF_ROOT}/lib:\${LD_LIBRARY_PATH} \${PROTOBUF_ROOT}/bin/protoc
SRCD=${CMAKE_CURRENT_SOURCE_DIR}
OUTD=${OUTD}
PBFLAGS=${PBFLAGS} ${PB_INCS}${UG_PB_OPTS_PBFLAGS}
")
  set (PB_FILES "")
  set (ALL_DEPS "")

  foreach(PB_FILE ${UG_PB_OPTS_PROTOS})
    get_filename_component(PB_FILENAME ${PB_FILE} NAME_WE)
    get_filename_component(PB_DIR ${PB_FILE} DIRECTORY)
    get_filename_component(PB_DIR "${PB_DIR}" ABSOLUTE)
    string(REPLACE "${CMAKE_CURRENT_SOURCE_DIR}" "." PB_DIR ${PB_DIR})
    set(PB_DIR "${PB_DIR}/")
    string(REPLACE "./" "" PB_DIR ${PB_DIR})


    string(SUBSTRING "${PB_DIR}" 0 1 PB_DIR_FIRST_CHAR)
    if ("${PB_DIR_FIRST_CHAR}" STREQUAL "/")
      file (MAKE_DIRECTORY ${OUTD})
      set (PB_TARGET_FILE \${OUTD}/${PB_FILENAME}${FILE_EXT})
      set (PB_SRC_FILE ${PB_DIR}${PB_FILENAME}.proto)
      set (PB_FILES "${PB_FILES};${OUTD}/${PB_DIR}${PB_FILENAME}")
    else()
      file (MAKE_DIRECTORY ${OUTD}/${PB_DIR})
      set (PB_TARGET_FILE \${OUTD}/${PB_DIR}${PB_FILENAME}${FILE_EXT})
      set (PB_SRC_FILE \${SRCD}/${PB_DIR}${PB_FILENAME}.proto)
      set (PB_FILES "${PB_FILES};${OUTD}/${PB_DIR}${PB_FILENAME}")
    endif()

    if ("${LANGUAGE}" STREQUAL "go")
      set (OUTFLAGS "--go_out \${OUTD}")
    elseif ("${LANGUAGE}" STREQUAL "cpp")
      set (OUTFLAGS "--cpp_out \${OUTD}")
    elseif ("${LANGUAGE}" STREQUAL "grpc")
      if ("${FILE_EXT}" STREQUAL ".grpc.pb.cc")
        set (OUTFLAGS "--grpc_out \${OUTD}")
      elseif ("${FILE_EXT}" STREQUAL "_grpc.pb.go")
        set (OUTFLAGS "--go-grpc_out \${OUTD}")
      else()
        message(FATAL_ERROR "Unknown grpc file extension: ${FILE_EXT}")
      endif()
      #set (OUTFLAGS "--grpc_out \${OUTD}")
    endif()
    # Ensure the config action will be retriggered when the .proto file
    # has been changed.
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${PB_FILE}")

    set (ALL_DEPS "${ALL_DEPS} ${PB_TARGET_FILE}")
    set (PB_MAKEFILE_CONTENT "${PB_MAKEFILE_CONTENT}${PB_TARGET_FILE}: ${PB_SRC_FILE}
\t\${PROTOC} \${PBFLAGS} ${OUTFLAGS} ${PB_SRC_FILE}
")
  endforeach()
  set (PB_MAKEFILE_CONTENT "${PB_MAKEFILE_CONTENT}all: ${ALL_DEPS}\nclean:\n\trm -f ${ALL_DEPS}")

  set (PB_MAKEFILE_UPDATE_TO_DATE False)
  if (EXISTS ${PB_MAKEFILE})
    file(READ ${PB_MAKEFILE} PB_MAKEFILE_CONTENT_READ)
    if ("${PB_MAKEFILE_CONTENT_READ}" STREQUAL "${PB_MAKEFILE_CONTENT}")
      set (PB_MAKEFILE_UPDATE_TO_DATE True)
    endif ()
  endif ()
  if (${PB_MAKEFILE_UPDATE_TO_DATE})
    message (STATUS "update to date ${PB_MAKEFILE}")
  else()
    file (WRITE ${PB_MAKEFILE} "${PB_MAKEFILE_CONTENT}")
    message (STATUS "generate ${PB_MAKEFILE}")
  endif()

  set (PB_CMD bash -c ". ${PROJECT_BINARY_DIR}/ug_env.sh && make all -s -j ${UG_NPROC} -f ${PB_MAKEFILE}")
  execute_process(COMMAND ${PB_CMD}
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
    RESULT_VARIABLE EXEC_RETCODE)
  if (NOT "${EXEC_RETCODE}" STREQUAL "0")
    message(FATAL_ERROR "generate pb fail: ${EXEC_RETCODE}, run '${PB_CMD}' in ${CMAKE_CURRENT_BINARY_DIR}")
  endif()
  set (${OUTPUT_PB_FILES} ${PB_FILES} PARENT_SCOPE)
endfunction ()

function (ug_protobuf_generate_cpp OUTPUT_PROTO_SRCS OUTPUT_PROTO_HDRS)
  ug_protobuf_generate (cpp .pb.cc PB_FILES ${ARGN})
  set (PROTO_SRCS "")
  set (PROTO_HDRS "")
  foreach (PB_FILE ${PB_FILES})
    set (PROTO_SRCS "${PROTO_SRCS};${PB_FILE}.pb.cc")
    set (PROTO_HDRS "${PROTO_HDRS};${PB_FILE}.pb.h")
  endforeach ()
  set (${OUTPUT_PROTO_SRCS} "${PROTO_SRCS}" PARENT_SCOPE)
  set (${OUTPUT_PROTO_HDRS} "${PROTO_HDRS}" PARENT_SCOPE)
endfunction()

function (ug_grpc_generate_cpp OUTPUT_PROTO_SRCS OUTPUT_PROTO_HDRS)
  ug_protobuf_generate (grpc .grpc.pb.cc PB_FILES ${ARGN})
  set (PROTO_SRCS "")
  set (PROTO_HDRS "")
  foreach (PB_FILE ${PB_FILES})
    set (PROTO_SRCS "${PROTO_SRCS};${PB_FILE}.grpc.pb.cc")
    set (PROTO_HDRS "${PROTO_HDRS};${PB_FILE}.grpc.pb.h")
  endforeach ()
  set (${OUTPUT_PROTO_SRCS} "${PROTO_SRCS}" PARENT_SCOPE)
  set (${OUTPUT_PROTO_HDRS} "${PROTO_HDRS}" PARENT_SCOPE)
endfunction()

function(ug_protobuf_generate_go)
  ug_protobuf_generate (go .pb.go PB_FILES ${ARGN})
endfunction()

function(ug_grpc_generate_go)
  ug_protobuf_generate (grpc _grpc.pb.go PB_FILES ${ARGN})
endfunction()


# ==================== UPK 打包函数 ====================
# 功能：先将 LIB_FILES/SBIN_FILES/BIN_FILES 拷入 rootfs，再执行 build_upk.sh。
# 用法：
#   ug_pack_upk(PROGRAM_NAME <name> [LIB_FILES ...] [SBIN_FILES ...] [BIN_FILES ...])
function(ug_pack_upk)
  cmake_parse_arguments(ARG "" "PROGRAM_NAME" "LIB_FILES;SBIN_FILES;BIN_FILES" ${ARGN})

  if(NOT ARG_PROGRAM_NAME)
    message(FATAL_ERROR "ug_pack_upk: PROGRAM_NAME is required, e.g. ug_pack_upk(PROGRAM_NAME myprog)")
  endif()

  set(BUILD_SCRIPT "/usr/local/ugreen/ugbase/script/build_upk.sh")
  # 检查脚本是否存在
  if(NOT EXISTS ${BUILD_SCRIPT})
    message(FATAL_ERROR "build_upk.sh not found at ${BUILD_SCRIPT}, pack_upk target will not be created")
    return()
  endif()

  set(ROOTFS_LIB "${CMAKE_BINARY_DIR}/rootfs/lib")
  set(ROOTFS_SBIN "${CMAKE_BINARY_DIR}/rootfs/sbin")
  set(ROOTFS_BIN "${CMAKE_BINARY_DIR}/rootfs/bin")
  set(_ug_pack_mkdirs "${ROOTFS_LIB}" "${ROOTFS_SBIN}")
  if(ARG_BIN_FILES)
    list(APPEND _ug_pack_mkdirs "${ROOTFS_BIN}")
  endif()
  set(UG_PACK_CMD
    COMMAND ${CMAKE_COMMAND} -E make_directory ${_ug_pack_mkdirs}
  )
  foreach(_f ${ARG_LIB_FILES})
    if(NOT "${_f}" STREQUAL "")
      list(APPEND UG_PACK_CMD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_f}" "${ROOTFS_LIB}/")
    endif()
  endforeach()
  foreach(_f ${ARG_SBIN_FILES})
    if(NOT "${_f}" STREQUAL "")
      list(APPEND UG_PACK_CMD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_f}" "${ROOTFS_SBIN}/")
    endif()
  endforeach()
  foreach(_f ${ARG_BIN_FILES})
    if(NOT "${_f}" STREQUAL "")
      list(APPEND UG_PACK_CMD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_f}" "${ROOTFS_BIN}/")
    endif()
  endforeach()
  list(APPEND UG_PACK_CMD COMMAND bash "${BUILD_SCRIPT}" "${ARG_PROGRAM_NAME}")

  add_custom_command(
    OUTPUT ${CMAKE_BINARY_DIR}/pack-complete
    ${UG_PACK_CMD}
    WORKING_DIRECTORY ${CMAKE_BINARY_DIR}
    VERBATIM
  )

  add_custom_target(pack_upk
    DEPENDS ${CMAKE_BINARY_DIR}/pack-complete
  )

  install(CODE "
    execute_process(
      COMMAND ${CMAKE_COMMAND} --build ${CMAKE_BINARY_DIR} --target pack_upk
      RESULT_VARIABLE pack_result
    )
    if(NOT pack_result EQUAL 0)
      message(FATAL_ERROR \"pack_upk执行失败!\")
    endif()
  ")

  message(STATUS "Registered 'pack_upk' target: make pack_upk")
  message(STATUS "  Build script: ${BUILD_SCRIPT}")
  message(STATUS "  Program: ${ARG_PROGRAM_NAME}")
  if(ARG_LIB_FILES)
    message(STATUS "  LIB_FILES: ${ARG_LIB_FILES}")
  endif()
  if(ARG_SBIN_FILES)
    message(STATUS "  SBIN_FILES: ${ARG_SBIN_FILES}")
  endif()
  if(ARG_BIN_FILES)
    message(STATUS "  BIN_FILES: ${ARG_BIN_FILES}")
  endif()
  message(STATUS "  Working directory: ${PROJECT_SOURCE_DIR}")
endfunction()
