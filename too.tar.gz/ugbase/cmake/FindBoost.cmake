set(BOOST_ROOT $ENV{blitz_3rd_boost_ROOT} CACHE INTERNAL "")
if (BOOST_ROOT STREQUAL "")
  message(FATAL_ERROR "BOOST_ROOT is null")
endif()

set (BOOST_INCLUDE_DIRS "${BOOST_ROOT}/include" CACHE INTERNAL "")
set (BOOST_LIBS "filesystem"
  "program_options"
  "thread"
  "stacktrace"
  "unit_test_framework"
  "url"
)

foreach (BOOST_LIB ${BOOST_LIBS})
  set (BOOST_LIBRARIES "${BOOST_LIBRARIES};${BOOST_ROOT}/lib/lib${BOOST_LIB}.so")
  set (BOOST_LIBRARIES "${BOOST_LIBRARIES};${BOOST_ROOT}/lib/lib${BOOST_LIB}.a")
endforeach ()

set (BOOST_LIBRARIES "${BOOST_LIBRARIES}" CACHE INTERNAL "")

if (NOT TARGET Boost::filesystem)
  add_library(Boost::boost INTERFACE IMPORTED)
  set_target_properties(Boost::boost PROPERTIES
      INTERFACE_INCLUDE_DIRECTORIES
      "${BOOST_INCLUDE_DIRS}")

  foreach (BOOST_LIB ${BOOST_LIBS})
    add_library(Boost::${BOOST_LIB}_static STATIC IMPORTED)
    set_target_properties(Boost::${BOOST_LIB}_static
      PROPERTIES INTERFACE_COMPILE_DEFINITIONS
      "BOOST_STACKTRACE_USE_BACKTRACE"
      INTERFACE_INCLUDE_DIRECTORIES
      "${BOOST_INCLUDE_DIRS}"
      IMPORTED_LOCATION
      "${BOOST_ROOT}/lib/libboost_${BOOST_LIB}.a")

    add_library(Boost::${BOOST_LIB} SHARED IMPORTED)
    set_target_properties(Boost::${BOOST_LIB}
      PROPERTIES INTERFACE_COMPILE_DEFINITIONS
      "BOOST_STACKTRACE_USE_BACKTRACE"
      INTERFACE_INCLUDE_DIRECTORIES
      "${BOOST_INCLUDE_DIRS}"
      IMPORTED_LOCATION
      "${BOOST_ROOT}/lib/libboost_${BOOST_LIB}.so")
  endforeach ()
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(Boost DEFAULT_MSG BOOST_LIBRARIES BOOST_INCLUDE_DIRS)

MARK_AS_ADVANCED(
  BOOST_INCLUDE_DIRS
  BOOST_LIBRARIES)
