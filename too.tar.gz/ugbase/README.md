# ugbase build tool
ugreen base build tool
## requires
Linux debian with podman
to install podman run 'sudo apt-get install -y podman'
## start docker
run './start_docker.sh' starts a new docker contained named with `whoami`_dev
## start docker with another name
run './start_docker.sh aaa' starts a new docker container named with `whoami`_aaa
## run commands in the docker
run './docker_run_cmd.sh <mycmd> [mycmd_opts]' to run a command in a new docker container
### ugbt command
run this command in the docker container
### get command list supported by ugbt
run './ugbt' to list all the commands
### get help of ugbt
run './ugbt help' to get all the commands with help
### get help of a command of ugbt
run './ugbt help [command] to get the help of a command
### to run a command of ugbt
run './ugbt [command] [options] [targets]' the run a command
for example:
./ugbt config log.show.source=1
### to format all python code
run ./format_py_code.sh to format all the python code
the format is defined in .flake8
