# Jenkins 使用说明

本目录有 3 个脚本：

- `_init_jenkins.sh`：初始化（只允许执行一次）
- `start_jenkins.sh`：启动 Jenkins
- `stop_jenkins.sh`：停止 Jenkins

## 执行顺序

1. `./_init_jenkins.sh`（先执行，且只执行一次）
2. `./start_jenkins.sh`
3. `./stop_jenkins.sh`

未初始化时，`start/stop` 会直接报错并提醒先执行初始化。

## 初始化做了什么

- 拉取/更新 `jenkins-resource`
- 查找 `jenkins.war` 和 JDK 包
- 解压 JDK 到运行目录
- 生成初始化标记和环境文件

## 关键文件

初始化后会生成：

- `.jenkins_initialized`
- `jenkins_env.sh`

`start_jenkins.sh` 和 `stop_jenkins.sh` 都依赖这两个文件。

## 路径和端口（环境变量）

默认值：

- `BENCHMARK_WORKSPACE=$HOME/.ugreen.tmp/jenkins_workspace`
- `JENKINS_RUNTIME_DIR=$BENCHMARK_WORKSPACE/jenkins_runtime`
- `JENKINS_HOME=$JENKINS_RUNTIME_DIR/home`
- `JENKINS_LOG_DIR=$JENKINS_RUNTIME_DIR/logs`
- `JENKINS_PORT=8080`


在 `ugbase/jenkins` 目录下执行：

```bash
cd  自己项目的 ugbase/jenkins
./_init_jenkins.sh
./start_jenkins.sh
./stop_jenkins.sh
```

如需自定义端口再这样执行：

```bash
JENKINS_PORT=18080 ./start_jenkins.sh
```
