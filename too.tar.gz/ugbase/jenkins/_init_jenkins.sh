#!/usr/bin/env bash
set -euo pipefail

BENCHMARK_WORKSPACE="${BENCHMARK_WORKSPACE:-$HOME/.ugreen.tmp/jenkins_workspace}"
JENKINS_RESOURCE_REPO="${JENKINS_RESOURCE_REPO:-git@gitlab.ugnas.com:scm/jenkins-resource.git}"
JENKINS_RESOURCE_DIR="${JENKINS_RESOURCE_DIR:-$BENCHMARK_WORKSPACE/jenkins-resource}"
JENKINS_RUNTIME_DIR="${JENKINS_RUNTIME_DIR:-$BENCHMARK_WORKSPACE/jenkins_runtime}"
JDK_INSTALL_BASE="${JDK_INSTALL_BASE:-$JENKINS_RUNTIME_DIR/jdk}"
JENKINS_HOME="${JENKINS_HOME:-$JENKINS_RUNTIME_DIR/home}"
JENKINS_LOG_DIR="${JENKINS_LOG_DIR:-$JENKINS_RUNTIME_DIR/logs}"
JENKINS_ENV_FILE="${JENKINS_ENV_FILE:-$JENKINS_RUNTIME_DIR/jenkins_env.sh}"
JENKINS_INIT_FLAG="${JENKINS_INIT_FLAG:-$JENKINS_RUNTIME_DIR/.jenkins_initialized}"

echo "=========================================="
echo "🧱 Jenkins 初始化脚本开始执行"
echo "BENCHMARK_WORKSPACE: $BENCHMARK_WORKSPACE"
echo "JENKINS_RESOURCE_DIR: $JENKINS_RESOURCE_DIR"
echo "JENKINS_RUNTIME_DIR: $JENKINS_RUNTIME_DIR"
echo "=========================================="

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "❌ 缺少命令: $1"
    exit 1
  fi
}

need_cmd git
need_cmd tar
need_cmd awk
need_cmd stat
need_cmd mktemp

find_latest_file() {
  local latest=""
  local latest_ts=0
  local f=""
  for f in "$@"; do
    [ -f "$f" ] || continue
    local ts
    ts="$(stat -c %Y "$f" 2>/dev/null || echo 0)"
    if [ "$ts" -gt "$latest_ts" ]; then
      latest_ts="$ts"
      latest="$f"
    fi
  done
  echo "$latest"
}

if [ -f "$JENKINS_INIT_FLAG" ] || [ -f "$JENKINS_ENV_FILE" ]; then
  echo "❌ 检测到 Jenkins 已初始化，禁止重复初始化。"
  echo "初始化标记: $JENKINS_INIT_FLAG"
  echo "环境文件: $JENKINS_ENV_FILE"
  echo "如需重建，请先手工清理 jenkins_runtime 后再执行。"
  exit 1
fi

mkdir -p "$BENCHMARK_WORKSPACE" "$JDK_INSTALL_BASE" "$JENKINS_HOME" "$JENKINS_LOG_DIR"

if [ -d "$JENKINS_RESOURCE_DIR/.git" ]; then
  echo "🔄 检测到仓库已存在，执行 git pull ..."
  git -C "$JENKINS_RESOURCE_DIR" pull --ff-only
else
  if [ -e "$JENKINS_RESOURCE_DIR" ] && [ ! -d "$JENKINS_RESOURCE_DIR/.git" ]; then
    echo "❌ 目标路径已存在但不是 git 仓库: $JENKINS_RESOURCE_DIR"
    exit 1
  fi
  echo "📥 执行 git clone: $JENKINS_RESOURCE_REPO"
  git clone "$JENKINS_RESOURCE_REPO" "$JENKINS_RESOURCE_DIR"
fi

shopt -s nullglob globstar

JENKINS_WAR="$(find_latest_file "$JENKINS_RESOURCE_DIR"/**/jenkins.war)"
JDK_PKG="$(find_latest_file \
  "$JENKINS_RESOURCE_DIR"/**/*jdk*.tar.gz \
  "$JENKINS_RESOURCE_DIR"/**/*openjdk*.tar.gz)"

if [ -z "$JENKINS_WAR" ]; then
  echo "❌ 在仓库中未找到 jenkins.war"
  exit 1
fi
if [ -z "$JDK_PKG" ]; then
  echo "❌ 在仓库中未找到 JDK 压缩包（*jdk*.tar.gz）"
  exit 1
fi

echo "✅ Jenkins WAR: $JENKINS_WAR"
echo "✅ JDK 包: $JDK_PKG"

TAR_LIST_FILE="$(mktemp)"
tar -tf "$JDK_PKG" > "$TAR_LIST_FILE"
JDK_ROOT_NAME="$(awk 'NR==1{print; exit}' "$TAR_LIST_FILE")"
rm -f "$TAR_LIST_FILE"
JDK_ROOT_NAME="${JDK_ROOT_NAME%%/*}"

JAVA_HOME_DIR="$JDK_INSTALL_BASE/$JDK_ROOT_NAME"
JAVA_BIN="$JAVA_HOME_DIR/bin/java"

if [ ! -x "$JAVA_BIN" ]; then
  echo "📦 解压 JDK 到: $JDK_INSTALL_BASE"
  tar -xzf "$JDK_PKG" -C "$JDK_INSTALL_BASE"
else
  echo "ℹ️ 检测到 JDK 已解压，跳过解压。"
fi

if [ ! -x "$JAVA_BIN" ]; then
  echo "❌ JDK 安装后未找到可执行 java: $JAVA_BIN"
  exit 1
fi

echo "☕ Java 版本:"
"$JAVA_BIN" -version || true

{
  echo "#!/usr/bin/env bash"
  printf "JENKINS_WAR=%q\n" "$JENKINS_WAR"
  printf "JAVA_HOME_DIR=%q\n" "$JAVA_HOME_DIR"
  printf "JAVA_BIN=%q\n" "$JAVA_BIN"
} > "$JENKINS_ENV_FILE"
chmod +x "$JENKINS_ENV_FILE"

date '+%F %T' > "$JENKINS_INIT_FLAG"

echo "=========================================="
echo "✅ Jenkins 初始化完成"
echo "初始化标记: $JENKINS_INIT_FLAG"
echo "环境文件: $JENKINS_ENV_FILE"
echo "下一步可执行: ./start_jenkins.sh"
echo "=========================================="
