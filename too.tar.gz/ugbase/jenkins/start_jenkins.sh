#!/usr/bin/env bash
set -euo pipefail

BENCHMARK_WORKSPACE="${BENCHMARK_WORKSPACE:-$HOME/.ugreen.tmp/jenkins_workspace}"
JENKINS_RUNTIME_DIR="${JENKINS_RUNTIME_DIR:-$BENCHMARK_WORKSPACE/jenkins_runtime}"
JENKINS_HOME="${JENKINS_HOME:-$JENKINS_RUNTIME_DIR/home}"
JENKINS_PORT="${JENKINS_PORT:-8080}"
JENKINS_LOG_DIR="${JENKINS_LOG_DIR:-$JENKINS_RUNTIME_DIR/logs}"
JENKINS_LOG_FILE="${JENKINS_LOG_FILE:-$JENKINS_LOG_DIR/jenkins.out}"
JENKINS_PID_FILE="${JENKINS_PID_FILE:-$JENKINS_LOG_DIR/jenkins.pid}"
JENKINS_JAVA_OPTS="${JENKINS_JAVA_OPTS:--Djenkins.install.runSetupWizard=false}"
JENKINS_ENV_FILE="${JENKINS_ENV_FILE:-$JENKINS_RUNTIME_DIR/jenkins_env.sh}"
JENKINS_INIT_FLAG="${JENKINS_INIT_FLAG:-$JENKINS_RUNTIME_DIR/.jenkins_initialized}"

echo "=========================================="
echo "🚀 Jenkins 启动脚本开始执行"
echo "BENCHMARK_WORKSPACE: $BENCHMARK_WORKSPACE"
echo "JENKINS_RUNTIME_DIR: $JENKINS_RUNTIME_DIR"
echo "JENKINS_HOME: $JENKINS_HOME"
echo "JENKINS_PORT: $JENKINS_PORT"
echo "=========================================="

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "❌ 缺少命令: $1"
    exit 1
  fi
}

need_cmd awk
need_cmd nohup

port_in_use() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ss -lnt | awk '$4 ~ /:'"$port"'$/ {found=1} END{exit !found}'
    return $?
  fi
  if command -v netstat >/dev/null 2>&1; then
    netstat -lnt 2>/dev/null | awk '$4 ~ /:'"$port"'$/ {found=1} END{exit !found}'
    return $?
  fi
  if command -v lsof >/dev/null 2>&1; then
    lsof -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
    return $?
  fi
  echo "⚠️ 未找到 ss/netstat/lsof，跳过端口占用预检查。"
  return 1
}

if [ ! -f "$JENKINS_INIT_FLAG" ] || [ ! -f "$JENKINS_ENV_FILE" ]; then
  echo "❌ Jenkins 尚未初始化，不能直接启动。"
  echo "请先执行: ./_init_jenkins.sh"
  exit 1
fi

source "$JENKINS_ENV_FILE"

if [ -z "${JENKINS_WAR:-}" ] || [ -z "${JAVA_HOME_DIR:-}" ] || [ -z "${JAVA_BIN:-}" ]; then
  echo "❌ 初始化环境文件缺少必要字段: $JENKINS_ENV_FILE"
  echo "请重新执行: ./_init_jenkins.sh"
  exit 1
fi
if [ ! -f "$JENKINS_WAR" ] || [ ! -x "$JAVA_BIN" ]; then
  echo "❌ 初始化产物已失效（WAR/JAVA 不存在或不可执行）。"
  echo "请重新执行: ./_init_jenkins.sh"
  exit 1
fi

mkdir -p "$JENKINS_HOME" "$JENKINS_LOG_DIR"

echo "☕ Java 版本:"
"$JAVA_BIN" -version || true

if [ -f "$JENKINS_PID_FILE" ]; then
  OLD_PID="$(cat "$JENKINS_PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "ℹ️ Jenkins 已在运行（PID: $OLD_PID），无需重复启动。"
    echo "日志: $JENKINS_LOG_FILE"
    exit 0
  fi
fi

if port_in_use "$JENKINS_PORT"; then
  echo "❌ 端口 $JENKINS_PORT 已被占用，请换端口重试（如 JENKINS_PORT=18080）"
  exit 1
fi

echo "🚀 启动 Jenkins ..."
# shellcheck disable=SC2086
nohup env JENKINS_HOME="$JENKINS_HOME" JAVA_HOME="$JAVA_HOME_DIR" \
  "$JAVA_BIN" $JENKINS_JAVA_OPTS -jar "$JENKINS_WAR" --httpPort="$JENKINS_PORT" \
  > "$JENKINS_LOG_FILE" 2>&1 &

NEW_PID=$!
echo "$NEW_PID" > "$JENKINS_PID_FILE"

sleep 2
if ! kill -0 "$NEW_PID" 2>/dev/null; then
  echo "❌ Jenkins 启动失败，进程已退出。"
  echo "请检查日志: $JENKINS_LOG_FILE"
  if grep -q "Address already in use" "$JENKINS_LOG_FILE" 2>/dev/null; then
    echo "👉 检测到端口冲突，请换端口重试，例如：JENKINS_PORT=18080 $0"
  fi
  exit 1
fi

echo "=========================================="
echo "✅ Jenkins 启动完成"
echo "PID: $NEW_PID"
echo "访问地址: http://127.0.0.1:$JENKINS_PORT"
echo "日志文件: $JENKINS_LOG_FILE"
echo "PID 文件: $JENKINS_PID_FILE"
echo "=========================================="
