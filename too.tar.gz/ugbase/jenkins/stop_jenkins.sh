#!/usr/bin/env bash
set -euo pipefail

BENCHMARK_WORKSPACE="${BENCHMARK_WORKSPACE:-$HOME/.ugreen.tmp/jenkins_workspace}"
JENKINS_RUNTIME_DIR="${JENKINS_RUNTIME_DIR:-$BENCHMARK_WORKSPACE/jenkins_runtime}"
JENKINS_LOG_DIR="${JENKINS_LOG_DIR:-$JENKINS_RUNTIME_DIR/logs}"
JENKINS_PID_FILE="${JENKINS_PID_FILE:-$JENKINS_LOG_DIR/jenkins.pid}"
JENKINS_INIT_FLAG="${JENKINS_INIT_FLAG:-$JENKINS_RUNTIME_DIR/.jenkins_initialized}"
JENKINS_ENV_FILE="${JENKINS_ENV_FILE:-$JENKINS_RUNTIME_DIR/jenkins_env.sh}"

echo "=========================================="
echo "🛑 Jenkins 停止脚本开始执行"
echo "BENCHMARK_WORKSPACE: $BENCHMARK_WORKSPACE"
echo "JENKINS_RUNTIME_DIR: $JENKINS_RUNTIME_DIR"
echo "PID 文件: $JENKINS_PID_FILE"
echo "=========================================="

if [ ! -f "$JENKINS_INIT_FLAG" ] || [ ! -f "$JENKINS_ENV_FILE" ]; then
  echo "❌ Jenkins 尚未初始化，不能执行停止流程。"
  echo "请先执行: ./_init_jenkins.sh"
  exit 1
fi

STOPPED=0

if [ -f "$JENKINS_PID_FILE" ]; then
  PID="$(cat "$JENKINS_PID_FILE" 2>/dev/null || true)"
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    echo "🔻 发现 Jenkins 进程 PID=$PID，正在停止..."
    kill "$PID" || true
    sleep 2
    if kill -0 "$PID" 2>/dev/null; then
      echo "⚠️ 普通停止未生效，执行强制停止 PID=$PID"
      kill -9 "$PID" || true
    fi
    STOPPED=1
  elif [ -n "$PID" ]; then
    echo "⚠️ PID 文件记录为 $PID，但当前环境无法访问该进程（可能在宿主机命名空间）。"
  fi
  rm -f "$JENKINS_PID_FILE"
fi

PIDS="$(pgrep -f 'jenkins.war' || true)"
if [ -n "$PIDS" ]; then
  echo "🔻 发现残留 Jenkins 进程，正在清理: $PIDS"
  kill $PIDS || true
  sleep 2
  PIDS_LEFT="$(pgrep -f 'jenkins.war' || true)"
  if [ -n "$PIDS_LEFT" ]; then
    echo "⚠️ 强制清理残留 Jenkins 进程: $PIDS_LEFT"
    kill -9 $PIDS_LEFT || true
  fi
  STOPPED=1
fi

if [ "$STOPPED" -eq 1 ]; then
  echo "✅ Jenkins 停止流程完成。"
else
  echo "ℹ️ 未发现可停止的 Jenkins 进程。"
fi

echo "=========================================="
