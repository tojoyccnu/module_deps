#!/usr/bin/env python
import atexit
import getopt
import os
import sys
sys.path.insert(1, sys.path[0] + "/lib")
sys.path.insert(1, sys.path[0] + "/plugin")

from ug_common import env_is_true, fatal, load_yaml_f, make_dir, rm_rf, run, runex, info, uuid_gen
from ug_common import error, full_stack, load_json_f, log_set_show_date, log_set_show_pid, log_set_show_src, \
    log_set_show_stack, log_set_show_tid, log_set_show_verbose
import ug_cmd_base
from ug_utils import init_ugdata


class Config:
  def __init__(self, root):
    self.__build_env = None
    self.__build_vars = None
    self.root = root
    self.__repo_root = ""
    self.__tmp_dir = None

  def get_build_env(self):
    if not self.__build_env:
      conf_path = os.path.join(self.root, "conf", "build_env.yaml")
      self.__build_env = load_yaml_f(conf_path)
    return self.__build_env

  def get_local_repo_root(self):
    if not self.__repo_root:
      if "LOCAL_REPO" in os.environ:
        local_repo = os.environ["LOCAL_REPO"]
        info("found LOCAL_REPO in env -> %s" % local_repo)
      else:
        local_repo = self.get_build_env()["LOCAL_REPO"]
      self.__repo_root = os.path.expandvars(local_repo)
    make_dir(self.__repo_root)
    return self.__repo_root

  def get_build_vars(self):
    if not self.__build_vars:
      conf_path = os.path.join(self.root, "conf", "build_vars.yaml")
      self.__build_vars = load_yaml_f(conf_path)
    return self.__build_vars

  def get_temp_file(self):
    if not self.__tmp_dir:
      tmp_dir = "/tmp/%s/ugbt/%s-%s" % (self.me, os.getpid(), uuid_gen())
      make_dir(tmp_dir)
      if not env_is_true("UG_RESERVE_TMP_FILES"):
        atexit.register(lambda: rm_rf(tmp_dir))
      self.__tmp_dir = tmp_dir
    return os.path.join(self.__tmp_dir, uuid_gen() + ".tmp")


def init(env):
  pass


def fini():
  pass


def main():
  try:
    log_set_show_date(False)
    log_set_show_pid(False)
    log_set_show_tid(False)
    log_set_show_src(True)
    log_set_show_verbose(False)
    log_set_show_stack(True)

    # config_file = os.path.join(os.environ["HOME"], ".ugreen", "ugbt.config.json")
    # if os.path.exists(config_file):
    #  config = load_json_f(config_file)
    #  keys = [("log.show.source", log_set_show_src),
    #          ("log.show.stack", log_set_show_stack)]
    #  for key, func in keys:
    #     if key in config:
    #       val = (int(config[key]) != 0)
    #       func(val)

    env = Config(sys.path[0])

    init(env)

    env.pwd = os.getcwd()

    env.home = os.environ["HOME"]
    env.me = runex("whoami")
    init_ugdata(env.pwd, env.home)
    env.cmds = []

    return ug_cmd_base.run_tool(env, "ugbt", "ugreen base tool 1.0.1")
  except getopt.GetoptError as e:
    error(str(e))
  except Exception as e:
    stack = full_stack()
    error("Exception raised: " + str(e) + "\n" + stack)

  finally:
    fini()
    pass
  return 1


sys.exit(main())
