
from collections import OrderedDict
import os
from ug_common import SambaConnection, dump_yaml, fatal, get_machine, info, sort_dict
from ug_common import split_2_part


DEFAULT_BUILD_VARS = "DEFAULT_BUILD_VARS"
__current_cpu_arch = None


def normalize_cpu_arch(cpu_arch):
  cpu_arch = str(cpu_arch).strip().lower()
  if cpu_arch == "x86_64":
    return "amd64"
  if cpu_arch == "aarch64":
    return "arm64"
  fatal("Unknown CPU architecture: %s" % cpu_arch)


def get_current_cpu_arch():
  global __current_cpu_arch
  if __current_cpu_arch is None:
    __current_cpu_arch = normalize_cpu_arch(get_machine())
  return __current_cpu_arch


class BuildPlatform:
  def __init__(self, env, build_vars, proj_platform):
    self.env = env
    input_vars = OrderedDict()
    for var in build_vars:
      parts = split_2_part(var, ch='=')
      input_vars[parts[0].strip()] = parts[1].strip()
    file_vars = env.get_build_vars()

    for var_key in input_vars.keys():
      if not var_key in file_vars.keys():
        fatal("invalid build_var [%s] , must be one of [%s]" % (var_key, file_vars))
      v = input_vars[var_key]
      if not v in file_vars[var_key]:
        fatal("%s is invalid of %s, must be one of [%s]" % (v, var_key, file_vars[var_key]))

    for var_key in proj_platform:
      if not var_key in file_vars.keys():
        fatal("invalid var [%s] in platform of ugreen_project.yaml, must be one of [%s]" % (var_key, file_vars))

    self.__data = OrderedDict()
    default_vars = self.__get_default_vars(proj_platform)
    for var_key in proj_platform:
      if var_key in input_vars.keys():
        self.__data[var_key] = input_vars[var_key]
      elif var_key in default_vars:
        self.__data[var_key] = default_vars[var_key]
      else:
        self.__data[var_key] = file_vars[var_key][0]

  def __get_default_vars(self, proj_platform):
    if not hasattr(self.env, "get_build_env"):
      return {}
    build_env = self.env.get_build_env()
    default_conf = build_env.get(DEFAULT_BUILD_VARS, {})
    if not default_conf:
      return {}
    cpu_arch = get_current_cpu_arch()
    if not cpu_arch in default_conf:
      return {}
    defaults = default_conf[cpu_arch]
    if not isinstance(defaults, dict):
      fatal("%s.%s must be a dict" % (DEFAULT_BUILD_VARS, cpu_arch))
    file_vars = self.env.get_build_vars()
    ret = {}
    for var_key in defaults.keys():
      if not var_key in proj_platform:
        continue
      if not var_key in file_vars.keys():
        fatal("invalid default build_var [%s] in %s.%s" % (var_key, DEFAULT_BUILD_VARS, cpu_arch))
      if not defaults[var_key] in file_vars[var_key]:
        fatal("%s is invalid of default %s, must be one of [%s]" % (
            defaults[var_key], var_key, file_vars[var_key]))
      ret[var_key] = defaults[var_key]
    return ret

  def has(self, k):
    return not self.__data.get(k, None) is None

  def keys(self):
    return list(self.__data.keys())

  def get(self, k):
    v = self.__data.get(k, None)
    if v is None:
      fatal(k + " not set")
    return v

  def __str__(self):
    return "build_platform: " + dump_yaml(self.__data)

  def get_sorted_str(self):
    d = sort_dict(self.__data)
    ss = ""
    for k in d.keys():
      v = d[k]
      if ss:
        ss += "__"
      ss += "%s_%s" % (k, v)
    if not ss:
      ss = "all"
    return ss

  def get_sorted_short_str(self):
    d = sort_dict(self.__data)
    ss = ""
    for k in d.keys():
      v = d[k]
      if ss:
        ss += "_"
      ss += "%s" % v
    if not ss:
      ss = "all"
    return ss

  def get_env_str(self):
    d = sort_dict(self.__data)
    ss = ""
    for k in d.keys():
      v = d[k]
      ss += "export %s=%s\n" % (k.upper(), v)
    ss += "export BUILD_PLATFORM=%s\n" % self.get_sorted_str()
    ss += "export BUILD_PLATFORM_SHORT=%s\n" % self.get_sorted_short_str()
    return ss

  def search_compatiable_pack_in_local(self, dep_path, local_repo_root=None):
    env = self.env
    if not local_repo_root:
      local_repo_root = env.get_local_repo_root()
    full_dep_path = os.path.join(local_repo_root, dep_path)
    if os.path.exists(full_dep_path):
      dirs = os.listdir(full_dep_path)
    else:
      dirs = []
    compatible_dirs = []
    for dir_name in dirs:
      if self.__is_compatible_with(full_dep_path, dir_name):
        compatible_dirs.append(dir_name)

    if len(compatible_dirs) > 1:
      fatal("more than 1 dir is compatible: " + dump_yaml(compatible_dirs) + " in " + full_dep_path)
    if len(compatible_dirs) == 1:
      return compatible_dirs[0]
    else:
      return None

  def __is_compatible_with(self, parent, dir_name):
    env = self.env
    if dir_name.endswith(".tmp"):
      return False
    if dir_name.startswith("."):
      return False
    if dir_name == "all":
      return True
    tokens = dir_name.split("__")
    data_keys = set(self.__data.keys())
    for token in tokens:
      found = False
      for build_var_k in env.get_build_vars().keys():
        if token.startswith(build_var_k + "_"):
          found = True
          build_var_vs = env.get_build_vars()[build_var_k]
          build_var_v = token[len(build_var_k) + 1:]
          if not build_var_v in build_var_vs:
            fatal("unkown build var %s in [%s] in %s" % (build_var_v, build_var_vs, parent))

          if build_var_k in self.__data:
            if self.__data[build_var_k] != build_var_v:
              return False
            data_keys.remove(build_var_k)
          break
      if not found:
        fatal("invalid dir name: " + dir_name + " in " + parent)
    # if every build var is compatible
    return True

  def search_compatiable_pack_in_remote(self, dep_path):
    # @ SmbConnection conn
    env = self.env
    smb_host = env.get_build_env()["SMB_HOST"]
    share_name = env.get_build_env()["SMB_SHARE_NAME"]
    repo_root = env.get_build_env()["SMB_REPO"]
    full_dep_path = os.path.join(repo_root, dep_path)
    conn = SambaConnection.instance(smb_host)
    folders = conn.ls(share_name, full_dep_path)
    sub_folders = []
    for folder in folders:
      if folder == ".":
        continue
      if folder == "..":
        continue
      sub_folders.append(folder)
    parent = "smb://%s/%s/%s" % (smb_host, share_name, full_dep_path)
    info("ls %s return %s" % (parent, sub_folders))
    compatible_dirs = []
    for dir_name in sub_folders:
      if self.__is_compatible_with(parent, dir_name):
        compatible_dirs.append(dir_name)

    if len(compatible_dirs) > 1:
      fatal("more than 1 dir is compatible: " + dump_yaml(compatible_dirs))
    if len(compatible_dirs) == 1:
      return compatible_dirs[0]
    else:
      return None

  @staticmethod
  def parse(env, dir_name):
    if dir_name == "all":
      return BuildPlatform(env, [], [])
    build_vars = []
    platform = []
    tokens = dir_name.split("__")
    for token in tokens:
      found = False
      for build_var_k in env.get_build_vars().keys():
        if token.startswith(build_var_k + "_"):
          found = True
          build_var_vs = env.get_build_vars()[build_var_k]
          build_var_v = token[len(build_var_k) + 1:]
          if not build_var_v in build_var_vs:
            fatal("unkown build var %s in [%s]" % (build_var_v, build_var_vs))
          platform.append(build_var_k)
          build_vars.append(build_var_k + "=" + build_var_v)
      if not found:
        fatal("invalid dir name: " + dir_name)
    return BuildPlatform(env, build_vars, platform)
