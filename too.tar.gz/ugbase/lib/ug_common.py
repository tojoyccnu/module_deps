import hashlib
import os
import random
import shlex
import shutil
import socket
import sys

import atexit
import copy
import fcntl
import inspect
import json
import logging
import logging.handlers
import os
import io
import pwd
import subprocess
import time
import traceback
import threading
from datetime import datetime
from collections import OrderedDict
from urllib.parse import unquote, urlparse

import uuid
from pathlib import Path


def is_verbose():
  if "UG_VERBOSE" in os.environ:
    return is_true(os.environ["UG_VERBOSE"])


def set_verbose(v=False):
  os.environ["UG_VERBOSE"] = ("1" if v else "0")


def is_iterable(obj):
  try:
    iter(obj)
    return True
  except Exception as e:
    return False


__machine = None


def get_machine():
  global __machine
  if __machine is None:
    __machine = runex("uname -m").strip()
  return __machine


class DateEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, datetime):
      return obj.strftime("%Y-%m-%d %H:%M:%S")
    else:
      return json.JSONEncoder.default(self, obj)


def dump_json(obj):
  content = json.dumps(obj, indent=2, ensure_ascii=False)
  return content.replace(" \n", "\n")


def load_json(text):
  return json.loads(text, object_pairs_hook=OrderedDict)


def load_json_f(file):
  content = ""
  try:
    content = read_file(file)
  except Exception as e:
    fatal("read from file " + file + " fail: " + str(e))

  try:
    return load_json(content)
  except Exception as e:
    fatal("parse json of file " + file + " fail: " + str(e))


def require_dir(path):
  if not os.path.isdir(path):
    fatal("directory not found: %s" % path)


def is_true(text):
  if not text:
    return False
  text = str(text).lower().strip()

  if text.isdigit():
    val = int(text)
    return val != 0
  else:
    return text != "false" and text != "off"


def env_is_true(key):
  return key in os.environ and is_true(os.environ[key])


__default_logger = None


def set_default_logger(logger):
  global __default_logger
  __default_logger = logger


def get_logger(log_file=None, only_file=False):
  global __default_logger

  if __default_logger:
    return __default_logger

  if not log_file:
    if not __default_logger:
      key = "UG_PYTHON_LOG_DIR"
      if key in os.environ:
        dir = os.environ[key]
        if not os.path.exists(os.environ[key]):
          fatal(os.environ[key] + " not found")
      else:
        dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "logs")
      dir = os.path.abspath(dir)
      if not os.path.exists(dir):
        os.makedirs(dir)
        if not os.path.exists(dir):
          print("make dir %s fail" % dir, file=sys.stderr)
          sys.exit(2)

      _, main_name = os.path.split(sys.argv[0])
      main_name = main_name.replace(".py", "")
      log_file = os.path.join(dir, main_name + ".log")
      __default_logger = __get_logger("default", log_file, only_file)
    return __default_logger
  else:
    return __get_logger(log_file, log_file, only_file)


def debug(s):
  get_logger().debug(s)


def info(s):
  get_logger().info(s)


def info_x(s):
  if is_verbose():
    info(s)


def warning(s):
  get_logger().warning(s)


def error(s):
  get_logger().error(s)


def fatal(s):
  global __log_show_stack
  if __log_show_stack:
    s = s + " " + full_stack()
  get_logger().fatal(s)
  sys.exit(1)


def uuid_gen():
  return str(uuid.uuid1())


def red(s):
  return "\033[1;31;40m" + s + "\033[0m"


def yellow(s):
  return "\033[1;33;40m" + s + "\033[0m"


def green(s):
  return "\033[1;32;40m" + s + "\033[0m"


def get_colourless_str(str_):
  trans_map = {
      "\033[1;31;40m": "",
      "\033[1;32;40m": "",
      "\033[1;33;40m": "",
      "\033[0m": ""
  }
  return batch_replace(str_, trans_map)


def ret_code(code):
  retcode = code >> 8
  signum = code & 0xff
  if signum != 0:
    return signum
  else:
    return retcode


__log_show_date = True
__log_show_pid = False
__log_show_src = True
__log_show_tid = False
__log_show_stack = False
__log_show_verbose = False


def log_set_show_date(val):
  global __log_show_date
  __log_show_date = val


def log_set_show_pid(val):
  global __log_show_pid
  __log_show_pid = val


def log_set_show_tid(val):
  global __log_show_tid
  __log_show_tid = val


def log_set_show_src(val):
  global __log_show_src
  __log_show_src = val


def log_set_show_verbose(val):
  global __log_show_verbose
  __log_show_verbose = val


def log_set_show_stack(val):
  global __log_show_stack
  __log_show_stack = val


class InfoFilter(logging.Filter):
  def filter(self, rec):
    return rec.levelno in (logging.DEBUG, logging.INFO)


class WarnFilter(logging.Filter):
  def filter(self, rec):
    return rec.levelno == logging.WARNING


class ErrorFilter(logging.Filter):
  def filter(self, rec):
    return rec.levelno == logging.ERROR


_log_skipped_source_file_names = ["ug_common.py", "cmd_base.py"]
_log_skipped_function_names = ["log", "info", "debug", "warning", "fatal", "error"]


def log_get_skipped_source_file_names():
  global _log_skipped_source_file_names
  return _log_skipped_source_file_names


def log_get_skipped_function_names():
  global _log_skipped_function_names
  return _log_skipped_function_names


class UgLogger(logging.Logger):
  def __init__(self, log_name, level=None):
    logging.Logger.__init__(self, log_name)

  def findCaller(self, stack_info=False, stacklevel=1):
    global _log_skipped_source_file_names
    global _log_skipped_function_names
    sinfo = None
    f = inspect.currentframe()
    # On some versions of IronPython, currentframe() returns None if
    # IronPython isn't run with -X:Frames.
    if f is not None:
      f = f.f_back

    if sys.version_info.major == 2:
      rv = "(unknown file)", 0, "(unknown function)"
    else:
      rv = "(unknown file)", 0, "(unknown function)", sinfo

    stat = 0
    while hasattr(f, "f_code"):
      co = f.f_code
      filename = os.path.normcase(co.co_filename)

      if "/logging/" in filename:
        f = f.f_back
        continue

      _, name = os.path.split(filename)
      if name in _log_skipped_source_file_names:
        f = f.f_back
        continue

      if co.co_name in _log_skipped_function_names:
        f = f.f_back
        continue

      if stack_info:
        sio = io.StringIO()
        sio.write('Stack (most recent call last):\n')
        traceback.print_stack(f, file=sio)
        sinfo = sio.getvalue()
        if sinfo[-1] == '\n':
          sinfo = sinfo[:-1]
        sio.close()
      rv = co.co_filename, f.f_lineno, co.co_name, sinfo
      break

    f = f.f_back
    return rv


def _close_handler(handler):
  handler.close()


def __get_logger(name, log_file, only_file=False):
  global __log_show_date
  global __log_show_pid
  global __log_show_src
  global __log_show_tid
  global __log_show_verbose

  logger = UgLogger(name)
  if __log_show_verbose:
    logger.setLevel(logging.DEBUG)
  else:
    logger.setLevel(logging.INFO)

  if __log_show_date:
    datefmt = '%Y-%m-%d %H:%M:%S'
  else:
    datefmt = '%H:%M:%S'

  formatter = "%(asctime)s.%(msecs)03d ${level}"
  if __log_show_pid:
    formatter += " %(process)d"
  if __log_show_tid:
    formatter += " %(threadName)s"
  formatter += " %(message)s"
  if __log_show_src:
    formatter += " |%(filename)s(%(lineno)d)"

  logfile = os.path.abspath(log_file)
  file_handler = logging.handlers.RotatingFileHandler(logfile, maxBytes=100 * 1024 * 1024, backupCount=10)
  file_handler.setLevel(logging.DEBUG)
  file_handler.setFormatter(logging.Formatter(formatter.replace("${level}", "%(levelname)s"), datefmt=datefmt))
  logger.addHandler(file_handler)
  atexit.register(_close_handler, file_handler)

  if only_file:
    return logger

  info_handler = logging.StreamHandler(sys.stdout)
  info_handler.addFilter(InfoFilter())
  info_handler.setFormatter(logging.Formatter(formatter.replace("${level}", green("%(levelname)s")), datefmt=datefmt))
  logger.addHandler(info_handler)

  warn_handler = logging.StreamHandler(sys.stdout)
  warn_handler.setLevel(logging.WARNING)
  warn_handler.addFilter(WarnFilter())
  logger.addHandler(warn_handler)
  warn_handler.setFormatter(logging.Formatter(formatter.replace("${level}", yellow("%(levelname)s")), datefmt=datefmt))
  logger.addHandler(warn_handler)

  error_handler = logging.StreamHandler(sys.stderr)
  error_handler.setLevel(logging.ERROR)
  error_handler.addFilter(ErrorFilter())
  error_handler.setFormatter(logging.Formatter(formatter.replace("${level}", red("%(levelname)s")), datefmt=datefmt))
  logger.addHandler(error_handler)

  fatal_handler = logging.StreamHandler(sys.stderr)
  fatal_handler.setLevel(logging.FATAL)
  fatal_handler.setFormatter(logging.Formatter(formatter.replace("${level}", red("FATAL")), datefmt=datefmt))
  logger.addHandler(fatal_handler)

  return logger


def get_ug_logger(name, log_file, only_file=False):
  return __get_logger(name, log_file, only_file=only_file)


def cd(dir, show_log=True):
  try:
    if os.path.abspath(os.getcwd()) != os.path.abspath(dir):
      os.chdir(dir)
      if show_log:
        info("cd [" + dir + "]")
  except Exception as e:
    fatal("cd " + dir + " fail: " + str(e))


def get_owner(dir):
  return pwd.getpwuid(os.stat(dir).st_uid).pw_name


def run(cmd, assert_ok=True, show_log=True, raise_exception=False, show_start_log=False, retry_interval=None, retry_timeout=None, retry_times=None):
  if retry_timeout is None and retry_interval is None and retry_times is None:
    return run_impl(cmd, assert_ok, show_log, raise_exception, show_start_log)

  start_time = time.time()
  if retry_timeout is not None and assert_ok:
    fatal("not support")

  if retry_times is not None and assert_ok:
    fatal("not support")

  if retry_times is not None and retry_timeout is not None:
    fatal("not support")

  if retry_timeout is None:
    retry_timeout = 0
  if retry_interval is None:
    retry_interval = 0.5

  if retry_times is None:
    while True:
      try:
        ret = run_impl(cmd, assert_ok, show_log, raise_exception, show_start_log)
        if ret != 0:
          raise Exception("cmd:%s returns: %s" % (cmd, ret))
      except Exception as ex:
        delta = time.time() - start_time
        if delta < 0 or delta > retry_timeout:
          error("run %s timeout delta %s timeout %s" % (cmd, delta, retry_timeout))
          raise ex
        else:
          info("ignore excpetion ex: %s, sleeping %s ..." % (ex, retry_interval))
          time.sleep(retry_interval)
          info("retrying cmd: %s" % cmd)
      return ret
  else:
    for i in range(retry_times):
      try:
        ret = run_impl(cmd, assert_ok, show_log, raise_exception, show_start_log)
        if ret != 0:
          raise Exception("cmd:%s returns: %s" % (cmd, ret))
        else:
          return ret
      except Exception as ex:
        info("ignore excpetion ex: %s, sleeping %s ..." % (ex, retry_interval))
        time.sleep(retry_interval)
        info("retrying cmd: %s" % cmd)
        info('this is retry cmd %s times' % (i + 1))
    return ret


def run_impl(cmd, assert_ok=True, show_log=True, raise_exception=False, show_start_log=False):
  global __log_show_stack
  if show_start_log:
    info("start [" + cmd + "] ...")
  ret = os.system(cmd)
  if ret != 0:
    if show_log or assert_ok:

      if assert_ok:
        fail = red("fail")
      else:
        fail = yellow("fail")

      msg = "exec [" + cmd + "] " + fail + " ret:" + str(ret) + " in " + os.getcwd()
      if __log_show_stack:
        msg += " " + full_stack()

      if assert_ok:
        error(msg)
      else:
        warning(msg)

    if raise_exception:
      raise Exception("exec [%s] failed, ret %s" % (cmd, ret))
    if assert_ok:
      sys.exit(ret_code(ret))
  else:
    if show_log:
      info("exec [" + cmd + "] " + green("OK"))
  return ret_code(ret)


def _runex(cmd, assert_ok=True, show_log=False, err_output=False, raise_exception=False):
  global __log_show_stack
  try:
    (ret, output) = subprocess.getstatusoutput(cmd)
  except Exception as e:
    if assert_ok:
      fatal(str(e))
    else:
      ret = 1
      output = str(e)

  if ret != 0:

    if assert_ok:
      fails = red("fail")
    else:
      fails = yellow("fail")
    msg = "exec [" + cmd + "] " + fails + " ret " + str(ret) + " in " + os.getcwd() + " " + output
    if __log_show_stack:
      msg += " " + full_stack()

    if assert_ok:
      error(msg)
      sys.exit(ret_code(ret))
    else:
      if show_log:
        warning(msg)
      if not err_output:
        output = ""
    if raise_exception:
      raise Exception("exec [%s] failed" % cmd)
  else:
    if show_log:
      info("exec [" + cmd + "] " + green("OK"))

  return ret, output


def runex3(cmd, **kwargs):
  return _runex(cmd, **kwargs)


def runex(cmd, assert_ok=True, show_log=False, err_output=False, raise_exception=False):
  _, output = _runex(cmd, assert_ok=assert_ok, show_log=show_log,
                     err_output=err_output, raise_exception=raise_exception)
  return output


def md5(file):
  ret = runex("bash -c \"set -o pipefail && md5sum %s | awk '{print \\$1}'\"" % file).strip()
  return ret


def join_cmd(args):
  tokens = []
  for arg in args:
    tokens.append(shlex.quote(arg))
  return " ".join(tokens)


def glob_files(root_dir, roots, suffixes, skip_dirs=()):
  files = []
  root = Path(root_dir)
  if roots is None:
    roots = []
    for path in sorted(root.iterdir()):
      if not path.is_dir():
        continue
      if path.name in skip_dirs:
        continue
      roots.append(path.name)
  for suffix in suffixes:
    for path in sorted(root.glob("*" + suffix)):
      if path.is_file():
        files.append(str(path.relative_to(root)))
  for name in roots:
    path_root = root / name
    for suffix in suffixes:
      for path in sorted(path_root.glob("**/*" + suffix)):
        if path.is_symlink() or not path.is_file():
          continue
        rel_parts = path.relative_to(root).parts[0:-1]
        if [part for part in rel_parts if part in skip_dirs]:
          continue
        files.append(str(path.relative_to(root)))
  return sorted(set(files))


def read_file(name):
  fp = open(name, "r")
  content = fp.read()
  fp.close()
  return content


def make_dir(dir, show_log=True):
  if dir == "" or dir == "." or dir == "..":
    return
  if os.path.islink(dir):
    run("rm -f " + dir, show_log=show_log)
  if not os.path.exists(dir):
    run("mkdir -p " + dir, show_log=show_log)
  if not os.path.exists(dir):
    fatal(dir + " not exist")


def copy_dir(src, dst, ignore_patterns=[]):
  if not os.path.isdir(src):
    fatal("copy src dir not found: " + src)
  if os.path.exists(dst):
    fatal("copy dst already exists: " + dst)
  ignore = shutil.ignore_patterns(*ignore_patterns) if ignore_patterns else None
  shutil.copytree(src, dst, ignore=ignore)


def write_file(name, content, show_log=True):
  if type(content).__name__ == "bytes":
    content = content.decode('utf-8')
  make_dir(os.path.dirname(name))
  if os.path.exists(name):
    fd = os.open(name, os.O_WRONLY | os.O_TRUNC)
    fp = os.fdopen(fd, "w")
  else:
    fp = open(name, "w")

  fp.write(content)
  fp.close()
  if show_log:
    info("Write to [%s] OK, size %d" % (name, len(content)))


def full_stack():
  exc = sys.exc_info()[0]
  stack = traceback.extract_stack()[:-1]
  if exc is not None:
    del stack[-1]
  trc = 'Traceback (most recent call last):\n'
  stackstr = trc + ''.join(traceback.format_list(stack))
  if exc is not None:
    stackstr += '  ' + traceback.format_exc().lstrip(trc)
  return stackstr


def convert_string_numbers(data):
  if isinstance(data, dict):
    return {k: convert_string_numbers(v) for k, v in data.items()}
  elif isinstance(data, list):
    return [convert_string_numbers(v) for v in data]
  elif isinstance(data, str) and data.isdigit():
    return int(data)
  return data


def verify_sudo():
  ret = os.system("sudo ls>/dev/null 2>/dev/null")
  if ret != 0:
    error("Can not sudo")
    sys.exit(ret_code(ret))


_me = None


def whoami():
  global _me
  if not _me:
    _me = runex("whoami")
  return _me


import yaml


class YamlOrderedDumper(yaml.Dumper):
  pass


def _dict_representer(dumper, data):
  return dumper.represent_mapping(
      yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, list(data.items()))


YamlOrderedDumper.add_representer(OrderedDict, _dict_representer)


def dump_yaml(obj):
  return yaml.dump(obj, Dumper=YamlOrderedDumper, indent=2, allow_unicode=True, default_flow_style=False)


class YamlOrderedLoader(yaml.Loader):
  pass


def _construct_mapping(loader, node):
  loader.flatten_mapping(node)
  return OrderedDict(loader.construct_pairs(node))


YamlOrderedLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _construct_mapping)


def load_yaml(text):
  obj = yaml.load(text, Loader=YamlOrderedLoader)
  return obj


def load_yaml_f(file):
  content = ""
  try:
    content = read_file(file)
  except Exception as e:
    fatal("read from file " + file + " in " + os.getcwd() + " fail: " + str(e))

  try:
    return load_yaml(content)
  except Exception as e:
    fatal("parse yaml of file " + file + " fail: " + str(e))


def get_git_dir(git):
  pos = git.rfind("/")
  if pos < 0:
    fatal("Invalid git repo " + git)

  ret = git[pos + 1:]
  if ret.endswith(".git"):
    ret = ret[0:len(ret) - 4]
  return ret


def confirm_to_continue(msg):
  sys.stdout.write("%s [Y]|N : " % msg)
  sys.stdout.flush()
  input = sys.stdin.readline().strip().lower()
  if len(input) > 0 and input[0] == "y":
    return
  fatal("user break")


def sort_dict(var, reverse=False):
  keys = sorted(var, reverse=reverse)
  var_new = OrderedDict()
  for key in keys:
    var_new[key] = var[key]
  return var_new


__dirs = []


def pushd():
  global __dirs
  __dirs.append(os.getcwd())


def popd(show_log=True):
  global __dirs
  dir = __dirs.pop()
  cd(dir, show_log=show_log)


def split_ex(text, ch, func=None):
  lst = []
  tokens = text.split(ch)
  for token in tokens:
    token = token.strip()
    if token:
      if func:
        lst.append(func(token))
      else:
        lst.append(token)
  return lst


def atoi(text):
  ret = 0
  try:
    ret = int(text)
  except Exception as e:
    ret = 0
  return ret


def pidstr(text):
  ret = ""
  text = text.replace("\n", " ")
  tokens = text.split(" ")
  for token in tokens:
    token = token.strip()
    if token:
      if ret:
        ret += " "
      ret += token
  return ret


def stop_process(cond, sudo=False, sig="9", retry_count=120):
  for n in range(0, retry_count):
    text = runex(cond, assert_ok=False).strip()
    pids = pidstr(text)
    if not pids:
      return
    run("ps --pid " + pids, assert_ok=False)
    if sig == "9":
      cmd = "kill -9 " + pids
    else:
      cmd = "kill -s %s %s" % (sig, pids)
    if sudo:
      cmd = "sudo " + cmd
    run(cmd, assert_ok=False)
    time.sleep(1)
  run("ps auxf")
  fatal("Stop process '%s' fail" % cond)


def utf8_substr(input, start, length):
  if length >= len(input):
    return input
  result = ''
  i = start
  p = start
  flag = True
  rs = start
  while True:
    ch = ord(input[i])
    # 1111110x
    if ch >= 252:
      p = p + 6
      if flag == True:
        rs = p
        flag = False
    # 111110xx
    elif ch >= 248:
      p = p + 5
      if flag == True:
        rs = p
        flag = False
     # 11110xxx
    elif ch >= 240:
      p = p + 4
      if flag == True:
        rs = p
        flag = False
      # 1110xxxx
    elif ch >= 224:
      p = p + 3
      if flag == True:
        rs = p
        flag = False
    # 110xxxxx
    elif ch >= 192:
      p = p + 2
      if flag == True:
        rs = p
        flag = False
    else:
      p = p + 1
    i = p
    if (p - start) >= length:
      break

  return input[start:i]


def __topo_sort_find_first_leaf(lst):
  for key in lst.keys():
    sublst = lst[key]
    if len(sublst) == 0:
      return key
    else:
      ret = __topo_sort_find_first_leaf(sublst)
      if ret:
        return ret
  return ""


def __topo_sort_remove_leaf(lst, input_key):
  if input_key in lst:
    del lst[input_key]
  for key in lst.keys():
    sublst = lst[key]
    __topo_sort_remove_leaf(sublst, input_key)


def find_subtree(root, name, level):
  for key in root.keys():
    subtree = root[key]
    if key.find(name + "/") >= 0:
      return subtree
    else:
      subtree = find_subtree(subtree, name, level + 1)
      if subtree:
        return subtree
  return None


def topo_sort(root):
  input = copy.deepcopy(root)
  ret = []
  while True:
    key = __topo_sort_find_first_leaf(input)
    if not key:
      break
    ret.append(key)
    __topo_sort_remove_leaf(input, key)
  return ret


def runex2(cmds, assert_ok=True, show_log=True):
  cmd = ""
  for x in cmds:
    if cmd:
      cmd += " "
    if " " in x:
      cmd += "\"%s\"" % x
    else:
      cmd += x
  return runex(cmd, assert_ok=assert_ok, show_log=show_log)


class FileLock(object):

  def __init__(self, lock_file):
    if not os.path.exists(lock_file):
      make_dir(os.path.dirname(lock_file))
      run("touch " + lock_file)
    self.lock_file = lock_file
    self.lock_fp = None

  def lock(self, block=True):
    self.lock_fp = open(self.lock_file, "rb")

    if block:
      fcntl.flock(self.lock_fp, fcntl.LOCK_EX)
      return self.lock_fp
    else:
      try:
        fcntl.flock(self.lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return self.lock_fp
      except IOError as e:
        return None

  def unlock(self):
    if not self.lock_fp:
      raise AttributeError("'FileLock' object has no attribute 'lock_fp'")
    fcntl.flock(self.lock_fp, fcntl.LOCK_UN)
    self.lock_fp.close()


def format_duration(n, short_mode=False, min_mode=False, second_placeholder='%.2f'):
  second_part = "%s seconds" % second_placeholder

  if n < 60:
    duration = second_part % n
  if n < 3600:
    duration = ("%d minutes " + second_part) % (n / 60, n % 60)
  else:
    duration = ("%d hours %d minutes " + second_part) % (n / 3600, (n % 3600) / 60, (n % 3600) % 60)

  if short_mode:
    duration = duration.replace("hours", "hour").replace("minutes", "min").replace("seconds", "sec")

  if min_mode:
    duration = duration.replace("hours", "h").replace("minutes", "m").replace("seconds", "s")

  return duration


def rm_make_dir(dir):
  if os.path.exists(dir) or os.path.islink(dir):
    run("rm -rf " + dir)
  make_dir(dir)


def rm_rf(dir):
  if os.path.exists(dir) or os.path.islink(dir):
    run("rm -rf " + dir)


def add_tail_lf(content):
  if len(content) > 0:
    if content[-1] != '\n':
      return content + '\n'
    else:
      return content
  else:
    return '\n'


def safe_cp(src, dst):
  if os.path.islink(dst):
    dst = os.readlink(dst)

  if os.path.exists(dst):
    if os.path.isfile(dst):
      run("rm -f " + dst)
    elif os.path.isdir(dst):
      _, name = os.path.split(src)
      dst = os.path.join(dst, name)
    else:
      fatal("unkonwn file type")

  dst_tmp = dst + "-" + uuid_gen()
  run("cp %s %s" % (src, dst_tmp))
  run("mv %s %s" % (dst_tmp, dst))


def is_elf(path):
  if os.path.getsize(path) <= 4:
    return False

  fp = open(path, "rb")
  header = fp.read(4)
  fp.close()
  return b'\x7fELF' == header


import queue


def parallel_run(inputs, count, func, args=()):
  if len(inputs) <= 0:
    return
  outputs = []
  for i in range(len(inputs)):
    outputs.append(-1)
  # 线程里的异常默认不会传回主线程，这里集中收集，join 后再抛出。
  exceptions = []
  exceptions_lock = threading.Lock()
  q = queue.Queue()
  for i in range(len(inputs)):
    q.put((i, inputs[i]))

  def __entry(q, outputs, func, args):
    while True:
      try:
        # 多线程下 q.empty() 只能做瞬时判断，直接非阻塞取任务更稳。
        i, item = q.get_nowait()
      except queue.Empty:
        break
      running_args = args + (item,)
      try:
        outputs[i] = func(*running_args)
      except BaseException as e:
        # 捕获 BaseException 是为了让 fatal()/SystemExit 这类异常也能回到主线程。
        with exceptions_lock:
          exceptions.append(e)
        break

  threads = []
  for i in range(count):
    thread = threading.Thread(target=__entry, args=(q, outputs, func, args))
    threads.append(thread)
    thread.start()

  for i in range(count):
    threads[i].join()

  # 保持调用方感知失败，避免 worker 异常被静默吞掉。
  if exceptions:
    raise exceptions[0]

  return outputs


def base64_decode(string):
  output = runex("echo %s | base64 -d" % string)
  return output


def split_2_part(content, ch=' '):
  pos = content.find(ch)
  if pos < 0:
    fatal("split_2_part [%s] use [%s] fail" % (content, ch))
  return (content[0:pos], content[pos + 1:])


def batch_replace(str_, map_):
  for k, v in map_.items():
    str_ = str_.replace(k, v)
  return str_


class Git:

  def __init__(self, verbose, dir, assert_ok=True):
    self.__verbose = verbose
    self.__dir = dir
    self.__assert_ok = assert_ok

  def current_branch(self):
    cmd = "cd %s && git rev-parse --abbrev-ref HEAD" % self.__dir
    ret, branch = runex3(cmd, assert_ok=False, show_log=self.__verbose)

    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    if branch == "HEAD":
      if self.__assert_ok:
        fatal("run [%s] fail, get branch [HEAD]")
      return None
    return branch.strip()

  def remote_branch(self):
    cmd = "cd %s && git rev-parse --abbrev-ref --symbolic-full-name @{upstream}" % self.__dir
    ret, content = runex3(cmd, assert_ok=False, show_log=self.__verbose)

    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    return content.strip().replace("origin/", "")

  def top_dir(self):
    cmd = "cd %s && git rev-parse --show-toplevel" % self.__dir
    ret, dir = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    return dir

  def origin_url(self):
    cmd = "cd %s && git remote -v | grep origin | grep fetch | awk '{print $2}'" % self.__dir
    ret, url = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    else:
      return url

  def get_head(self):
    cmd = "cd %s && git rev-parse HEAD" % self.__dir
    ret, rev = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    return rev.strip()

  def is_dirty(self):
    cmd = "cd %s && git status -s" % self.__dir
    ret, content = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    else:
      content = content.strip()
      return content != ""

  def get_diff_content(self, rev):
    cmd = "cd %s && git show %s" % (self.__dir, rev)
    ret, content = runex3(
        cmd, assert_ok=False, show_log=self.__verbose)
    if ret == 0:
      return content
    else:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return "???"

  def latest_revisions(self, count):
    cmd = "cd %s && git log --oneline --no-color -n %d --no-abbrev-commit ." % (self.__dir, count)
    ret, content = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    else:
      return split_ex(content, '\n', lambda line: split_2_part(line))

  def patch_id(self, rev):
    cmd = "cd %s && git show %s | git patch-id --stable|awk '{print $1}'" % (self.__dir, rev)
    ret, content = runex3(cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    else:
      return content.strip()

  def find_remote_branches_of(self, rev):
    cmd = "cd %s && git branch -r --contains %s" % (self.__dir, rev)
    ret, content = runex3(
        cmd, assert_ok=False, show_log=self.__verbose)
    if ret != 0:
      if self.__assert_ok:
        fatal("run [%s] fail, ret %d" % (cmd, ret))
      return None
    else:
      return split_ex(content, '\n', lambda line: line.replace('origin/', ''))


def retry(times, interval):
  def decorator(f):
    def wrap(*args, **kwargs):
      for i in range(times):
        try:
          return f(*args, **kwargs)
        except Exception as e:
          time.sleep(interval)
          warning('Exception: %s, retry time left %s' % (e, times - i - 1))
          continue
      raise Exception('Retried %s times, mission failed.' % times)
    return wrap
  return decorator


def array_remove_null(ss):
  new_arr = []
  for s in ss:
    if s:
      new_arr.append(s)
  return new_arr


def write_file_if_changed(filename, content):
  if os.path.exists(filename):
    content_old = read_file(filename)
    if content_old == content:
      if is_verbose():
        info("update to date - " + filename)
    else:
      write_file(filename, content)
  else:
    write_file(filename, content)


def get_ugdata():
  return os.environ["UGDATA"]


class SmbLocation:
  """SMB URL 解析结果：主机、共享名、共享内路径。"""

  def __init__(self, host, share, remote_path):
    self.host = host
    self.share = share
    self.remote_path = remote_path


def parse_smb_url(url, error_cls=ValueError):
  """解析 smb://host/share/path 或 \\\\host\\share\\path 格式的 SMB 路径。"""
  raw_url = url or ""
  if raw_url.startswith("\\"):
    if "/" in raw_url:
      raise error_cls("smb-url must use either smb://host/share/path or \\\\host\\share\\path")
    parts = [unquote(part) for part in raw_url.split("\\") if part]
    if len(parts) < 3:
      raise error_cls("smb-url must include share and remote path: %s" % url)
    return SmbLocation(parts[0], parts[1], "/".join(parts[2:]))

  parsed = urlparse(raw_url)
  if parsed.scheme != "smb" or not parsed.netloc:
    raise error_cls("smb-url must use either smb://host/share/path or \\\\host\\share\\path")
  if "\\" in parsed.path:
    raise error_cls("smb-url must use either smb://host/share/path or \\\\host\\share\\path")
  parts = [unquote(part) for part in parsed.path.split("/") if part]
  if len(parts) < 2:
    raise error_cls("smb-url must include share and remote path: %s" % url)
  share = parts[0]
  remote_path = "/".join(parts[1:])
  return SmbLocation(parsed.netloc, share, remote_path)


from smb.SMBConnection import SMBConnection

_smb_conn = None


class SambaConnection:
  @staticmethod
  def instance(host):
    global _smb_conn
    if _smb_conn:
      return _smb_conn
    else:
      conn = SambaConnection(host)
      conn.connect()
      _smb_conn = conn
      return conn

  def __init__(self, host):
    self.__init_smb_credential()
    self.__local_ip = runex("hostname -I | awk '{print $1}'")
    self.__host = host
    self.__conn = None

  def __init_smb_credential(self):
    cfile_path = os.path.join(os.environ["HOME"], ".smb-credentials")
    if not os.path.exists(cfile_path):
      fatal(cfile_path + " not found, add a .smb-credentials to ~/ with username=xxx\\npassword=yyy")
    self.__cred = cfile_path
    ct = OrderedDict()
    with open(cfile_path, 'r') as f:
      for line in f:
        line = line.strip()
        tokens = line.split('=')
        if len(tokens) <= 1:
          continue
        if len(tokens) != 2:
          fatal("invalid line: " + line + " in " + cfile_path)
        ct[tokens[0].strip()] = tokens[1].strip()

    if not "username" in ct:
      fatal("username not found in " + cfile_path)
    if not "password" in ct:
      fatal("password not found in " + cfile_path)
    self.__smb_username = ct["username"]
    self.__smb_password = ct["password"]

  def connect(self):
    conn = SMBConnection(
        username=self.__smb_username,
        password=self.__smb_password,
        my_name=self.__local_ip,
        remote_name=self.__host,
        use_ntlm_v2=True
    )

    info("connecting to %s 445 ..." % self.__host)
    conn.connect(self.__host, 445)
    conn.listShares()
    info("connect OK")
    self.__conn = conn

  def exists(self, share_name, path):
    path = os.path.expandvars(path)
    try:
      # pysmb: getAttributes succeeds iff path exists. Old logic used isNormal|isReadonly;
      # (1) typo isReadonly -> AttributeError -> False; (2) isNormal is False for ATTR_ARCHIVE
      # files (typical on Windows/Samba), so real files looked "missing".
      self.__conn.getAttributes(share_name, path)
      return True
    except Exception as ex:
      return False

  def isdir(self, share_name, path):
    try:
      ff = self.__conn.getAttributes(share_name, path)
      return ff.isDirectory
    except Exception as ex:
      return False

  def mkdir(self, share_name, dir_path):
    dir_path = os.path.expandvars(dir_path)
    if self.isdir(share_name, dir_path):
      return

    steps = dir_path.split('/')
    path = ""
    for step in steps:
      if path:
        path += '/'
      path += step
      if not self.exists(share_name, path):
        self.__conn.createDirectory(share_name, path)

    if not self.isdir(share_name, dir_path):
      fatal("mkdir %s/%s fail" % (share_name, dir_path))

  def remove(self, share_name, remote_path, skip_on_fail=False):
    remote_path = os.path.expandvars(remote_path)
    try:
      self.__conn.deleteFiles(share_name, remote_path)
    except Exception as ex:
      if not skip_on_fail:
        raise ex

  def delete_dir_recursive(self, share_name, dir_path):
    dir_path = os.path.expandvars(dir_path)
    conn = self.__conn
    items = conn.listPath(share_name, dir_path)
    for item in items:
      if item.filename in ['.', '..']:
        continue
      full_path = f"{dir_path}/{item.filename}"
      if item.isDirectory:
        self.delete_dir_recursive(share_name, full_path)
      else:
        conn.deleteFiles(share_name, full_path)
    conn.deleteDirectory(share_name, dir_path)

  def upload(self, local_path, share_name, remote_path):
    local_path = os.path.expandvars(local_path)
    remote_path = os.path.expandvars(remote_path)
    cmd = "smbclient //%s/%s" % (self.__host, share_name)
    cmd += " -A " + self.__cred
    smb_cmd = ""
    if os.path.isdir(local_path):
      smb_cmd = "recurse on; prompt off; mkdir " + remote_path + ";"
      smb_cmd += " cd %s; lcd %s; mput *" % (remote_path, local_path)
    else:
      smb_cmd = "put %s %s" % (local_path, remote_path)
    cmd += " -c \"%s\"" % smb_cmd
    run(cmd, show_start_log=True)

  def upload_dir_recursive(self, local_dir, share_name, remote_dir):
    """递归上传本地目录；smbclient 一次会话比 Python 逐文件上传更适合发布大包。"""
    local_dir = os.path.expandvars(local_dir)
    remote_dir = os.path.expandvars(remote_dir)
    if not os.path.isdir(local_dir):
      fatal("upload dir not found: " + local_dir)

    cmd = "smbclient //%s/%s" % (self.__host, share_name)
    cmd += " -A " + self.__cred
    cmd += " -c \"recurse on; prompt off; cd %s; lcd %s; mput *\"" % (remote_dir, local_dir)
    run(cmd, show_start_log=True)

  def mv(self, share_name, a, b):
    a = os.path.expandvars(a)
    b = os.path.expandvars(b)

    if self.exists(share_name, b):
      fatal("%s/%s/%s exists" % (self.__host, share_name, b))
    self.__conn.rename(share_name, a, b)
    info("mv %s %s/%s/%s OK" % (a, self.__host, share_name, b))

  def ls(self, share_name, dir_name):
    dir_name = os.path.expandvars(dir_name)

    try:
      ff = self.__conn.getAttributes(share_name, dir_name)
    except Exception as ex:
      info("ls smb://%s/%s/%s return nothing" % (self.__host, share_name, dir_name))
      return []
    if not ff.isDirectory:
      fatal("%s %s %s is not a directory" % (self.__host, share_name, dir_name))
    files = self.__conn.listPath(share_name, dir_name)
    folders = []
    for smb_folder in files:
      folders.append(smb_folder.filename)
    return folders

  def download(self, share_name, dir_name, local_path):
    dir_name = os.path.expandvars(dir_name)
    local_path = os.path.expandvars(local_path)
    cmd = "smbclient //%s/%s" % (self.__host, share_name)
    cmd += " -A " + self.__cred
    cmd += " -c \"get %s %s\"" % (dir_name, local_path)
    run(cmd, show_start_log=True)

  def download_dir_recursive(self, share_name, remote_dir, local_dir):
    """递归下载 SMB 目录到本地目录。"""
    remote_dir = os.path.expandvars(remote_dir)
    local_dir = os.path.expandvars(local_dir)
    if not os.path.isdir(local_dir):
      fatal("download dir not found: " + local_dir)

    cmd = "smbclient //%s/%s" % (self.__host, share_name)
    cmd += " -A " + self.__cred
    cmd += " -c \"recurse on; prompt off; lcd %s; cd %s; mget *\"" % (local_dir, remote_dir)
    run(cmd, show_start_log=True)

  def size(self, share_name, path):
    path = os.path.expandvars(path)
    try:
      attr = self.__conn.getAttributes(share_name, path)
      return attr.file_size if hasattr(attr, "file_size") else attr.fileSize
    except Exception as e:
      info(f"Failed to get file size for {path}: {e}")
      return 0


import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.utils import format_datetime, formataddr, parseaddr

_smtp_login_info = None


def format_mail_address_header(addrs):
  # 邮件头里的 To/Cc/Bcc 是“展示头”，格式必须是：
  #   =?utf-8?...?= <user@example.com>,
  #       =?utf-8?...?= <other@example.com>
  # 也就是只对中文显示名做 RFC 2047 编码，邮箱地址本身必须保留为
  # <addr@domain>。如果直接把 "中文名 <addr@domain>" 塞给 msg['To']，
  # email 库可能会把整段字符串一起编码，导致邮件头里看不到明文地址。
  ret = []
  for addr in addrs:
    # parseaddr 支持 "显示名 <邮箱>"，返回 (显示名, 邮箱)。
    # 显示名为空或解析失败时保留原始字符串，避免误改纯邮箱地址等合法输入。
    name, email_addr = parseaddr(addr)
    if name and email_addr:
      # formataddr 负责生成标准 address header；Header 只包住显示名，
      # 所以最终会变成 "=?utf-8?...?= <email>"，和常见邮件客户端格式一致。
      ret.append(formataddr((str(Header(name, 'utf-8')), email_addr)))
    else:
      ret.append(addr)
  # 多个收件人按 RFC header continuation 形式折行。
  # 这样 request_for_testing 群发十几个组时，To 头不会挤在一条超长行里。
  return ',\n    '.join(ret)


def format_mail_date_header(now=None):
  if now is None:
    now = datetime.now().astimezone()
  return format_datetime(now)


def send_notify_mail(tos=[], subject="", content="", attachments=None):
  global _smtp_login_info
  # attachments 使用 None 做默认值，避免可变默认参数在多次调用间共享状态。
  if attachments is None:
    attachments = []

  if _smtp_login_info is None:
    conf_file = os.path.join(os.environ["HOME"], ".smtp-credentials")
    if not os.path.exists(conf_file):
      fatal(conf_file + " not found, add a file with host, port, user, password, address in yaml format", )
    _smtp_login_info = load_yaml_f(conf_file)

  host = _smtp_login_info["host"]
  port = _smtp_login_info["port"]
  user = _smtp_login_info["user"]
  password = _smtp_login_info["password"]
  sender = _smtp_login_info["address"]

  if attachments:
    # 有附件时外层必须是 mixed，正文部分仍保持 alternative 的 plain/html 结构。
    msg = MIMEMultipart('mixed')
    body = MIMEMultipart('alternative')
  else:
    msg = MIMEMultipart('alternative')
    body = msg
  text_content = "请查看HTML格式，如果您看到这行文字，说明您的邮件客户端不支持HTML格式。"
  text_part = MIMEText(text_content, 'plain', 'utf-8')
  body.attach(text_part)
  html_content = content
  html_part = MIMEText(html_content, 'html', 'utf-8')
  body.attach(html_part)
  if attachments:
    msg.attach(body)
  msg['From'] = sender
  if len(tos) <= 0:
    fatal("To not found")
  # msg['To'] 是给邮件客户端展示和解析邮件头用的，不等同于 SMTP 实际投递列表。
  # 这里必须保证中文显示名编码正确、邮箱地址保持明文可解析。
  msg['To'] = format_mail_address_header(tos)
  msg['Subject'] = subject
  msg['Date'] = format_mail_date_header()

  # 目前 request_for_testing 只会传 CSV 文本附件，因此这里按 csv 文本类型发送。
  for attachment in attachments:
    path = attachment["path"]
    filename = attachment.get("filename", os.path.basename(path))
    if not os.path.exists(path):
      fatal("mail attachment not found: " + path)
    part = MIMEText(read_file(path), 'csv', 'utf-8')
    part.add_header('Content-Disposition', 'attachment', filename=('utf-8', '', filename))
    msg.attach(part)

  recipients = []
  for to in tos:
    # sendmail 的第二个参数是 SMTP envelope recipients，只需要纯邮箱地址。
    # 即使展示头里有中文显示名，这里也只提取 addr@domain，确保实际投递目标正确。
    _, to_addr = parseaddr(to)
    recipients.append(to_addr)
  body_content = msg.as_string()

  server = smtplib.SMTP_SSL(host, port)
  if is_verbose():
    server.set_debuglevel(1)
  server.login(user, password)
  server.sendmail(user, recipients, body_content)
  server.quit()
  info("%s sendmail to %s [%s] size %d attachments %d OK" %
       (sender, str(tos), subject, len(body_content), len(attachments)))


def hash_str(s, n):
  data = s.encode('utf-8')
  hash_obj = hashlib.sha256(data)
  hash_bytes = hash_obj.digest()
  hash_int = int.from_bytes(hash_bytes, byteorder='big')
  return hash_int % (n + 1)


def tool_set_verbose(tool):
  if tool.get_opt('verbose'):
    os.environ["UG_VERBOSE"] = "1"


_job_count = 0


def get_job_count():
  global _job_count
  if _job_count == 0:
    _job_count = int(runex("nproc"))
    if _job_count > 8:
      _job_count = 8
  return _job_count


def tool_set_job_count(tool):
  jobs = tool.get_opt('job')
  if not jobs:
    jobc = get_job_count()
  else:
    jobc = int(jobs)
  if jobc <= 0:
    jobc = 1
  elif jobc > 128:
    jobc = 128
  info("running job count: " + str(jobc))
  os.environ["UG_NPROC"] = str(jobc)


__current_user_id = None


def try_to_set_file_777(file):
  global __current_user_id
  if not os.path.exists(file):
    return
  if __current_user_id is None:
    __current_user_id = runex("id -u").strip()
  if str(os.stat(file).st_uid) != str(__current_user_id):
    warning("the owner of %s (%s) is not me(%s)" % (file, os.stat(file).st_uid, __current_user_id))
    return
  os.chmod(file, 0o777)


def __get_random_ports(port_file, count, append):
  all_ports = {}
  content = ""

  if os.path.exists(port_file):
    content = read_file(port_file)
    port_mapping = load_json(content)
  else:
    port_mapping = {}

  user = runex("whoami").strip()
  docker_name = os.environ["DOCKER_NAME"]
  this_container_name = user + "_" + docker_name

  if not append and this_container_name in port_mapping:
    del port_mapping[this_container_name]

  ports = []
  socks = []
  base = 10000 + int(random.random() * 100000) % 10000
  for i in range(0, 10000):
    port = base + i
    if port >= 20000:
      port -= 10000
    if port in all_ports:
      continue

    sock = socket.socket()
    try:
      sock.bind(("", port))
    except Exception as e:
      warning("socket bind fail on port %d" % port)
      continue

    port = sock.getsockname()[1]
    socks.append(sock)
    ports.append(port)
    if len(ports) >= count:
      break

  for sock in socks:
    sock.close()
  if len(ports) < count:
    fatal("not enough port")

  if this_container_name in port_mapping:
    port_mapping[this_container_name].extend(ports)
  else:
    port_mapping[this_container_name] = ports

  new_content = dump_json(port_mapping)
  if new_content != content:
    write_file(port_file, new_content)
    try_to_set_file_777(port_file)

  return ports


def get_random_ports(count, append=True):
  port_file = "/dev/shm/ugreen.port_mapping.json"
  lock_file = port_file + ".lock"
  if not os.path.exists(lock_file):
    run("touch " + lock_file)

  lockf = open(lock_file, "rb")
  fcntl.flock(lockf, fcntl.LOCK_EX)
  ret = __get_random_ports(port_file, count, append)
  fcntl.flock(lockf, fcntl.LOCK_UN)
  return ret
