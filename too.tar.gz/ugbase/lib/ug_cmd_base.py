import getopt
import shlex
import sys
from ug_common import fatal, full_stack, info, red, runex, error


class CommandTool(object):
  cmd = ""
  help = ""
  env = {}
  index = {}
  opdesc = []
  enable = True
  self_define = False

  def __check_opdesc(self, cmd, opdesc):
    ch_index = []
    name_index = []
    for op in opdesc:
      ch, name, help, opdefault = op[0:4]
      if ch in ch_index:
        fatal("dupliate [%s] option int %s" % (ch, cmd))
      if name in name_index:
        fatal("dupliate [%s] option int %s" % (name, cmd))

      ch_index.append(ch)
      name_index.append(name)

      if ch == 'h' or name == 'help':
        fatal("-h or --help is used by cmd framework")

  def _init_opdesc(self, opdesc):
    self.opdesc = []
    for op in opdesc:
      if len(op) < 5:
        op_list = list(op)
        op_list.append(None)
        op = tuple(op)
      self.opdesc.append(op)

  def __init__(self, env, cmd, help, opdesc, enable=True, self_define=False):
    opdesc_ = [op[0:4] for op in opdesc]
    self.__check_opdesc(cmd, opdesc_)
    self._init_opdesc(opdesc)

    self.cmd = cmd
    self.help = help
    self.env = env
    self.index = {}
    self.enable = enable
    self.self_define = self_define
    if not self_define:
      self.opdesc.append(('h', 'help', 'show help', False))

  def optch2opt(self, optch):
    for op in self.opdesc:
      if op[0] == optch:
        return op[1]
    return None

  def build_index(self):
    for op in self.opdesc:
      self.index[op[1]] = op

  def get_targets(self):
    return self.env.args

  def has_opt(self, name):
    return name in self.index

  def get_opt(self, name):
    if not name in self.index:
      fatal("OPTION [" + name + "] does not exist")

    op = self.index[name]
    opdef = op[3]
    name = "--" + name
    if type(opdef) == bool:
      return name in self.env.opts

    if name in self.env.opts:
      return self.env.opts[name]
    return opdef

  def get_optdesc_obj(self, name):
    if not name in self.index:
      fatal("OPTION [" + name + "] does not exist")

    return self.index[name][4]

  def get_opts(self, name):
    if not name in self.index:
      fatal("OPTION [" + name + "] does not exist")

    op = self.index[name]
    opdef = op[3]
    name = "--" + name
    if type(opdef) == bool:
      return [name in self.env.opts]

    if name in self.env.opts_multiple:
      return self.env.opts_multiple[name]
    else:
      return [opdef]


def show_opt_help(cmd):
  for op in cmd.opdesc:
    ch, name, help, opdefault = op[0:4]
    text = "    %-20s %s" % ("-" + ch + " --" + name, help.replace("\n", "\n                         "))
    if opdefault:
      text += " [default: %s]" % str(opdefault)
    print(text, file=sys.stderr)


def __show_cmd_help(cmds, key, show_opt):
  cmd = cmds[key]
  if show_opt:
    print("", file=sys.stderr)
  print("  %-20s " % cmd.cmd + cmd.help, file=sys.stderr)
  if show_opt:
    show_opt_help(cmd)


def show_help(env, ver, show_opt=True):
  print(ver, file=sys.stderr)
  print("Usage: " + env.cmdname + " COMMAND [OPTIONS] [TARGETS]", file=sys.stderr)
  print("COMMAND can be:", file=sys.stderr)
  print("  %-20s show all help" % "help", file=sys.stderr)
  print("  %-20s show the detail of the COMMAND" % "help COMMAND", file=sys.stderr)

  cmds = {}
  for cmd in env.cmds:
    if not cmd.enable:
      continue
    cmds[cmd.cmd] = cmd
  lst = sorted(cmds.keys())
  # env.cmd_help_list = ['bar', 'foo'], can show a help command list by user-defined order
  if hasattr(env, "cmd_help_list"):
    for key in env.cmd_help_list:
      if not key in lst:
        fatal(key + " NOT FOUND")
      __show_cmd_help(cmds, key, show_opt)
      lst.remove(key)

  for key in lst:
    __show_cmd_help(cmds, key, show_opt)


def show_cmd_help(env, command, ver):
  print(ver, file=sys.stderr)
  print("Usage: " + env.cmdname + " COMMAND [OPTIONS] [TARGETS]", file=sys.stderr)
  print("COMMAND:", file=sys.stderr)
  for cmd in env.cmds:
    if cmd.cmd == command:
      print("  %-20s %s" % (cmd.cmd, cmd.help), file=sys.stderr)
      show_opt_help(cmd)
      return
    else:
      continue
  print("  Unknown COMMAND" + command, file=sys.stderr)


def get_opt_define(cmd):
  ret = ""
  for op in cmd.opdesc:
    ch, name, help, opdefault = op[0:4]
    if type(opdefault) == bool:
      ret += "-" + ch
    else:
      ret += "-" + ch + ":"
  return ret


def get_long_opt_define(cmd):
  ret = []
  mapping = {}
  for op in cmd.opdesc:
    ch, name, help, opdefault = op[0:4]
    if type(opdefault) == bool:
      ret.append(name)
    else:
      ret.append(name + "=")
    mapping["-" + ch] = "--" + name

  return (ret, mapping)


def __getopt_split(argv):
  argv1 = []
  argv2 = []

  flag = False
  for arg in argv:
    if flag:
      argv2.append(arg)
    else:
      if arg == "--":
        flag = True
      else:
        argv1.append(arg)
  return (argv1, argv2)


def __getopt_ex(argv, short_opts, long_opts):
  ret_opts = []
  ret_args = []
  flag = False
  index = 0

  (argv, argv_targets) = __getopt_split(argv)

  while index < len(argv):
    opts, args = getopt.getopt(argv[index:], short_opts, long_opts)
    ret_opts.extend(opts)
    if flag:
      ret_args.extend(args)
      break
    else:
      found = False
      for arg in args:
        if len(arg) > 0 and arg[0:1] == '-':
          for i in range(index, len(argv)):
            if argv[i] == arg:
              index = i
              found = True
              break
          if found:
            break
          else:
            fatal(arg + " not found in " + str(argv) + " on index " + index)
        else:
          ret_args.append(arg)
      if not found:
        break
  ret_args.extend(argv_targets)
  return (ret_opts, ret_args)


def check_default_not_none(env):
  ok = True
  for op in env.cmd.opdesc:
    ch, name, help, default = op[0:4]
    if not "--" + name in env.opts:
      if default is None:
        error("necessary parameter is missing: -%s --%s %s" % (ch, name, help))
        ok = False
  if not ok:
    sys.exit(1)


def __check_cmd(cmd):
  _cmd = cmd.strip().replace('-', '')
  if _cmd in {"help", "h"}:
    return False
  return True


def run_tool(env, cmdname, ver, plugin="plugin"):
  env.cmdname = cmdname
  if len(sys.argv) > 1 and __check_cmd(cmd=sys.argv[1]):
    inputcmd = sys.argv[1]
    content = runex("grep .CommandTool.__init__ %s/%s/*.py -H" % (sys.path[0], plugin) +
                    "|grep -F " + shlex.quote('"' + inputcmd + '"') +
                    "|awk -F \\: '{print $1}'")
  else:
    content = runex("find " + sys.path[0] + "/%s -type f -name \"*.py\"" % plugin)
  lines = content.split("\n")

  for line in lines:
    line = line.strip()
    if not line:
      continue
    pos = line.rfind("/")
    filename = line
    if pos >= 0:
      filename = line[pos + 1:]
    module = filename.replace(".py", "")
    try:
      namespace = {}
      namespace["env"] = env
      exec("import " + module + "\ncmd=" + module + ".Tool(env)", namespace)
      cmd = namespace["cmd"]
      cmd.build_index()
      env.cmds.append(cmd)
    except Exception as e:
      print("import " + module + red(" FAIL:") + str(e), file=sys.stderr)
      print(full_stack(), file=sys.stderr)

  if len(sys.argv) < 2:
    show_help(env, ver, show_opt=False)
    return 1
  if len(sys.argv[1]) <= 0 or sys.argv[1][0:1] == "-":
    show_help(env, ver, show_opt=False)
    return 2
  inputcmd = sys.argv[1]

  if inputcmd == "help":
    if len(sys.argv) >= 3:
      show_cmd_help(env, sys.argv[2], ver)
    else:
      show_help(env, ver)
    return 0

  for cmd in env.cmds:
    if cmd.cmd == inputcmd:
      if cmd.self_define:
        return cmd.main()

      (long_opts, mapping) = get_long_opt_define(cmd)
      opts, args = __getopt_ex(sys.argv[2:], get_opt_define(cmd), long_opts)
      for (opt, _) in opts:
        if opt == "-h" or opt == "--help":
          show_cmd_help(env, cmd.cmd, ver)
          return 1
      optsdict = {}
      optsdict_multiple = {}
      # mapping {'-d' : 'depth'}
      for (name, val) in opts:
        if name in mapping:
          name = mapping[name]
        optsdict[name] = val
        if not name in optsdict_multiple:
          optsdict_multiple[name] = []
        optsdict_multiple[name].append(val)
      env.opts = optsdict
      env.opts_multiple = optsdict_multiple
      env.args = args
      env.cmd = cmd
      check_default_not_none(env)
      return cmd.main()
  fatal("Unknown COMMAND: " + inputcmd)
