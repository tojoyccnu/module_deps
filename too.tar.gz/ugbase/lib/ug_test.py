import os
import shlex

from ug_common import make_dir, run


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def run_ugbt(project_dir, command, isolate=False, home=None, use_project_ugdata=True, extra_env=None):
  project_dir = str(project_dir)
  env = []
  unset_env = ""
  if isolate:
    cache_dir = os.path.join(project_dir, "ugreen_build", "cache")
    home = str(home or os.path.join(project_dir, "ugreen_build", "home"))
    make_dir(home)
    env = [
        "BRANCH=master",
        "HOME=%s" % shlex.quote(home),
        "PATH=%s:$PATH" % shlex.quote(PROJECT_ROOT),
        "XDG_CACHE_HOME=%s" % shlex.quote(cache_dir),
        "GOCACHE=%s" % shlex.quote(os.path.join(cache_dir, "go-build")),
        "GOMODCACHE=%s" % shlex.quote(os.path.join(cache_dir, "go-mod")),
        "CCACHE_DISABLE=1",
        "CC=gcc",
        "CXX=g++",
        "GITLAB_USER_LOGIN=ugbt-test",
        "CI_PIPELINE_URL=http://example.com/ugbt-test",
    ]
    if use_project_ugdata:
      ugdata = os.path.join(project_dir, "ugreen_build", ".ugreen.tmp")
      env.extend([
          "UGDATA=%s" % shlex.quote(ugdata),
          "LOCAL_REPO=%s" % shlex.quote(os.path.join(ugdata, "repo")),
      ])
    unset_env = "-u UGDATA -u LOCAL_REPO "

  if extra_env:
    env.extend("%s=%s" % (key, shlex.quote(str(value))) for key, value in extra_env.items())
  env_cmd = "env %s%s" % (unset_env, " ".join(env)) if unset_env or env else ""
  cmd = "cd %s && %s %s %s" % (
      shlex.quote(project_dir),
      env_cmd,
      shlex.quote(os.path.join(PROJECT_ROOT, "ugbt")),
      command,
  )
  return run(cmd, assert_ok=False)


def init_git_repo(project_dir, remote, branch=None):
  project_dir = str(project_dir)
  init_branch = "-b %s " % shlex.quote(branch) if branch else ""
  commands = [
      "git init %s%s" % (init_branch, shlex.quote(project_dir)),
      "git -C %s config user.email test@example.com" % shlex.quote(project_dir),
      "git -C %s config user.name test" % shlex.quote(project_dir),
      "git -C %s remote add origin %s" % (shlex.quote(project_dir), shlex.quote(remote)),
      "git -C %s add ." % shlex.quote(project_dir),
      "git -C %s commit -m init" % shlex.quote(project_dir),
  ]
  for command in commands:
    assert run(command, assert_ok=False) == 0
