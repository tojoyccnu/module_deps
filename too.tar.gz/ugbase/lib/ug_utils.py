from collections import OrderedDict
import copy
import csv
import html
import io
import os
import re
import fcntl
import time
import xmltodict

from ug_build_platform import BuildPlatform
from urllib.parse import urlparse
from ug_common import Git, SambaConnection, array_remove_null, dump_json, env_is_true, get_ugdata, hash_str, is_verbose, load_json_f, parallel_run, parse_smb_url, read_file, send_notify_mail, sort_dict, write_file_if_changed, whoami
from ug_common import dump_yaml, fatal, load_yaml_f, make_dir, run, runex, \
    write_file, uuid_gen, info, error, md5, warning


def short_git(git_url):
  git_url = git_url.replace("ssh://git@gitlab.ugnas.com/", "gitlab.ugnas.com/").replace(".git", "")
  git_url = git_url.replace("ssh://git@gitlab-frontend.ugreencloud.com/", "gitlab-frontend.ugreencloud.com/")
  git_url = git_url.replace("https://" + GS.PROXY_PREFIX, "")
  return git_url


def is_remote_repo(name):
  return name.startswith("frontend") or name.startswith("media")


def beta_default_tools_dir(home=None):
  home = home or os.environ.get("HOME", "~")
  return os.path.expanduser(os.path.join(home, "tools"))


def beta_normalize_mode(mode):
  mode = (mode or "").strip().lower()
  if mode not in ("ga", "beta"):
    fatal("mode must be ga or beta: %s" % mode)
  return mode


def beta_is_release_branch(part):
  prefix = "release_"
  return len(part) >= len(prefix) + 8 and part.startswith(prefix) and part[-8:].isdigit()


def beta_release_branch_index(parts):
  index = len(parts) - 3
  if index >= 0 and beta_is_release_branch(parts[index]):
    return index
  return -1


def beta_resolve_package_type(smb_url):
  location = parse_smb_url((smb_url or "").strip())
  parts = [part for part in location.remote_path.split("/") if part]
  if "image" in parts:
    return "firmware"
  return "suite"


def get_clean_git_url(url):
  lines = url.split('\n')
  for line in lines:
    line = line.strip()
    if line:
      url = line
      if url.startswith("git@"):
        url = "ssh://" + url
        url = url.replace(".com:", ".com/")
      url = url.replace(".git", "")
      parsed_url = urlparse(url)
      host = parsed_url.netloc.split('@')[-1]
      if host == "gitlab.ugnas.com":
        ret = "ssh://git@%s%s.git" % (host, parsed_url.path)
      else:
        if GS.PROXY_PREFIX in url:
          ret = "https://%s%s" % (host, parsed_url.path)
        else:
          ret = "https://%s%s%s" % (GS.PROXY_PREFIX, host, parsed_url.path)
      ret = ret.replace("gitlab.ugnas.com/firmware/scm/ugbase.git", "gitlab.ugnas.com/scm/ugbase.git")
      ret = ret.replace("gitlab.ugnas.com/firmware/scm/ugbase.git", "gitlab.ugnas.com/scm/ugbase.git")
      return ret
  fatal("??")


_users = None
_users_gitlab = None


def search_dev_user_by_gitlab(env, input_gitlab_user):
  global _users
  global _users_gitlab
  if _users is None:
    _users = load_yaml_f(os.path.join(env.root, "dev", "users.yaml"))
    _users_gitlab = OrderedDict()
    for email in _users.keys():
      user = _users[email]
      user["email"] = email
      if user.get("gitlab", ""):
        gitlab_user = user["gitlab"]
        _users_gitlab[gitlab_user] = user
  return _users_gitlab.get(input_gitlab_user, None)


def format_git_url(url):
  return get_clean_git_url(url)


def parse_git_branch_rev(text):
  tokens = text.split(' ')
  if len(tokens) != 3:
    fatal("invalid git + branch + rev text: " + text)
  url = tokens[0].strip()
  url = format_git_url(url)
  if not url:
    fatal("url is empty")
  branch = tokens[1].strip()
  if not branch:
    fatal("branch is empty")
  revision = tokens[2].strip()
  if not revision:
    fatal("revision is empty")
  return (url, branch, revision)


class GS:
  AMD64 = "amd64"
  ARCH_SPU = "arch_spu"
  ARM64 = "arm64"
  BOTH = "both"
  BRANCH = "branch"
  BUILD = "build"
  BUILD_DIR = "ugreen_build"
  BUILD_TYPE = "build_type"
  BUILLD_OUTPUT = "BUILD_OUTPUT"
  CLEAN = "clean"
  CMAKE = "cmake"
  CPU_ARCH = "cpu_arch"
  DEFAULT = "default"
  DEPEND_FW_VERSION = "depend-fw-version"
  DEPS = "deps"
  DEPS_TREE_FILE = "deps_tree.md"
  DEV = "dev"
  DIR = "dir"
  ENV = "env"
  FEATURE = "feature"
  FILENAME = "ugreen_project.yaml"
  FILES = "files"
  FORMAT = "format"
  GO_INSTALL = "go-install"
  GO_MOD = "go.mod"
  INSTALL = "install"
  INTEL = "intel"
  KERNEL = "kernel"
  LOCKED = "locked"
  MODULES = "modules"
  NAME = "name"
  OTA_TYPE = "ota-type"
  OUTPUT = "output"
  OUTPUT = "output"
  PACK = "pack"
  PLATFORM = "platform"
  PREPARE = "prepare"
  PRODUCT_SERIES = "product_series"
  PROXY_PREFIX = "ghproxy.cfd/https://"
  RAW = "raw"
  RELEASE = "release"
  RELEASE_NAME = "release-name"
  REPO = "repo"
  REV = "rev"
  RK3576 = "rk3576"
  RK3588 = "rk3588"
  SCHEMA_VERSION = "schema-version"
  STABLE = "stable"
  TEMPLATE = "template"
  TEST = "test"
  TGZ = "tgz"
  UGBASE = "ugbase"
  # UGTOOLS = "ugtools"
  # UGTOOLS_UPK = "ugtools-upk"
  UPLOAD = "upload"
  V1 = "v1"
  V2 = "v2"
  VERSION = "version"
  VERSIONS = "versions"
  VERSION_REF = "version-ref"


class Repo:
  __project_branches_cache = {}
  __project_paths_cache = {}
  __yaml_cache = {}

  def __init__(self, workspace):
    self.__workspace = os.path.abspath(os.path.expandvars(workspace))
    self.__project_list = os.path.join(self.__workspace, ".repo", "project.list")
    self.__manifests_dir = os.path.join(self.__workspace, ".repo", "manifests")
    self.__manifest_file = os.path.join(self.__manifests_dir, "default.xml")

  @staticmethod
  def find(project_root, assert_found=True):
    path = os.path.abspath(os.path.expandvars(project_root))
    while True:
      if os.path.isdir(os.path.join(path, ".repo")):
        return Repo(path)
      parent = os.path.dirname(path)
      if parent == path:
        if assert_found:
          fatal("repo workspace not found for project: %s" % project_root)
        return None
      path = parent

  def get_workspace(self):
    return self.__workspace

  def get_project_path(self, project_root):
    project_path = os.path.relpath(os.path.abspath(project_root), self.__workspace)
    if project_path not in self.read_project_paths():
      fatal("project not found in repo workspace: %s" % project_root)
    return project_path

  def load_build_metadata(self, project_root):
    project_path = self.get_project_path(project_root)
    building_file = os.path.join(self.__manifests_dir, "building.yaml")
    version_file = os.path.join(self.__manifests_dir, "building.version.yaml")
    for path in [building_file, version_file]:
      if path not in Repo.__yaml_cache:
        if not os.path.isfile(path):
          fatal("repo building manifest not found: %s" % path)
        Repo.__yaml_cache[path] = load_yaml_f(path)

    building = Repo.__yaml_cache[building_file]
    if project_path not in building:
      fatal("project not found in repo building manifest: %s" % project_path)
    return project_path, building[project_path], Repo.__yaml_cache[version_file]

  def read_project_paths(self, assert_project_exists=False):
    if self.__project_list not in Repo.__project_paths_cache:
      if not os.path.isdir(self.__workspace):
        fatal("repo workspace not found: %s" % self.__workspace)
      if not os.path.isfile(self.__project_list):
        fatal("repo project list not found: %s" % self.__project_list)
      paths = set()
      for line in read_file(self.__project_list).splitlines():
        line = line.strip()
        if line:
          paths.add(line)
      Repo.__project_paths_cache[self.__project_list] = paths

    paths = Repo.__project_paths_cache[self.__project_list]
    if assert_project_exists:
      for path in paths:
        project_path = os.path.join(self.__workspace, path)
        if not os.path.isdir(project_path):
          fatal("repo project not found: %s" % project_path)
    return paths

  def __get_revision_branch(self, revision):
    revision = revision.strip()
    if not revision:
      fatal("repo manifest revision is empty: %s" % self.__manifest_file)
    prefix = "refs/heads/"
    if revision.startswith(prefix):
      revision = revision[len(prefix):]
    return revision

  def __load_project_branches(self):
    if self.__manifest_file in Repo.__project_branches_cache:
      return Repo.__project_branches_cache[self.__manifest_file]
    if not os.path.isfile(self.__manifest_file):
      fatal("repo manifest not found: %s" % self.__manifest_file)

    manifest = xmltodict.parse(read_file(self.__manifest_file))["manifest"]
    default_revision = manifest.get("default", {}).get("@revision", "").strip()
    projects = manifest.get("project", [])
    if isinstance(projects, dict):
      projects = [projects]

    project_branches = {}
    for project_node in projects:
      repo_path = project_node.get("@path", project_node.get("@name", "")).strip()
      if not repo_path:
        fatal("repo manifest project path is empty: %s" % self.__manifest_file)
      revision = project_node.get("@revision", default_revision).strip()
      if not revision:
        fatal("repo manifest project revision not found: %s" % repo_path)
      project_branches[repo_path] = self.__get_revision_branch(revision)
    Repo.__project_branches_cache[self.__manifest_file] = project_branches
    return project_branches

  def get_project_branch(self, repo_path):
    project_branches = self.__load_project_branches()
    if repo_path not in project_branches:
      fatal("repo manifest project not found: %s" % repo_path)
    return project_branches[repo_path]


def init_ugdata(project_root, home):
  ugdata = os.environ.get("UGDATA", "")
  if not ugdata:
    repo = Repo.find(project_root, assert_found=False)
    data_root = repo.get_workspace() if repo else home
    ugdata = os.path.join(data_root, ".ugreen.tmp")
  os.environ["UGDATA"] = os.path.abspath(os.path.expanduser(os.path.expandvars(ugdata)))
  if not os.environ.get("LOCAL_REPO", ""):
    os.environ["LOCAL_REPO"] = os.path.join(os.environ["UGDATA"], "repo")


def parse_git_log(content):
  lst = []
  commit = ""
  item = None
  lines = content.split('\n')
  for line in lines:
    if line.startswith("commit "):
      commit = line.split(' ')[-1].strip()
      item = OrderedDict()
      item["commit"] = commit
      lst.append(item)
    elif line.startswith("Merge: "):
      if item:
        item["Merge"] = line.replace("Merge: ", "").strip()
    elif line.startswith("Date: "):
      if item:
        item["Date"] = line.replace("Date: ", "").strip()
    elif line.startswith("Author: "):
      if item:
        item["Author"] = line.replace("Author: ", "").strip()
    else:
      if item:
        line = line.strip()
        if line:
          if not "Title" in item:
            item["Title"] = line
          else:
            item["Title"] += "\n" + line
  ret_lst = []
  for item in lst:
    if "Merge" in item:
      continue
    title = item.get("Title", "")
    if "[skip ci]" in title:
      continue
    if "auto ugbt update" in title:
      continue
    ret_lst.append(item)
  return ret_lst


def _git_rev_log(env, git, rev):
  f = env.get_temp_file()
  cmd = "ugbt lock_git_run -u %s -c -o %s" % (git, f)
  cmd += " -- git log --no-color -1 " + rev
  run(cmd)

  content = read_file(f)
  lst = parse_git_log(content)
  ret = OrderedDict()
  for commit in lst:
    commit_id = commit["commit"]
    del commit["commit"]
    short_git_url = short_git(git)
    ret[short_git_url + " " + commit_id] = commit
  return ret


def _diff_git(env, git_new, rev_new, git_old, rev_old):
  mod_diff = OrderedDict()
  mod_diff["right"] = OrderedDict()
  mod_diff["left"] = OrderedDict()
  if git_new != git_old:
    mod_diff["type"] = "new"
    mod_diff["desc"] = "git change from %s to %s" % (git_new, git_old)
    mod_diff["right"][short_git(git_new) + " " + rev_new] = _git_rev_log(env, git_new, rev_new)
    mod_diff["left"][short_git(git_old) + " " + rev_old] = _git_rev_log(env, git_old, rev_old)
  elif rev_new == rev_old:
    mod_diff["type"] = "no-change"
    mod_diff["desc"] = "rev " + rev_new
  else:
    mod_diff["type"] = "changed"
    mod_diff["desc"] = "rev %s <- %s" % (rev_new, rev_old)
    f1 = env.get_temp_file()
    f2 = env.get_temp_file()
    diff_cmd = "ugbt lock_git_run -u " + git_new + " -c -o %s"
    diff_cmd += " -- git log --no-color %s"
    diff_cmd += " %s...%s" % (rev_old, rev_new)

    run(diff_cmd % (f1, "--left-only"))
    lcontent = read_file(f1)
    lst = parse_git_log(lcontent)
    info("parse git log %d" % len(lst))
    for item in lst:
      commit = item["commit"]
      del item["commit"]
      mod_diff["left"][short_git(git_new) + " " + commit] = item

    run(diff_cmd % (f2, "--right-only"))
    rcontent = read_file(f2)
    lst = parse_git_log(rcontent)
    info("parse git log %d" % len(lst))

    for item in lst:
      commit = item["commit"]
      del item["commit"]
      short_git_url = short_git(git_new)
      mod_diff["right"][short_git_url + " " + commit] = item
  return mod_diff


def _attach_diff(res, mod, ver, new_diff):
  sides = ["left", "right"]
  mod = mod.replace(GS.PROXY_PREFIX, "")
  for side in sides:
    if side in new_diff:
      for k in new_diff[side]:
        if not side in res:
          res[side] = OrderedDict()
        if k in res[side]:
          res[side][k]["mod"].append(mod + " " + ver)
        else:
          res[side][k] = copy.deepcopy(new_diff[side][k])
          res[side][k]["mod"] = [mod + " " + ver]


def _go_mod_remove_comment(line):
  pos = line.find('//')
  if pos >= 0:
    return line[0:pos].strip()
  else:
    return line.strip()


def load_go_mod(file):
  content = read_file(file)
  lines = content.split('\n')
  mod = OrderedDict()
  mod["deps"] = OrderedDict()
  state = 0
  for line in lines:
    line = _go_mod_remove_comment(line)
    if line:
      if state == 0:
        if line.startswith("module "):
          mod["module"] = line.split()[-1]
        elif line.startswith("go "):
          mod["go"] = line.split()[-1]
        elif line.startswith("require "):
          state = 1
      elif state == 1:
        if line == ")":
          state = 0
        else:
          tokens = line.split()
          if len(tokens) != 2:
            fatal("unrecognized line: " + line)
          mod_name = tokens[0].strip()
          # if mod_name.startswith("github.com/") or \
          if mod_name.startswith("gitlab.ugnas.com"):
            mod["deps"][mod_name] = tokens[1].strip()
          else:
            # warning("TODO, can not hold %s ..." % mod_name)
            continue
  return mod


def load_go_mod_deps(file: str) -> dict[str, dict[str, str]]:
  if not os.path.exists(file):
    return {}

  result = {
      "direct": {},
      "indirect": {}
  }

  in_require_block = False
  in_require_line = False

  content = read_file(file)
  lines = content.split('\n')
  for line in lines:
    line = line.strip()
    # 跳过空行和注释行
    if not line or line.startswith("//"):
      continue
    # 检查是否进入require块
    if line.startswith("require ("):
      in_require_block = True
      continue
    elif line == ")":
      in_require_block = False
      continue
    elif line.startswith("require ") and not line.startswith("require ("):
      # 单行require声明，继续处理这一行，格式如：require github.com/gin-gonic/gin v1.11.0
      in_require_line = True
      line = line.replace("require ", "")

    if (in_require_block or in_require_line) and line.startswith('gitlab.ugnas.com/'):
      parts = line.split()
      if len(parts) == 2:  # 直接依赖
        result["direct"][parts[0]] = parts[1]
      elif len(parts) in [3, 4]:  # 间接依赖，以//indirect或// indirect结尾
        result["indirect"][parts[0]] = parts[1]

    if in_require_line:
      in_require_line = False
  return result


def go_module_to_git_url(mod_name):
  """将 Go module 路径转换为 git URL。
  对于 gitlab.ugnas.com，git 仓库路径为 host/group/repo（2层），
  更深的路径段为仓库内子包，不应包含在 git URL 中。
  例：gitlab.ugnas.com/library/go-agents/llmorganizer
       -> ssh://git@gitlab.ugnas.com/library/go-agents.git
  """
  parts = mod_name.split('/')
  host = parts[0]
  if host == 'gitlab.ugnas.com' and len(parts) > 3:
    mod_name = '/'.join(parts[:3])
  return get_clean_git_url("ssh://git@" + mod_name + ".git")


def _go_module_git_rev_candidates(mod_name, version):
  candidates = [version]
  parts = mod_name.split('/')
  # Go module 可以位于一个 GitLab 仓库的子目录里，tag 通常会带子目录前缀。
  # 例如 module .../go-agents/llmorganizer v1.0.3 对应的 git ref 可能是
  # llmorganizer/v1.0.3，而不是仓库根部的 v1.0.3。
  if (parts[0] == 'gitlab.ugnas.com' and len(parts) > 3 and
          re.match(r"^v\d+\.\d+\.\d+", version)):
    candidates.append('/'.join(parts[3:]) + "/" + version)
    if re.match(r"^v\d+$", parts[-1]) and len(parts) > 4:
      candidates.append('/'.join(parts[3:-1]) + "/" + version)
  return list(OrderedDict.fromkeys(candidates))


def go_module_version_to_git_rev(mod_name, version, git_rev_exists=None):
  # Pseudo version 的最后一段就是 commit hash，不能按普通 semver tag 处理。
  pseudo_match = re.match(
      r"^v\d+\.\d+\.\d+.*[.-]\d{14}-([0-9a-fA-F]+)$",
      version,
  )
  if pseudo_match:
    return pseudo_match.group(1)

  candidates = _go_module_git_rev_candidates(mod_name, version)
  if git_rev_exists is not None:
    for rev in candidates:
      if git_rev_exists(rev):
        return rev
  return candidates[1] if len(candidates) > 1 else candidates[0]


def _git_rev_exists(env, git, rev, rev_exists_cache):
  key = (git, rev)
  if key in rev_exists_cache:
    return rev_exists_cache[key]
  output_file = env.get_temp_file()
  cmd = "ugbt lock_git_run -u %s -c -o %s -- git rev-parse --verify --quiet %s^{commit}" % (
      git, output_file, rev)
  rev_exists_cache[key] = run(cmd, assert_ok=False, show_log=False) == 0
  return rev_exists_cache[key]


def _resolve_go_module_git_rev(env, git, mod_name, version, rev_exists_cache):
  return go_module_version_to_git_rev(
      mod_name,
      version,
      lambda rev: _git_rev_exists(env, git, rev, rev_exists_cache),
  )


def find_request_for_testing_manifest_files(version_path_full):
  if not os.path.isdir(version_path_full):
    fatal("固件包本地目录不存在，无法生成提测邮件: %s。请先确认固件包已成功打包并上传到 SMB。" %
          version_path_full)

  manifest_files = []
  for root, _, files in os.walk(version_path_full):
    # version_path_full 本身通常在 ~/.ugreen.tmp 下，不能因为绝对路径包含
    # ".tmp" 就过滤整棵目录；这里只跳过固件目录内部的临时平台目录。
    rel_root = os.path.relpath(root, version_path_full)
    rel_root_parts = [] if rel_root == "." else rel_root.split(os.sep)
    if any(part.endswith(".tmp") for part in rel_root_parts):
      continue
    for name in files:
      if not name.endswith(".manifest.yaml"):
        continue
      full_path = os.path.join(root, name)
      manifest_files.append(os.path.relpath(full_path, version_path_full))

  manifest_files.sort()
  if len(manifest_files) <= 0:
    fatal("固件包目录没有找到 manifest 文件，无法生成提测邮件: %s" % version_path_full)
  return manifest_files


def _warmup_go_mod_git_cache(git, warmed_git_urls):
  if git in warmed_git_urls:
    return
  warmed_git_urls.add(git)
  # diff-manifest 为了性能会带 UG_LOCK_GIT_NO_CLEAN=1，但 go.mod 里可能引用
  # manifest 预热阶段没有覆盖到的仓库，这里先单独刷新一次。
  run("UG_LOCK_GIT_NO_CLEAN=0 UG_LOCK_GIT_NO_UPDATE=0 ugbt lock_git_run -u %s -- true" % git,
      show_start_log=True)


def diff_go_mods(env, file_new, file_old):
  go_mod_new = load_go_mod(file_new)
  go_mod_old = load_go_mod(file_old)

  mod_key_set_old = set(list(go_mod_old["deps"].keys()))
  mod_key_set_new = set(list(go_mod_new["deps"].keys()))
  warmed_git_urls = set()
  rev_exists_cache = {}

  res = OrderedDict()

  for mod_name in mod_key_set_old - mod_key_set_new:
    git = go_module_to_git_url(mod_name)
    _warmup_go_mod_git_cache(git, warmed_git_urls)
    rev_old = _resolve_go_module_git_rev(
        env, git, mod_name, go_mod_old["deps"][mod_name].strip(), rev_exists_cache)
    mod_diff = OrderedDict()
    mod_diff["right"] = OrderedDict()
    mod_diff["left"] = _git_rev_log(env, git, rev_old)
    _attach_diff(res, mod_name, rev_old, mod_diff)

  for mod_name in mod_key_set_old.intersection(mod_key_set_new):
    git = go_module_to_git_url(mod_name)
    rev_new = _resolve_go_module_git_rev(
        env, git, mod_name, go_mod_new["deps"][mod_name].strip(), rev_exists_cache)
    rev_old = _resolve_go_module_git_rev(
        env, git, mod_name, go_mod_old["deps"][mod_name].strip(), rev_exists_cache)
    if rev_new != rev_old:
      _warmup_go_mod_git_cache(git, warmed_git_urls)
      mod_diff = _diff_git(env, git, rev_new, git, rev_old)
      _attach_diff(res, mod_name, rev_new, mod_diff)

  for mod_name in mod_key_set_new - mod_key_set_old:
    git = go_module_to_git_url(mod_name)
    _warmup_go_mod_git_cache(git, warmed_git_urls)
    rev_new = _resolve_go_module_git_rev(
        env, git, mod_name, go_mod_new["deps"][mod_name].strip(), rev_exists_cache)
    info("right: " + mod_name)
    mod_diff = OrderedDict()
    mod_diff["right"] = _git_rev_log(env, git, rev_new)
    mod_diff["left"] = OrderedDict()
    _attach_diff(res, mod_name, rev_new, mod_diff)
  return res


class ManifestLoader:
  _instance = None

  def __init__(self):
    self.__cache = {}

  @staticmethod
  def instance():
    if ManifestLoader._instance is None:
      ManifestLoader._instance = ManifestLoader()
    return ManifestLoader._instance

  def find_pre_versions(self, env, proj, manifest_path, count=1000):
    manifest_dir = os.path.basename(os.path.dirname(manifest_path))
    platform = BuildPlatform.parse(env, manifest_dir)
    "release_20250820-firmware_ugreen_pkg-1.8.0.16-all.manifest.yaml"
    manifest_file = os.path.basename(manifest_path)
    "release_20250820-firmware_ugreen_pkg-1.8.0.16-all"
    ss = manifest_file.replace(".manifest.yaml", "")
    ss = ss.replace("-" + platform.get_sorted_short_str(), "")
    "release_20250820-firmware_ugreen_pkg-1.8.0.16"
    version_and_build_numver = ss.split("-")[-1]
    v = version_and_build_numver.split('.')

    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]

    build_number_dir = os.path.dirname(proj.get_install_path())
    info("build_dir: %s" % build_number_dir)
    version_dir = os.path.dirname(build_number_dir)
    version_path = os.path.join(repo_root, version_dir)
    verion_path_full = "smb://%s/%s/%s" % (host, share_name, version_path)
    if not conn.exists(share_name, version_path):
      info("%s not exist" % version_path)
      return None, None, None

    this_num = int(v[3])
    ret_lst = [this_num]
    info("latest build number: " + str(this_num))
    folders = conn.ls(share_name, version_path)
    build_numbers = set()
    for folder in folders:
      if folder.startswith("."):
        continue
      if folder.find(".tmp") >= 0:
        continue
      n = int(folder)
      if n >= this_num:
        continue
      build_numbers.add(n)
    if len(build_numbers) <= 0:
      info("No pre version found in " + version_path)
      return ret_lst, [], []
    lst = sorted(list(build_numbers), reverse=True)
    info("lst: %s" % lst)
    manifest_files = []
    manifests = []
    for num in lst:
      item = SmbDep()
      item.version = "%d.%d.%d" % (int(v[0]), int(v[1]), int(v[2]))
      item.build_number = num
      item.name = proj.get_name()
      item.branch = proj.get_branch()
      f, m = self.__load_ex(env, platform, item)
      manifest_files.append(f)
      manifests.append(m)
      ret_lst.append(num)
      if len(ret_lst) >= count:
        break
    return ret_lst, manifest_files, manifests

  @staticmethod
  def __search_deps(env, platform, manifest):
    if not "deps" in manifest:
      return {}, {}
    indirect_deps = OrderedDict()
    direct_deps = OrderedDict()
    for dep in manifest["deps"]:
      smb_dep, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      direct_deps[str(smb_dep)] = (smb_dep, dep_manifest)

    # dep_parent_map: 间接依赖的 dep_key -> 引入它的直接依赖的 dep_key
    dep_parent_map = {}
    for dep in manifest["deps"]:
      smb_dep, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      direct_key = str(smb_dep)
      UgProject.search_dep_tree(env, [], platform, dep_manifest, direct_deps, indirect_deps,
                                dep_parent_map, direct_key)
    deps = OrderedDict()
    conflicted = {}  # mod_name -> list of {"branch": str, "version": str, "referrer": str|None}

    def _make_entry(smb_dep, dep_key):
      referrer_key = dep_parent_map.get(dep_key)
      referrer = referrer_key.split(' ')[0].split('@')[0] if referrer_key else None
      return {"branch": smb_dep.branch,
              "version": "%s.%d" % (smb_dep.version, smb_dep.build_number),
              "referrer": referrer}

    def _record_conflict(mod_name, smb_dep, dep_key):
      entry = _make_entry(smb_dep, dep_key)
      if mod_name not in conflicted:
        existing_smb, _ = deps[mod_name]
        existing_key = str(existing_smb)
        conflicted[mod_name] = [_make_entry(existing_smb, existing_key)]
      if entry not in conflicted[mod_name]:
        conflicted[mod_name].append(entry)

    for k, (smb_dep_k, dep_manifest_k) in direct_deps.items():
      mod_name = smb_dep_k.name
      if mod_name in deps:
        _record_conflict(mod_name, smb_dep_k, k)
      else:
        deps[mod_name] = (smb_dep_k, dep_manifest_k)
    for k, (smb_dep_k, dep_manifest_k) in indirect_deps.items():
      mod_name = smb_dep_k.name
      if mod_name in deps:
        _record_conflict(mod_name, smb_dep_k, k)
      elif mod_name not in conflicted:
        deps[mod_name] = (smb_dep_k, dep_manifest_k)
    # 移除有版本冲突的依赖项，避免在变更汇总中使用不确定的版本
    for mod_name in conflicted:
      deps.pop(mod_name, None)
      info("dep version conflict (skipped in changelist): " + mod_name)
    return deps, conflicted

  @staticmethod
  def __add_manifest_git_url(git_urls, git_url):
    if not git_url:
      return
    git_url = get_clean_git_url(git_url)
    # 只预热公司 GitLab SSH 仓库，跳过本地路径、SMB 路径和外部地址。
    if git_url.startswith("ssh://git@gitlab.ugnas.com/"):
      git_urls[git_url] = None

  @staticmethod
  def collect_git_urls(env, platform, manifest, git_urls, visited_deps=None):
    # 收集 manifest 及其依赖链里的 git url，用于 request_for_testing 提前预热缓存。
    if visited_deps is None:
      visited_deps = set()

    ManifestLoader.__add_manifest_git_url(git_urls, manifest.get("git", ""))

    if "ugbase" in manifest:
      tokens = manifest["ugbase"].split()
      if tokens:
        ManifestLoader.__add_manifest_git_url(git_urls, tokens[0])

    if "go-install" in manifest:
      for go_install in manifest["go-install"].values():
        ManifestLoader.__add_manifest_git_url(git_urls, go_install.get("git", ""))

    if "deps" not in manifest:
      return

    for dep in manifest["deps"]:
      smb_dep, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      if is_remote_repo(smb_dep.name):
        continue
      dep_key = str(smb_dep)
      # 依赖可能被多个平台重复引用，也可能形成链路回环；这里避免重复递归。
      if dep_key in visited_deps:
        continue
      visited_deps.add(dep_key)
      ManifestLoader.collect_git_urls(env, platform, dep_manifest, git_urls, visited_deps)

  @staticmethod
  def __gen_smb_dep(env, name, branch, manifest_path):
    item = SmbDep()
    manifest_dir = os.path.basename(os.path.dirname(manifest_path))
    platform = BuildPlatform.parse(env, manifest_dir)

    "release_20250820-firmware_ugreen_pkg-1.8.0.16-all.manifest.yaml"
    manifest_file = os.path.basename(manifest_path)

    "release_20250820-firmware_ugreen_pkg-1.8.0.16-all"
    ss = manifest_file.replace(".manifest.yaml", "")
    ss = ss.replace("-" + platform.get_sorted_short_str(), "")

    "release_20250820-firmware_ugreen_pkg-1.8.0.16"
    version_and_build_numver = ss.split("-")[-1]
    v = version_and_build_numver.split('.')

    item = SmbDep()
    item.version = "%d.%d.%d" % (int(v[0]), int(v[1]), int(v[2]))
    item.build_number = int(v[3])
    item.name = name
    item.branch = branch
    item.dep_alias = ""
    return item

  def __compare_root(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]

    git_diff = _diff_git(env,
                         get_clean_git_url(manifest_new["git"]), manifest_new["revision"],
                         get_clean_git_url(manifest_old["git"]), manifest_old["revision"]
                         )
    vs = smb_dep_new.version + "." + str(new_build_number)
    _attach_diff(res, env.meta["base"]["name"], vs, git_diff)

  def __compare_ugbase(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]
    ugbase_new = manifest_new["ugbase"].split()
    ugbase_old = manifest_old["ugbase"].split()
    git_diff = _diff_git(env,
                         get_clean_git_url(ugbase_new[0]), ugbase_new[2],
                         get_clean_git_url(ugbase_old[0]), ugbase_old[2]
                         )
    vs = smb_dep_new.version + "." + str(new_build_number)
    _attach_diff(res, env.meta["base"]["name"], vs, git_diff)
    for dep in deps_new.keys():
      if dep in deps_old:
        x_smb_dep_new, x_dep_new = deps_new[dep]
        x_smb_dep_old, x_dep_old = deps_old[dep]
        # frontend module
        if "ugbase" in x_dep_new and "ugbase" in x_dep_old:
          x_ugbase_new = x_dep_new["ugbase"].split()
          x_ugbase_old = x_dep_old["ugbase"].split()
          git_diff = _diff_git(env,
                               get_clean_git_url(x_ugbase_new[0]), x_ugbase_new[2],
                               get_clean_git_url(x_ugbase_old[0]), x_ugbase_old[2]
                               )
          vs = x_smb_dep_new.version + "." + str(x_smb_dep_new.build_number)
          _attach_diff(res, x_smb_dep_new.name, vs, git_diff)

  def __compare_go_installs(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]
    if not "go-install" in manifest_new or not "go-install" in manifest_old:
      return
    for go_install_cmd in manifest_new["go-install"].keys():
      go_install_new = manifest_new["go-install"][go_install_cmd]
      if "go-install" in manifest_old and go_install_cmd in manifest_old["go-install"]:
        go_install_old = manifest_old["go-install"][go_install_cmd]
        git_diff = _diff_git(env,
                             get_clean_git_url(go_install_new["git"]), go_install_new["rev"],
                             get_clean_git_url(go_install_old["git"]), go_install_old["rev"]
                             )
        vs = vs = smb_dep_new.version + "." + str(new_build_number)
        _attach_diff(res, env.meta["base"]["name"], vs, git_diff)

    for dep in deps_new.keys():
      if dep in deps_old:
        x_smb_dep_new, x_dep_new = deps_new[dep]
        x_smb_dep_old, x_dep_old = deps_old[dep]
        # frontend module
        if "go-install" in x_dep_new and "go-install" in x_dep_old:
          for x_go_install_cmd in x_dep_new["go-install"].keys():
            x_go_install_new = x_dep_new["go-install"][x_go_install_cmd]
            info("%s -> %s" % (x_go_install_cmd, dump_yaml(x_dep_old["go-install"])))
            if x_go_install_cmd in x_dep_old["go-install"]:
              x_go_install_old = x_dep_old["go-install"][x_go_install_cmd]
              git_diff = _diff_git(env,
                                   get_clean_git_url(x_go_install_new["git"]), x_go_install_new["rev"],
                                   get_clean_git_url(x_go_install_old["git"]), x_go_install_old["rev"]
                                   )
            vs = x_smb_dep_new.version + "." + str(x_smb_dep_new.build_number)
            _attach_diff(res, x_smb_dep_new.name, vs, git_diff)

  def __compare_frontend(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]
    for dep in deps_new.keys():
      if is_remote_repo(dep):
        x_smb_dep_new, x_manifest_new = deps_new[dep]
        git = short_git(get_clean_git_url(x_manifest_new["git"]))
        mod_diff = OrderedDict()
        if "change-list" in x_manifest_new:
          change_list_new = x_manifest_new["change-list"]
          change_list_old = OrderedDict()
          if dep in deps_old:
            x_smb_dep_old, x_manifest_old = deps_old[dep]
            if "change-list" in x_manifest_old:
              change_list_old = x_manifest_old["change-list"]
          change_list_new_dict = OrderedDict()
          for item in change_list_new:
            x_item = copy.deepcopy(item)
            del x_item["commit"]
            change_list_new_dict[item["commit"]] = x_item

          change_list_old_dict = OrderedDict()
          for item in change_list_old:
            x_item = copy.deepcopy(item)
            del x_item["commit"]
            change_list_old_dict[item["commit"]] = x_item

          new_commits = set(list(change_list_new_dict.keys()))
          old_commits = set(list(change_list_old_dict.keys()))
          info("change list %d %d" % (len(new_commits), len(old_commits)))
          right = list(new_commits - old_commits)
          left = list(old_commits - new_commits)
          mod_diff["right"] = OrderedDict()
          mod_diff["left"] = OrderedDict()
          for commit in right:
            mod_diff["right"][git + " " + commit] = change_list_new_dict[commit]
          for commit in left:
            mod_diff["left"][git + " " + commit] = change_list_old_dict[commit]
        else:
          mod_diff["type"] = "no-change"
          mod_diff["desc"] = "rev " + x_manifest_new["revision"]
          mod_diff["right"] = []
          mod_diff["left"] = []
        vs = x_smb_dep_new.version + "." + str(x_smb_dep_new.build_number)
        _attach_diff(res, x_smb_dep_new.name, vs, mod_diff)

  def __compare_deps(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]
    for dep in deps_new.keys():
      if is_remote_repo(dep):
        continue
      if dep in deps_old:
        x_smb_dep_new, x_dep_new = deps_new[dep]
        x_smb_dep_old, x_dep_old = deps_old[dep]
        git_diff = _diff_git(env,
                             get_clean_git_url(x_dep_new["git"]), x_dep_new["revision"],
                             get_clean_git_url(x_dep_old["git"]), x_dep_old["revision"]
                             )
        vs = x_smb_dep_new.version + "." + str(x_smb_dep_new.build_number)
        _attach_diff(res, x_smb_dep_new.name, vs, git_diff)

  def __compare_go_mod(self, res, new_build_number, old_build_number):
    env = self.env
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]
    cmd_pattern = "ugbt lock_git_run -u %s -c -o %s -- git cat-file -p %s:go.mod"

    for dep in deps_new.keys():
      if is_remote_repo(dep):
        continue
      if dep in deps_old:
        x_smb_dep_new, x_dep_new = deps_new[dep]
        x_smb_dep_old, x_dep_old = deps_old[dep]

        git_new = get_clean_git_url(x_dep_new["git"])
        rev_new = x_dep_new["revision"]
        git_old = get_clean_git_url(x_dep_old["git"])
        rev_old = x_dep_old["revision"]
        # 依赖仓库和 revision 完全一致时，go.mod 不可能变化，跳过外部命令。
        if git_new == git_old and rev_new == rev_old:
          continue

        go_mod_new = env.get_temp_file()
        ret = run(cmd_pattern % (git_new, go_mod_new, rev_new),
                  assert_ok=False, show_log=False)
        if ret != 0:
          info("%s is not a go project" % x_smb_dep_new.name)
          continue

        go_mod_old = env.get_temp_file()
        ret = run(cmd_pattern % (git_old, go_mod_old, rev_old),
                  assert_ok=False, show_log=False)
        if ret != 0:
          info("%s is not a go project" % x_smb_dep_old.name)
          continue

        go_diff_file = env.get_temp_file()
        cmd = "ugbt diff-go-mod %s %s -o %s" % (go_mod_new, go_mod_old, go_diff_file)
        run(cmd)
        go_diff = load_yaml_f(go_diff_file)
        vs = x_smb_dep_new.version + "." + str(x_smb_dep_new.build_number)
        _attach_diff(res, x_smb_dep_new.name, vs, go_diff)

  def __compare_2_build_number(self, new_build_number, old_build_number):
    env = self.env
    info("compare new %d vs old %d" % (new_build_number, old_build_number))
    res = OrderedDict()
    res["left"] = OrderedDict()
    res["right"] = OrderedDict()
    smb_dep_new, manifest_new, deps_new = env.meta[new_build_number]
    smb_dep_old, manifest_old, deps_old = env.meta[old_build_number]

    k1 = "%s@%s-%s.%d" % (smb_dep_new.name, manifest_new["branch"], smb_dep_new.version, smb_dep_new.build_number)
    k2 = "%s@%s-%s.%d" % (smb_dep_old.name, manifest_old["branch"], smb_dep_old.version, smb_dep_old.build_number)
    cache_key = k1 + "-VS-" + k2
    cache_hash = "%03d" % hash_str(cache_key, 1000)
    cache_key = cache_key.replace("/", "_")
    cache_dir = os.path.join(os.environ["HOME"], "ugreen.tmp", "cache", "diff", cache_hash)
    make_dir(cache_dir)
    cache_path = os.path.join(cache_dir, cache_key + ".yaml")
    info("cache path: " + cache_path)
    if os.path.exists(cache_path):
      return load_yaml_f(cache_path)
    # compare root project
    self.__compare_root(res, new_build_number, old_build_number)
    # compare ugbase
    self.__compare_ugbase(res, new_build_number, old_build_number)
    # compare ugtools (go-install)
    self.__compare_go_installs(res, new_build_number, old_build_number)
    self.__compare_frontend(res, new_build_number, old_build_number)
    self.__compare_deps(res, new_build_number, old_build_number)
    self.__compare_go_mod(res, new_build_number, old_build_number)
    write_file(cache_path, dump_yaml(res))
    return res

  def diff(self, env, name, branch, manifest_files):
    self.env = env
    env.meta = OrderedDict()
    env.meta["base"] = OrderedDict()

    platform_str_0 = os.path.basename(os.path.dirname(manifest_files[0]))
    platform_0 = BuildPlatform.parse(env, platform_str_0)
    smb_dep_0 = ManifestLoader.__gen_smb_dep(env, name, branch, manifest_files[0])
    manifest_0 = ManifestLoader.instance().__load(env, platform_0, smb_dep_0)
    deps_0, conflicted_0 = ManifestLoader.__search_deps(env, platform_0, manifest_0)
    build_number_0 = smb_dep_0.build_number
    all_conflicted = dict(conflicted_0)

    env.meta["base"]["name"] = name
    env.meta["base"]["branch"] = branch
    env.meta["base"]["version"] = smb_dep_0.version
    env.meta["base"]["git"] = get_clean_git_url(manifest_0["git"])
    env.meta[build_number_0] = (smb_dep_0, manifest_0, deps_0)

    res = OrderedDict()
    res["changelist"] = OrderedDict()
    info("build info: " + dump_yaml(env.meta["base"]))
    info("build number: " + str(build_number_0))
    build_number_mapping = OrderedDict()

    for i in range(len(manifest_files)):
      if i == 0:
        continue
      platform_str_n = os.path.basename(os.path.dirname(manifest_files[i]))
      platform_n = BuildPlatform.parse(env, platform_str_n)
      smb_dep_n = ManifestLoader.__gen_smb_dep(env, name, branch, manifest_files[i])
      manifest_n = ManifestLoader.instance().__load(env, platform_n, smb_dep_n)
      deps_n, conflicted_n = ManifestLoader.__search_deps(env, platform_n, manifest_n)
      for mod_name, versions in conflicted_n.items():
        if mod_name not in all_conflicted:
          all_conflicted[mod_name] = versions
        else:
          for entry in versions:
            if entry not in all_conflicted[mod_name]:
              all_conflicted[mod_name].append(entry)
      build_number_n = smb_dep_n.build_number
      if build_number_n >= build_number_0:
        fatal("build number %d found >= base %d" % (build_number_n, build_number_0))
      if build_number_n in build_number_mapping:
        fatal("build number %d duplicate found" % build_number_n)
      build_number_mapping[build_number_n] = (deps_n, manifest_n)
      env.meta[build_number_n] = (smb_dep_n, manifest_n, deps_n)

    build_number_mapping = sort_dict(build_number_mapping, reverse=True)
    compare_pairs = []
    new_build_number = build_number_0
    for old_build_number in build_number_mapping.keys():
      # diff-manifest 比较的是相邻构建版本：89 vs 88、88 vs 87 ...
      compare_pairs.append((new_build_number, old_build_number))
      new_build_number = old_build_number

    def __compare_build_pair(pair):
      new_build_number, old_build_number = pair
      info("compare older build number %d vs newer %d " % (old_build_number, new_build_number))
      return (new_build_number, self.__compare_2_build_number(new_build_number, old_build_number))

    parallel_count = int(os.environ.get("UGBT_DIFF_MANIFEST_PARALLEL", "64"))
    if parallel_count < 1:
      parallel_count = 1
    # 构建对之间互不依赖，可以并行比较以减少 request_for_testing 邮件生成时间。
    info("diff-manifest compare build pairs parallel count: %d" % parallel_count)
    for new_build_number, diff_res in parallel_run(compare_pairs, parallel_count, __compare_build_pair):
      res["changelist"][new_build_number] = diff_res
    if all_conflicted:
      res["conflicted_deps"] = [{"name": name, "versions": versions}
                                for name, versions in sorted(all_conflicted.items())]
    return res

  def __load(self, env, platform, dep):
    _, ret = self.__load_ex(env, platform, dep)
    return ret

  def __load_ex(self, env, platform, dep):
    dep_path = os.path.join(dep.name,
                            dep.branch,
                            dep.version,
                            str(dep.build_number))
    manifest_local_root = os.path.join(get_ugdata(), "manifest_root")
    # 先尝试从标准本地仓库查找（与完整包相同的路径）
    standard_local_repo_root = env.get_local_repo_root()
    local_dir = platform.search_compatiable_pack_in_local(dep_path, local_repo_root=standard_local_repo_root)
    if local_dir:
      # 如果标准本地仓库找到了，使用标准仓库路径
      manifest_local_root = standard_local_repo_root
    else:
      # 如果标准仓库没找到，尝试从 manifest_root 查找
      local_dir = platform.search_compatiable_pack_in_local(dep_path, local_repo_root=manifest_local_root)
      if not local_dir:
        # 本地都找不到，才尝试从远程查找
        remote_dir = platform.search_compatiable_pack_in_remote(dep_path)
        if not remote_dir:
          fatal("can not locate dep: " + str(dep))
        UgProject.download_dep(env, dep, dep_path, remote_dir, local_repo_root=manifest_local_root, only_manifest=True)
        local_dir = platform.search_compatiable_pack_in_local(dep_path, local_repo_root=manifest_local_root)
        if not local_dir:
          fatal("can not locate dep: " + str(dep))

    pack_name = UgProject.get_dep_pack_name(env, dep, local_dir)

    manifest_path = os.path.join(dep_path, local_dir, pack_name + ".manifest.yaml")
    manifest_path_full = os.path.join(manifest_local_root, manifest_path)
    if manifest_path in self.__cache:
      return manifest_path_full, self.__cache[manifest_path]

    if not os.path.exists(manifest_path_full):
      fatal(manifest_path_full + " not found")
    manifest = load_yaml_f(manifest_path_full)
    self.__cache[manifest_path] = manifest
    return manifest_path_full, manifest

  def load(self, env, platform, depstr):
    dep = SmbDep.parse(depstr)
    manifest = self.__load(env, platform, dep)
    return dep, manifest

  def load_ex(self, env, platform, dep):
    return self.__load_ex(env, platform, dep)


class SmbDep:
  def __str__(self):
    return "%s@%s %s.%d" % (self.name, self.branch, self.version, self.build_number)

  @staticmethod
  def parse(ss, default_branch="", source_file_chain=[]):
    tokens = ss.split(' ')
    if len(tokens) != 2:
      fatal("invalid dep: " + ss)
    dep_name_str = tokens[0].strip()
    dep_ver = tokens[1].strip()

    # 解析 buildtools 标记，格式如：name@branch[buildtools] 或 name@branch(alias)[buildtools]
    buildtools = False
    if dep_name_str.endswith("[buildtools]"):
      buildtools = True
      dep_name_str = dep_name_str[:-len("[buildtools]")].strip()

    pattern = "^(.+)\\((.*)\\)$"
    match = re.match(pattern, dep_name_str)
    dep_alias = ""
    if match:
      groups = match.groups()
      dep_name_str = groups[0].strip()
      dep_alias = groups[1].strip()
      if not dep_alias:
        fatal("alias is empty in [%s]" % dep_name_str)

    dep_name_parts = dep_name_str.split('@')
    if len(dep_name_parts) == 2:
      dep_name = dep_name_parts[0].strip()
      branch = dep_name_parts[1].strip()
    else:
      dep_name = dep_name_parts[0].strip()
      branch = default_branch
      fatal("invalid dep_name [%s] must be name@branch" % dep_name_str)

    version, build_number = UgProject.parse_version_string(dep_ver)
    item = SmbDep()
    item.ss = ss
    item.version = version
    item.build_number = build_number
    item.name = dep_name
    item.branch = branch
    item.dep_alias = dep_alias
    item.buildtools = buildtools
    item.source_file_chain = source_file_chain
    item.dep_ver = dep_ver
    return item

  def get_prefix(self):
    text = self.name
    if self.dep_alias:
      text += "(%s)" % self.dep_alias
    if self.buildtools:
      text += "[buildtools]"
    return text

  def formart_source_file_chain(self):
    format_str = ""
    if hasattr(self, 'source_file_chain'):
      if isinstance(self.source_file_chain, list) and self.source_file_chain:
        format_str = "    " + "\n    -> ".join(self.source_file_chain + [self.ss]) + "\n"
    return format_str


class UgProject:
  __VALID_KEYS = {
      GS.SCHEMA_VERSION,
      GS.NAME,
      GS.VERSION,
      GS.DEPS,
      GS.UGBASE,
      GS.RELEASE_NAME,
      GS.LOCKED,
      GS.PLATFORM,
      GS.BUILD,
      GS.RELEASE,
      GS.TEMPLATE,
      GS.ENV,
      GS.PACK,
      GS.OUTPUT,
      GS.GO_INSTALL,
      GS.BRANCH,
      GS.OTA_TYPE,
      GS.DEPEND_FW_VERSION,
  }

  class GoDep:
    @staticmethod
    def parse(text):
      git, branch, rev = parse_git_branch_rev(text)
      item = UgProject.GoDep()
      item.git = get_clean_git_url(git)
      item.path = item.git.replace("ssh://git@", "")
      item.branch = branch
      item.revision = rev
      return item

  def get_data(self):
    return self.__data

  class UgBase:
    @staticmethod
    def parse(text):
      git, branch, rev = parse_git_branch_rev(text)
      item = UgProject.UgBase()
      item.git = get_clean_git_url(git)
      item.path = item.git.replace("ssh://git@", "")
      item.branch = branch
      item.revision = rev
      return item

  class GoInstall:
    @staticmethod
    def parse(filename, obj):
      item = UgProject.GoInstall()
      item.git = get_clean_git_url(obj["git"].strip())
      item.branch = obj["branch"].strip()
      item.rev = obj["rev"].strip()
      item.path = obj["path"].strip()
      item.filename = filename
      return item

  def __init__(self, env, build_vars):
    self.__root = ""
    self.__data = {}
    self.__schema_version = GS.V1
    self.__go_deps = []
    self.__go_installs = []
    build_vars = array_remove_null(build_vars)
    self.__build_vars = build_vars
    self.__env = env
    self.__go_mod_deps = {}
    self.__email_conflicted_deps = []
    self.__locked_mods = set()

  def __get(self, name):
    if not name in self.__data:
      fatal("%s not found in %s/%s" % (name, self.__root, GS.FILENAME))
    return self.__data[name]

  @staticmethod
  def parse_version_string(version):
    # 1.0.1
    # or 1.0.1.0000
    tokens = version.split('.')
    vs = ["", "", "", "0"]
    if len(tokens) == 3 or len(tokens) == 4:
      vs[0] = tokens[0].strip()
      vs[1] = tokens[1].strip()
      vs[2] = tokens[2].strip()
      if len(tokens) == 4:
        vs[3] = tokens[3].strip()
    else:
      fatal("invalid version: " + version)

    for vs_i in vs:
      if not vs_i.isdigit():
        fatal("invalid version: " + version)

    build_number = int(vs[3])
    if build_number < 0:
      fatal("invalid version: " + version)

    major_version = "%d.%d.%d" % (int(vs[0]), int(vs[1]), int(vs[2]))
    return major_version, build_number

  def init_branch(self):
    if not "BRANCH" in os.environ:
      branch = self.__data.get(GS.BRANCH, "")
      if branch:
        fatal("do not set branch in " + GS.FILENAME)
      git = Git(False, self.__root, assert_ok=False)
      branch = git.remote_branch()
      if not branch:
        branch = git.current_branch()
        if not branch:
          fatal("can not get git current branch")
        warning("remote branch not found, use current branch " + branch)
      if is_verbose():
        info("there is no BRANCH in env or %s, use the current remote branch [%s] of git" %
             (GS.FILENAME, branch))
      os.environ["BRANCH"] = branch

  def get_deps(self):
    return self.__deps

  def get_version_text(self):
    return self.__version_text

  @staticmethod
  def get_branch():
    branch = os.environ["BRANCH"].strip()
    if not branch:
      fatal("not found branch in BRANCH env")
    return branch

  def get_name(self):
    return self.__name

  def get_schema_version(self):
    return self.__schema_version

  def get_ugbase(self):
    return self.__ugbase

  def __load_data(self, proj_path, default_branch=""):
    self.__data = load_yaml_f(proj_path)
    if not isinstance(self.__data, dict):
      fatal("%s is not a yaml dict" % proj_path)
    for key in self.__data.keys():
      if key not in UgProject.__VALID_KEYS:
        fatal("%s unknown field: %s, allowed fields: [%s]" % (
            proj_path, key, ", ".join(sorted(UgProject.__VALID_KEYS))))
    self.__schema_version = self.__data.get(GS.SCHEMA_VERSION, GS.V1)
    if self.__schema_version not in [GS.V1, GS.V2]:
      fatal("%s invalid %s: %s" % (proj_path, GS.SCHEMA_VERSION, self.__schema_version))
    if self.__data.get(GS.RELEASE) == GS.RELEASE:
      fatal("%s invalid %s: %s, %s字段不能是%s" % (
          proj_path, GS.RELEASE, GS.RELEASE, GS.RELEASE, GS.RELEASE))
    if not self.__data.get(GS.NAME):
      fatal("%s missing %s" % (proj_path, GS.NAME))
    self.__name = self.__get(GS.NAME)
    if self.__schema_version == GS.V1:
      if GS.VERSION not in self.__data:
        fatal("%s missing %s" % (proj_path, GS.VERSION))
      self.__version_text = str(self.__get(GS.VERSION))
      self.__version, self.__build_number = UgProject.parse_version_string(self.__version_text)
    self.__deps = []
    for dep in self.__data.get(GS.DEPS, []):
      self.__deps.append(SmbDep.parse(dep, default_branch, [proj_path]))

  def __load_v2_metadata(self):
    repo = Repo.find(self.__root)
    project_path, project_data, version_data = repo.load_build_metadata(self.__root)
    version_ref = project_data.get(GS.VERSION_REF, "")
    if not version_ref:
      fatal("%s missing %s in repo building manifest" % (project_path, GS.VERSION_REF))

    module_versions = version_data.get(GS.MODULES, {})
    if version_ref not in module_versions:
      fatal("%s not found in repo building module versions" % version_ref)
    module_version = str(module_versions[version_ref]).split()
    if len(module_version) != 2:
      fatal("invalid repo building module version: %s" % module_versions[version_ref])
    self.__version_text = module_version[1]
    self.__version, self.__build_number = UgProject.parse_version_string(self.__version_text)

    ugbase_data = version_data.get(GS.UGBASE, {})
    ugbase_modules = ugbase_data.get(GS.MODULES, {})
    if version_ref not in ugbase_modules:
      fatal("%s not found in repo building ugbase modules" % version_ref)
    ugbase_ref = ugbase_modules[version_ref]
    ugbase_versions = ugbase_data.get(GS.VERSIONS, {})
    if ugbase_ref not in ugbase_versions:
      fatal("%s not found in repo building ugbase versions" % ugbase_ref)
    self.__ugbase = UgProject.UgBase.parse(ugbase_versions[ugbase_ref])

  def __load_attrs(self, env, platform):
    if "INSTALL_PREFIX" in os.environ:
      self.__name = os.path.join(os.environ["INSTALL_PREFIX"], self.__name)
    if self.__schema_version == GS.V1:
      self.__ugbase = UgProject.UgBase.parse(self.__get(GS.UGBASE))
    self.__release_name = self.__data.get(GS.RELEASE_NAME, "")
    self.__locked_mods = set(self.__data.get(GS.LOCKED, []))

    if GS.PLATFORM in self.__data:
      proj_platform = self.__data[GS.PLATFORM]
      if platform:
        build_vars = []
        for var_key in platform.keys():
          if var_key not in proj_platform:
            fatal("invalid var [%s] in platform string, must be one of [%s]" % (var_key, proj_platform))
        for var_key in proj_platform:
          if platform.has(var_key):
            build_vars.append(var_key + "=" + platform.get(var_key))
        self.__platform = BuildPlatform(env, build_vars, proj_platform)
      else:
        self.__platform = BuildPlatform(env, self.__build_vars, proj_platform)
    else:
      if platform:
        self.__platform = platform
      else:
        self.__platform = BuildPlatform(env, self.__build_vars, [])

    if GS.BUILD in self.__data:
      self.__build = self.__data[GS.BUILD]
    else:
      self.__build = ""

    self.__release = self.__data.get(GS.RELEASE, GS.DEV)
    self.__template = self.__data.get(GS.TEMPLATE, "default")
    self.__env_vars = self.__data.get(GS.ENV, {})

    self.__pack = self.__data.get(GS.PACK, "")
    output_dict = self.__data.get(GS.OUTPUT, {})
    if GS.FORMAT in output_dict:
      self.__output_format = output_dict[GS.FORMAT]
    else:
      self.__output_format = GS.TGZ

    if GS.GO_INSTALL in self.__data:
      for tool in self.__data[GS.GO_INSTALL].keys():
        go_install_item = self.__data[GS.GO_INSTALL][tool]
        self.__go_installs.append(UgProject.GoInstall.parse(tool, go_install_item))

    go_mod_path = os.path.join(self.__root, GS.GO_MOD)
    self.__go_mod_deps = load_go_mod_deps(go_mod_path)

  def __load(self, platform=None, root=None):
    env = self.__env
    default_branch = ""
    if root:
      self.__root = os.path.abspath(os.path.expandvars(root))
    else:
      self.__root = UgProject.find_project_root()
      self.init_branch()
      default_branch = UgProject.get_branch()

    proj_path = os.path.join(self.__root, GS.FILENAME)
    self.__load_data(proj_path, default_branch)
    if self.__schema_version == GS.V2:
      self.__load_v2_metadata()
    self.__load_attrs(env, platform)

  def __get_go_dep_list(self):
    env = self.__env
    lst = []
    for go_dep in self.__go_deps:
      git_x_path = go_dep.git_path.replace("/", "__")
      # master_dir = os.path.join(env.work_dir, "code", git_x_path, "master")
      # lst.append((master_dir, go_dep))
    return lst

  def __init_go_code_master(self):
    for master_dir, go_dep in self.__get_go_dep_list():
      if os.path.exists(master_dir):
        run("cd %s && git fetch" % master_dir)
      else:
        run("git clone %s %s" % (go_dep.git, master_dir))

    for ins in self.__go_installs:
      master_dir = os.path.join(get_ugdata(), GS.GO_INSTALL,
                                ins.git.replace("/", "__"))
      if os.path.exists(master_dir):
        run("cd %s && git fetch" % master_dir)
      else:
        run("git clone %s %s" % (ins.git, master_dir))

    master_dir = os.path.join(get_ugdata(), GS.UGBASE)
    if os.path.exists(master_dir):
      run("cd %s && git fetch" % master_dir)
    else:
      run("git clone %s %s" % (self.__ugbase.git, master_dir))

  def get_root(self):
    return self.__root

  def get_platform(self):
    return self.__platform

  @staticmethod
  def detect_host_cpu_arch():
    """检测当前主机的 CPU 架构
    返回值: "amd64" 或 "arm64"
    """
    import platform
    machine = platform.machine().lower()

    # x86_64 架构的各种表示
    if machine in ['x86_64', 'amd64', 'x64', 'i686', 'i386']:
      return 'amd64'
    # ARM 架构的各种表示
    elif machine in ['aarch64', 'arm64', 'armv8', 'armv8l', 'armv7l', 'arm']:
      return 'arm64'
    else:
      # 未知架构，返回默认值并警告
      warning("Unknown host CPU architecture: %s, defaulting to amd64" % machine)
      return 'amd64'

  def get_host_platform(self):
    """获取主机平台，用于 buildtools 类型的依赖
    若目标平台包含 cpu_arch，则将其替换为主机的 cpu_arch；
    若目标平台未包含 cpu_arch（如 ugreen-pkg 的 platform 为空），仍返回带主机 cpu_arch 的平台，
    以便 buildtools 依赖只匹配宿主机架构对应的目录（如 cpu_arch_amd64）。
    """
    host_cpu_arch = UgProject.detect_host_cpu_arch()
    target_platform_data = self.__platform._BuildPlatform__data

    if self.__platform.has(GS.CPU_ARCH):
      # 目标平台有 cpu_arch，仅替换为主机架构
      host_build_vars = ["cpu_arch=" + host_cpu_arch]
      for key, value in target_platform_data.items():
        if key != GS.CPU_ARCH:
          host_build_vars.append(key + "=" + value)
      platform_keys = list(target_platform_data.keys())
    else:
      # 目标平台无 cpu_arch（如 platform 为空），仍为 buildtools 构造带主机 cpu_arch 的平台
      host_build_vars = ["cpu_arch=" + host_cpu_arch]
      platform_keys = [GS.CPU_ARCH]

    from ug_build_platform import BuildPlatform
    host_platform = BuildPlatform(self.__env, host_build_vars, platform_keys)
    return host_platform

  @staticmethod
  def load(env, build_vars, platform=None, root=None):
    prj = UgProject(env, build_vars)
    prj.__load(platform=platform, root=root)
    return prj

  def generate_cmake(self):
    content = ""
    content += "function (ugbt_init)\n"
    implicit_deps = self.__get_implicit_deps()
    all_deps = self.__deps + implicit_deps
    for dep in all_deps:
      env_k = UgProject.escape_env_name(dep.name)
      dname = "\"${CMAKE_BINARY_DIR}/deps/" + env_k + "/cmake\""
      content += "  if (EXISTS %s)\n" % dname
      content += "    list(INSERT CMAKE_MODULE_PATH 0 %s)\n" % dname
      content += "    list(INSERT CMAKE_PREFIX_PATH 0 %s)\n" % dname
      content += "  endif()\n"

      # iname = "\"${CMAKE_BINARY_DIR}/deps/" + env_k + "/include\""
      # content += "  if (EXISTS %s)\n" % iname
      # content += "    include_directories(%s)\n" % iname
      # content += "  endif()\n"

      # lib_name = "\"${CMAKE_BINARY_DIR}/deps/" + env_k + "/lib\""
      # content += "  if (EXISTS %s)\n" % lib_name
      # content += "    link_directories(%s)\n" % lib_name
      # content += "  endif()\n"

      content += "\n"
    content += "set (CMAKE_MODULE_PATH \"${CMAKE_MODULE_PATH}\" PARENT_SCOPE)\n"
    content += "set (CMAKE_PREFIX_PATH \"${CMAKE_PREFIX_PATH}\" PARENT_SCOPE)\n"
    content += "endfunction ()\n"
    write_file_if_changed("ugbt.cmake", content)

    self.__generate_ugenv_sh(implicit_deps)

  def __generate_ugenv_sh(self, implicit_dep_list=[]):
    exportstr = self.__get_export_str()
    envstr = self.__get_dep_envstr(with_path=True, implicit_dep_list=implicit_dep_list)
    content = ""
    content += exportstr
    content += "\n"
    content += envstr
    write_file("ug_env.sh", content)

  def get_all_platforms(self):
    env = self.__env
    if GS.PLATFORM in self.__data:
      sorted_platforms = str(sorted(self.__data[GS.PLATFORM]))
      br = "build_type_release"
      if sorted_platforms == "['cpu_arch']":
        platform_strs = [
            "cpu_arch_amd64",
            "cpu_arch_arm64"
        ]
      elif sorted_platforms == "['cpu_arch', 'product_series']":
        platform_strs = [
            "cpu_arch_amd64__product_series_nasync",
            "cpu_arch_arm64__product_series_nasync",
            "cpu_arch_arm64__product_series_homeagent",
        ]
      elif sorted_platforms == "['arch_spu', 'cpu_arch', 'kernel', 'product_series']":
        platform_strs = [
            "arch_spu_intel__cpu_arch_amd64__kernel_6.12.30+__product_series_nasync",
            "arch_spu_intel__cpu_arch_amd64__kernel_6.1.27__product_series_nasync",
            "arch_spu_rk3588__cpu_arch_arm64__kernel_6.1.27__product_series_nasync",
            "arch_spu_rk3576__cpu_arch_arm64__kernel_6.1.27__product_series_nasync",
            # homeagent 产品系列：
            # "arch_spu_intel__cpu_arch_amd64__kernel_6.12.30+__product_series_homeagent",
            "arch_spu_rk3588__cpu_arch_arm64__kernel_6.1.27__product_series_homeagent",
        ]
      elif sorted_platforms == "['arch_spu', 'build_type', 'cpu_arch', 'kernel']":
        platform_strs = [
            "build_type_release__cpu_arch_amd64__arch_spu_intel__kernel_6.12.30+",
            "build_type_release__cpu_arch_arm64__arch_spu_rk3588__kernel_6.1.27",
        ]
      elif sorted_platforms == "['arch_spu', 'build_type', 'cpu_arch', 'kernel', 'product_series']":
        platform_strs = [
            "build_type_release__cpu_arch_amd64__arch_spu_intel__kernel_6.12.30+__product_series_nasync",
            "build_type_release__cpu_arch_amd64__arch_spu_intel__kernel_6.12.30+__product_series_homeagent",
            "build_type_release__cpu_arch_amd64__arch_spu_intel__kernel_6.18__product_series_nasync",
            "build_type_release__cpu_arch_amd64__arch_spu_intel__kernel_6.18__product_series_homeagent",
            "build_type_release__cpu_arch_arm64__arch_spu_rk3576__kernel_6.1.27__product_series_nasync",
            "build_type_release__cpu_arch_arm64__arch_spu_rk3576__kernel_6.1.27__product_series_homeagent",
            "build_type_release__cpu_arch_arm64__arch_spu_rk3588__kernel_6.1.27__product_series_nasync",
            "build_type_release__cpu_arch_arm64__arch_spu_rk3588__kernel_6.1.27__product_series_homeagent",
        ]
      elif sorted_platforms == "['arch_spu', 'cpu_arch', 'kernel']":
        platform_strs = [
            "cpu_arch_amd64__arch_spu_intel__kernel_6.1.27",
            "cpu_arch_amd64__arch_spu_intel__kernel_6.12.30+",
            "cpu_arch_arm64__arch_spu_rk3588__kernel_6.1.27",
            "cpu_arch_arm64__arch_spu_rk3576__kernel_6.1.27",
        ]
      elif sorted_platforms == "['arch_spu', 'cpu_arch']":
        platform_strs = [
            "cpu_arch_amd64__arch_spu_intel",
            "cpu_arch_arm64__arch_spu_rk3588",
            "cpu_arch_arm64__arch_spu_rk3576",
        ]
      elif sorted_platforms == "[]":
        platform_strs = [
            "all"
        ]
      else:
        fatal("Unkown platform: " + sorted_platforms)

      platforms = []
      for platform_str in platform_strs:
        platform = BuildPlatform.parse(env, platform_str)
        platforms.append(platform)
      return platforms
    else:
      platform = BuildPlatform(env, self.__build_vars, [])
      return [platform]

  def __get_root_files_str(self):
    rootfs_file_map = OrderedDict()
    rootfs_sources = [("rootfs_common", "${ROOTFS_COMMON}")]

    if self.get_platform().has(GS.CPU_ARCH):
      cpu_arch = self.get_platform().get(GS.CPU_ARCH)
      rootfs_sources.append(("rootfs_" + cpu_arch, "${ROOTFS_ARCH}"))

    if self.get_platform().has(GS.PRODUCT_SERIES):
      product_series = self.get_platform().get(GS.PRODUCT_SERIES)
      rootfs_sources.append(("rootfs_" + product_series, "${ROOTFS_PRODUCT_SERIES}"))

    if self.get_platform().has(GS.CPU_ARCH) and self.get_platform().has(GS.PRODUCT_SERIES):
      cpu_arch = self.get_platform().get(GS.CPU_ARCH)
      product_series = self.get_platform().get(GS.PRODUCT_SERIES)
      rootfs_sources.append(("rootfs_" + cpu_arch + "_" + product_series, "${ROOTFS_ARCH_PRODUCT_SERIES}"))

    for rootfs_dir_name, rootfs_var in rootfs_sources:
      rootfs_dir = os.path.join(self.__root, rootfs_dir_name)
      rootfs_filestr = ""
      if os.path.exists(rootfs_dir):
        rootfs_filestr = runex("cd %s && find . -type f -or -type l -or -type d" % rootfs_dir)
      rootfs_files = rootfs_filestr.split('\n')

      for rootfs_file in rootfs_files:
        rootfs_file = rootfs_file.strip()
        if rootfs_file == ".":
          continue
        if not rootfs_file:
          continue
        rootfs_file = rootfs_file.replace("./", "").strip()
        rootfs_file_map[rootfs_file] = rootfs_var + "/" + rootfs_file

    rootfs_files = list(rootfs_file_map.values())
    rootfs_files = sorted(rootfs_files)
    escaped_rootfs_files = []
    for rootfs_file in rootfs_files:
      escape_rootfs_file = rootfs_file
      escape_rootfs_file = escape_rootfs_file.replace(' ', '\\ ')
      escape_rootfs_file = escape_rootfs_file.replace('*', '\\*')
      escape_rootfs_file = escape_rootfs_file.replace('?', '\\?')
      escape_rootfs_file = escape_rootfs_file.replace('#', '\\#')
      escape_rootfs_file = escape_rootfs_file.replace('[', '\\[')
      escape_rootfs_file = escape_rootfs_file.replace(']', '\\]')
      escaped_rootfs_files.append(escape_rootfs_file)
    return '\\\n\t\t'.join(escaped_rootfs_files)

  def __get_go_install_target_str(self):
    ss = ""
    for go_ins in self.__go_installs:
      ss += " ${BUILD_DIR}/bin/" + go_ins.filename
    return ss

  def __get_go_install_str(self):
    go_install_tools = ""
    lines = []
    for go_ins in self.__go_installs:
      go_install_tools += " ${BUILD_DIR}/bin/" + go_ins.filename
    lines.append(GS.GO_INSTALL + ":" + go_install_tools + " ${PROJECT_DIR}/" + GS.FILENAME)
    lines.append("")

    # 获取DOCKER_TYPE_ARCH
    docker_arch_type = os.environ["DOCKER_ARCH_TYPE"]
    if docker_arch_type == "arm" or docker_arch_type == "arm64":
      docker_arch_type = "arm64"
    else:
      docker_arch_type = "amd64"
    for ins in self.__go_installs:
      lines.append("${BUILD_DIR}/bin/" + go_ins.filename + ": ${PROJECT_DIR}/" + GS.FILENAME)
      short_git = ins.git.replace("ssh://git@", "").replace(".git", "")
      lines.append("\tGOARCH=" + docker_arch_type + " GOBIN=${BUILD_DIR}/bin" +
                   " go install %s/%s@%s" % (short_git, ins.path, ins.rev))
    return '\n'.join(lines)

  @staticmethod
  def __extract_pack(pack_dir, pack_full_name):
    pack_name = pack_full_name.replace(".tar.gz", "")
    lock_file = os.path.join(pack_dir, pack_name + ".lock")
    if lock_file.startswith("/data_191"):
      lock_file = lock_file.replace("/data_191/", "/data/gitlab/")
    make_dir(os.path.dirname(lock_file))
    if not os.path.exists(lock_file):
      run("touch " + lock_file)
    fp = open(lock_file, "rb")

    pack_path = os.path.join(pack_dir, pack_name)
    if os.path.exists(pack_path):
      return

    info("try to get lock %s ..." % lock_file)
    fcntl.flock(fp, fcntl.LOCK_EX)
    info("get lock %s OK" % lock_file)
    if not os.path.exists(pack_path):
      tmp_dir = pack_path + "-" + uuid_gen() + ".tmp"
      make_dir(tmp_dir)
      run("cd %s && tar xfz ../%s" % (tmp_dir, pack_full_name))
      run("mv %s %s" % (tmp_dir, pack_path))
    fcntl.flock(fp, fcntl.LOCK_UN)
    fp.close()

  @staticmethod
  def __link_to(folder, src_path, link_name):
    make_dir(folder)
    if not os.path.exists(src_path):
      pack_dir = os.path.dirname(src_path)
      pack_full_name = runex("cd %s && find . -name \"*.tar.gz\" -type f" % pack_dir).strip()
      pack_full_name = pack_full_name.replace("./", "")
      UgProject.__extract_pack(pack_dir, pack_full_name)
    link_path = os.path.join(folder, link_name)
    if os.path.islink(link_path):
      if os.readlink(link_path) == src_path:
        return
      run("unlink " + link_path)
    if os.path.exists(link_path):
      run("rm -rf " + link_path)
    run("cd %s && ln -s %s %s" % (folder, src_path, link_name))

  def __link_dep(self, deps_dir, local_repo_dir, dep):
    env_k = UgProject.escape_env_name(dep.name)
    UgProject.__link_to(deps_dir, local_repo_dir, env_k)
    if dep.dep_alias:
      UgProject.__link_to(deps_dir, local_repo_dir, dep.dep_alias)

  @staticmethod
  def download_dep(env, dep, dep_path, dir_name, local_repo_root=None, only_manifest=False):
    pack_name = UgProject.get_dep_pack_name(env, dep, dir_name)
    build_env = env.get_build_env()
    remote_repo_root = build_env["SMB_REPO"]
    if not local_repo_root:
      local_repo_root = env.get_local_repo_root()

    local_repo_dir = os.path.join(local_repo_root, dep_path, dir_name)
    tmp_local_repo_dir = local_repo_dir + "-" + uuid_gen() + ".tmp"
    if os.path.exists(local_repo_dir):
      run("rm -rf " + local_repo_dir)
    make_dir(tmp_local_repo_dir)

    data_file = os.path.join(dep_path, dir_name, pack_name + ".tar.gz")
    manifest_file = os.path.join(dep_path, dir_name, pack_name + ".manifest.yaml")
    if only_manifest:
      files = [manifest_file]
    else:
      files = [data_file, manifest_file]

    make_dir(tmp_local_repo_dir)

    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]

    for file in files:
      remote_path = os.path.join(remote_repo_root, file)
      filename = os.path.basename(remote_path)
      local_path = os.path.join(tmp_local_repo_dir, filename)
      conn.download(share_name, remote_path, local_path)
    data_dir = os.path.join(tmp_local_repo_dir, pack_name)
    make_dir(data_dir)
    manifest = load_yaml_f(os.path.join(tmp_local_repo_dir, pack_name + ".manifest.yaml"))
    pack_file = os.path.join(tmp_local_repo_dir, pack_name + ".tar.gz")
    md5_value = manifest["md5"]
    if not only_manifest:
      if isinstance(md5_value, str):
        md5_value = md5_value.lower()
        md5_in_file = md5(pack_file).lower()
        if md5_value != md5_in_file:
          fatal("md5 not match [%s] != [%s] of %s" % (md5_value, md5_in_file, dep))
      else:
        for file_name in md5_value.keys():
          file_md5 = md5_value[file_name].lower()
          pack_file = os.path.join(tmp_local_repo_dir, file_name)
          md5_in_file = md5(pack_file).lower()
          if file_md5 != md5_in_file:
            fatal("md5 not match [%s] != [%s] of %s, file %s" % (file_md5, md5_in_file, dep, file_name))

      run("cd %s && tar xfz ../%s.tar.gz" % (data_dir, pack_name))
    run("mv %s %s" % (tmp_local_repo_dir, local_repo_dir))

  @staticmethod
  def escape_env_name(env_k):
    env_k = env_k.replace(".", "_")
    env_k = env_k.replace("-", "_")
    env_k = env_k.replace("/", "_")
    return env_k

  @staticmethod
  def get_dep_pack_name(env, dep, local_dir):
    platform = BuildPlatform.parse(env, local_dir)
    pack_name = dep.branch + "-" + dep.name.replace("/", "_")
    pack_name += "-" + dep.version + "." + str(dep.build_number)
    pack_name += "-" + platform.get_sorted_short_str()
    return pack_name

  def get_release(self):
    return self.__release

  def __get_dep_envstr(self, with_path=False, implicit_dep_list=[]):
    env = self.__env
    envstr = ""
    pathes = []
    lib_pathes = []
    if len(self.__deps) > 0:
      envstr += "# ENV VARS for deps start\n"
      all_deps = self.__deps + implicit_dep_list
      for dep in all_deps:
        dep_path = os.path.join(dep.name,
                                dep.branch,
                                dep.version,
                                str(dep.build_number))

        # 如果是 buildtools 依赖，使用主机平台；否则使用目标平台
        platform = self.get_host_platform() if getattr(dep, 'buildtools', False) else self.get_platform()
        local_dir = platform.search_compatiable_pack_in_local(dep_path)
        if not local_dir:
          fatal("can not locate dep: " + str(dep))

        env_k = UgProject.escape_env_name(dep.name)
        pack_name = UgProject.get_dep_pack_name(env, dep, local_dir)
        full_local_dir = os.path.join(env.get_local_repo_root(), dep_path, local_dir, pack_name)
        full_tar_filename = full_local_dir + ".tar.gz"
        envstr += "export %s_ROOT=%s\n" % (env_k, full_local_dir)
        envstr += "export %s_PACK=%s\n" % (env_k, full_tar_filename)
        envstr += "export %s_VERSION=%s\n" % (env_k, dep.version)
        envstr += "export %s_BUILD_NUMBER=%s\n" % (env_k, dep.build_number)
        envstr += "export %s_BUILD_NUMBER_04D=%04d\n" % (env_k, dep.build_number)
        if dep.dep_alias:
          envstr += "export %s_ROOT=%s\n" % (dep.dep_alias, full_local_dir)
          envstr += "export %s_PACK=%s\n" % (dep.dep_alias, full_tar_filename)
          envstr += "export %s_VERSION=%s\n" % (dep.dep_alias, dep.version)
          envstr += "export %s_BUILD_NUMBER=%s\n" % (dep.dep_alias, dep.build_number)
          envstr += "export %s_BUILD_NUMBER_04D=%04d\n" % (dep.dep_alias, dep.build_number)
        if os.path.exists(os.path.join(full_local_dir, "bin")):
          pathes.append(os.path.join(full_local_dir, "bin"))
        if os.path.exists(os.path.join(full_local_dir, "lib")):
          lib_pathes.append(os.path.join(full_local_dir, "lib"))
        if os.path.exists(os.path.join(full_local_dir, "lib64")):
          lib_pathes.append(os.path.join(full_local_dir, "lib64"))
      envstr += "# ENV VARS for deps end\n\n"
    if with_path:
      if len(pathes) > 0:
        envstr += "export PATH=%s:$PATH\n" % (':'.join(pathes))
      if len(lib_pathes) > 0:
        envstr += "export LD_LIBRARY_PATH=%s:$LD_LIBRARY_PATH\n" % (':'.join(lib_pathes))
    return envstr

  def __format_as_list(self, data, level=0):
    """将嵌套的依赖结构转换为Markdown列表格式的字符串"""
    result = []

    for item in data:
        # 获取当前项的键（节点名称）
      name = list(item.keys())[0]

      # 添加当前节点，根据层级使用不同数量的"- "
      indent = "\t" * level
      result.append(f"{indent}- {name}")

      # 处理子节点
      children = item[name]
      if children:
          # 递归处理子节点，层级+1
        child_result = self.__format_as_list(children, level + 1)
        result.extend(child_result)

    return result

  def __format_deps_tree(self, deps_tree_node=[]):
    return "\n".join(self.__format_as_list(deps_tree_node))

  # 隐式依赖检查
  def __check_implicit_dep(self, env, dep, implicit_dep_dict: OrderedDict, implicit_dep_chain: set, only_manifest=False, deps_tree_node=[]):
    # 读取manifest文件
    # 如果是 buildtools 依赖，使用主机平台；否则使用目标平台
    platform = self.get_host_platform() if getattr(dep, 'buildtools', False) else self.get_platform()
    manifest_path_full, manifest_data = ManifestLoader.instance().load_ex(env, platform, dep)
    new_deps_tree_node = {dep.ss: []}
    if GS.DEPS in manifest_data:
      for manifest_dep in manifest_data[GS.DEPS]:
        dep_obj = SmbDep.parse(manifest_dep, UgProject.get_branch(), dep.source_file_chain + [manifest_path_full])
        env_k = UgProject.escape_env_name(dep_obj.name)
        # 检查循环依赖
        if env_k in implicit_dep_chain:
          fatal("circular dependency: " + "->".join(implicit_dep_chain) + "->" + env_k)
        else:
          implicit_dep_chain.add(env_k)

        # 验证dep_obj是否已经存在且版本一致，如果存在则跳过，版本不一致则报错
        if env_k in implicit_dep_dict:
          dep_value = implicit_dep_dict[env_k]
          # 版本不一致报错
          is_buildtools = getattr(dep_obj, 'buildtools', False) or getattr(dep_value, 'buildtools', False)
          # 主线分支（release_YYYYMMDD）对 buildtools 依赖仍做严格版本校验
          # is_mainline_branch = bool(re.match(r'^release_\d{8}$', UgProject.get_branch()))
          # if is_buildtools and not is_mainline_branch:
          if is_buildtools:
            # 非主线分支：buildtools 依赖只验证语义化版本第一段，如 1.x.x.x 与 1.y.y.y 兼容，与 2.y.y.y 不兼容
            ver_conflict = (dep_obj.dep_ver.split('.')[0] != dep_value.dep_ver.split('.')[0])
          else:
            ver_conflict = (dep_obj.version != dep_value.version or dep_obj.build_number != dep_value.build_number)
          if ver_conflict:
            fatal("dep conflict: %s, version: %s vs %s, file chain:\n%s\n%s" %
                  (dep_value.name, dep_value.dep_ver, dep_obj.dep_ver, dep_value.formart_source_file_chain(), dep_obj.formart_source_file_chain()))
        else:
          implicit_dep_dict[env_k] = dep_obj

        # 隐式依赖也应该拉取到本地并检查
        self.__process_dep(env, dep_obj, implicit_dep_dict, implicit_dep_chain,
                           only_manifest, new_deps_tree_node[dep.ss])

        # 循环依赖递归出来要把当前节点删掉，走到这里env_k必定存在直接使用remove
        implicit_dep_chain.remove(env_k)
    deps_tree_node.append(new_deps_tree_node)

  # 检查本地和samba是否存在依赖库并拉取到本地缓存
  # 如果是c++编译继续检查隐式依赖
  # implicit_dep_dict 用于检查菱形依赖版本不一致报错, implicit_dep_chain 用于检查单向链循环依赖报错
  def __process_dep(self, env, dep, implicit_dep_dict: OrderedDict, implicit_dep_chain: set, only_manifest=False, deps_tree_node=[]) -> str:
    # 非 only_manifest 模式才需要下载完整依赖包
    if not only_manifest:
      dep_path = os.path.join(dep.name,
                              dep.branch,
                              dep.version,
                              str(dep.build_number))

      # 如果是 buildtools 依赖，使用主机平台；否则使用目标平台
      platform = self.get_host_platform() if getattr(dep, 'buildtools', False) else self.get_platform()

      local_dir = platform.search_compatiable_pack_in_local(dep_path)
      if not local_dir:
        # 如果本地找不到，尝试从远程查找并下载
        remote_dir = platform.search_compatiable_pack_in_remote(dep_path)
        if not remote_dir:
          # 本地和远程都找不到，才报错
          fatal("can not locate dep: " + str(dep))

        # 从远程下载依赖包
        UgProject.download_dep(env, dep, dep_path, remote_dir)
        # 下载后再次在本地查找
        local_dir = platform.search_compatiable_pack_in_local(dep_path)
        if not local_dir:
          fatal("can not locate dep: " + str(dep))

      pack_name = UgProject.get_dep_pack_name(env, dep, local_dir)
      full_local_dir = os.path.join(env.get_local_repo_root(), dep_path, local_dir, pack_name)
      if is_verbose():
        info(" dep found - " + full_local_dir)
      # env.build_dir 需要注意有没有赋值，未赋值会报错，未赋值时也不需要link
      if hasattr(env, "build_dir"):
        # 如果是 buildtools 依赖，链接到主机平台的 build_dir/deps
        # 否则链接到目标平台的 build_dir/deps
        if getattr(dep, 'buildtools', False):
          # buildtools 依赖：使用主机平台的 build_dir
          host_platform_str = platform.get_sorted_str()
          build_root = os.path.dirname(env.build_dir)  # ugreen_build/
          host_build_dir = os.path.join(build_root, host_platform_str)
          deps_dir = os.path.join(host_build_dir, "deps")
        else:
          # 普通依赖：使用目标平台的 build_dir
          deps_dir = os.path.join(env.build_dir, "deps")
        self.__link_dep(deps_dir, full_local_dir, dep)
    # 检查依赖库的依赖库
    self.__check_implicit_dep(env, dep, implicit_dep_dict, implicit_dep_chain, only_manifest, deps_tree_node)

  def __get_prepare_str(self):
    env = self.__env
    ss = "prepare: ${BUILD_DIR}/prepare-ok\n\n"
    ss += "${BUILD_DIR}/prepare-ok: ${PROJECT_DIR}/" + GS.FILENAME
    implicit_dep_list = []
    if len(self.__deps) > 0:
      implicit_dep_dict = OrderedDict()
      deps_tree_node = []
      # 提前把显式依赖写进去，为了避免隐式依赖又依赖了该显式依赖，版本冲突时可以报错
      for dep in self.__deps:
        implicit_dep_dict[UgProject.escape_env_name(dep.name)] = dep
      for dep in self.__deps:
        implicit_dep_chain = {UgProject.escape_env_name(dep.name)}
        self.__process_dep(env, dep, implicit_dep_dict, implicit_dep_chain, deps_tree_node=deps_tree_node)
      if os.path.exists(os.path.join(self.__root, GS.BUILD_DIR)):
        with open(os.path.join(self.__root, GS.BUILD_DIR, GS.DEPS_TREE_FILE), "w") as f:
          f.write(self.__format_deps_tree(deps_tree_node))
      else:
        info("deps tree:\n%s" % self.__format_deps_tree(deps_tree_node))
      # 按顺序记录下显式依赖和隐式依赖到ss字符串，并提取出隐式依赖列表
      for env_k, dep_value in implicit_dep_dict.items():
        ss += "\\\n\t\t${%s_PACK}" % env_k
        if dep_value not in self.__deps:
          implicit_dep_list.append(dep_value)

    envstr = self.__get_dep_envstr(implicit_dep_list=implicit_dep_list)
    ss += "\n"
    ss += "\ttouch ${BUILD_DIR}/prepare-ok"
    return envstr, ss + "\n"

  # 获取隐式依赖列表，ugbt gen-ugbt-cmake使用
  def __get_implicit_deps(self) -> list:
    if self.__template != GS.CMAKE:
      return []
    env = self.__env
    pstr = self.get_platform().get_sorted_str()
    env.build_dir = os.path.join(self.__root, GS.BUILD_DIR, pstr)
    implicit_dep_list = []
    if len(self.__deps) > 0:
      implicit_deps = OrderedDict()
      deps_tree_node = []
      # 提前把显式依赖写进去，为了避免隐式依赖又依赖了该显式依赖，版本冲突时可以报错
      for dep in self.__deps:
        implicit_deps[UgProject.escape_env_name(dep.name)] = dep
      for dep in self.__deps:
        implicit_dep_chain = {UgProject.escape_env_name(dep.name)}
        self.__process_dep(env, dep, implicit_deps, implicit_dep_chain, deps_tree_node=deps_tree_node)
      if os.path.exists(os.path.join(self.__root, GS.BUILD_DIR)):
        with open(os.path.join(self.__root, GS.BUILD_DIR, GS.DEPS_TREE_FILE), "w") as f:
          f.write(self.__format_deps_tree(deps_tree_node))
      else:
        info("deps tree:\n%s" % self.__format_deps_tree(deps_tree_node))
      for value in implicit_deps.values():
        # 排除显式依赖
        if value not in self.__deps:
          implicit_dep_list.append(value)
    return implicit_dep_list

  def __get_env_vars(self):
    if not self.__env_vars or len(self.__env_vars) == 0:
      return ""

    header = "# ENV VARS in " + GS.FILENAME + " start\n"
    for var_k in self.__env_vars.keys():
      var_v = self.__env_vars[var_k]
      header += "export %s=%s\n" % (var_k, var_v)
    header += "# ENV VARS end\n\n"
    return header

  def __get_build_vars(self):
    header = "# BUILD VARS start\n"
    header += self.get_platform().get_env_str()
    header += "# BUILD VARS end\n\n"
    return header

  def __gen_template_makefile(self):
    env = self.__env
    makefile_tpl = os.path.join(env.root, "tpl", "Makefile-" + self.__template + ".in")
    pstr = self.get_platform().get_sorted_str()
    makefile = os.path.join(self.__root, GS.BUILD_DIR, self.__template + "-" + pstr + ".mk")

    if not os.path.exists(makefile_tpl):
      fatal(makefile_tpl + " not found")
    content = read_file(makefile_tpl)

    # if self.__template == GS.UGTOOLS or self.__template == GS.UGTOOLS_UPK:
    # elif self.__template == GS.DEFAULT:
    if not self.__template:
      fatal("template is empty")

    content = content.replace("%%ROOTFS_FILES%%", self.__get_root_files_str())
    content = content.replace("%%PACK%%", self.__pack)

    pack_cmd = "cd ${BUILD_DIR} && source ug_env.sh && make -j ${UG_NPROC} && make install -j ${UG_NPROC}"
    if self.__env_vars and self.__env_vars.get("UG_PACK_CMD", ""):
      pack_cmd += " && ${UG_PACK_CMD}"
    content = content.replace("%%PACK_CMD%%", pack_cmd)

    # content = content.replace("%%UGTOOLS%%", self.__get_go_install_target_str())

    write_file_if_changed(makefile, content)

  def get_envs(self):
    pack_name = self.__get_install_pack_name()
    env = OrderedDict()
    env["PACK_NAME"] = pack_name
    return env

  def source_envs(self):
    envs = self.get_envs()
    for env_k in envs.keys():
      env_v = envs[env_k]
      os.environ[env_k] = env_v

  def __gen_framework_makefile(self):
    env = self.__env
    pstr = self.get_platform().get_sorted_str()
    makefile_tpl = os.path.join(env.root, "tpl", "Makefile-framework.in")
    if not os.path.exists(makefile_tpl):
      fatal(makefile_tpl + " not found")

    makefile = os.path.join(self.__root, GS.BUILD_DIR, "Makefile-" + pstr)

    content = read_file(makefile_tpl)
    if self.__output_format == GS.RAW:
      if not self.__release_name:
        fatal("please set 'release-name' in ugreen_project.yaml")
      install = "${BUILD_DIR}/ugbt_framework_install.sh"
      install_path = os.path.join(env.build_dir, "ugbt_framework_install.sh")
      icontent = ""
      icontent += "#!/bin/bash\n"
      icontent += "set -ex\n"
      icontent += "\n"
      icontent += "rm -rf ${INSTALL_DIR}\n"
      icontent += "TMP_INSTALL_DIR=${INSTALL_DIR}-$(uuidgen).tmp\n"
      icontent += "mkdir -p ${TMP_INSTALL_DIR}\n"
      icontent += "cd ${BUILD_DIR}_pack\n"
      icontent += "rsync -a ${BUILD_DIR}_pack/ ${TMP_INSTALL_DIR}\n"
      icontent += "\"${UGBASE_ROOT}/ugbt\" manifest -d ${TMP_INSTALL_DIR} -p ${PACK_NAME}\n"
      icontent += "mv ${TMP_INSTALL_DIR} ${INSTALL_DIR}"
      write_file(install_path, icontent)
      run("chmod +x " + install_path)
    elif self.__output_format == GS.TGZ:
      install = "${UGBASE_ROOT}/script/install.sh"
    elif self.__output_format == GS.BOTH:
      if not self.__release_name:
        fatal("please set 'release-name' in ugreen_project.yaml")
      install = "${UGBASE_ROOT}/script/install_both.sh"
    else:
      fatal("Unknown output format: " + self.__output_format)

    content = content.replace("%%UGBASE_ROOT%%", env.root)
    content = content.replace("%%PROJECT_DIR%%", self.__root)
    content = content.replace("%%BUILD_DIR%%", env.build_dir)
    install_path = self.get_install_path()
    content = content.replace("%%INSTALL%%", install)
    install_dir = os.path.join(env.get_local_repo_root(), install_path)
    content = content.replace("%%INSTALL_DIR%%", install_dir)
    pack_name = self.__get_install_pack_name()
    content = content.replace("%%PACK_NAME%%", pack_name)
    content = content.replace("%%VERSION%%", self.__version)
    content = content.replace("%%BUILD_NUMBER%%", str(self.__build_number))
    content = content.replace("%%BUILD_NUMBER_04D%%", "%04d" % (self.__build_number))

    if self.__template:
      include_tpl = "\ninclude ${PROJECT_DIR}/ugreen_build/" + self.__template + "-" + pstr + ".mk"
      if self.__template == GS.DEFAULT:
        if os.path.exists(os.path.join(self.__root, "ugbt.mk")):
          include_tpl = "\ninclude ${PROJECT_DIR}/ugbt.mk"
    else:
      include_tpl = ""
    content = content.replace("%%INCLUDE%%", include_tpl)
    content = content.replace("%%PACK%%", self.__pack)
    content = content.replace("%%GO_INSTALLS%%", self.__get_go_install_str())
    envstr, prepare_str = self.__get_prepare_str()
    content = content.replace("%%PREPARE%%", prepare_str)
    content = self.__get_env_vars() + self.__get_build_vars() + envstr + content

    write_file_if_changed(makefile, content)

  def gen_makefiles(self):
    env = self.__env
    pstr = self.get_platform().get_sorted_str()
    env.build_dir = os.path.join(self.__root, GS.BUILD_DIR, pstr)
    make_dir(env.build_dir)
    self.__gen_framework_makefile()
    if self.__template:
      self.__gen_template_makefile()

  def get_go_install(self, name):
    for ins in self.__go_installs:
      if ins.filename == name:
        return ins
    fatal(name + " go-install not found")

  def go_install(self):
    env = self.__env
    proj_tmp_bin = os.path.join(self.__root, GS.BUILD_DIR, "bin")

    for ins in self.__go_installs:
      make_dir(proj_tmp_bin)
      tool_path = os.path.join(proj_tmp_bin, ins.filename)
      if os.path.exists(tool_path):
        info("found " + tool_path)
      else:
        cmd = "GOBIN=" + proj_tmp_bin
        cmd += " go install %s/%s@%s" % (ins.git, ins.path, ins.rev)
        run(cmd, show_start_log=True)
        if not os.path.exists(tool_path):
          fatal("%s not found, go install fail" % tool_path)

  def __get_export_str(self):
    pstr = self.get_platform().get_sorted_str()
    bdir = os.path.join(self.__root, GS.BUILD_DIR, pstr)
    ss = ""
    ss += "export VERSION=" + self.__version + "\n"
    ss += "export BUILD_NUMBER=" + str(self.__build_number) + "\n"
    ss += "export PROJECT_DIR=" + self.__root + "\n"
    ss += "export BUILD_DIR=" + bdir + "\n"
    pstr = self.get_platform().get_sorted_str()
    target_dir = os.path.join(self.__root, GS.BUILD_DIR, pstr)
    ss += "export TARGET_DIR=" + target_dir + "\n"
    ss += self.get_platform().get_env_str()
    return ss

  def build(self):
    info("build start ...")
    if self.__build:
      cmd = self.__get_export_str()
      cmd += "bash -c \"%s\"" % self.__build
      run(cmd, show_start_log=True)
    info("build OK")

  def __check_docker_need_update(self):
    env = self.__env
    if not "DOCKER_TAG" in os.environ:
      fatal("this docker need to restart")
    this_tag = os.environ["DOCKER_TAG"]
    info(this_tag)

    docker_arch_type = os.environ.get("DOCKER_ARCH_TYPE")
    if docker_arch_type == "arm64" or docker_arch_type == "arm":
      main_tag = read_file(os.path.join(env.root, "DOCKER-ARM-VERSION")).strip()
    else:
      main_tag = read_file(os.path.join(env.root, "DOCKER-VERSION")).strip()
    dev_tag = main_tag + "-dev"
    if dev_tag != this_tag and main_tag != this_tag:
      if not (env.me == "jenkins" or env.me == "gitlab"):
        fatal("docker need restart to update, [%s] -> [%s] or [%s]" % (this_tag, main_tag, dev_tag))

  def __check_core_pattern(self):
    core_pattern_path = "/proc/sys/kernel/core_pattern"
    core_pattern = read_file(core_pattern_path)
    cc = "/coredump/core-%u-%p-%s-%t-%e\n"
    if core_pattern != cc:
      error("invalid core pattern [ %s ] in file [ %s ], should be [ %s ]" % (core_pattern, core_pattern_path, cc))
      fatal("to change to core_pattern, run the following commands on the physical machine, not in docker, and restart the docker container:\n" +
            "sudo systemctl disable --now apport.service\n" +
            "sudo install -d -m 1777 /data/coredump\n" +
            "sudo ln -sfnT /data/coredump /coredump\n" +
            "echo 'kernel.core_pattern = /coredump/core-%u-%p-%s-%t-%e' | sudo tee /etc/sysctl.d/99-ugreen-coredump.conf\n" +
            "sudo sysctl --system\n" +
            "cat /proc/sys/kernel/core_pattern\n"
            )

  def __check_aio_max_nr(self):
    path = "/proc/sys/fs/aio-max-nr"
    v = int(read_file(path).strip())
    expect = 1048576
    if v < expect:
      error("invalid %s [ %s ], should >= [ %s ]" % (path, v, expect))
      fatal("to change the aio-max-nr, run the following commands on the physical machine, not in docker, and restart the docker container:\n" +
            "echo \"fs.aio-max-nr = 1048576\" | sudo tee /etc/sysctl.d/99-ugreen-aio.conf\n" +
            "sudo sysctl --system\n" +
            "cat /proc/sys/fs/aio-max-nr\n"
            )

  def __check_perf_event_paranoid(self):
    path = "/proc/sys/kernel/perf_event_paranoid"
    v = int(read_file(path).strip())
    expect = 1
    if v > expect:
      error("invalid %s [ %s ], should <= [ %s ]" % (path, v, expect))
      fatal("to change the perf_event_paranoid, run the following commands on the physical machine, not in docker, and restart the docker container:\n" +
            "echo \"kernel.perf_event_paranoid = 1\" | sudo tee /etc/sysctl.d/99-ugreen-perf.conf\n" +
            "sudo sysctl --system\n" +
            "cat /proc/sys/kernel/perf_event_paranoid\n"
            )

  def get_version(self):
    return self.__version

  def get_build_number(self):
    return self.__build_number

  def make(self, target, dry_run=False):
    self.__check_docker_need_update()
    self.__check_core_pattern()
    self.__check_aio_max_nr()
    self.__check_perf_event_paranoid()
    cmd = ""
    cmd += "cd " + os.path.join(self.__root) + " &&\\\n"
    runopts = " --dry-run" if dry_run else ""
    pstr = self.get_platform().get_sorted_str()
    makefile = os.path.join(GS.BUILD_DIR, "Makefile-" + pstr)
    cmd += "  make -f " + makefile
    cmd += runopts
    if isinstance(target, str):
      cmd += " " + target
    elif isinstance(target, list):
      cmd += " " + ','.join(target)
    else:
      fatal("unknown target type " + type(target))
    run(cmd, show_start_log=True)

  def pack(self):
    info("pack start ...")
    pstr = self.get_platform().get_sorted_str()
    target_dir = os.path.join(self.__root, GS.BUILD_DIR, pstr)
    make_dir(target_dir)
    cmd = self.__get_export_str()
    cmd += "bash -c \"%s\"" % self.__pack
    run(cmd, show_start_log=True)
    info("pack OK")

  def get_install_path(self):
    return os.path.join(self.__name,
                        UgProject.get_branch(),
                        self.__version,
                        str(self.__build_number),
                        self.__platform.get_sorted_str())

  def __get_install_pack_name(self):
    name = self.__name.replace("/", "_")
    pack_name = (
        f"{UgProject.get_branch()}-{name}"
        f"-{self.__version}.{self.__build_number}-{self.__platform.get_sorted_short_str()}"
    )
    return pack_name

  def __get_install_files(self):
    pack_name = self.__get_install_pack_name()
    return (pack_name + ".tar.gz", pack_name + ".manifest.yaml")

  def generate_manifest(self, pack_dir, pack_name):
    env = self.__env
    if self.__build_number == 0:
      fatal("build number is 0000, run 'ugbt update' first")
    if self.__output_format == GS.TGZ or self.__output_format == GS.BOTH:
      pack_path = os.path.join(pack_dir, pack_name + ".tar.gz")
      md5_value = md5(pack_path)
    elif self.__output_format == GS.RAW:
      md5_value = OrderedDict()
      for folder, dirs, files in os.walk(pack_dir):
        for file in files:
          f = os.path.join(folder, file)
          f = f[len(pack_dir) + 1:]
          md5_value[f] = md5(os.path.join(pack_dir, f))
    else:
      fatal("unknown output format: " + self.__output_format)
    manifest_path = os.path.join(pack_dir, pack_name + ".manifest.yaml")

    manifest = OrderedDict()
    if "GITLAB_USER_LOGIN" in os.environ:
      manifest["author"] = "gitlab:" + os.environ["GITLAB_USER_LOGIN"]
      manifest["url"] = os.environ["CI_PIPELINE_URL"]
    elif "BUILD_URL" in os.environ:
      manifest["author"] = "jenkins:user"
      # TODO, jenkins does not install build var plugin
      # manifest["author"] = "jenkins:" + os.environ["BUILD_USER"]
      manifest["url"] = os.environ["BUILD_URL"]
    else:
      if env.me == "jenkins" or env.me == "gitlab":
        fatal("Invalid author: " + env.me + ", can not be gitlab or jenkins")
      manifest["author"] = "local:" + env.me
    manifest["time"] = runex("date -R")
    manifest["host"] = runex("hostname -I | awk '{print $1}'")
    manifest["md5"] = md5_value
    git = Git(False, self.__root, assert_ok=True)
    manifest["git"] = git.origin_url()
    manifest["branch"] = UgProject.get_branch()
    if self.__platform.has(GS.PRODUCT_SERIES):
      manifest[GS.PRODUCT_SERIES] = self.__platform.get(GS.PRODUCT_SERIES)
    manifest["dirty"] = git.is_dirty()
    info("manifest beta: release=%s, GS.RELEASE=%s, beta=%s" %
         (self.__release, GS.RELEASE, self.__release != GS.RELEASE))
    manifest["beta"] = self.__release != GS.RELEASE
    manifest["revision"] = git.get_head()
    manifest[GS.UGBASE] = "%s %s %s" % (
        self.__ugbase.git, self.__ugbase.branch, self.__ugbase.revision)
    if GS.GO_INSTALL in self.__data:
      manifest[GS.GO_INSTALL] = self.__data[GS.GO_INSTALL]
    if GS.DEPS in self.__data:
      manifest[GS.DEPS] = self.__data[GS.DEPS]
    if GS.OUTPUT in self.__data:
      manifest[GS.OUTPUT] = self.__data[GS.OUTPUT]
      if GS.FILES in manifest[GS.OUTPUT]:
        files = manifest[GS.OUTPUT][GS.FILES]
        for i in range(len(files)):
          files[i] = os.path.expandvars(files[i])

    content = dump_yaml(manifest)
    write_file(manifest_path, content)
    info("manifest: " + content)

  @staticmethod
  def __get_max_folder(parent, folders):
    maxn = 0
    maxs = ""

    for folder in folders:
      if folder.startswith("."):
        continue
      if folder.find("tmp") >= 0:
        continue
      if folder.startswith("."):
        continue
      if not folder.isdigit():
        fatal("invalid folder [%s] in %s, must be digit" % (folder, parent))
      folder_n = int(folder)
      if maxn == folder_n:
        fatal("invalid folder [%s] in %s, duplicate or is 0" % (folder, parent))
      if maxn < folder_n:
        maxn = folder_n
        maxs = folder
    return maxs

  def check_remote(self):
    env = self.__env
    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]

    build_number_dir = os.path.dirname(self.get_install_path())
    version_dir = os.path.dirname(build_number_dir)
    version_path = os.path.join(repo_root, version_dir)
    verion_path_full = "smb://%s/%s/%s" % (host, share_name, version_path)
    upload_path = os.path.join(repo_root, build_number_dir)
    upload_path_full = "smb://%s/%s/%s" % (host, share_name, upload_path)
    if not conn.exists(share_name, version_path):
      info("%s not exist" % version_path)
      info("[%s] is ready for upload" % upload_path_full)
      return
    folders = conn.ls(share_name, version_path)
    max_folder = UgProject.__get_max_folder(version_path, folders)
    if not max_folder:
      max_folder_n = 0
    else:
      max_folder_n = int(max_folder)
    if max_folder_n >= self.__build_number:
      fatal("current build number [%d] <= [%d] on [%s]" % (
          self.__build_number, max_folder_n, verion_path_full
      ))

    if conn.exists(share_name, upload_path):
      fatal("[%s] exists" % upload_path_full)
    else:
      info("[%s] is ready for upload" % upload_path_full)

  def __clean_tmp_folders(self, folders):
    ret = []
    for folder in folders:
      if ".tmp" in folder:
        ret.append(folder)
    return ret

  def __clean_local_repo_temp_dirs(self):
    env = self.__env
    build_number_dir = os.path.dirname(self.get_install_path())
    repo_root = env.get_local_repo_root()
    build_number_path = os.path.join(repo_root, build_number_dir)
    if not os.path.exists(build_number_path):
      return
    folders = os.listdir(build_number_path)
    folders_to_del = self.__clean_tmp_folders(folders)
    for folder in folders_to_del:
      path_to_del = os.path.join(build_number_path, folder)
      run("rm -rf " + path_to_del)

  def __clean_remote_repo_temp_dirs(self):
    env = self.__env
    product_dir = os.path.join(self.__name,
                               UgProject.get_branch(),
                               self.__version)

    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    product_path = os.path.join(repo_root, product_dir)
    if not conn.exists(share_name, product_path):
      return
    folders = conn.ls(share_name, product_path)
    folders_to_del = self.__clean_tmp_folders(folders)
    for folder in folders_to_del:
      path_to_del = os.path.join(product_path, folder)
      conn.delete_dir_recursive(share_name, path_to_del)
      info("clean - smb://%s/%s/%s" % (host, share_name, path_to_del))

  def clean_repo_tmp_dirs(self):
    self.__clean_local_repo_temp_dirs()
    self.__clean_remote_repo_temp_dirs()

  @staticmethod
  def sanitize_upload_staging_id(staging_id):
    if not staging_id or not str(staging_id).strip():
      fatal("empty staging id")
    s = re.sub(r'[^a-zA-Z0-9._-]+', '_', str(staging_id).strip())
    if not s:
      fatal("invalid staging id after sanitize")
    return s

  @staticmethod
  def __remove_remote_path_if_exists(conn, share_name, path):
    if not conn.exists(share_name, path):
      return
    if conn.isdir(share_name, path):
      conn.delete_dir_recursive(share_name, path)
    else:
      conn.remove(share_name, path)

  @staticmethod
  def clear_upload_staging_platform(env, staging_id, platform):
    """Remove this platform's directory under SMB staging before retrying upload."""
    staging_id = UgProject.sanitize_upload_staging_id(staging_id)
    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    proj = UgProject.load(env, {}, platform=platform)
    proj.source_envs()
    pdir = proj.get_platform().get_sorted_str()
    vdir = os.path.dirname(os.path.join(repo_root, proj.get_install_path()))
    vdir_staging = vdir + "-" + staging_id + ".tmp"

    if not conn.exists(share_name, vdir_staging):
      info("staging root not present, skip remote platform clear: smb://%s/%s/%s" % (host, share_name, vdir_staging))
      return

    plat_dir = os.path.join(vdir_staging, pdir)
    if conn.exists(share_name, plat_dir):
      if conn.isdir(share_name, plat_dir):
        conn.delete_dir_recursive(share_name, plat_dir)
      else:
        conn.remove(share_name, plat_dir)
      info("cleared remote staging platform path: smb://%s/%s/%s" % (host, share_name, plat_dir))

  @staticmethod
  def __upload_one_platform_to_staging(env, conn, share_name, vdir_parent, platform):
    proj = UgProject.load(env, {}, platform=platform)
    proj.source_envs()
    pdir = proj.get_platform().get_sorted_str()
    plat_staging = os.path.join(vdir_parent, pdir)
    UgProject.__remove_remote_path_if_exists(conn, share_name, plat_staging)
    conn.mkdir(share_name, plat_staging)
    install_dir = os.path.join(env.get_local_repo_root(), proj.get_install_path())
    if not os.path.exists(install_dir):
      fatal("install dir not found: " + install_dir)
    pack_file_name, manifest_file_name = proj.__get_install_files()
    manifest_path = os.path.join(install_dir, manifest_file_name)
    data = load_yaml_f(manifest_path)
    if data["dirty"]:
      fatal("pack " + install_dir + " is dirty")

    output_files = []
    if proj.__output_format == GS.RAW:
      for folder, dirs, files in os.walk(install_dir):
        for f in files:
          f = os.path.join(install_dir, f)
          f = f[len(install_dir) + 1:]
          output_files.append(f)
    elif proj.__output_format == GS.TGZ:
      output_files.append(pack_file_name)
    elif proj.__output_format == GS.BOTH:
      output_files.append(pack_file_name)
      pack_name = proj.__get_install_pack_name()
      output_files.append(pack_name)
    else:
      fatal("??")

    for f in output_files:
      f_path = os.path.join(install_dir, f)
      upload_path = os.path.join(plat_staging, f)
      conn.upload(f_path, share_name, upload_path)

    manifest_path = os.path.join(install_dir, manifest_file_name)
    upload_manifest_path = os.path.join(plat_staging, manifest_file_name)
    conn.upload(manifest_path, share_name, upload_manifest_path)

  @staticmethod
  def upload_stage_platform(env, platform, staging_id):
    staging_id = UgProject.sanitize_upload_staging_id(staging_id)
    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    proj = UgProject.load(env, {}, platform=platform)
    proj.source_envs()
    # 其他构建的外层 staging 可能仍在上传，当前任务只能操作自己的 staging_id。
    vdir = os.path.dirname(os.path.join(repo_root, proj.get_install_path()))
    vdir_staging = vdir + "-" + staging_id + ".tmp"
    conn.mkdir(share_name, vdir_staging)
    UgProject.__upload_one_platform_to_staging(env, conn, share_name, vdir_staging, platform)

  @staticmethod
  def upload_finalize(env, platforms, staging_id):
    staging_id = UgProject.sanitize_upload_staging_id(staging_id)
    if len(platforms) == 0:
      fatal("upload_finalize: no platforms")
    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    proj0 = UgProject.load(env, {}, platform=platforms[0])
    proj0.source_envs()
    # finalize 只检查并发布当前 staging，不能清理其他流水线保留的外层 tmp。
    vdir = os.path.dirname(os.path.join(repo_root, proj0.get_install_path()))
    vdir_staging = vdir + "-" + staging_id + ".tmp"
    if not conn.exists(share_name, vdir_staging) or not conn.isdir(share_name, vdir_staging):
      fatal("staging path not found or not a directory: smb://%s/%s/%s" % (host, share_name, vdir_staging))
    for platform in platforms:
      proj = UgProject.load(env, {}, platform=platform)
      proj.source_envs()
      pdir = proj.get_platform().get_sorted_str()
      plat_dir = os.path.join(vdir_staging, pdir)
      if not conn.isdir(share_name, plat_dir):
        fatal("staging missing platform dir: smb://%s/%s/%s" % (host, share_name, plat_dir))
      _, manifest_file = proj.__get_install_files()
      manifest_remote = os.path.join(plat_dir, manifest_file)
      if not conn.exists(share_name, manifest_remote):
        fatal("staging missing manifest: smb://%s/%s/%s" % (host, share_name, manifest_remote))
    if conn.exists(share_name, vdir):
      fatal("final path already exists: smb://%s/%s/%s" % (host, share_name, vdir))
    conn.mv(share_name, vdir_staging, vdir)

  @staticmethod
  def upload_all(env, platforms):
    # vdir = os.path.dirname(os.path.join(env.get_local_repo_root(), dumpy_proj.get_install_path()))
    not_found_lst = []
    dirty_lst = []
    for platform in platforms:
      proj = UgProject.load(env, {}, platform=platform)
      proj.source_envs()
      install_dir = os.path.join(env.get_local_repo_root(), proj.get_install_path())
      if not os.path.exists(install_dir):
        not_found_lst.append(proj.get_platform().get_sorted_str())
      _, manifest_file = proj.__get_install_files()
      manifest_path = os.path.join(install_dir, manifest_file)
      data = load_yaml_f(manifest_path)

      if data["dirty"]:
        dirty_lst.append(proj.get_platform().get_sorted_str())

    # check installed
    if len(not_found_lst) > 0:
      fatal("the following platform packages not found:\n" + dump_yaml(not_found_lst))
    # check not dirty
    if len(dirty_lst) > 0:
      fatal("the following platform packages are dirty:\n" + dump_yaml(dirty_lst))

    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    ref = UgProject.load(env, {}, platform=platforms[0])
    ref.source_envs()
    # 一次性上传也使用独立 tmp，禁止按构建号删除其他流水线的 staging。
    vdir = os.path.dirname(os.path.join(repo_root, ref.get_install_path()))
    vdir_tmp = vdir + "-" + uuid_gen() + ".tmp"
    conn.mkdir(share_name, vdir_tmp)
    for platform in platforms:
      UgProject.__upload_one_platform_to_staging(env, conn, share_name, vdir_tmp, platform)

    conn.mv(share_name, vdir_tmp, vdir)

  def upload(self, is_mock):
    env = self.__env
    install_relative_path = self.get_install_path()
    install_dir = os.path.join(env.get_local_repo_root(), install_relative_path)
    pack_file_name, manifest_file_name = self.__get_install_files()
    manifest_path = os.path.join(install_dir, manifest_file_name)
    if not os.path.exists(install_dir):
      fatal(install_dir + " not found")

    manifest = load_yaml_f(manifest_path)
    if manifest["dirty"]:
      fatal("pack " + install_dir + " is dirty")
    if is_mock:
      info("mock upload OK")
      return

    build_env = env.get_build_env()
    host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(host)
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    upload_dir = os.path.join(repo_root, install_relative_path)
    if conn.exists(share_name, upload_dir):
      fatal("smb://%s/%s/%s exists" % (host, share_name, upload_dir))

    tmp_upload_dir = upload_dir + "-" + uuid_gen() + ".tmp"
    conn.mkdir(share_name, tmp_upload_dir)

    pack_path = os.path.join(install_dir, pack_file_name)
    upload_path = os.path.join(tmp_upload_dir, pack_file_name)
    conn.upload(pack_path, share_name, upload_path)

    manifest_upload_path = os.path.join(tmp_upload_dir, manifest_file_name)
    conn.upload(manifest_path, share_name, manifest_upload_path)

    conn.mv(share_name, tmp_upload_dir, upload_dir)

  def __generate_build_number(self, odd=False):
    build_number = self.__build_number
    new_build_number = build_number + ((2 if build_number % 2 else 3) if odd else 1)
    if build_number < 0 or new_build_number > 9999:
      fatal("invalid build number: %s" % build_number)
    return new_build_number

  def inc_build_number(self):
    self.__build_number = self.__generate_build_number(odd=True)
    self.__data[GS.VERSION] = self.__version + "." + str(self.__build_number)

  def __find_version_to_update(self, parent, data, dep, folders):
    folder = UgProject.__get_max_folder(parent, folders)
    if is_verbose():
      info("version [%s] found" % folder)
    if not folder:
      fatal("no dep [%s] found in %s" % (dep, parent))
    build_number = int(folder)
    for i in range(len(data[GS.DEPS])):
      depstr = data[GS.DEPS][i]
      if is_verbose():
        info("depstr " + depstr)
      if not (dep.name + " " in depstr or dep.name + "@" in depstr):
        if is_verbose():
          info("dep name not match : " + dep.name)
        continue

      tokens = depstr.split(' ')
      if len(tokens) != 2:
        fatal("invalid depstr: " + depstr)
      vs = tokens[1].split('.')
      if len(vs) != 4:
        fatal("invalid depstr: " + depstr)
      old_build_number = int(vs[3])
      if build_number > old_build_number:
        new_depstr = "%s %s.%s.%s.%s" % (tokens[0], vs[0], vs[1], vs[2], build_number)
        info("new version found: " + new_depstr)
        data[GS.DEPS][i] = new_depstr
      elif build_number < old_build_number:
        warning("skipped build number [%s] < old build number [%s] of %s" % (build_number, old_build_number, depstr))

  def save(self, data=None):
    if not data:
      data = self.__data
    content = dump_yaml(data)
    fname = os.path.join(self.__root, GS.FILENAME)
    content_old = read_file(fname)
    if content == content_old:
      info("Update to date - " + fname)
    else:
      write_file(fname, content)

  def update(self, in_local, increate_build_number, skip_lock):
    env = self.__env
    data = copy.deepcopy(self.__data)
    self.__init_go_code_master()
    for master_dir, go_dep in self.__get_go_dep_list():
      rev = runex("cd %s && git rev-parse origin/%s" % (master_dir, go_dep.branch)).strip()
      if rev != go_dep.revision:
        go_dep.revision = rev

    for ins in self.__go_installs:
      master_dir = os.path.join(get_ugdata(), GS.GO_INSTALL,
                                ins.git.replace("/", "__"))
      rev = runex("cd %s && git rev-parse origin/%s" % (master_dir, ins.branch)).strip()
      data[GS.GO_INSTALL][ins.filename][GS.REV] = rev

    master_dir = os.path.join(get_ugdata(), GS.UGBASE)
    ret = run("cd %s && git show-ref --tags --verify refs/tags/%s > /dev/null 2>&1" % (
        master_dir, self.__ugbase.branch), assert_ok=False, show_log=False)
    is_tag = (ret == 0)
    if is_tag:
      rev = runex("cd %s && git rev-parse refs/tags/%s" % (master_dir, self.__ugbase.branch)).strip()
    else:
      rev = runex("cd %s && git rev-parse origin/%s" % (master_dir, self.__ugbase.branch)).strip()
    data[GS.UGBASE] = "%s %s %s" % (self.__ugbase.git, self.__ugbase.branch, rev)

    if in_local:
      info("looking up new version in local repo ...")
    else:
      info("looking up new version in remote repo ...")
    deps_not_found = []
    deps_ok = []
    for dep in self.__deps:
      if not skip_lock and (dep.name in self.__locked_mods):
        warning("[%s] is locked" % dep.name)
        continue
      vdir = os.path.join(dep.name, dep.branch, dep.version)
      if in_local:
        build_env = env.get_build_env()
        local_repo = build_env["LOCAL_REPO"]
        product_path = os.path.expandvars(os.path.join(local_repo, vdir))
        if not os.path.exists(product_path):
          deps_not_found.append((dep, vdir))
          continue
        folders = os.listdir(product_path)
        self.__find_version_to_update(product_path, data, dep, folders)
        deps_ok.append(dep)
      else:
        build_env = env.get_build_env()
        host = build_env["SMB_HOST"]
        conn = SambaConnection.instance(host)
        share_name = build_env["SMB_SHARE_NAME"]
        smb_repo = build_env["SMB_REPO"]
        product_path = os.path.join(smb_repo, vdir)
        if not conn.exists(share_name, product_path):
          deps_not_found.append((dep, vdir))
          continue
        folders = conn.ls(share_name, product_path)
        parent = "smb://%s/%s/%s" % (host, share_name, product_path)
        self.__find_version_to_update(parent, data, dep, folders)
        deps_ok.append(dep)
    for dep, product_path in deps_not_found:
      error("%s not found in %s" % (dep, product_path))
    if len(deps_not_found) > 0:
      fatal("%d deps found, %d deps not found" % (len(deps_ok), len(deps_not_found)))

    if increate_build_number:
      new_build_number = self.__generate_build_number()
      info("new build number: %s of %s %s" % (new_build_number, self.__name, self.__version))
      data[GS.VERSION] = self.__version + "." + str(new_build_number)

    # data中的depstr是最新的，解析新的dep结构
    if GS.DEPS in data:
      proj_path = os.path.join(self.__root, GS.FILENAME)
      deptmps = []
      implicit_dep_dict = OrderedDict()
      deps_tree_node = []
      for depstr in data[GS.DEPS]:
        deptmp = SmbDep.parse(depstr, UgProject.get_branch(), [proj_path])
        deptmps.append(deptmp)
        implicit_dep_dict[UgProject.escape_env_name(deptmp.name)] = deptmp
      for deptmp in deptmps:
        implicit_dep_chain = {UgProject.escape_env_name(deptmp.name)}
        self.__process_dep(env, deptmp, implicit_dep_dict, implicit_dep_chain,
                           only_manifest=True, deps_tree_node=deps_tree_node)
      if os.path.exists(os.path.join(self.__root, GS.BUILD_DIR)):
        with open(os.path.join(self.__root, GS.BUILD_DIR, GS.DEPS_TREE_FILE), "w") as f:
          f.write(self.__format_deps_tree(deps_tree_node))
      else:
        info("deps tree:\n%s" % self.__format_deps_tree(deps_tree_node))

    self.save(data)

    '''
    platforms = []
    if GS.PLATFORM in self.__data:
      platforms = self.__data[GS.PLATFORM]
    platforms = sorted(platforms)
    platforms_str = ",".join(platforms)
    tpl_gitlab_ci_yml_file = os.path.join(env.root, "tpl", "gitlab-ci-" + platforms_str + ".yml.in")
    user_gitlab_ci_yml_file = os.path.join(self.__root, "gitlab-ci-ugreen.yml")
    content = ""
    if os.path.exists(tpl_gitlab_ci_yml_file):
      content += read_file(tpl_gitlab_ci_yml_file)
    if os.path.exists(user_gitlab_ci_yml_file):
      content += read_file(user_gitlab_ci_yml_file)
    gitlab_ci_yml_file = os.path.join(self.__root, ".gitlab-ci.yml")
    content_old = ""
    if os.path.exists(gitlab_ci_yml_file):
      content_old = read_file(gitlab_ci_yml_file)
    if content_old == content:
      info("update to date - " + gitlab_ci_yml_file)
    else:
      write_file(gitlab_ci_yml_file, content)
    '''

  def __str__(self):
    ss = "proj: " + os.path.join(self.__root, GS.FILENAME)
    ss += "\n" + dump_yaml(self.__data)
    return ss

  # find the root of ugreen_project.yaml
  # go.mod and ugreen_project.yaml is mutually exclusive
  @staticmethod
  def find_project_root():
    pwd = os.getcwd()
    root = os.path.abspath(pwd)
    while root != "/":
      proj_file = os.path.join(root, GS.FILENAME)
      if os.path.exists(proj_file):
        return root
      root = os.path.join(root, "..")
      root = os.path.abspath(root)

    fatal("can not find [%s] from [%s]" % (GS.FILENAME, pwd))
    return None

  @staticmethod
  def __get_table_style():
    return "class=\"ug-table\""

  @staticmethod
  def __version_check_pass():
    return "class=\"deps-version-check-pass\""

  @staticmethod
  def __version_check_fail():
    return "class=\"deps-version-check-fail\""

  @staticmethod
  def __version_check_noneed():
    return "class=\"deps-version-check-noneed\""

  def __generate_req_test_email_pack_info(self):
    env = self.__env
    manifest_file0 = env.manifest_files[0]
    manifest0 = load_yaml_f(os.path.join(env.version_path_full, manifest_file0))
    vstr = self.__version + ".%04d" % self.__build_number
    content = ""
    content += "<p>"
    content += "【%s】" % self.__get_pack_release_cname()
    content += "【%s】" % UgProject.get_branch()
    content += "【%s-%s】" % (self.__name, vstr)
    content += "【%s】" % env.now_str
    content += "</p>\n"
    content += "<p>版本名称：%s</p>\n" % vstr
    vs = vstr.split('.')
    vstr_without_dot = "%d%02d%02d%04d" % (int(vs[0]), int(vs[1]), int(vs[2]), self.__build_number)
    content += "<p>版本名称：%s</p>\n" % vstr_without_dot
    if False:
      product_json_path = manifest0.replace(".manifest.yaml", "") + ".product.json"
      product_json_path_full = os.path.join(env.version_path_full, product_json_path)
      if os.path.exists(product_json_path_full):
        product = load_json_f(product_json_path_full)
        for prodk in product.key():
          if prodk == "version":
            continue
          prod = product[prodk]
          content += "<p>%s产品信息：</p>\n" % html.escape(prodk)
          for k in prod.keys():
            v = prod[k]
            content += "<p> - %s：%s</p>\n" % (html.escape(k), html.escape(v))
    content += "<p>分支：%s</p>\n" % UgProject.get_branch()
    content += "<p>git url：%s</p>\n" % get_clean_git_url(manifest0["git"])
    content += "<p>git revision: %s</p>\n" % manifest0["revision"]
    content += "<p>%d个平台</p>\n" % len(env.manifest_files)
    content += "<table %s>\n" % UgProject.__get_table_style()
    content += "<tr><th width=100>平台</th>"
    content += "<th width=150>归档位置</th>"
    content += "<th width=150>大小</th>"
    content += "<th width=120>MD5</th>"
    content += "<th width=40>签名</th>"
    content += "<th width=120>打包时间</th>"
    content += "</tr>\n"

    build_env = env.get_build_env()
    smb_host = build_env["SMB_HOST"]
    smb_share_name = build_env["SMB_SHARE_NAME"]
    smb_repo = build_env["SMB_REPO"]
    vdir = os.path.dirname(self.get_install_path())

    for manifest_file in env.manifest_files:
      platform_str = os.path.dirname(manifest_file)
      manifest_path = os.path.join(env.version_path_full, manifest_file)
      manifest = load_yaml_f(manifest_path)
      platform = BuildPlatform.parse(env, platform_str)
      content += "<tr><td>%s</td>" % platform.get_sorted_short_str()

      # 获取版本"归档位置"
      loc = "\\\\%s\\%s\\%s\\%s\\%s" % (smb_host, smb_share_name, smb_repo, vdir, platform_str)
      loc = loc.replace("/", "\\")
      content += "<td>%s</td>" % loc

      # 获取版本大小信息
      version_size_info = UgProject.get_version_size_info(smb_host, smb_share_name, smb_repo, vdir, platform_str)
      diff_size = version_size_info["diff_size"] / 1024 / 1024
      if diff_size > 0:
        size_td_style = UgProject.__version_check_fail()  # 版本大小变大
      elif diff_size == 0:
        size_td_style = UgProject.__version_check_noneed()  # 版本正常大小不变
      else:
        size_td_style = UgProject.__version_check_pass()  # 版本正常大小减小

      info("size_td_style: %s" % size_td_style)
      size_str = "max_version[%s]: %dMB, min_version[%s]: %dMB, diff_size: %dMB" % (
          version_size_info["max_version"],
          version_size_info["max_size"] / 1024 / 1024,
          version_size_info["min_version"],
          version_size_info["min_size"] / 1024 / 1024,
          diff_size)
      content += "<td %s>%s</td>" % (size_td_style, size_str)

      md5_value = manifest["md5"]
      if isinstance(md5_value, str):
        content += "<td>%s</td>" % md5_value
      else:
        content += "<td><table>"
        for md5_file in md5_value.keys():
          md5_file_value = md5_value[md5_file]
          content += "<tr><td>%s</td><td>%s</td></tr>" % (md5_file, md5_file_value)
        content += "</table></td>"
      content += "<td>V2</td>"
      content += "<td>%s</td>" % str(manifest["time"])
      content += "</tr>\n"
    content += "</table>\n"

    return content

  @staticmethod
  def __collect_changelist_mod_names(changelist):
    # 统一收集完整历史里的模块名，保证邮件正文和 CSV 附件的模块编号一致。
    mod_names = OrderedDict()
    for build_number in changelist.keys():
      changes = changelist[build_number]
      for side in ["left", "right"]:
        side_changes = changes[side]
        for side_change_key in side_changes.keys():
          side_change = side_changes[side_change_key]
          for mod in side_change["mod"]:
            tokens = mod.split()
            mod_key = tokens[0]
            if mod_key not in mod_names:
              mod_names[mod_key] = None

    mod_names = sort_dict(mod_names)
    mod_index = 1
    for mod_name in mod_names.keys():
      mod_names[mod_name] = mod_index
      mod_index += 1
    return mod_names

  @staticmethod
  def __get_changelist_mod_value(mods, mod_name):
    for mod in mods:
      tokens = mod.split()
      mod_key = tokens[0]
      if mod_name == mod_key:
        return tokens[1]
    return "-"

  def __generate_req_test_changelist_csv(self, proj, changelist, mod_names):
    # 邮件正文只展示最新版本，完整历史变更放到 CSV 附件，避免正文过大。
    csv_file = self.__env.get_temp_file() + ".csv"
    csv_buf = io.StringIO()
    csv_writer = csv.writer(csv_buf)
    csv_writer.writerow(["版本", "作者", "时间", "标题", "git", "commit"] +
                        [mod_names[mod_name] for mod_name in mod_names.keys()])

    for build_number in changelist.keys():
      changes = changelist[build_number]
      version = proj.get_version() + "." + str(build_number)
      for side in ["left", "right"]:
        side_changes = changes[side]
        for side_change_key in side_changes.keys():
          tokens = side_change_key.split()
          git_url = tokens[0]
          rev = tokens[1]
          side_change = side_changes[side_change_key]
          row_title = side_change.get("Title", "")
          if side == "left":
            row_title = "[版本倒退] " + row_title
          row = [
              version,
              side_change.get("Author", ""),
              side_change.get("Date", ""),
              row_title,
              git_url,
              rev,
          ]
          mods = side_change["mod"]
          for mod_name in mod_names.keys():
            row.append(UgProject.__get_changelist_mod_value(mods, mod_name))
          csv_writer.writerow(row)

    csv_writer.writerow([])
    csv_writer.writerow(["模块编号", "模块名称"])
    for mod_name in mod_names.keys():
      csv_writer.writerow([mod_names[mod_name], mod_name])
    write_file(csv_file, "\ufeff" + csv_buf.getvalue())
    return {
        "path": csv_file,
        "filename": "历史版本变更.csv",
    }

  def __warmup_req_test_git_cache(self, manifest_paths):
    env = self.__env
    # request_for_testing 使用专用缓存，避免并发发送邮件时污染默认 for_lock_git。
    cache_root = os.path.join(get_ugdata(), "cache", "request_for_testing_git")
    cache_env = "UG_LOCK_GIT_CACHE_ROOT=%s" % cache_root
    # 只有调用方明确接受复用旧缓存时才跳过 pull；默认更新，避免 CI 旧缓存缺少 manifest 引用的 commit。
    if env_is_true("UGBT_REQUEST_FOR_TESTING_NO_GIT_UPDATE"):
      cache_env += " UG_LOCK_GIT_NO_UPDATE=1"
    git_urls = OrderedDict()
    visited_deps = set()
    for manifest_path in manifest_paths:
      platform_str = os.path.basename(os.path.dirname(manifest_path))
      platform = BuildPlatform.parse(env, platform_str)
      manifest = load_yaml_f(manifest_path)
      ManifestLoader.collect_git_urls(env, platform, manifest, git_urls, visited_deps)

    git_url_list = list(git_urls.keys())
    if not git_url_list:
      info("request_for_testing git warmup skipped, no git url found")
      return

    parallel_count = int(os.environ.get("UGBT_GIT_WARMUP_PARALLEL", "8"))
    if parallel_count < 1:
      parallel_count = 1
    info("request_for_testing git warmup repos %d parallel count %d" %
         (len(git_url_list), parallel_count))
    info("request_for_testing git cache root: %s" % cache_root)

    def __warmup_git(git_url):
      # lock_git_run -- true 只负责 clone/fetch 并建立缓存，不执行额外业务命令。
      run("%s ugbt lock_git_run -u %s -- true" % (cache_env, git_url), show_start_log=True)
      return git_url

    parallel_run(git_url_list, parallel_count, __warmup_git)

  def __render_req_test_changelist_html(self, proj, title, vs_from, build_numbers, changelist, mod_names):
    content = ""

    content += "<p>%s</p>\n" % html.escape(title)
    content += "<p>邮件正文仅展示最新版本变更；完整历史变更请下载邮件附件 CSV 查看。</p>\n"
    content += "<p>模块</p>\n"
    for mod_name in mod_names.keys():
      mod_index = mod_names[mod_name]
      content += "<p>%d &nbsp %s</p>\n" % (mod_index, mod_name)
    content += "<p></p>\n"
    content += "<p>红色表示版本倒退</p>\n"
    content += "<p></p>\n"

    for build_number in changelist.keys():
      changes = changelist[build_number]
      version = proj.get_version() + "." + str(build_number)
      if build_numbers[0] == build_number:
        content += "<details open>"
      else:
        content += "<details>"
      content += "<summary>%s</summary>\n" % html.escape(version)
      content += "<table %s><tr><th width=50>作者</th>" % UgProject.__get_table_style()
      content += "<th width=120>时间</th>"
      content += "<th width=250>标题</th>"
      content += "<th width=200>git</th>"
      content += "<th width=120>commit</th>"
      for mod_name in mod_names.keys():
        mod_index = mod_names[mod_name]
        content += "<th width=30>%d</th>\n" % mod_index
      content += "</tr>\n"

      for side in ["left", "right"]:
        side_changes = changes[side]
        for side_change_key in side_changes.keys():
          tokens = side_change_key.split()
          git_url = tokens[0]
          rev = tokens[1]
          side_change = side_changes[side_change_key]
          if side == "left":
            content += "<tr style=\"color: red;\">"
          else:
            content += "<tr>"
          try:
            content += "<td>%s</td>" % html.escape(side_change["Author"])
            content += "<td>%s</td>" % html.escape(side_change["Date"])
            content += "<td>%s</td>" % html.escape(side_change["Title"])
            content += "<td>%s</td>" % git_url
            content += "<td>%s</td>" % rev
          except Exception as ex:
            fatal("bad side change, git_url %s rev %s side_change_key %s, excpetion: %s" % (
                git_url, rev, side_change_key, ex))

          mods = side_change["mod"]
          for mod_name in mod_names.keys():
            content += "<td>%s</td>\n" % UgProject.__get_changelist_mod_value(mods, mod_name)
          content += "</tr>\n"
      content += "</table></details>\n"
    content += "<p>earliest version %s</p>\n" % vs_from
    return content

  def __generate_req_test_email_update_info(self):
    start_time = time.time()
    env = self.__env
    proj = UgProject.load(env, {})
    name = proj.get_name()
    manifest_path_0 = os.path.join(env.version_path_full, env.manifest_files[0])
    info("manifest_0 " + manifest_path_0)
    input_file = env.get_temp_file()
    input_content = manifest_path_0 + "\n"
    build_numbers, manifest_pathes, manifests = ManifestLoader.instance().find_pre_versions(env, proj, manifest_path_0)
    for manifest_path_n in manifest_pathes:
      input_content += manifest_path_n + "\n"
    if not manifest_pathes:
      # 如果是第一次构建，不需要对比，直接返回
      content = "<p>First build version %s, no change information.</p>\n" % (
          proj.get_version() + "." + str(build_numbers[0]))
      return content, []
    vs_from = proj.get_version() + "." + str(build_numbers[-1])
    vs_to = proj.get_version() + "." + str(build_numbers[0])
    title = "changelist of %s from %s to %s" % (name, vs_from, vs_to)
    step_time = time.time()
    self.__warmup_req_test_git_cache([manifest_path_0] + manifest_pathes)
    info("request_for_testing git warmup cost %.3fs" % (time.time() - step_time))
    write_file(input_file, input_content)
    cache_root = os.path.join(get_ugdata(), "cache", "request_for_testing_git")
    cmd = "UG_LOCK_GIT_CACHE_ROOT=%s UG_LOCK_GIT_NO_CLEAN=1 ugbt diff-manifest -i " % cache_root + input_file
    diff_file = env.get_temp_file()
    cmd += " --output " + diff_file
    cmd += " -n " + name
    run(cmd, show_start_log=True)
    diff = load_yaml_f(diff_file)
    self.__email_conflicted_deps = diff.get("conflicted_deps", [])
    changelist = diff.get("changelist") or OrderedDict()
    full_mod_names = UgProject.__collect_changelist_mod_names(changelist)

    latest_build_number = build_numbers[0]
    latest_changelist = OrderedDict()
    # 正文只展示最新一次构建的变更，历史完整内容通过 CSV 附件保留。
    if latest_build_number in changelist:
      latest_changelist[latest_build_number] = changelist[latest_build_number]
    else:
      warning("latest build number %s not found in changelist, render all changelist in email" %
              latest_build_number)
      latest_changelist = changelist

    attachments = []
    if changelist:
      attachments.append(self.__generate_req_test_changelist_csv(proj, changelist, full_mod_names))
    content = self.__render_req_test_changelist_html(proj, title, vs_from, build_numbers,
                                                     latest_changelist, full_mod_names)
    info("request_for_testing update info generated in %.3fs" % (time.time() - start_time))
    return content, attachments

  @staticmethod
  def search_dep_tree(env, search_stack, platform, manifest, direct_deps, indirect_deps,
                      dep_parent_map=None, root_key=None):
    if not "deps" in manifest:
      return
    for dep in manifest["deps"]:
      smb_dep, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      dep_key = str(smb_dep)
      if dep_key in direct_deps:
        continue
      if dep_key in indirect_deps:
        continue
      indirect_deps[dep_key] = (smb_dep, dep_manifest)
      if dep_parent_map is not None and dep_key not in dep_parent_map and root_key:
        dep_parent_map[dep_key] = root_key
      if dep_key in search_stack:
        fatal("circular dependency detected %s -> %s" % (search_stack, dep_key))
      search_stack.append(dep_key)
      UgProject.search_dep_tree(env, search_stack, platform, dep_manifest, direct_deps, indirect_deps,
                                dep_parent_map, root_key)
      search_stack.pop()

  def __generate_req_test_email_deps_info(self):
    env = self.__env
    manifest_file = env.manifest_files[0]
    manifest = load_yaml_f(os.path.join(env.version_path_full, manifest_file))
    content = ""
    if not "deps" in manifest or len(manifest["deps"]) <= 0:
      return ""

    platform_str = os.path.dirname(manifest_file)
    platform = BuildPlatform.parse(env, platform_str)
    content += "<details open>"
    content += "<summary>直接依赖</summary>\n"
    content += "<table %s>\n" % UgProject.__get_table_style()
    content += "<tr><th width=200>包名</th>"
    content += "<th width=100>分支</th>"
    content += "<th width=60>版本</th>"
    content += "<th width=120>打包时间</th>"
    content += "<th width=40>打包人</th>"
    content += "<th width=200>仓库</th>"
    content += "</tr>\n"

    indirect_deps = OrderedDict()
    direct_deps = {}
    for dep in manifest["deps"]:
      smb_dep, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      direct_deps[str(smb_dep)] = None
      content += "<tr>"
      content += "<td>%s</td>" % smb_dep.name
      content += "<td>%s</td>" % smb_dep.branch
      content += "<td>%s</td>" % (smb_dep.version + "." + str(smb_dep.build_number))
      content += "<td>%s</td>" % dep_manifest["time"]
      content += "<td>%s</td>" % str(dep_manifest["author"])
      content += "<td>%s &nbsp %s</td>" % (get_clean_git_url(dep_manifest["git"]),
                                           dep_manifest["revision"])
      content += "</tr>\n"
    content += "</table>\n"
    content += "</details>"

    for dep in manifest["deps"]:
      _, dep_manifest = ManifestLoader.instance().load(env, platform, dep)
      UgProject.search_dep_tree(env, [], platform, dep_manifest, direct_deps, indirect_deps)

    content += "<details open>"
    content += "<summary>间接依赖</summary>\n"
    content += "<div><table %s>\n" % UgProject.__get_table_style()
    content += "<tr><th width=200>包名</th>"
    content += "<th width=100>分支</th>"
    content += "<th width=60>版本</th>"
    content += "<th width=120>打包时间</th>"
    content += "<th width=40>打包人</th>"
    content += "<th width=200>仓库</th>"
    content += "</tr>\n"
    for dep_key in indirect_deps.keys():
      smb_dep, dep_manifest = indirect_deps[dep_key]
      content += "<tr>"
      content += "<td>%s</td>" % smb_dep.name
      content += "<td>%s</td>" % smb_dep.branch
      content += "<td>%s</td>" % (smb_dep.version + "." + str(smb_dep.build_number))
      content += "<td>%s</td>" % dep_manifest["time"]
      content += "<td>%s</td>" % str(dep_manifest["author"])
      content += "<td>%s &nbsp %s</td>" % (get_clean_git_url(dep_manifest["git"]),
                                           dep_manifest["revision"])
      content += "</tr>\n"
    content += "</table></div>\n"
    content += "</details>"
    return content

  def __generate_req_test_email_html(self, to_myself, team_addrs):
    env = self.__env
    tpl_file = os.path.join(env.root, "tpl", "email", "request_for_testing.html")
    content = read_file(tpl_file)
    if to_myself:
      prefix = "<div><table %s id='noneed_table'><td>\n" % UgProject.__get_table_style()
      prefix += "<p>这是一封发给自己的测试邮件，仔细查看内容是否正确，正式邮件会发到以下这些地址</p>\n"
      for to in team_addrs:
        prefix += "<p>%s</p>\n" % html.escape(to)
      prefix += "</td></table></div>\n"
    else:
      prefix = ""
    content = content.replace("${PREFIX}", prefix)
    # 自测评估->执行人
    content = content.replace("${USER.NAME}", env.myself["name"])
    # 提交信息
    pack_info = self.__generate_req_test_email_pack_info()
    content = content.replace("${PACK_INFO}", pack_info)
    # 更新内容（先执行，以填充 __email_conflicted_deps 供最新版本检测节使用）
    update_info, attachments = self.__generate_req_test_email_update_info()
    content = content.replace("${UPDATE_INFO}", update_info)
    # 最新版本检测（后执行，读取 __email_conflicted_deps 展示冲突警告）
    latest_version_check_info = self.__generate_latest_version_check_info()
    content = content.replace("${DEPS_LATEST_VERSION_CHECK_INFO}", latest_version_check_info)
    # 依赖组件
    deps_info = self.__generate_req_test_email_deps_info()
    content = content.replace("${DEPS_INFO}", deps_info)
    return content, attachments

  def __get_pack_release_cname(self):
    if self.__release == GS.DEV:  # dev
      return "提测包Beta"
    elif self.__release == GS.STABLE:  # stable
      return "稳定包Beta"
    elif self.__release == GS.RELEASE:  # relese
      fatal("%s字段不能是%s，request_for_testing不允许发送正式包邮件" % (
          GS.RELEASE, GS.RELEASE))
    else:
      if not self.__release.endswith("专项包"):
        fatal("自定义release字段必须以[专项包]结尾")
      if self.__release == "专项包":
        fatal("自定义release字段不能叫[专项包]，必须叫[xxx专项包]")
      return self.__release + "Beta"

  @staticmethod
  def __download_smb_dir_recursive(conn, share_name, remote_dir, local_dir):
    for entry in conn.ls(share_name, remote_dir):
      if entry in ('.', '..'):
        continue
      remote_path = os.path.join(remote_dir, entry)
      local_path = os.path.join(local_dir, entry)
      if conn.isdir(share_name, remote_path):
        make_dir(local_path)
        UgProject.__download_smb_dir_recursive(conn, share_name, remote_path, local_path)
      else:
        info("downloading %s -> %s" % (remote_path, local_path))
        conn.download(share_name, remote_path, local_path)

  def __sync_platforms_from_smb(self, version_path, version_path_full):
    """When builds run on separate ARM/x86 machines, the local repo only has
    the current architecture's artifacts.  Download complete platform directories
    from SMB so that the local cache is consistent and the email covers every
    platform."""
    env = self.__env
    build_env = env.get_build_env()
    smb_host = build_env["SMB_HOST"]
    conn = SambaConnection.instance(smb_host)
    share_name = build_env["SMB_SHARE_NAME"]
    smb_repo = build_env["SMB_REPO"]
    smb_version_dir = os.path.join(smb_repo, version_path)

    if not conn.exists(share_name, smb_version_dir):
      info("SMB version dir not found, skip platform sync: %s" % smb_version_dir)
      return

    sync_entries = []
    for entry in conn.ls(share_name, smb_version_dir):
      if entry in ('.', '..'):
        continue
      remote_platform_dir = os.path.join(smb_version_dir, entry)
      if not conn.isdir(share_name, remote_platform_dir):
        continue

      local_platform_dir = os.path.join(version_path_full, entry)
      if os.path.exists(local_platform_dir):
        if any(f.endswith('.manifest.yaml') for f in os.listdir(local_platform_dir)):
          continue

      sync_entries.append(entry)

    if not sync_entries:
      return

    parallel_count = int(os.environ.get("UGBT_SYNC_PLATFORM_PARALLEL", "8"))
    if parallel_count < 1:
      parallel_count = 1
    # 不同平台目录互不影响，可以并发从 SMB 同步，减少邮件生成前置等待。
    info("request_for_testing sync platform dirs %d parallel count %d" %
         (len(sync_entries), parallel_count))

    def __sync_one_platform(entry):
      # 每个线程独立创建 SambaConnection，避免多个线程共享同一个连接对象。
      local_conn = SambaConnection(smb_host)
      local_conn.connect()
      remote_platform_dir = os.path.join(smb_version_dir, entry)
      local_platform_dir = os.path.join(version_path_full, entry)
      info("syncing platform from SMB: %s" % entry)
      tmp_dir = local_platform_dir + "-" + uuid_gen() + ".tmp"
      make_dir(tmp_dir)
      try:
        UgProject.__download_smb_dir_recursive(local_conn, share_name, remote_platform_dir, tmp_dir)
        if os.path.exists(local_platform_dir):
          run("rm -rf " + local_platform_dir)
        run("mv %s %s" % (tmp_dir, local_platform_dir))
      except Exception:
        run("rm -rf " + tmp_dir)
        raise
      return entry

    parallel_run(sync_entries, parallel_count, __sync_one_platform)

  def request_for_testing(self, to_myself, gitlab_user):
    start_time = time.time()
    env = self.__env
    install_path = self.get_install_path()
    version_path = os.path.dirname(install_path)
    version_path_full = os.path.join(env.get_local_repo_root(), version_path)
    step_time = time.time()
    self.__sync_platforms_from_smb(version_path, version_path_full)
    info("request_for_testing sync platforms cost %.3fs" % (time.time() - step_time))
    step_time = time.time()
    manifest_files = find_request_for_testing_manifest_files(version_path_full)
    info("manifest files:\n" + dump_yaml(manifest_files))
    info("request_for_testing find manifest files cost %.3fs" % (time.time() - step_time))

    branch = load_yaml_f(os.path.join(version_path_full, manifest_files[0]))["branch"]

    step_time = time.time()
    myself = search_dev_user_by_gitlab(env, gitlab_user)
    if not myself:
      fatal("gitlab user [%s] is not a valid user in <ugbase>/dev/users.yaml" % gitlab_user)
    info("request_for_testing resolve recipients cost %.3fs" % (time.time() - step_time))

    subject = ""
    if self.__release_name:
      subject += "【%s】" % self.__release_name
    subject += "【%s】" % self.__get_pack_release_cname()
    subject += "【%s】" % branch
    subject += "【%s-%s】" % (self.__name, self.__version + ".%04d" % self.__build_number)
    env.now_str = runex("date -R")
    subject += "【%s】" % env.now_str

    env.version_path_full = version_path_full
    env.manifest_files = manifest_files
    env.myself = myself

    myself_addr = []
    myself_addr.append(myself["name"] + " <" + myself["email"] + "@ugreen.com>")
    team_addrs = []
    team_addrs.append("NAS-测试组 <nas-test@ugreen.com>")
    team_addrs.append("NAS-软件开发组 <nas-develop@ugreen.com>")
    team_addrs.append("NAS-PRO-产品小组 <nas-pro-product@ugreen.com>")
    team_addrs.append("NAS-UI设计组 <nas-ui@ugreen.com>")
    team_addrs.append("NAS-产品运营组 <nas-cpyy@ugreen.com>")
    team_addrs.append("NAS-音视频组 <nas-media@ugreen.com>")
    team_addrs.append("NAS-系统安全组 <nas-security@ugreen.com>")
    team_addrs.append("NAS-系统 <nas-os@ugreen.com>")
    team_addrs.append("NAS-云端组 <nas-cloud@ugreen.com>")
    team_addrs.append("NAS-软件项目组 <nas-project@ugreen.com>")
    team_addrs.append("NAS-AI <nas-ai@ugreen.com>")
    team_addrs.append("NAS-DQE组 <pz-nasdqe@ugreen.com>")
    team_addrs.append("NAS-硬件开发 <nas-hwyf@ugreen.com>")

    step_time = time.time()
    content, attachments = self.__generate_req_test_email_html(to_myself, team_addrs)
    info("request_for_testing generate email html cost %.3fs" % (time.time() - step_time))
    if to_myself:
      tos = myself_addr
    else:
      tos = team_addrs
    step_time = time.time()
    send_notify_mail(tos=tos, subject=subject, content=content, attachments=attachments)
    info("request_for_testing send notify mail cost %.3fs" % (time.time() - step_time))
    info("request_for_testing total cost %.3fs" % (time.time() - start_time))

  def __generate_latest_version_check_info(self) -> str:
    direct_is_ok, indirect_is_ok, go_mod_direct_is_ok, go_mod_indirect_is_ok = True, True, True, True  # 最新版本检测是否通过
    deps = self.get_deps()  # ugreen_project.yaml->deps

    manifest_file = self.__env.manifest_files[0]
    platform_str = os.path.dirname(manifest_file)
    platform = BuildPlatform.parse(self.__env, platform_str)

    content = ""
    content += "<details open>"
    content += "<summary>直接依赖</summary>\n"
    content += "<table %s>\n" % self.__get_table_style()
    content += "<tr><th width=200>包名</th>"
    content += "<th width=100>分支</th>"
    content += "<th width=100>当前版本</th>"
    content += "<th width=100>最新版本</th>"
    content += "</tr>\n"

    indirect_deps = OrderedDict()
    direct_deps = {}
    for dep in deps:
      raw = self.__check_version_and_build_info(dep)
      if raw:
        direct_is_ok = False
      content += raw
      smb_dep, dep_manifest = ManifestLoader.instance().load(self.__env, platform, dep.__str__())
      direct_deps[str(smb_dep)] = None
      # 按深度优先遍历获取所有deps间接依赖
      UgProject.search_dep_tree(self.__env, [], platform, dep_manifest, direct_deps, indirect_deps)
    if self.__go_mod_deps:
      # 如果是go项目，检查go.mod 直接依赖
      go_mod_direct_deps = self.__go_mod_deps.get('direct', {})
      raw = self.__check_go_mod_version_and_build_info(go_mod_direct_deps)
      if raw:
        go_mod_direct_is_ok = False
      content += raw
    content += "</table>\n"
    content += "</details>"

    content += "<details open>"
    content += "<summary>间接依赖</summary>\n"
    content += "<div><table %s>\n" % self.__get_table_style()
    content += "<tr><th width=200>包名</th>"
    content += "<th width=100>分支</th>"
    content += "<th width=100>当前版本</th>"
    content += "<th width=100>最新版本</th>"
    content += "</tr>\n"
    for _, (smb_dep, _) in indirect_deps.items():
      raw = self.__check_version_and_build_info(smb_dep)
      if raw:
        indirect_is_ok = False
      content += raw
    if self.__go_mod_deps:
      # 如果是go项目，检查go.mod 间接依赖
      go_mod_indirect_deps = self.__go_mod_deps.get('indirect', {})
      raw = self.__check_go_mod_version_and_build_info(go_mod_indirect_deps)
      if raw:
        go_mod_indirect_is_ok = False
      content += raw
    content += "</table>\n"
    content += "</details>"

    def _conflict_table():
      if not self.__email_conflicted_deps:
        return ""
      red = "style=\"color:red\""
      t = "<p %s><b>⚠ 以下依赖存在版本冲突，变更历史信息已略过</b></p>\n" % red
      t += "<table %s>\n" % self.__get_table_style()
      t += "<tr><th width=280>依赖包名</th><th width=140>分支</th><th width=110>版本</th><th width=220>引用来源</th></tr>\n"
      for item in self.__email_conflicted_deps:
        if isinstance(item, dict):
          dep_name = item.get("name", "")
          versions = item.get("versions", [])
        else:
          dep_name = item
          versions = []
        if versions:
          row_count = len(versions)
          for i, ver in enumerate(versions):
            branch = ver.get("branch", "-") if isinstance(ver, dict) else "-"
            version = ver.get("version", "-") if isinstance(ver, dict) else "-"
            referrer = ver.get("referrer") if isinstance(ver, dict) else None
            referrer_str = html.escape(referrer) if referrer else "(直接依赖)"
            if i == 0:
              name_cell = "<td %s rowspan=%d>%s</td>" % (red, row_count, html.escape(dep_name))
            else:
              name_cell = ""
            t += "<tr>%s<td %s>%s</td><td %s>%s</td><td %s>%s</td></tr>\n" % (
                name_cell, red, html.escape(branch), red, html.escape(version), red, referrer_str)
        else:
          t += "<tr><td %s>%s</td><td>-</td><td>-</td><td>-</td></tr>\n" % (red, html.escape(dep_name))
      t += "</table>\n"
      return t

    content += "<p %s>检查结果：请注意！以上依赖包未使用最新版本！</p>" % self.__version_check_fail()
    content += _conflict_table()
    if direct_is_ok and indirect_is_ok and go_mod_direct_is_ok and go_mod_indirect_is_ok:
      content = "<p %s>检查结果：所有依赖包均已使用最新版本</P>" % self.__version_check_pass()
      content += _conflict_table()
    return content

  def __check_version_and_build_info(self, smb_dep: SmbDep) -> str:
    build_env = self.__env.get_build_env()
    conn = SambaConnection.instance(build_env["SMB_HOST"])
    share_name = build_env["SMB_SHARE_NAME"]
    repo_root = build_env["SMB_REPO"]
    content = ""

    dep_full_path = os.path.join(repo_root, smb_dep.name, smb_dep.branch, smb_dep.version)
    if conn.exists(share_name, dep_full_path):
      folders = conn.ls(share_name, dep_full_path)
      max_folder = UgProject.__get_max_folder(dep_full_path, folders)
      # 只需检查小版本号
      if smb_dep.build_number < int(max_folder):
        check_fail_style = self.__version_check_fail()
        content += "<tr>"
        content += "<td>%s</td>" % smb_dep.name
        content += "<td>%s</td>" % smb_dep.branch
        content += "<td %s>%s</td>" % (check_fail_style, (smb_dep.version + "." + str(smb_dep.build_number)))
        content += "<td %s>%s</td>" % (check_fail_style, (smb_dep.version + "." + str(max_folder)))
        content += "</tr>"
    return content

  def __check_go_mod_version_and_build_info(self, go_mod_deps: dict[str, str]) -> str:
    content = ""
    check_fail_style = self.__version_check_fail()
    for key, value in go_mod_deps.items():
      git = "ssh://git@" + key + ".git"
      git = get_clean_git_url(git)

      pattern = r"^(v\d+\.\d+)\.(\d+)$"
      match = re.match(pattern, value)
      if not match:
        content += "<tr>"
        content += "<td>%s</td>" % key
        content += "<td>-</td>"
        remind_message = html.escape("引用的TAG[%s]不符合go modules的语义化版本规范(v1.2.3格式)" % value)
        content += "<td %s>%s</td>" % (check_fail_style, remind_message)
        content += "<td>-</td>"
        content += "</tr>"
        continue
      tag_prefix, build_version = match.group(1), match.group(2)
      f = self.__env.get_temp_file()
      cmd = "ugbt lock_git_run -u %s -c -o %s" % (git, f)
      # 匹配git最末尾的小版本号，按小版本号降序排列，取最大小版本号
      cmd += " -- git tag -l \"%s.*\" --sort=-version:refname" % tag_prefix
      run(cmd)
      file_content = read_file(f)
      tag_versions = file_content.splitlines()
      if len(tag_versions) > 0:
        max_tag_version = tag_versions[0]
        max_build_version = max_tag_version.split(".")[-1]
        if int(build_version) < int(max_build_version):
          content += "<tr>"
          content += "<td>%s</td>" % key
          content += "<td>-</td>"
          content += "<td %s>%s</td>" % (check_fail_style, value)
          content += "<td %s>%s</td>" % (check_fail_style, max_tag_version)
          content += "</tr>"
      else:
        content += "<tr>"
        content += "<td>%s</td>" % key
        content += "<td>-</td>"
        content += "<td %s>%s</td>" % (check_fail_style, value)
        content += "<td %s>%s</td>" % (check_fail_style, "%s此依赖没有找到tag,请检查!" % key)
        content += "</tr>"
    return content

  @staticmethod
  def __get_max_min_version(folders) -> tuple[str, str]:
    """
    获取目录列表中数字命名的最大和最小目录名
    :param folders: 子目录列表
    :return: (max_folder, min_folder)
    """
    maxn = None
    minn = None
    maxs = ""
    mins = ""
    for folder in folders:
      if folder.startswith("."):
        continue
      if "tmp" in folder:
        continue
      if not folder.isdigit():
        error(f"folder: {folder} is not a digit")
        continue
      folder_n = int(folder)
      if maxn is None or folder_n > maxn:
        maxn = folder_n
        maxs = folder
      if minn is None or folder_n < minn:
        minn = folder_n
        mins = folder
    return maxs, mins

  @staticmethod
  def __get_size_info(conn, share_name, repo_root, branch_dir, version, platform) -> int:
    if conn is None:
      return 0
    version_platform_path = os.path.join(repo_root, branch_dir, version, platform)
    if not conn.exists(share_name, version_platform_path):
      return 0
    folders = conn.ls(share_name, version_platform_path)
    for folder in folders:
      if folder.startswith("."):
        continue
      if folder.endswith(".img"):
        size = conn.size(share_name, os.path.join(version_platform_path, folder))
        return size
    return 0

  @staticmethod
  def get_version_size_info(smb_host, share_name, repo_root, version_dir, platform):
    version_size_info = {"max_size": 0, "max_version": "", "min_size": 0, "min_version": "", "diff_size": 0}
    conn = SambaConnection.instance(smb_host)
    # share_name: 产品研发事业中心,
    # repo_root: 产品经营部/NAS组/repo,
    # version_dir: firmware/image/release_20251126/1.11.0/39,
    # branch_dir: firmware/image/release_20251126/1.11.0,
    # platform: arch_spu_intel__cpu_arch_amd64__kernel_6.12.30+
    branch_dir = os.path.dirname(version_dir)
    branch_folders = conn.ls(share_name, os.path.join(repo_root, branch_dir))
    max_version, min_version = UgProject.__get_max_min_version(branch_folders)
    if max_version == "" or min_version == "":
      return version_size_info

    # 获取当前版本号，并判断是否小于max_version，如果小于，则将max_version设置为当前版本号
    vl = version_dir.rstrip("/").split("/")
    if len(vl) == 0:
      return version_size_info
    current_version = vl[-1]
    if current_version.isdigit() and int(current_version) < int(max_version):
      max_version = current_version

    min_size = 0
    max_size = UgProject.__get_size_info(conn, share_name, repo_root, branch_dir, max_version, platform)
    if max_version == min_version:
      min_size = max_size
    else:
      min_size = UgProject.__get_size_info(conn, share_name, repo_root, branch_dir, min_version, platform)

    info("max_version:%s, max_size: %s, min_version:%s, min_size: %s" % (max_version, max_size, min_version, min_size))
    diff_size = max_size - min_size
    version_size_info["max_size"] = max_size
    version_size_info["max_version"] = max_version
    version_size_info["min_size"] = min_size
    version_size_info["min_version"] = min_version
    version_size_info["diff_size"] = diff_size
    return version_size_info

  def get_project_size_report_tpl(self) -> str:
    env = self.__env
    tpl_file = os.path.join(env.root, "tpl", "email", "project_size_report.html")
    return read_file(tpl_file)

  def get_ugreen_project(self, key: str) -> str:
    return self.__get(key)

  @staticmethod
  def parse_entry(dep) -> dict:
    """
    兼容解析：
      1) 传入字符串: "kernel/debian12-utils@release_20251224 1.12.0.32"
      2) 传入 SmbDep 对象
    返回字段: base_url, repo, branch, version, version_dir
    """
    # 如果是 SmbDep 对象，直接用字段
    if isinstance(dep, SmbDep):
      name = dep.name                            # 例如: "kernel/debian12-utils"
      branch = dep.branch                        # 例如: "release_20251224"
      version = "%s.%d" % (dep.version, dep.build_number)  # 例如: "1.12.0.32"

    # 拆出 base_url 和 repo
    if "/" in name:
      base_url, repo = name.rsplit("/", 1)
    else:
      base_url, repo = "", name

    # 生成 ver_dir，例如 1.12.0.32 -> 1.12.0/32
    ver_main, ver_last = version.rsplit(".", 1)
    ver_dir = "%s/%s" % (ver_main, ver_last)

    info_dict = {
        "base_url": base_url,
        "repo": repo,
        "branch": branch,
        "version": version,
        "version_main": ver_main,
        "version_last": ver_last,
        "version_dir": ver_dir,
    }
    return info_dict

  @staticmethod
  def __get_size_info2(conn, share_name, version_platform_path, size_info=None, level=0) -> dict:
    if level == 0:
      size_info = {"upk_size": {"file": "", "size": -1},
                   "img_size": {"file": "", "size": -1}, "tar_size": {"file": "", "size": -1}}
    if conn is None:
      return size_info
    if not conn.exists(share_name, version_platform_path):
      return size_info
    folders = conn.ls(share_name, version_platform_path)
    for folder in folders:
      if folder.startswith("."):
        continue
      # 调试日志：在包含 storage_serv 的路径下打印详细信息
      if level == 0 and conn.isdir(share_name, os.path.join(version_platform_path, folder)):
        size_info2 = UgProject.__get_size_info2(conn, share_name, os.path.join(
            version_platform_path, folder), size_info, level + 1)
        for key, value in size_info2.items():
          size_info[key]["file"] = value["file"]
          size_info[key]["size"] = value["size"]
      if folder.endswith(".upk"):
        size = conn.size(share_name, os.path.join(version_platform_path, folder))
        size_info["upk_size"]["file"] = folder
        size_info["upk_size"]["size"] = size
      if folder.endswith(".img"):
        size = conn.size(share_name, os.path.join(version_platform_path, folder))
        size_info["img_size"]["file"] = folder
        size_info["img_size"]["size"] = size
      if folder.endswith(".tar.gz"):
        size = conn.size(share_name, os.path.join(version_platform_path, folder))
        size_info["tar_size"]["file"] = folder
        size_info["tar_size"]["size"] = size
    return size_info

  @staticmethod
  def get_project_version_size_info(conn, smb_share_name, smb_repo, entry, version) -> dict:
    version_size = {"version": version, "dir": "", "platform_size": None}
    if conn is None:
      return version_size
    version_dir = os.path.join(smb_repo, entry["base_url"], entry["repo"],
                               entry["branch"], entry["version_main"], version)
    version_size["dir"] = version_dir
    if not conn.exists(smb_share_name, version_dir):
      return version_size
    folders = conn.ls(smb_share_name, version_dir)
    platform_size = []
    for folder in folders:
      if folder.startswith("."):
        continue
      size_info = {"platform": folder, "size": None}
      size_info["size"] = UgProject.__get_size_info2(conn, smb_share_name, os.path.join(version_dir, folder))
      platform_size.append(size_info)
    version_size["platform_size"] = platform_size
    return version_size

  @staticmethod
  def get_project_diff_size(max_size_info, min_size_info) -> list[dict]:
    # info("max_size_info: %s, min_size_info: %s" % (max_size_info, min_size_info))
    diff_size_infos = []
    max_platform_size = max_size_info["platform_size"] or []
    min_platform_size = min_size_info["platform_size"] or []
    for max_platform in max_platform_size:
      diff_size_info = {"max_version": "", "min_version": "", "platform": "",
                        "upk_diff_info": {"max_file": "", "min_file": "", "diff_size": 0},
                        "img_diff_info": {"max_file": "", "min_file": "", "diff_size": 0},
                        "tar_diff_info": {"max_file": "", "min_file": "", "diff_size": 0}}
      platform_name = max_platform["platform"]
      diff_size_info["max_version"] = max_size_info["version"]
      diff_size_info["min_version"] = min_size_info["version"]
      diff_size_info["platform"] = platform_name
      max_size = max_platform["size"]
      min_size = None
      for min_platform in min_platform_size:
        if min_platform["platform"] == platform_name:
          min_size = min_platform["size"]
          break

      # 小版本目录缺少同名平台时无对照 size，只保留平台行、不做差分
      if min_size is None or max_size is None:
        diff_size_infos.append(diff_size_info)
        continue

      if max_size["upk_size"]["file"] != "" and min_size["upk_size"]["file"] != "" and max_size["upk_size"]["size"] != -1 and min_size["upk_size"]["size"] != -1:
        diff_size_info["upk_diff_info"]["max_file"] = max_size["upk_size"]["file"]
        diff_size_info["upk_diff_info"]["min_file"] = min_size["upk_size"]["file"]
        diff_size_info["upk_diff_info"]["diff_size"] = max_size["upk_size"]["size"] - min_size["upk_size"]["size"]
      if max_size["img_size"]["file"] != "" and min_size["img_size"]["file"] != "" and max_size["img_size"]["size"] != -1 and min_size["img_size"]["size"] != -1:
        diff_size_info["img_diff_info"]["max_file"] = max_size["img_size"]["file"]
        diff_size_info["img_diff_info"]["min_file"] = min_size["img_size"]["file"]
        diff_size_info["img_diff_info"]["diff_size"] = max_size["img_size"]["size"] - min_size["img_size"]["size"]
      if max_size["tar_size"]["file"] != "" and min_size["tar_size"]["file"] != "" and max_size["tar_size"]["size"] != -1 and min_size["tar_size"]["size"] != -1:
        diff_size_info["tar_diff_info"]["max_file"] = max_size["tar_size"]["file"]
        diff_size_info["tar_diff_info"]["min_file"] = min_size["tar_size"]["file"]
        diff_size_info["tar_diff_info"]["diff_size"] = max_size["tar_size"]["size"] - min_size["tar_size"]["size"]
      diff_size_infos.append(diff_size_info)
    return diff_size_infos

  @staticmethod
  def get_project_size_info(conn, smb_share_name, smb_repo, entry) -> dict:
    project_size_info = {"repo": entry["repo"], "branch": entry["branch"],
                         "max_info": None, "min_info": None, "diff_info": None}
    if conn is None:
      return project_size_info

    version_dir = os.path.join(smb_repo, entry["base_url"], entry["repo"], entry["branch"], entry["version_main"])
    # info("version_dir: %s" % version_dir)
    if not conn.exists(smb_share_name, version_dir):
      return project_size_info
    folders = conn.ls(smb_share_name, version_dir)
    max_version, min_version = UgProject.__get_max_min_version(folders)
    max_version_size = UgProject.get_project_version_size_info(conn, smb_share_name, smb_repo, entry, max_version)
    min_version_size = UgProject.get_project_version_size_info(conn, smb_share_name, smb_repo, entry, min_version)
    project_size_info["max_info"] = max_version_size
    project_size_info["min_info"] = min_version_size
    project_size_info["plateform_diff"] = UgProject.get_project_diff_size(max_version_size, min_version_size)
    return project_size_info

  def get_project_size(self) -> list[dict]:
    project_size_infos = []
    env = self.__env
    version = self.get_ugreen_project(GS.VERSION)
    info("get_project_size start for [%s] ..." % version)
    build_env = env.get_build_env()
    smb_host = build_env["SMB_HOST"]
    smb_share_name = build_env["SMB_SHARE_NAME"]
    smb_repo = build_env["SMB_REPO"]
    conn = SambaConnection.instance(smb_host)
    deps = self.get_deps()
    for dep in deps:
      entry = UgProject.parse_entry(dep)
      project_size_info = UgProject.get_project_size_info(conn, smb_share_name, smb_repo, entry)
      project_size_infos.append(project_size_info)
    # info("project_size_infos: %s" % project_size_infos)
    return project_size_infos, version

  @staticmethod
  def generate_size_html(tpl: str, version: str, project_size_infos: list[dict], output_file: str = "project_size_report.html") -> str:
    """
    根据 project_size_infos 生成静态 HTML 表格，并保存到 output_file。
    表头包括：
      repo, branch, platform, file, version(max/min),
      size.img_size, size.upk_size, size.tar_size,
      img_diff_size, tar_diff_size, upk_diff_size
    其中 diff_size 列按数值正负着色：
      >0 红色，<0 绿色，=0 黑色。
    对于同一个 repo 和 platform 的两行，diff_size 列会合并显示（使用 rowspan），
    且小版本在第一行，大版本在第二行。
    size 与 diff 列在 HTML 中按 M 展示：1 M = 1024×1024 字节（MiB）。
    """

    bytes_per_m = 1024.0 * 1024.0

    def _bytes_to_m_display(byte_val):
      """将字节数转为表格用 M（MiB）字符串；无效值返回 None 表示显示为 -。"""
      if byte_val is None or byte_val == -1:
        return None
      mib = float(byte_val) / bytes_per_m
      a = abs(mib)
      if a >= 100:
        text = f"{mib:.1f} M"
      elif a >= 1:
        text = f"{mib:.2f} M"
      elif a >= 1e-4:
        text = f"{mib:.4f} M"
      elif mib == 0:
        text = "0 M"
      else:
        text = f"{mib:.6f} M"
      return text

    def _format_size(value):
      text = _bytes_to_m_display(value)
      if text is None:
        return "-"
      return text

    def _format_diff_cell(value):
      if value is None:
        return "-"
      try:
        v = int(value)
      except Exception:
        return html.escape(str(value))
      text = _bytes_to_m_display(v)
      if text is None:
        return "-"
      color = "black"
      if v > 0:
        color = "red"
      elif v < 0:
        color = "green"
      return f'<span style="color:{color}">{html.escape(text)}</span>'

    def _compare_version(v1, v2):
      """比较两个版本号字符串，返回 -1 如果 v1 < v2，0 如果 v1 == v2，1 如果 v1 > v2"""
      try:
        parts1 = [int(x) for x in v1.split('.')]
        parts2 = [int(x) for x in v2.split('.')]
        # 补齐长度
        max_len = max(len(parts1), len(parts2))
        parts1.extend([0] * (max_len - len(parts1)))
        parts2.extend([0] * (max_len - len(parts2)))
        for i in range(max_len):
          if parts1[i] < parts2[i]:
            return -1
          elif parts1[i] > parts2[i]:
            return 1
        return 0
      except Exception:
        # 如果版本号格式不对，按字符串比较
        if v1 < v2:
          return -1
        elif v1 > v2:
          return 1
        return 0

    rows = []
    # 表头：顺序为 size.upk_size(M), size.tar_size(M), upk_diff_size(M), tar_diff_size(M)
    header = (
        "<tr>"
        "<th>repo</th>"
        "<th>branch</th>"
        "<th>platform</th>"
        "<th>file</th>"
        "<th>version</th>"
        "<th>size.upk_size (M)</th>"
        "<th>size.tar_size (M)</th>"
        "<th>upk_diff_size (M)</th>"
        "<th>tar_diff_size (M)</th>"
        "</tr>"
    )
    rows.append(header)

    # 先收集所有行数据，用于计算 rowspan
    all_rows_data = []
    for proj in project_size_infos or []:
      repo = html.escape(str(proj.get("repo", "")))
      branch = html.escape(str(proj.get("branch", "")))

      max_info = proj.get("max_info") or {}
      min_info = proj.get("min_info") or {}
      plateform_diff_list = proj.get("plateform_diff") or []

      max_version = str(max_info.get("version", "") or "")
      min_version = str(min_info.get("version", "") or "")
      max_version_html = html.escape(max_version)
      min_version_html = html.escape(min_version)

      # 将 plateform_diff 组织成按 platform 索引的字典
      diff_by_platform = {}
      for d in plateform_diff_list:
        platform_name = d.get("platform")
        if platform_name:
          diff_by_platform[platform_name] = d

      # 将 min_platforms 组织成按 platform 索引的字典，方便查找
      min_platforms_map = {}
      min_platforms = min_info.get("platform_size") or []
      for p in min_platforms:
        platform_name = p.get("platform", "")
        if platform_name:
          min_platforms_map[platform_name] = p

      # 辅助函数：从新的 size_info 结构中提取文件信息
      def _extract_file_info(size_info, file_type):
        """从 size_info 中提取指定类型的文件信息"""
        if not size_info:
          return "", -1
        type_info = size_info.get(file_type, {})
        file_name = type_info.get("file", "") or ""
        size_value = type_info.get("size", -1)
        return file_name, size_value

      # 遍历 max_platforms，为每个 platform 的每个文件类型生成行
      max_platforms = max_info.get("platform_size") or []
      for p in max_platforms:
        platform_name = p.get("platform", "")
        platform_html = html.escape(str(platform_name))

        max_size = p.get("size") or {}
        min_platform = min_platforms_map.get(platform_name)
        min_size = min_platform.get("size") or {} if min_platform else {}

        # 比较版本号，确定哪个是小版本，哪个是大版本
        version_compare = _compare_version(max_version, min_version)
        if version_compare <= 0:
          small_version = max_version_html
          large_version = min_version_html
          small_size = max_size
          large_size = min_size
        else:
          small_version = min_version_html
          large_version = max_version_html
          small_size = min_size
          large_size = max_size

        # 获取 diff_size 信息（只获取 upk 和 tar，移除 img）
        diff = diff_by_platform.get(platform_name, {}) or {}
        tar_diff_info = diff.get("tar_diff_info", {}) or {}
        upk_diff_info = diff.get("upk_diff_info", {}) or {}

        # 为每个文件类型生成行（如果大小不为 -1，只处理 upk 和 tar）
        # 按照文件类型分组，相同文件类型的文件相邻展示
        file_types = [
            ("upk_size", upk_diff_info),
            ("tar_size", tar_diff_info),
        ]

        # 对于每个文件类型，先处理小版本，再处理大版本，使相同文件类型相邻
        for file_type, diff_info in file_types:
          # 先处理小版本的文件
          small_file, small_size_val = _extract_file_info(small_size, file_type)
          if small_size_val != -1 and small_file:
            # 小版本有该文件类型，生成一行
            all_rows_data.append({
                "repo": repo,
                "branch": branch,
                "platform": platform_html,
                "file": html.escape(small_file),
                "version": small_version,
                "file_type": file_type,
                "upk_size": _format_size(small_size_val) if file_type == "upk_size" else "-",
                "tar_size": _format_size(small_size_val) if file_type == "tar_size" else "-",
                "upk_diff": _format_diff_cell(diff_info.get("diff_size")) if file_type == "upk_size" else "-",
                "tar_diff": _format_diff_cell(diff_info.get("diff_size")) if file_type == "tar_size" else "-",
            })

          # 再处理大版本的文件（相同文件类型）
          large_file, large_size_val = _extract_file_info(large_size, file_type)
          if large_size_val != -1 and large_file:
            # 大版本有该文件类型，生成一行（不显示 diff）
            all_rows_data.append({
                "repo": repo,
                "branch": branch,
                "platform": platform_html,
                "file": html.escape(large_file),
                "version": large_version,
                "file_type": file_type,
                "upk_size": _format_size(large_size_val) if file_type == "upk_size" else "-",
                "tar_size": _format_size(large_size_val) if file_type == "tar_size" else "-",
                "upk_diff": "-",  # 大版本行不显示 diff
                "tar_diff": "-",
            })

    def _contiguous_block_len(rows_list, start_idx, key_tuple_fn):
      """
      从 start_idx 起连续相同 key 的行数（用于 rowspan）。
      必须用连续块长度：同一 repo 在 deps 中出现多次时，全局计数会导致 rowspan 跨段错位。
      """
      if start_idx >= len(rows_list):
        return 0
      key = key_tuple_fn(rows_list[start_idx])
      count = 0
      for idx in range(start_idx, len(rows_list)):
        if key_tuple_fn(rows_list[idx]) != key:
          break
        count += 1
      return count

    # 生成 HTML 行，合并相同 repo、(repo, branch) 和连续相同 (repo, branch, platform) 的单元格
    current_repo = None
    current_branch = None
    current_platform = None

    for i, row_data in enumerate(all_rows_data):
      repo = row_data["repo"]
      branch = row_data["branch"]
      platform = row_data["platform"]

      # 判断是否需要显示 repo 列（只在 repo 改变时显示）
      show_repo = (repo != current_repo)
      if show_repo:
        current_repo = repo
        current_branch = None  # repo 改变时，重置 branch，确保 branch 也会显示
        current_platform = None  # repo 改变时，重置 platform

      # 判断是否需要显示 branch 列（只在 (repo, branch) 改变时显示）
      show_branch = (branch != current_branch or repo != current_repo)
      if show_branch:
        current_branch = branch
        current_platform = None  # branch 改变时，重置 platform

      # 判断是否需要显示 platform 列（只在 (repo, branch, platform) 改变时显示）
      show_platform = (platform != current_platform or branch != current_branch or repo != current_repo)
      if show_platform:
        current_platform = platform

      # 构建行 HTML
      row_parts = ["<tr>"]

      # repo 列：只在第一次出现时显示，并设置 rowspan（仅本连续块行数）
      if show_repo:
        repo_rowspan = _contiguous_block_len(all_rows_data, i, lambda r: r["repo"])
        row_parts.append(f'<td rowspan="{repo_rowspan}">{repo}</td>')

      # branch 列：只在第一次出现时显示，并设置 rowspan
      if show_branch:
        branch_rowspan = _contiguous_block_len(
            all_rows_data, i, lambda r: (r["repo"], r["branch"]))
        row_parts.append(f'<td rowspan="{branch_rowspan}">{branch}</td>')

      # platform 列：只在连续相同 platform 第一次出现时显示，并设置 rowspan
      if show_platform:
        platform_rowspan = _contiguous_block_len(
            all_rows_data, i, lambda r: (r["repo"], r["branch"], r["platform"]))
        row_parts.append(f'<td rowspan="{platform_rowspan}">{platform}</td>')

      row_parts.append(f'<td>{row_data["file"]}</td>')
      row_parts.append(f'<td>{row_data["version"]}</td>')
      # 列顺序：size.upk_size, size.tar_size, upk_diff_size, tar_diff_size
      row_parts.append(f'<td>{row_data["upk_size"]}</td>')
      row_parts.append(f'<td>{row_data["tar_size"]}</td>')
      row_parts.append(f'<td>{row_data["upk_diff"]}</td>')
      row_parts.append(f'<td>{row_data["tar_diff"]}</td>')

      row_parts.append("</tr>")
      rows.append("".join(row_parts))

    body_rows = "\n".join(rows)

    # 使用模板生成最终的 HTML 内容
    final_html_content = tpl.replace("{version}", version).replace("{body_rows}", body_rows)

    # 保存到文件
    write_file_if_changed(output_file, final_html_content)
    return final_html_content
