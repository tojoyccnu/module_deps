
from collections import OrderedDict
from logging import fatal
import os

from ug_common import atoi, dump_json, load_json, read_file, write_file


configs = OrderedDict()
configs["log.show.source"] = OrderedDict()
configs["log.show.source"]["default"] = "0"

configs["log.show.stack"] = OrderedDict()
configs["log.show.stack"]["default"] = "0"


def get_total_configs():
  global configs
  return configs


class Config:
  env = {}

  def __init__(self, env):
    self.env = env
    self.__mapping = {}
    self.__file = os.path.join(env.home, ".ugreen", "ugbt.config.json")
    self.load()

  def __get_log_int(self, key):
    valid_key = "__%s_valid" % (key)
    valid = True
    if valid_key in self.__mapping:
      valid = self.__mapping[valid_key]

    ret = "0"
    if valid and key in self.__mapping:
      ret = self.__mapping[key]
    else:
      ret = get_total_configs()[key]["default"]
    return atoi(ret)

  def get_log_show_source(self):
    return self.__get_log_int("log.show.source")

  def get_log_show_stack(self):
    return self.__get_log_int("log.show.stack")

  def get(self):
    return self.__mapping

  def load(self):
    if os.path.exists(self.__file):
      content = read_file(self.__file)
      self.__mapping = load_json(content)

  def set(self, key, val):
    global configs
    if not key in configs:
      fatal("unregonized config " + key)
    self.__mapping[key] = val

  def set_valid(self, key, valid):
    global configs
    if not key in configs:
      fatal("unregonized config " + key)
    self.__mapping["__" + key + "_valid"] = valid

  def delete(self, key):
    global configs
    if key in self.__mapping:
      del self.__mapping[key]
    key = "__" + key + "_valid"
    if key in self.__mapping:
      del self.__mapping[key]

  def save(self):
    content = dump_json(self.__mapping)
    write_file(self.__file, content)
