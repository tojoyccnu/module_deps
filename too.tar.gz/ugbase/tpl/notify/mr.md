#### <font color=#00BFFF>gitlab merge request</font>
* ${CI_COMMIT_TITLE}
* [latest commit](${CI_PROJECT_URL}/-/commit/${CI_COMMIT_SHA})
* [pipeline](${CI_PIPELINE_URL}) start
