# ugbase 项目背景（PROJECT_CONTEXT）
## 1. 项目概述
**ugbase** 是 Ugreen 的 **基础构建与研发工具集**：以命令行入口 `ugbt`（ugreen base tool）为核心，在容器化（Docker/Podman）环境中提供编译、打包、配置、GitLab 集成、通知、用户/组管理等一系列子命令，支撑本地与 CI 上的统一工作流。
---
## 2. 技术架构
| 类别 | 说明 |
|------|------|
| **语言** | Python 3（主程序与插件）；Bash（入口包装、Docker/脚本、CI 前置检查） |
| **入口** | `ugbt` → 调用 `script/python3` 执行 `_main.py`（要求已通过 `start_docker.sh` 设置 `DOCKER_NAME` 等容器环境） |
| **命令框架** | `lib/ug_cmd_base.py`：`CommandTool` 基类、`getopt` 解析、`plugin/` 下各 `*_tool.py` 动态加载 |
| **公共能力** | `lib/ug_common.py`（日志、进程、JSON/YAML、子进程等）；`lib/ug_utils.py`、`lib/ug_build_platform.py`、`lib/ug_config.py` 等与工程/平台构建相关 |
| **配置** | `conf/build_env.yaml`（如 `LOCAL_REPO`、SMB 相关）；`conf/build_vars.yaml`（构建类型、CPU 架构、内核、产品系列等枚举）；用户可选 `~/.ugreen/ugbt.config.json`（如 `log.show.source`） |
| **容器** | README 要求 **Linux Debian + Podman**；`start_docker.sh` / `docker_run_cmd.sh` 启动并在容器中执行命令 |
| **测试** | 使用`pytest`框架, 用xdist插件, 不使用`unittest`框架, 测试时优先使用ugbt命令行方式测试plugin下的功能 |
| **原则** | python代码不要随意引入新的pip，如果必须引入请询问; 优先使用ug_common里的日志函数来记录日志info, debug等，不要直接使用logging模块的日志，异常处理优先使用fatal直接exit的方式，尽量不使用异常，业务用多进程方式叠起来，每个进程尽量做到失败就直接exit; class里非外部使用的代码优先private🌹加__前缀，其次procted，加_前缀; 不要随意使用正则或者日志内容反拆去做业务，这可能导致不稳定和性能问题，必须如此实现的时候请询问确认; 如果返回值不被使用就别return; plugin下的tool不要互相import, 需要共享的业务函数写到lib下 |
| **ug_common** | 优先使用ug_common函数load_file,write_file,load_yaml_f,load_yaml,dump_yaml,load_json,load_json_f,dump_json,run,runex,env_is_true,parallel_run,md5 |
| **plugin代码** | plugin下的代码，写在class Tool里，全局变量作为类的成员变量，不要做全局函数和全局变量; plugin Tool请用self.env来保存全局变量，并且不要为env里的成员声明别名，请直接引用 |
| **ugreen_project** | 处理ugreen_project.yaml时引入ug_utils.py的UgProject；常量请使用ut_utils.GS; ugreen_project.yaml的依赖定义说明，例子`devtools/ugtools@release_v2[buildtools](ugtools) 1.1.0.28`，其中`devtools/ugtools`是name, `release_v2`是branch, 方括号里的buildtools是关键字，说明这是个build工具，目的是忽略它的依赖冲突，用圆括号括起来的ugtools是别名，1.1.0.28是版本，必须4个数字，其中第4个数字叫build_number; ugreen_project.yaml的v2格式会去掉ugbase关联，去掉dep里的branch和版本，去掉自己的版本 |
| **优化方向** | 以代码行数少为目标，不要写三行以下的函数，这种函数属于抽象冗余; 没事别考虑fallback, 尽量信任上游输入，保持一错就挂在第一现场的脆弱性; command返回成功与否，通过return code而不要看stdout或者stderr的输出内容; 不要考虑对旧代码的少侵入，而应该重视代码整体是否抽象良好、冗余逻辑少; 尽量不要使用python代码做文件内容处理，包括计算md5，读写文件内容等，能使用lilinux工具命令的时候尽量使用命令，这是为性能考|
| **其他** | 默认branch用master，不要用main; 解析xml优先使用xmltodict; 检查并删除相关.py源码里没有被引用的import; 不要随便在/tmp, /run下留下临时文件，默认临时文件目录采用project目录下的ugreen_build目录 |
---
## 3. 目录结构
| 路径 | 职责 |
|------|------|
| `_main.py` | 程序入口：初始化日志选项、`ug_cmd_base.run_tool` 调度插件 |
| `ugbt` | Bash 入口，转调 `script/python3` + `_main.py` |
| `lib/` | `ug_cmd_base`（命令注册与解析）、`ug_common`、`ug_utils`、`ug_build_platform`、`ug_config` 等 |
| `plugin/` | 各子命令，如 `build_tool`（`ugbt build`）、`config_tool`、`yaml_tool`、`gitlab_tool`、`notify_tool`、`user_tool`、`pack_tool`、`test_tool` 等；约定为 `class Tool(CommandTool)` 且 `cmd` 与文件名对应 |
| `conf/` | 构建环境变量与构建维度定义（YAML） |
| `dev/` | 研发侧 YAML（用户、项目、分组、钉钉等，由相关子命令消费） |
| `tpl/` | Makefile、GitLab CI、通知等模板（`.in` / `.yaml`） |
| `bin/`、`script/` | 环境准备、安装、UPK、Python 包装脚本等 |
| `jenkins/` | Jenkins 启停与初始化脚本 |
| `benchmark/` | 基准/数据库相关脚本与说明 |
| `public/` | 如升级脚本等公共资源 |
| `res/` | 辅助资源（如 prompt、sshd 脚本） |
---
## 4 重要源码分类
| 路径 | 职责 |
|------|------|
| `lib/ug_common.py` | 通用python共享库 |
| `lib/ug_util.py` | 通用业务共享库 |
5. 开发规范
Python 风格：以 .flake8 为准——2 空格缩进、最大行宽 120、忽略 E402（import 不在文件顶部等场景）。
命名与插件约定：子命令类名为 Tool，继承 CommandTool；cmd 字符串与文件名（如 build_tool.py → build）一致，便于 grep 发现与动态加载。

