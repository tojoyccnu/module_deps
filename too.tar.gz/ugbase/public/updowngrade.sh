#!/bin/bash

# =============================================================================
# updowngrade.sh - 固件镜像安装/升级/降级脚本 - 20260205-weldon.chen
# =============================================================================
#
# 简介：
#   本脚本用于固件 1.12.0 及以后版本的系统后台升级或降级。脚本会从指定
#   的固件镜像文件中解压 ugpt、ugospro-upgrade 等组件，并调用升级程序完成
#   安装。
#
# 使用方法：
#   ./updowngrade.sh <镜像文件路径>
#
# 参数说明：
#   <镜像文件路径>  固件镜像文件（.img），可为绝对路径或相对路径。
#                   相对路径时相对于当前工作目录解析。
#
# 示例：
#   # 使用绝对路径
#   ./updowngrade.sh /path/to/release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img
#   ./updowngrade.sh ${PWD}/release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img
#
#   # 使用相对路径（相对于当前目录）
#   ./updowngrade.sh ./images/release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img
#   ./updowngrade.sh ../release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img
#
# 选项：
#   -h, --help  显示本帮助信息
#
# =============================================================================

# 打印每条执行的命令，便于调试
set -x
# -e: 命令失败时立即退出; -u: 使用未定义变量时报错; -o pipefail: 管道中任一命令失败则整体失败
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)

show_usage() {
    echo "用法: $0 <镜像文件路径>"
    echo ""
    echo "从固件镜像安装/升级/降级系统（固件 1.12.0+）。"
    echo ""
    echo "参数："
    echo "  <镜像文件路径>  固件 .img 文件，支持绝对路径或相对路径"
    echo ""
    echo "示例："
    echo "  $0 ${PWD}/release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img"
    echo "  $0 ./release_20260325-firmware_image-1.14.0.16-intel_amd64_6.12.30+.img"
    echo ""
    echo "选项："
    echo "  -h, --help  显示此帮助"
}

case "$1" in
    -h|--help)
        show_usage
        exit 0
        ;;
esac

if [ -z "$1" ]; then
    echo "错误: 请指定镜像文件路径"
    echo ""
    show_usage
    exit 1
fi

# 路径匹配：若非绝对路径则拼接为绝对路径（相对当前工作目录）
IMG_PATH=`readlink -f $1`

# 判断文件是否存在
if [ ! -f "$IMG_PATH" ]; then
    echo "错误: 文件不存在: $IMG_PATH"
    exit 2
fi

echo "当前工作目录: $SCRIPT_DIR"
echo "固件镜像文件路径: $IMG_PATH"

# 清理可能存在的旧文件
if [ -f "$SCRIPT_DIR/ugpt" ]; then
    echo "删除已存在的 $SCRIPT_DIR/ugpt 文件..."
    rm -f $SCRIPT_DIR/ugpt
fi

if [ -f "$SCRIPT_DIR/ugospro-upgrade" ]; then
    echo "删除已存在的 $SCRIPT_DIR/ugospro-upgrade 文件..."
    rm -f $SCRIPT_DIR/ugospro-upgrade
fi

# 从镜像中解压所需文件（归档内成员名为 ./ugpt、./ugospro-upgrade，用 -C 指定解压目录）
tar -xvf "$IMG_PATH" -C "$SCRIPT_DIR" ./ugpt ./ugospro-upgrade

# 无论脚本如何退出（成功、失败或 Ctrl+C）都清理解压的临时文件
cleanup_temp() {
    if [ -f "$SCRIPT_DIR/ugpt" ] || [ -f "$SCRIPT_DIR/ugospro-upgrade" ]; then
        echo "清理解压的临时文件..."
        rm -f "$SCRIPT_DIR/ugpt" "$SCRIPT_DIR/ugospro-upgrade"
    fi
}
trap cleanup_temp EXIT

# 检查解压文件是否存在，都存在则执行升级程序
if [ -f "$SCRIPT_DIR/ugpt" ] && [ -f "$SCRIPT_DIR/ugospro-upgrade" ]; then
    $SCRIPT_DIR/ugospro-upgrade "$IMG_PATH"
else
    echo "错误: 解压文件不完整"
    [ ! -f "$SCRIPT_DIR/ugpt" ] && echo "  - ugpt 不存在"
    [ ! -f "$SCRIPT_DIR/ugospro-upgrade" ] && echo "  - ugospro-upgrade 不存在"
    exit 1
fi

