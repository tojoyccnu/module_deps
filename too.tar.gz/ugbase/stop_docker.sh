#!/bin/bash

set -e
set -o pipefail

show_help() {
  cat << EOF
用法: $0

说明:
  列出 podman ps 中正在运行的容器，并选择性停止。
EOF
}

if [[ "$1" == "-h" ]] || [[ "$1" == "--help" ]]; then
  show_help
  exit 0
fi

if ! command -v podman >/dev/null 2>&1; then
  echo "podman not found" >&2
  exit 1
fi

containers=()
while IFS= read -r line; do
  containers+=("$line")
done < <(podman ps --format '{{.ID}}	{{.Names}}	{{.Image}}	{{.Status}}')

container_count=${#containers[@]}

if [ "$container_count" -eq 0 ]; then
  echo "所有容器都已经停止"
  exit 0
fi

stop_container() {
  local line=$1
  local container_id
  local container_name
  local container_image
  local container_status
  IFS=$'\t' read -r container_id container_name container_image container_status <<< "$line"
  echo "stop container: $container_name ($container_id)"
  podman stop "$container_id"
}

if [ "$container_count" -eq 1 ]; then
  stop_container "${containers[0]}"
  exit 0
fi

echo "运行中的容器:"
index=1
for line in "${containers[@]}"; do
  echo "  $index) $line"
  index=$((index + 1))
done

echo ""
if ! read -r -p "请选择要停止的容器编号，输入 a 停止全部，输入 q 取消: " choice; then
  echo "取消停止容器"
  exit 0
fi

if [[ "$choice" == "q" ]] || [[ "$choice" == "Q" ]]; then
  echo "取消停止容器"
  exit 0
fi

if [[ "$choice" == "a" ]] || [[ "$choice" == "A" ]]; then
  for line in "${containers[@]}"; do
    stop_container "$line"
  done
  exit 0
fi

if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
  echo "无效选择: $choice" >&2
  exit 1
fi

if [ "$choice" -lt 1 ] || [ "$choice" -gt "$container_count" ]; then
  echo "无效选择: $choice" >&2
  exit 1
fi

stop_container "${containers[$((choice - 1))]}"
